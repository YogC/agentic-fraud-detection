# 🛡️ SIU Fraud Review Dashboard

A standalone Streamlit-based UI for reviewing fraud detection decisions and providing feedback to improve the AI agent.

> **Note:** This is an independent dashboard application that connects to the Fraud Detection Backend API.

---

## 🚀 Quick Start

### **Prerequisites:**
- Python 3.8+
- Backend API running at http://localhost:8000 (or configured URL)

### **Installation:**

```powershell
# Navigate to dashboard directory
cd "c:\Yogesh\GenAI\Fraud Detection\SIU-Fraud-Dashboard"

# Install dependencies
pip install -r requirements.txt

# Configure environment (copy and edit)
copy .env.example .env
```

### **Configuration:**

Edit `.env` file:
```env
API_BASE_URL=http://localhost:8000/api/v1
APP_TITLE=SIU Fraud Review Dashboard
```

### **Run the Dashboard:**

```powershell
streamlit run app.py
```

The dashboard will open automatically at `http://localhost:8501`

---

## 📋 Features

### **1. Pending Queue** 📋
- View all cases pending SIU review
- Filter by event type, status, or reviewer
- Expandable case cards with full details
- Submit reviews with feedback

### **2. Case Details View** 🔍
- **Transaction/Event Info:** Full event data
- **Agent Findings:** Detection results from all agents
- **LLM Reasoning:** AI decision explanation
- **Risk Indicators:** Confidence scores and risk levels
- **Submit Feedback:** Approve/Deny with outcome selection

### **3. Analytics Dashboard** 📊
- Total decisions and pending reviews
- Decision distribution (BLOCK/WARN/ALLOW)
- Status breakdown
- Interactive charts with Plotly

### **4. Learning Insights** 🎓
- Agent accuracy metrics
- Average reward scores
- Correct vs. incorrect decisions
- High-value learning cases
- Recommendations for improvement

---

## 🎯 User Workflow

### **Step 1: Login**
1. Enter your Reviewer ID in sidebar
2. Dashboard loads pending cases

### **Step 2: Review Cases**
1. Browse pending queue
2. Click to expand case details
3. Review:
   - Event data
   - Detection results
   - LLM reasoning
   - Risk indicators

### **Step 3: Submit Feedback**
1. Select action: APPROVE, DENY, ESCALATE, REQUEST_INFO
2. Select actual outcome: CONFIRMED_FRAUD, FALSE_POSITIVE, etc.
3. Enter detailed review notes
4. Click "Submit Review"

### **Step 4: Monitor Learning**
1. Go to "Learning Insights" tab
2. Check agent accuracy
3. Review high-value cases
4. Monitor improvement trends

---

## 🔌 API Integration

The dashboard connects to your FastAPI backend:

| Endpoint | Purpose |
|----------|---------|
| `GET /decisions/pending` | Load pending reviews |
| `GET /decisions/{id}` | Get case details |
| `POST /decisions/review` | Submit review feedback |
| `GET /decisions/statistics/summary` | Load analytics |
| `GET /decisions/learning/insights` | Load learning metrics |

---

## 🎨 UI Components

### **Sidebar:**
- Reviewer ID input
- Filter controls
- Results limit
- Refresh button

### **Main Tabs:**
- **Pending Queue:** Case review interface
- **Analytics:** Dashboard metrics
- **Learning Insights:** AI improvement tracking

### **Case Card:**
- Event details
- Detection results
- LLM analysis
- Review form

---

## 🚢 Deployment Options

### **Option 1: Local Development**
```powershell
streamlit run app.py
```

### **Option 2: Network Access**
```powershell
streamlit run app.py --server.address=0.0.0.0 --server.port=8501
```

### **Option 3: Production (with auth)**
```powershell
# Install streamlit-authenticator
pip install streamlit-authenticator

# Run with authentication
streamlit run app.py
```

### **Option 4: Docker**
```dockerfile
FROM python:3.10-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

EXPOSE 8501

CMD ["streamlit", "run", "app.py", "--server.address=0.0.0.0"]
```

### **Option 5: Cloud Deployment**
- **Streamlit Cloud:** Push to GitHub, connect repo
- **AWS ECS:** Deploy as container
- **Azure Container Apps:** Deploy as container
- **Google Cloud Run:** Deploy as container

See `DEPLOYMENT.md` for detailed deployment instructions.

---

## 🔧 Configuration

### **Environment Variables:**

```env
# Backend API
API_BASE_URL=http://localhost:8000/api/v1

# App Settings
APP_TITLE=SIU Fraud Review Dashboard
REFRESH_INTERVAL=30

# Optional: Authentication
AUTH_ENABLED=false
AUTH_USERNAME=admin
AUTH_PASSWORD=secret
```

### **Streamlit Config:**

Create `.streamlit/config.toml`:

```toml
[theme]
primaryColor = "#1f77b4"
backgroundColor = "#ffffff"
secondaryBackgroundColor = "#f0f2f6"
textColor = "#262730"
font = "sans serif"

[server]
port = 8501
headless = true
enableCORS = false
```

---

## 📊 Project Structure

```
SIU-Fraud-Dashboard/
├── app.py                    # Main Streamlit application
├── api_client.py            # Backend API client
├── requirements.txt         # Python dependencies
├── .env                     # Configuration (create from .env.example)
├── .env.example            # Configuration template
├── README.md               # This file
├── QUICKSTART.md           # 3-minute setup guide
├── DEPLOYMENT.md           # Deployment options
├── deploy.ps1              # PowerShell deployment script
├── deploy.bat              # Batch deployment script
├── Dockerfile              # Docker containerization
└── docker-compose.yml      # Full stack deployment
```

---

## 🧪 Testing

```powershell
# Test API connectivity
python -c "from api_client import APIClient; print('✅ Connected' if APIClient().health_check() else '❌ Failed')"

# Run dashboard in dev mode
streamlit run app.py --server.runOnSave=true
```

---

## 🐛 Troubleshooting

### **Issue: "Backend Offline"**
```
Solution: 
1. Make sure FastAPI server is running
2. Check API_BASE_URL in .env
3. Verify port 8000 is accessible
```

### **Issue: "Connection Refused"**
```
Solution:
1. Check firewall settings
2. Verify network connectivity
3. Test API endpoint: curl http://localhost:8000/docs
```

### **Issue: "Module not found"**
```
Solution:
pip install -r requirements.txt
```

---

## 📈 Usage Tips

1. **Always provide actual outcome** when submitting reviews (enables learning)
2. **Write detailed notes** (helps agent understand context)
3. **Check learning insights regularly** (monitor improvement)
4. **Review high-value cases** (contribute to agent training)
5. **Use filters** to focus on specific fraud types

---

## 🔮 Future Enhancements

- [ ] User authentication with roles
- [ ] Real-time notifications for new cases
- [ ] Bulk review operations
- [ ] Export reports to PDF/Excel
- [ ] Advanced search and filtering
- [ ] Case similarity detection
- [ ] Reviewer performance metrics
- [ ] Mobile-responsive design
- [ ] Dark mode theme
- [ ] Multi-language support

---

## 📞 Support

**Backend API:** http://localhost:8000/docs  
**Dashboard:** http://localhost:8501  
**Documentation:** See backend project's `LEARNING_SYSTEM.md`

---

## 📄 License

This is part of the Fraud Detection System project.

---

**Built with ❤️ using Streamlit**
