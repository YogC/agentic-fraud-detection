"""
API Client for Backend Communication
Handles all HTTP requests to the FastAPI backend
"""
import requests
from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)


class APIClient:
    """Client for interacting with fraud detection backend API"""
    
    def __init__(self, base_url: str = "http://localhost:8000/api/v1"):
        """
        Initialize API client
        
        Args:
            base_url: Base URL of the API
        """
        self.base_url = base_url.rstrip('/')
        self.session = requests.Session()
    
    def _handle_response(self, response: requests.Response) -> Dict:
        """Handle API response and errors"""
        try:
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            logger.error(f"HTTP error: {e}")
            raise Exception(f"API Error: {response.status_code} - {response.text}")
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error: {e}")
            raise Exception(f"Connection Error: {str(e)}")
    
    # ========== Decision Endpoints ==========
    
    def get_all_decisions(self, limit: int = 100) -> List[Dict]:
        """Get all decisions"""
        url = f"{self.base_url}/decisions/?limit={limit}"
        response = self.session.get(url)
        return self._handle_response(response)
    
    def get_pending_reviews(self, limit: int = 50) -> List[Dict]:
        """Get pending SIU reviews"""
        url = f"{self.base_url}/decisions/pending?limit={limit}"
        response = self.session.get(url)
        result = self._handle_response(response)
        # Extract cases from the response dict
        return result.get('cases', []) if isinstance(result, dict) else result
    
    def get_decision_by_id(self, event_id: str) -> Dict:
        """Get specific decision by ID"""
        url = f"{self.base_url}/decisions/{event_id}"
        response = self.session.get(url)
        return self._handle_response(response)
    
    def get_decisions_by_event_type(self, event_type: str, limit: int = 100) -> List[Dict]:
        """Get decisions by event type"""
        url = f"{self.base_url}/decisions/event-types/{event_type}?limit={limit}"
        response = self.session.get(url)
        return self._handle_response(response)
    
    def get_decisions_by_status(self, status: str, limit: int = 100) -> List[Dict]:
        """Get decisions by status"""
        url = f"{self.base_url}/decisions/status/{status}?limit={limit}"
        response = self.session.get(url)
        return self._handle_response(response)
    
    def get_decisions_by_reviewer(self, reviewer_id: str, limit: int = 50) -> List[Dict]:
        """Get decisions by reviewer"""
        url = f"{self.base_url}/decisions/reviewer/{reviewer_id}?limit={limit}"
        response = self.session.get(url)
        return self._handle_response(response)
    
    # ========== Review Submission ==========
    
    def submit_review(
        self,
        event_id: str,
        timestamp: int,
        reviewer_id: str,
        reviewer_action: str,
        reviewer_notes: str,
        actual_outcome: Optional[str] = None,
        add_to_learning_queue: bool = False
    ) -> Dict:
        """
        Submit SIU review
        
        Args:
            event_id: Event identifier
            timestamp: Event timestamp
            reviewer_id: Reviewer username
            reviewer_action: APPROVE, DENY, ESCALATE, REQUEST_INFO
            reviewer_notes: Review notes
            actual_outcome: CONFIRMED_FRAUD, FALSE_POSITIVE, LEGITIMATE, INCONCLUSIVE
            add_to_learning_queue: Whether to add this case to the learning queue
        
        Returns:
            Updated decision
        """
        url = f"{self.base_url}/decisions/review"
        
        payload = {
            "event_id": event_id,
            "timestamp": timestamp,
            "reviewer_id": reviewer_id,
            "reviewer_action": reviewer_action,
            "reviewer_notes": reviewer_notes,
            "add_to_learning_queue": add_to_learning_queue
        }
        
        if actual_outcome:
            payload["actual_outcome"] = actual_outcome
        
        response = self.session.post(url, json=payload)
        return self._handle_response(response)
    
    # ========== Statistics & Analytics ==========
    
    def get_statistics(self) -> Dict:
        """Get dashboard statistics"""
        url = f"{self.base_url}/decisions/statistics/summary"
        response = self.session.get(url)
        return self._handle_response(response)
    
    # ========== Health Check ==========
    
    def health_check(self) -> bool:
        """Check if API is accessible"""
        try:
            response = self.session.get(f"{self.base_url.rsplit('/api/v1', 1)[0]}/docs", timeout=5)
            return response.status_code == 200
        except:
            return False

    # ========== Prompt Management ==========
    
    def list_prompts(self, event_type: Optional[str] = None, status: str = "ACTIVE", limit: int = 100) -> List[Dict]:
        """List all prompts with optional filtering"""
        params = {"status": status, "limit": limit}
        if event_type:
            params["event_type"] = event_type
        url = f"{self.base_url}/prompts/"
        response = self.session.get(url, params=params)
        return self._handle_response(response)
    
    def get_active_prompt(self, event_type: str, force_refresh: bool = False) -> Dict:
        """
        Get currently active prompt for event type
        
        Args:
            event_type: The event type (PAYMENT_FRAUD, PII_ACCESS, DATA_MODIFICATION)
            force_refresh: If True, adds cache-busting parameter to bypass backend cache
        """
        url = f"{self.base_url}/prompts/event-types/{event_type}/active"
        params = {}
        if force_refresh:
            import time
            params['_t'] = int(time.time())  # Cache buster
        response = self.session.get(url, params=params)
        return self._handle_response(response)
    
    def list_prompt_versions(self, event_type: str, limit: int = 50) -> List[Dict]:
        """List all versions of prompts for event type"""
        url = f"{self.base_url}/prompts/event-types/{event_type}/versions"
        response = self.session.get(url, params={"limit": limit})
        return self._handle_response(response)
    
    def get_prompt_by_id(self, prompt_id: str) -> Dict:
        """Get specific prompt by ID"""
        url = f"{self.base_url}/prompts/{prompt_id}"
        response = self.session.get(url)
        return self._handle_response(response)
    
    def create_prompt(
        self,
        event_type: str,
        template: str,
        version: str,
        description: str = "",
        created_by: str = "admin",
        status: str = "DRAFT"
    ) -> Dict:
        """Create a new prompt"""
        url = f"{self.base_url}/prompts/"
        payload = {
            "event_type": event_type,
            "template": template,
            "version": version,
            "description": description,
            "created_by": created_by,
            "status": status
        }
        response = self.session.post(url, json=payload)
        return self._handle_response(response)
    
    def update_prompt(
        self,
        prompt_id: str,
        template: str,
        description: str = "",
        updated_by: str = "admin"
    ) -> Dict:
        """Update an existing prompt"""
        url = f"{self.base_url}/prompts/{prompt_id}"
        payload = {
            "template": template,
            "description": description,
            "updated_by": updated_by
        }
        response = self.session.put(url, json=payload)
        return self._handle_response(response)
    
    def update_prompt_examples(
        self,
        prompt_id: str,
        few_shot_examples: List[Dict],
        updated_by: str = "admin"
    ) -> Dict:
        """
        Update few-shot examples in a prompt.
        This creates a new version of the prompt with updated examples.
        
        Args:
            prompt_id: Prompt identifier
            few_shot_examples: List of few-shot examples
            updated_by: User making the update
        
        Returns:
            Updated prompt version
        """
        url = f"{self.base_url}/prompts/{prompt_id}/examples"
        payload = {
            "few_shot_examples": few_shot_examples,
            "updated_by": updated_by
        }
        response = self.session.put(url, json=payload)
        return self._handle_response(response)
    
    def activate_prompt(self, prompt_id: str, activated_by: str = "admin") -> Dict:
        """Activate a prompt version"""
        url = f"{self.base_url}/prompts/{prompt_id}/activate"
        response = self.session.post(url, params={"activated_by": activated_by})
        return self._handle_response(response)
    
    def archive_prompt(self, prompt_id: str, archived_by: str = "admin") -> Dict:
        """Archive a prompt"""
        url = f"{self.base_url}/prompts/{prompt_id}/archive"
        response = self.session.post(url, params={"archived_by": archived_by})
        return self._handle_response(response)
    
    def compare_prompts(self, prompt_id_1: str, prompt_id_2: str) -> Dict:
        """Compare two prompt versions"""
        url = f"{self.base_url}/prompts/compare"
        response = self.session.post(url, params={"prompt_id_1": prompt_id_1, "prompt_id_2": prompt_id_2})
        return self._handle_response(response)
    
    def get_prompt_audit_trail(self, event_type: str, limit: int = 100) -> List[Dict]:
        """Get audit trail for prompt changes"""
        url = f"{self.base_url}/prompts/audit/{event_type}"
        response = self.session.get(url, params={"limit": limit})
        return self._handle_response(response)
    
    def get_prompt_statistics(self) -> Dict:
        """Get prompt management statistics"""
        url = f"{self.base_url}/prompts/statistics/summary"
        response = self.session.get(url)
        return self._handle_response(response)
    
    def add_example_to_prompt(
        self,
        event_type: str,
        example: Dict,
        created_by: str = "learning_queue"
    ) -> Dict:
        """
        Add a few-shot example to the active prompt for an event type.
        Creates a new DRAFT version with the example appended.
        
        This is used by the Learning Queue to convert SIU feedback into
        new few-shot examples for prompts.
        
        Args:
            event_type: Event type (PAYMENT_FRAUD, PII_ACCESS, DATA_MODIFICATION)
            example: Few-shot example to add (dict with scenario, decision, reasoning, etc.)
            created_by: Creator identifier (defaults to "learning_queue")
        
        Returns:
            New DRAFT prompt version with the example added
        """
        url = f"{self.base_url}/prompts/event-types/{event_type}/add-example"
        response = self.session.post(
            url,
            json=example,
            params={"created_by": created_by}
        )
        return self._handle_response(response)
    
    def update_prompt_from_learning_queue(
        self,
        event_type: str,
        template: str = None,
        example: Dict = None,
        description: str = None,
        created_by: str = "learning_queue",
        queue_id: str = None
    ) -> Dict:
        """
        Update prompt from Learning Queue - can update template and/or add examples.
        Creates a new DRAFT version with the changes.
        
        This allows Learning Queue to:
        1. Update just the prompt template (system prompt)
        2. Add just a new few-shot example
        3. Update both template and add an example
        
        Args:
            event_type: Event type (PAYMENT_FRAUD, PII_ACCESS, DATA_MODIFICATION)
            template: New system prompt template (optional)
            example: Few-shot example to add (optional)
            description: Change description (optional)
            created_by: Creator identifier (defaults to "learning_queue")
            queue_id: Learning queue item ID (optional, for tracking)
        
        Returns:
            New DRAFT prompt version with the changes applied
        """
        url = f"{self.base_url}/prompts/event-types/{event_type}/update-from-learning"
        
        payload = {}
        if template:
            payload['template'] = template
        if example:
            payload['example'] = example
        if description:
            payload['description'] = description
        if queue_id:
            payload['queue_id'] = queue_id
        
        response = self.session.post(
            url,
            json=payload,
            params={"created_by": created_by}
        )
        return self._handle_response(response)
    
    # ========== Learning Queue ==========
    
    def get_learning_queue(
        self,
        status: Optional[str] = None,
        event_type: Optional[str] = None,
        priority: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict]:
        """Get learning queue items with filtering"""
        params = {"limit": limit}
        if status:
            params["status"] = status
        if event_type:
            params["event_type"] = event_type
        if priority:
            params["priority"] = priority
        url = f"{self.base_url}/learning/queue"
        response = self.session.get(url, params=params)
        result = self._handle_response(response)
        # Extract items from the response dict
        return result.get('items', []) if isinstance(result, dict) else result
    
    def get_learning_item(self, queue_id: str) -> Dict:
        """Get specific learning queue item"""
        url = f"{self.base_url}/learning/queue/{queue_id}"
        response = self.session.get(url)
        return self._handle_response(response)
    
    def add_to_learning_queue(
        self,
        event_id: str,
        event_type: str,
        siu_feedback: str,
        actual_outcome: str,
        detection_accuracy: str,
        reviewer_id: str,
        suggested_improvement: Optional[str] = None
    ) -> Dict:
        """Add item to learning queue"""
        url = f"{self.base_url}/learning/queue"
        payload = {
            "event_id": event_id,
            "event_type": event_type,
            "siu_feedback": siu_feedback,
            "actual_outcome": actual_outcome,
            "detection_accuracy": detection_accuracy,
            "reviewer_id": reviewer_id
        }
        if suggested_improvement:
            payload["suggested_improvement"] = suggested_improvement
        response = self.session.post(url, json=payload)
        return self._handle_response(response)
    
    def review_learning_item(
        self,
        queue_id: str,
        reviewed_by: str,
        status: str,
        review_notes: str
    ) -> Dict:
        """Review and process learning queue item"""
        url = f"{self.base_url}/learning/queue/{queue_id}/review"
        payload = {
            "reviewed_by": reviewed_by,
            "status": status,
            "review_notes": review_notes
        }
        response = self.session.post(url, json=payload)
        return self._handle_response(response)
    
    def mark_as_implemented(
        self,
        queue_id: str,
        implemented_by: str,
        notes: Optional[str] = None
    ) -> Dict:
        """Mark learning item as implemented"""
        url = f"{self.base_url}/learning/queue/{queue_id}/implement"
        params = {"implemented_by": implemented_by}
        if notes:
            params["notes"] = notes
        response = self.session.post(url, params=params)
        result = self._handle_response(response)
        return result.get("item", result)
    
    def generate_improved_prompt(self, queue_id: str, generated_by: str) -> Dict:
        """Generate improved prompt from learning item"""
        url = f"{self.base_url}/learning/generate-prompt/{queue_id}"
        response = self.session.post(url, params={"generated_by": generated_by})
        return self._handle_response(response)
    
    def get_prompt_impact_analytics(self, event_type: Optional[str] = None) -> Dict:
        """Get prompt learning impact analytics"""
        url = f"{self.base_url}/learning/analytics/impact"
        params = {}
        if event_type:
            params["event_type"] = event_type
        response = self.session.get(url, params=params)
        return self._handle_response(response)
    
    def get_learning_statistics(self) -> Dict:
        """Get learning system statistics"""
        url = f"{self.base_url}/learning/statistics/summary"
        response = self.session.get(url)
        return self._handle_response(response)
    
    def get_learning_insights(self) -> Dict:
        """Get actionable learning insights"""
        url = f"{self.base_url}/learning/insights"
        response = self.session.get(url)
        return self._handle_response(response)
