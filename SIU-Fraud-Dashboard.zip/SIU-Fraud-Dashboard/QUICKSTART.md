# 🚀 Quick Start - SIU Dashboard

## ⚡ Get Started in 3 Minutes

### **Step 1: Start Backend (if not running)**
```powershell
# Open PowerShell Terminal 1
cd "c:\Yogesh\GenAI\Fraud Detection\Fraud-Internal-Detection"
python -m uvicorn app.main:app --reload --port 8000
```

**✅ Verify:** Visit http://localhost:8000/docs

---

### **Step 2: Start Dashboard**
```powershell
# Open PowerShell Terminal 2
cd "c:\Yogesh\GenAI\Fraud Detection\SIU-Fraud-Dashboard"
streamlit run app.py
```

**✅ Dashboard opens at:** http://localhost:8501

---

### **Step 3: Start Reviewing!**

1. **Enter your Reviewer ID** (e.g., `siu_john`)
2. **Browse pending cases** in the queue
3. **Click to expand** case details
4. **Review:**
   - Event data
   - Detection results
   - LLM reasoning
5. **Submit feedback:**
   - Select action (APPROVE/DENY)
   - Choose actual outcome
   - Write detailed notes
   - Click "Submit Review"

---

## 🎯 Dashboard Features

### **📋 Pending Queue Tab:**
- View all pending cases
- Filter by type/status
- Expandable case cards
- Inline review forms

### **📊 Analytics Tab:**
- Decision distribution charts
- Status breakdown
- Key metrics

### **🎓 Learning Insights Tab:**
- Agent accuracy
- Reward scores
- High-value learning cases
- Improvement recommendations

---

## 💡 Pro Tips

1. **Always provide actual outcome** - Enables agent learning!
2. **Write detailed notes** - Helps AI understand context
3. **Check learning insights** - Monitor improvement
4. **Use filters** - Focus on specific fraud types
5. **Refresh regularly** - New cases appear automatically

---

## 🔧 Troubleshooting

**Dashboard shows "Backend Offline"?**
- Make sure FastAPI server is running on port 8000
- Check `.env` file has correct API_BASE_URL

**No cases showing?**
- Run `python insert_sample_data.py` to add test data (in backend directory)
- Or wait for real fraud events to be detected

**Module errors?**
- Run: `pip install -r requirements.txt`

---

## 📚 Full Documentation

- **Complete Guide:** `README.md`
- **Deployment:** `DEPLOYMENT.md`
- **API Docs:** http://localhost:8000/docs
- **Learning System:** Backend project's `LEARNING_SYSTEM.md`

---

**🎉 You're ready to start reviewing fraud cases!**
