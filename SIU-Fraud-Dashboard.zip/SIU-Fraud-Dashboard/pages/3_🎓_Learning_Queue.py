"""
Learning Queue - Simple Prompt Generator
"""
import streamlit as st
import pandas as pd
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from api_client import APIClient

api = APIClient()

st.set_page_config(page_title="Learning Queue", page_icon="🎓", layout="wide")

st.title("🎓 Learning Queue")
st.markdown("**Convert SIU feedback into LLM training examples**")

st.info("💡 Load feedback → Generate training example → Add to Prompt Management")

# Add explanation of reward score (COMMENTED OUT - purely informational, not used by any functionality)
# with st.expander("ℹ️ Understanding Reward Score & Prioritization"):
#     st.markdown("""
#     **Reward Score** is a feedback metric that measures how well the LLM's decision aligned with the actual outcome:
#     - **Positive scores (+50 to +100)**: LLM made the correct decision - high value for reinforcing good patterns
#     - **Negative scores (-50 to -100)**: LLM made an incorrect decision - high value for correcting mistakes
#     - **Higher absolute values** indicate more important learning opportunities
#     
#     Items are automatically prioritized by absolute reward score. The system uses this to identify which cases 
#     provide the most valuable training signal. This is **not** reinforcement learning or model retraining - 
#     it's a prioritization system to help SIU reviewers focus on the most impactful feedback first.
#     """)


# Load button
if st.button("🔄 Load Feedback Items", type="primary"):
    with st.spinner("Loading..."):
        try:
            items = api.get_learning_queue(status="PENDING_REVIEW", limit=100)
            st.session_state['learning_items'] = items
            st.rerun()
        except Exception as e:
            st.error(f"Error loading items: {str(e)}")
            import traceback
            st.code(traceback.format_exc())

# Display items if loaded
if 'learning_items' in st.session_state:
    items = st.session_state['learning_items']
    
    if items and len(items) > 0:
        st.success(f"✅ Found {len(items)} items")
        
        # Show table
        df_data = []
        for item in items:
            # Convert all values to simple types
            # Score column commented out - purely display, not used in functionality
            # score = item.get('reward_score', 0)
            # try:
            #     score = float(score)
            # except:
            #     score = 0
            
            df_data.append({
                "Event": str(item.get('event_id', 'N/A')),
                "LLM": str(item.get('llm_decision', 'N/A')),
                "Actual": str(item.get('actual_outcome', 'N/A')),
                # "Score": score  # COMMENTED OUT - display only, not used in any button/API calls
            })
        
        if df_data:
            df = pd.DataFrame(df_data)
            st.dataframe(df, use_container_width=True)
            
            # Select item
            st.markdown("---")
            selected_idx = st.selectbox(
                "Select item",
                range(len(items)),
                format_func=lambda i: f"{items[i].get('event_id')} | {items[i].get('llm_decision')} → {items[i].get('actual_outcome')}"
            )
            
            item = items[selected_idx]
            
            col1, col2 = st.columns([2, 1])
            
            with col1:
                st.markdown("### 📊 Details")
                st.metric("LLM Decision", str(item.get('llm_decision', 'N/A')))
                st.metric("Actual Outcome", str(item.get('actual_outcome', 'N/A')))
                
                # Display reviewer feedback/notes
                feedback = str(item.get('reviewer_notes', item.get('siu_feedback', 'No feedback')))
                st.markdown("**SIU Feedback:**")
                st.info(feedback)
                
                # Generate example
                if st.button("🤖 Generate Training Data", type="primary", key="gen_btn"):
                    # Also load the current active prompt template
                    try:
                        event_type = item.get('event_type', 'PAYMENT_FRAUD')
                        active_prompt = api.get_active_prompt(event_type)
                        current_template = active_prompt.get('system_prompt', active_prompt.get('template', ''))
                    except:
                        current_template = "You are a fraud detection agent. Analyze transactions for fraud risk."
                    
                    # Determine decision based on actual outcome
                    actual_outcome = str(item.get('actual_outcome', ''))
                    if actual_outcome == 'CONFIRMED_FRAUD':
                        correct_decision = "BLOCK"
                    elif actual_outcome == 'CONFIRMED_LEGITIMATE':
                        correct_decision = "ALLOW"
                    else:
                        correct_decision = "WARN"
                    
                    st.session_state['generated_example'] = {
                        "scenario": str(item.get('scenario_description', 'Payment transaction')),
                        "correct_decision": correct_decision,
                        "reasoning": feedback
                    }
                    st.session_state['current_template'] = current_template
                    st.rerun()
                
                # Show generated example if exists
                if 'generated_example' in st.session_state:
                    st.success("✅ Training data generated!")
                    
                    # Section 1: Prompt Template Editor
                    st.markdown("---")
                    st.markdown("### 📝 Prompt Template")
                    st.markdown("**Edit the system prompt template (optional):**")
                    
                    edited_template = st.text_area(
                        "System Prompt Template",
                        value=st.session_state.get('current_template', ''),
                        height=200,
                        key="edit_template",
                        help="This is the main instruction given to the LLM. Edit if you want to update it."
                    )
                    
                    template_changed = edited_template != st.session_state.get('current_template', '')
                    if template_changed:
                        st.info("ℹ️ Template has been modified")
                    
                    # Section 2: Few-Shot Example Editor
                    st.markdown("---")
                    st.markdown("### 📚 Few-Shot Example")
                    st.markdown("**Edit the training example:**")
                    
                    edited_scenario = st.text_area(
                        "Scenario",
                        value=st.session_state['generated_example'].get('scenario', ''),
                        height=100,
                        key="edit_scenario",
                        help="Describe the transaction or scenario"
                    )
                    
                    edited_decision = st.selectbox(
                        "Decision",
                        options=["ALLOW", "WARN", "BLOCK"],
                        index=["ALLOW", "WARN", "BLOCK"].index(st.session_state['generated_example'].get('correct_decision', 'BLOCK')),
                        key="edit_decision",
                        help="Expected decision for this scenario"
                    )
                    
                    edited_reasoning = st.text_area(
                        "Reasoning",
                        value=st.session_state['generated_example'].get('reasoning', ''),
                        height=150,
                        key="edit_reasoning",
                        help="Explain why this decision is correct"
                    )
                    
                    # Update the generated example with edits (ensure flat structure, not nested)
                    updated_example = {
                        "scenario": edited_scenario,
                        "correct_decision": edited_decision,
                        "reasoning": edited_reasoning
                    }
                    
                    # Show what will be updated
                    st.markdown("---")
                    st.markdown("### 🎯 What Will Be Updated")
                    changes = []
                    if template_changed:
                        changes.append("✏️ Prompt template will be updated")
                    changes.append("📚 New training example will be added")
                    
                    for change in changes:
                        st.markdown(f"- {change}")
                    
                    # Show the example that will be sent
                    with st.expander("🔍 Preview Example JSON"):
                        st.json(updated_example)
                    
                    # Update button
                    if st.button("✅ Update Prompt", key="update_btn", type="primary"):
                        try:
                            # Get the event type and queue_id
                            event_type = item.get('event_type', 'PAYMENT_FRAUD')
                            queue_id = item.get('queue_id')
                            
                            # Update the prompt (template and/or example)
                            result = api.update_prompt_from_learning_queue(
                                event_type=event_type,
                                template=edited_template if template_changed else None,
                                example=updated_example,
                                description=None,  # Will be auto-generated
                                queue_id=queue_id
                            )
                            
                            # Mark the learning queue item as implemented
                            queue_id = item.get('queue_id')
                            if queue_id:
                                try:
                                    api.mark_as_implemented(
                                        queue_id=queue_id,
                                        implemented_by="learning_queue_ui",
                                        notes=f"Updated prompt to version {result.get('prompt_version', 'unknown')}"
                                    )
                                except Exception as e:
                                    st.warning(f"Note: Could not mark item as implemented: {e}")
                            
                            st.success("✅ Prompt Updated Successfully!")
                            st.info(f"📚 New **DRAFT** prompt version **{result.get('prompt_version', 'N/A')}** created.")
                            
                            # Show what was updated
                            if template_changed:
                                st.success("✏️ Prompt template updated")
                            st.success("📚 Training example added")
                            
                            st.info("💡 Go to **Prompt Management → Version History** to review and activate the new version.")
                            st.balloons()
                            
                            # Clean up session state
                            del st.session_state['generated_example']
                            if 'current_template' in st.session_state:
                                del st.session_state['current_template']
                            
                            # Remove this item from the list
                            items.remove(item)
                            st.session_state['learning_items'] = items
                            
                            st.rerun()
                        except Exception as e:
                            st.error(f"❌ Failed to update prompt: {str(e)}")
                            st.code(str(e))
            
            with col2:
                st.markdown("### 📋 Info")
                
                # Convert Decimals to float for display (COMMENTED OUT - not used in functionality)
                # try:
                #     score_val = float(item.get('reward_score', 0)) if item.get('reward_score') else 0
                # except:
                #     score_val = 0
                
                info_data = {
                    "event_id": str(item.get('event_id', 'N/A')),
                    "priority": str(item.get('priority', 'N/A')),
                    # "score": score_val  # COMMENTED OUT - display only, not sent to any APIs
                }
                st.json(info_data)
    else:
        st.info("No items available")

