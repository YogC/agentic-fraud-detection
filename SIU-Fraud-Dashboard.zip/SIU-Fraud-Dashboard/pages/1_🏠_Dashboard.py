"""
🛡️ SIU Fraud Review Dashboard - Main Application
Streamlit UI for reviewing fraud detection decisions
"""
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
from typing import Dict, List
import os
import sys
from dotenv import load_dotenv

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from api_client import APIClient

# Load environment variables
load_dotenv()

# Configuration
API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:8000/api/v1")
APP_TITLE = os.getenv("APP_TITLE", "🛡️ SIU Fraud Review Dashboard")

# Page config - MUST be the first Streamlit command
st.set_page_config(
    page_title="🛡️ SIU Fraud Review Dashboard",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        'Get Help': None,
        'Report a bug': None,
        'About': "🛡️ SIU Fraud Detection & Review Dashboard"
    }
)

# Initialize API client
@st.cache_resource
def get_api_client():
    return APIClient(base_url=API_BASE_URL)

api = get_api_client()

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        padding-bottom: 1rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
    .decision-block {
        background-color: #ffebee;
        padding: 0.5rem;
        border-radius: 0.3rem;
        border-left: 4px solid #f44336;
    }
    .decision-warn {
        background-color: #fff3e0;
        padding: 0.5rem;
        border-radius: 0.3rem;
        border-left: 4px solid #ff9800;
    }
    .decision-allow {
        background-color: #e8f5e9;
        padding: 0.5rem;
        border-radius: 0.3rem;
        border-left: 4px solid #4caf50;
    }
    .stButton>button {
        width: 100%;
    }
</style>
""", unsafe_allow_html=True)


def format_timestamp(ts: float) -> str:
    """Format timestamp to readable date"""
    try:
        dt = datetime.fromtimestamp(ts)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except:
        return "N/A"


def get_decision_color(decision: str) -> str:
    """Get color for decision type"""
    colors = {
        "BLOCK": "🔴",
        "WARN": "🟡",
        "ALLOW": "🟢"
    }
    return colors.get(decision, "⚪")


def render_decision_badge(decision: str) -> str:
    """Render decision as colored badge"""
    if decision == "BLOCK":
        return "decision-block"
    elif decision == "WARN":
        return "decision-warn"
    else:
        return "decision-allow"


def main():
    """Main application"""
    
    # Main title to clarify this is the SIU Dashboard
    st.markdown('<h1 class="main-header">🛡️ SIU Fraud Review Dashboard</h1>', unsafe_allow_html=True)
    st.markdown("**Review fraud detection cases, manage prompts, and monitor learning progress**")
    st.markdown("---")
    
    # Sidebar
    with st.sidebar:
        st.image("https://via.placeholder.com/200x60/1f77b4/ffffff?text=Fraud+Detection", 
                 width=200)
        st.markdown("---")
        
        # Check API connectivity
        if api.health_check():
            st.success("✅ Connected to Backend")
        else:
            st.error("❌ Backend Offline")
            st.info(f"API URL: {API_BASE_URL}")
            st.stop()
        
        st.markdown("### 👤 Reviewer Info")
        reviewer_id = st.text_input("Reviewer ID", value="siu_reviewer_01", key="reviewer_id")
        
        st.markdown("---")
        st.markdown("### 🔍 Filters")
        
        filter_type = st.selectbox(
            "Filter By",
            ["Pending Reviews", "All Decisions", "By Event Type", "By Status", "My Reviews"]
        )
        
        if filter_type == "By Event Type":
            event_type = st.selectbox(
                "Event Type",
                ["PAYMENT_FRAUD", "PII_ACCESS", "DATA_MODIFICATION", "DATA_EXPORT", "POLICY_VIOLATION"]
            )
        elif filter_type == "By Status":
            status = st.selectbox(
                "Status",
                ["PENDING_REVIEW", "AUTO_APPROVED", "APPROVED", "DENIED", "UNDER_INVESTIGATION"]
            )
        
        limit = st.slider("Results Limit", 10, 200, 50)
        
        if st.button("🔄 Refresh Data", use_container_width=True):
            st.cache_data.clear()
            st.rerun()
    
    # Tabs
    tab1, tab2, tab3 = st.tabs(["📋 Pending Queue", "📊 Analytics", "🎓 Learning Insights"])
    
    with tab1:
        render_pending_queue(filter_type, reviewer_id, limit, event_type if filter_type == "By Event Type" else None, 
                            status if filter_type == "By Status" else None)
    
    with tab2:
        render_analytics()
    
    with tab3:
        render_learning_insights()


def render_pending_queue(filter_type, reviewer_id, limit, event_type=None, status=None):
    """Render pending cases queue"""
    
    # Context-aware dynamic headers
    headers = {
        "Pending Reviews": "📋 Cases Awaiting Your Review",
        "All Decisions": "📊 All Fraud Detection Cases",
        "By Event Type": f"📁 {event_type} Cases" if event_type else "📁 Cases by Type",
        "By Status": f"🏷️ {status} Cases" if status else "🏷️ Cases by Status",
        "My Reviews": f"👤 Cases Reviewed by {reviewer_id}"
    }
    
    header = headers.get(filter_type, "📋 Cases")
    st.markdown(f"### {header}")
    
    # Fetch data based on filter
    try:
        if filter_type == "Pending Reviews":
            decisions = api.get_pending_reviews(limit=limit)
        elif filter_type == "By Event Type" and event_type:
            decisions = api.get_decisions_by_event_type(event_type, limit=limit)
        elif filter_type == "By Status" and status:
            decisions = api.get_decisions_by_status(status, limit=limit)
        elif filter_type == "My Reviews":
            decisions = api.get_decisions_by_reviewer(reviewer_id, limit=limit)
        else:
            decisions = api.get_all_decisions(limit=limit)
        
        if not decisions:
            if filter_type == "Pending Reviews":
                st.success("🎉 No cases pending review! All caught up!")
            else:
                st.info("No cases found matching your filters.")
            return
        
        # Dynamic metrics based on filter type
        if filter_type == "Pending Reviews":
            # Show agent risk levels for pending cases
            st.markdown("#### 🤖 Agent Risk Assessment")
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("📊 Total Awaiting Review", len(decisions))
            
            with col2:
                block_count = sum(1 for d in decisions if d.get('llm_decision') == 'BLOCK')
                st.metric("🔴 High Risk (BLOCK)", block_count)
            
            with col3:
                warn_count = sum(1 for d in decisions if d.get('llm_decision') == 'WARN')
                st.metric("🟡 Medium Risk (WARN)", warn_count)
            
            with col4:
                allow_count = sum(1 for d in decisions if d.get('llm_decision') == 'ALLOW')
                st.metric("🟢 Low Risk (ALLOW)", allow_count)
        else:
            # Show SIU outcomes for reviewed/all cases
            st.markdown("#### 📊 Case Overview")
            col1, col2, col3, col4, col5 = st.columns(5)
            
            with col1:
                st.metric("📊 Total Cases", len(decisions))
            
            with col2:
                denied_count = sum(1 for d in decisions if d.get('status') == 'DENIED')
                st.metric("❌ Fraud Confirmed", denied_count)
            
            with col3:
                approved_count = sum(1 for d in decisions if d.get('status') in ['APPROVED', 'AUTO_APPROVED'])
                st.metric("✅ Legitimate", approved_count)
            
            with col4:
                pending_count = sum(1 for d in decisions if d.get('status') == 'PENDING_REVIEW')
                st.metric("⏳ Pending", pending_count)
            
            with col5:
                # Calculate agent accuracy if we have reviewed cases
                reviewed_with_outcome = [d for d in decisions if d.get('actual_outcome')]
                if reviewed_with_outcome:
                    correct = sum(1 for d in reviewed_with_outcome 
                                 if (d.get('llm_decision') == 'BLOCK' and d.get('actual_outcome') == 'CONFIRMED_FRAUD') or
                                    (d.get('llm_decision') == 'ALLOW' and d.get('actual_outcome') in ['LEGITIMATE', 'FALSE_POSITIVE']))
                    accuracy = (correct / len(reviewed_with_outcome)) * 100 if reviewed_with_outcome else 0
                    st.metric("🎯 Agent Accuracy", f"{accuracy:.0f}%")
                else:
                    st.metric("🎯 Agent Accuracy", "N/A")
        
        st.markdown("---")
        
        # Case list
        for idx, decision in enumerate(decisions):
            render_case_card(decision, idx, reviewer_id, filter_type)
            st.markdown("---")
    
    except Exception as e:
        st.error(f"❌ Error loading cases: {str(e)}")


def render_case_card(decision: Dict, idx: int, reviewer_id: str, filter_type: str = "Pending Reviews"):
    """Render individual case card"""
    
    event_id = decision.get('event_id', 'N/A')
    llm_decision = decision.get('llm_decision', 'UNKNOWN')
    confidence = decision.get('llm_confidence', 0.0)
    event_type = decision.get('event_type', 'UNKNOWN')
    status = decision.get('status', 'UNKNOWN')
    reviewed_action = decision.get('reviewer_action')
    actual_outcome = decision.get('actual_outcome')
    reward_score = decision.get('reward_score')
    
    # Get normalized display information (handles both new and old records)
    display_info = get_normalized_display_info(decision)
    display_decision = display_info['display_decision']
    agent_score = display_info['agent_score']
    is_llm_knowledge = display_info['is_llm_knowledge']
    display_badge = display_info['display_badge']
    
    # Determine color for display decision
    # Extract base decision for color coding (handle composite decisions)
    base_decision = llm_decision
    if 'BLOCK' in display_decision.upper():
        base_decision = 'BLOCK'
    elif 'WARN' in display_decision.upper():
        base_decision = 'WARN'
    elif 'ALLOW' in display_decision.upper():
        base_decision = 'ALLOW'
    
    # Expandable case card
    with st.expander(
        f"{get_decision_color(base_decision)} **{event_id}** | {event_type} | "
        f"Decision: **{display_decision}** ({confidence:.0%}) | Status: {status}",
        expanded=(idx == 0)
    ):
        col1, col2 = st.columns([2, 1])
        
        with col1:
            # Case Details
            st.markdown("#### 📄 Case Details")
            
            st.markdown(f"**Event ID:** `{event_id}`")
            st.markdown(f"**Event Type:** {event_type}")
            st.markdown(f"**Risk Category:** {decision.get('risk_category', 'N/A')}")
            st.markdown(f"**Created:** {format_timestamp(decision.get('timestamp', 0))}")
            st.markdown(f"**Status:** `{status}`")
            
            # Event Data
            st.markdown("#### 📦 Event Data")
            event_data = decision.get('event_data', {})
            if event_data:
                st.json(event_data)
            else:
                st.info("No event data available")
            
            # Detection Results
            st.markdown("#### 🔍 Detection Results")
            detection_results = decision.get('detection_results', {})
            if detection_results:
                st.json(detection_results)
            else:
                st.info("No detection results available")
        
        with col2:
            # LLM Analysis
            st.markdown("#### 🤖 LLM Analysis")
            
            # Display LLM Knowledge Detection badge if applicable
            if is_llm_knowledge and display_badge:
                st.info(f"**{display_badge}**")
                st.markdown("---")
            
            decision_class = render_decision_badge(base_decision)
            st.markdown(f'<div class="{decision_class}">'
                       f'<strong>Decision:</strong> {display_decision}<br>'
                       f'<strong>Confidence:</strong> {confidence:.1%}'
                       f'</div>', unsafe_allow_html=True)
            
            # Show agent score context
            if agent_score is not None:
                st.markdown(f"**Agent Risk Score:** {agent_score}/6")
            else:
                st.markdown(f"**Agent Risk Score:** N/A (legacy record)")
            
            st.markdown("**Reasoning:**")
            st.write(decision.get('llm_reasoning', 'No reasoning provided'))
            
            # Show existing review if already reviewed
            if reviewed_action:
                st.markdown("---")
                st.markdown("#### ✅ Already Reviewed")
                
                # Show review outcome with clear visualization
                if reviewed_action == "DENY":
                    st.error(f"❌ **Fraud Confirmed** by {decision.get('reviewer_id', 'N/A')}")
                elif reviewed_action == "APPROVE":
                    st.success(f"✅ **Legitimate Transaction** by {decision.get('reviewer_id', 'N/A')}")
                else:
                    st.info(f"🔍 **{reviewed_action}** by {decision.get('reviewer_id', 'N/A')}")
                
                if actual_outcome:
                    outcome_label = {
                        'CONFIRMED_FRAUD': '🚨 Fraud Confirmed',
                        'FALSE_POSITIVE': '✓ False Alarm (Legitimate)',
                        'LEGITIMATE': '✓ Legitimate',
                        'INCONCLUSIVE': '❓ Inconclusive'
                    }.get(actual_outcome, actual_outcome)
                    st.markdown(f"**Outcome:** {outcome_label}")
                
                if reward_score is not None:
                    if reward_score > 0:
                        st.success(f"🏆 Learning Reward: +{reward_score} (Agent was correct!)")
                    elif reward_score < 0:
                        st.warning(f"📉 Learning Penalty: {reward_score} (Agent needs improvement)")
                
                st.markdown(f"**Notes:** {decision.get('reviewer_notes', 'No notes')}")
                st.markdown(f"**Reviewed:** {format_timestamp(decision.get('reviewed_at', 0)) if decision.get('reviewed_at') else 'N/A'}")
            else:
                # Review form for pending cases
                st.markdown("---")
                st.markdown("#### ✍️ Submit Your Review")
                
                # Show context with display decision
                st.info(f"**Decision:** {display_decision} ({confidence:.0%} confidence)")
                
                # Show LLM Knowledge Detection context if applicable
                if is_llm_knowledge:
                    st.warning(f"⚠️ **LLM Knowledge Detection:** Agents scored {agent_score}/6 but LLM flagged fraud patterns")
                
                # Step 1: Decision selection (OUTSIDE form for reactive updates)
                st.markdown("##### Step 1: What's Your Final Decision?")
                st.markdown(f"📊 **Current Recommendation:** {display_decision} ({confidence:.0%} confidence)")
                
                # Create context-aware decision options based on base decision
                if base_decision == "BLOCK":
                    action_help = "Transaction was blocked. Do you agree with the block?"
                    action_options = {
                        "✅ AGREE - Confirm Fraud (Block Transaction)": ("DENY", "CONFIRMED_FRAUD"),
                        "❌ DISAGREE - False Alarm (Allow Transaction)": ("APPROVE", "FALSE_POSITIVE")
                    }
                elif base_decision == "ALLOW":
                    action_help = "Transaction was allowed. Do you agree?"
                    action_options = {
                        "✅ AGREE - It's Legitimate (Allow Transaction)": ("APPROVE", "LEGITIMATE"),
                        "❌ DISAGREE - Missed Fraud (Block Transaction)": ("DENY", "CONFIRMED_FRAUD")
                    }
                else:  # WARN or other
                    action_help = f"Transaction flagged for review. What's your decision?"
                    action_options = {
                        "❌ BLOCK - It's Fraud": ("DENY", "CONFIRMED_FRAUD"),
                        "✅ ALLOW - It's Legitimate": ("APPROVE", "LEGITIMATE")
                    }
                
                selected_label = st.radio(
                    "Your Decision:",
                    list(action_options.keys()),
                    key=f"action_{idx}",
                    help=action_help
                )
                
                # Get both action and outcome from the selected option
                reviewer_action, actual_outcome = action_options[selected_label]
                
                # Show learning impact guide (COMMENTED OUT - purely informational, not used by backend)
                # if llm_decision == "BLOCK":
                #     st.info("""📚 **Learning Impact Guide:**
                # - ✅ AGREE (confirm fraud) → **+100 reward** (Agent correct!)
                # - ❌ DISAGREE (false alarm) → **-50 penalty** (Agent wrong)""")
                # elif llm_decision == "ALLOW":
                #     st.info("""📚 **Learning Impact Guide:**
                # - ✅ AGREE (it's legitimate) → **+50 reward** (Agent correct!)
                # - ❌ DISAGREE (missed fraud) → **-100 penalty** (Critical!)""")
                # else:
                #     st.info("""📚 **Learning Impact Guide:**
                # - ❌ BLOCK (it's fraud) → **+100 reward**
                # - ✅ ALLOW - It's Legitimate) → **+50 reward**""")
                
                st.markdown("---")
                
                # Step 2: Learning Queue check (OUTSIDE form for reactive updates)
                st.markdown("##### Step 2: Learning Queue (Optional)")
                
                st.info(
                    "📚 **Learning Queue**: All reviewed cases can be added to the Learning Queue "
                    "to improve future fraud detection. High-value cases (significant fraud or false positives) "
                    "are automatically added, but you can manually add any case you think is valuable for learning."
                )
                
                # Check if SIU decision differs from LLM decision (for contextual messaging)
                llm_says_block = llm_decision in ["BLOCK", "INVESTIGATE", "DENY", "WARN"]
                siu_says_block = reviewer_action == "DENY"
                siu_disagrees = (llm_says_block != siu_says_block)
                
                # Show contextual warning if there's disagreement
                if siu_disagrees:
                    st.warning(
                        "⚠️ **Your decision differs from the LLM recommendation!** "
                        "This is a valuable learning opportunity - consider adding to the Learning Queue."
                    )
                
                # ALWAYS show the checkbox, checked by default
                add_to_queue = st.checkbox(
                    "✅ Add to Learning Queue for Prompt Improvement",
                    value=True,
                    key=f"add_to_queue_{idx}",
                    help=(
                        "Add this case to the Learning Queue to improve future fraud detection. "
                        "The LLM will learn from your expertise, whether you agree or disagree with its decision. "
                        "High-value cases are automatically added, but you can uncheck this if not needed."
                    )
                )
                
                st.markdown("---")
                
                # Form only for notes and submit (Step 3)
                with st.form(f"review_form_{idx}"):
                    st.markdown("##### Step 3: Investigation Notes")
                    reviewer_notes = st.text_area(
                        "Describe your investigation and reasoning *",
                        placeholder="Document your investigation process...\n\nExample:\n- Contacted employee: verified legitimate business expense\n- Checked vendor: authorized supplier with existing contract\n- Reviewed approval: manager confirmed transaction\n- Conclusion: Transaction is legitimate",
                        key=f"notes_{idx}",
                        height=150,
                        help="Required: Explain how you reached your decision"
                    )
                    
                    submit_button = st.form_submit_button("📝 Submit Review", use_container_width=True)
                    
                    if submit_button:
                        if not reviewer_notes:
                            st.error("❌ Investigation notes are required")
                        else:
                            submit_review(
                                decision, 
                                reviewer_id, 
                                reviewer_action, 
                                reviewer_notes, 
                                actual_outcome,
                                add_to_queue
                            )


def submit_review(decision: Dict, reviewer_id: str, action: str, notes: str, outcome: str = None, add_to_queue: bool = False):
    """Submit review to backend"""
    
    try:
        with st.spinner("Submitting review..."):
            result = api.submit_review(
                event_id=decision['event_id'],
                timestamp=decision['timestamp'],
                reviewer_id=reviewer_id,
                reviewer_action=action,
                reviewer_notes=notes,
                actual_outcome=outcome,
                add_to_learning_queue=add_to_queue
            )
        
        st.success(f"✅ Review submitted successfully!")
        
        # Show if manually added to learning queue
        if add_to_queue:
            st.success(f"📚 Manually added to Learning Queue (disagreement case)!")
        
        # Show if automatically added to learning queue
        if result.get('added_to_learning_queue'):
            st.success(f"📚 Automatically added to Learning Queue (high-value case)!")
        
        # Show reward score if available
        if result.get('reward_score') is not None:
            reward = result['reward_score']
            if reward > 0:
                st.success(f"🎉 Learning Reward: +{reward} (Agent was correct!)")
            elif reward < 0:
                st.warning(f"⚠️ Learning Penalty: {reward} (Agent will learn from this)")
            else:
                st.info("ℹ️ Neutral feedback recorded")
        
        # Show completion message and refresh
        st.info("🔄 Refreshing dashboard...")
        st.balloons()
        
        # Clear cache and rerun to show updated data
        import time
        time.sleep(1)  # Brief pause to show success messages
        st.cache_data.clear()
        st.rerun()
    
    except Exception as e:
        st.error(f"❌ Error submitting review: {str(e)}")
        import traceback
        with st.expander("🐛 Error Details"):
            st.code(traceback.format_exc())


def render_analytics():
    """Render analytics dashboard"""
    
    st.markdown("### 📊 Analytics Dashboard")
    
    try:
        stats = api.get_statistics()
        
        # Key Metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                "📊 Total Decisions",
                stats.get('total_decisions', 0)
            )
        
        with col2:
            st.metric(
                "⏳ Pending Reviews",
                stats.get('pending_reviews', 0)
            )
        
        with col3:
            st.metric(
                "✅ Approved",
                stats.get('approved', 0)
            )
        
        with col4:
            st.metric(
                "❌ Denied",
                stats.get('denied', 0)
            )
        
        st.markdown("---")
        
        # Charts
        col1, col2 = st.columns(2)
        
        with col1:
            # Decision Distribution
            st.markdown("#### Decision Distribution")
            by_decision = stats.get('by_decision', {})
            
            if by_decision:
                fig = go.Figure(data=[go.Pie(
                    labels=list(by_decision.keys()),
                    values=list(by_decision.values()),
                    marker=dict(colors=['#f44336', '#ff9800', '#4caf50'])
                )])
                fig.update_layout(height=300)
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("No decision data available")
        
        with col2:
            # Status Distribution
            st.markdown("#### Status Distribution")
            status_data = {
                'Pending': stats.get('pending_reviews', 0),
                'Approved': stats.get('approved', 0),
                'Denied': stats.get('denied', 0)
            }
            
            fig = go.Figure(data=[go.Bar(
                x=list(status_data.keys()),
                y=list(status_data.values()),
                marker=dict(color=['#ff9800', '#4caf50', '#f44336'])
            )])
            fig.update_layout(height=300, showlegend=False)
            st.plotly_chart(fig, use_container_width=True)
    
    except Exception as e:
        st.error(f"❌ Error loading analytics: {str(e)}")


def render_learning_insights():
    """Render learning insights"""
    
    st.markdown("### 🎓 Agent Learning Insights")
    
    try:
        insights = api.get_learning_insights()
        
        # Key Learning Metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            accuracy = insights.get('accuracy_percent', 0)
            st.metric(
                "🎯 Agent Accuracy",
                f"{accuracy:.1f}%",
                help="Percentage of correct decisions"
            )
        
        with col2:
            avg_reward = insights.get('average_reward', 0)
            delta_color = "normal" if avg_reward >= 0 else "inverse"
            st.metric(
                "💯 Avg Reward",
                f"{avg_reward:.1f}",
                delta=f"{'+' if avg_reward > 0 else ''}{avg_reward:.1f}",
                help="Average reward score per review"
            )
        
        with col3:
            st.metric(
                "✅ Correct",
                insights.get('correct_decisions', 0)
            )
        
        with col4:
            st.metric(
                "❌ Incorrect",
                insights.get('incorrect_decisions', 0)
            )
        
        st.markdown("---")
        
        # Learning Status
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.markdown("#### 📈 Learning Progress")
            st.info(f"**Status:** {insights.get('learning_status', 'unknown').replace('_', ' ').title()}")
            st.write(insights.get('message', 'No insights available'))
            
            # Progress metrics
            total_reviewed = insights.get('total_reviewed', 0)
            with_feedback = insights.get('with_feedback', 0)
            
            if total_reviewed > 0:
                feedback_rate = (with_feedback / total_reviewed) * 100
                st.progress(feedback_rate / 100)
                st.caption(f"Feedback Rate: {feedback_rate:.1f}% ({with_feedback}/{total_reviewed} cases)")
        
        with col2:
            st.markdown("#### 🎯 High-Value Cases")
            high_value = insights.get('high_value_learning_cases', 0)
            
            st.metric(
                "Cases for Learning",
                high_value,
                help="Cases identified for prompt improvement"
            )
            
            if high_value > 0:
                st.success(f"✅ {high_value} cases ready for agent training")
            else:
                st.warning("⚠️ Need more feedback to improve")
        
        st.markdown("---")
        
        # Recommendations
        st.markdown("#### 💡 Recommendations")
        
        if accuracy < 70:
            st.warning("🔴 **Action Required:** Agent accuracy below 70%. Review high-value cases and update prompts.")
        elif accuracy < 85:
            st.info("🟡 **Good Progress:** Continue collecting feedback to improve accuracy.")
        else:
            st.success("🟢 **Excellent:** Agent performing well! Maintain feedback quality.")
        
        if with_feedback < 20:
            st.info("ℹ️ **Tip:** Submit more reviews with actual outcomes to enable learning.")
    
    except Exception as e:
        st.error(f"❌ Error loading learning insights: {str(e)}")


def calculate_agent_score_from_detection_results(detection_results: Dict) -> int:
    """
    Calculate total agent score from detection_results.
    Handles old records that don't have total_score field.
    
    Risk mapping: LOW=0, MED=1, HIGH=2
    """
    if not detection_results:
        return None  # Return None to indicate "not available"
    
    risk_map = {'LOW': 0, 'MED': 1, 'HIGH': 2}
    total = 0
    
    # Extract scores from each agent
    for agent_name, agent_result in detection_results.items():
        if isinstance(agent_result, dict):
            # Try to get score directly
            score = agent_result.get('score')
            if score is not None:
                total += int(score)
            else:
                # Fall back to risk level
                risk = agent_result.get('risk', 'LOW')
                total += risk_map.get(risk.upper(), 0)
    
    return total


def get_normalized_display_info(decision: Dict) -> Dict:
    """
    Get normalized display information for a decision.
    Handles both new records (with display_metadata) and old records (without).
    
    Returns:
        dict with: display_decision, agent_score, is_llm_knowledge, display_badge
    """
    llm_decision = decision.get('llm_decision', 'UNKNOWN')
    
    # Try to get display_metadata (new records)
    display_metadata = decision.get('display_metadata', {})
    
    # Check if display_metadata has actual content (not just empty dict)
    if display_metadata and display_metadata.get('display_decision'):
        # New record with display_metadata
        return {
            'display_decision': display_metadata.get('display_decision', llm_decision),
            'agent_score': display_metadata.get('agent_score'),
            'is_llm_knowledge': display_metadata.get('is_llm_knowledge_detection', False),
            'display_badge': display_metadata.get('display_badge'),
            'has_metadata': True
        }
    
    # Old record - build display info manually (or empty display_metadata)
    # Try to get agent score from total_score or detection_results
    agent_score = decision.get('total_score')
    if agent_score is None:
        detection_results = decision.get('detection_results', {})
        agent_score = calculate_agent_score_from_detection_results(detection_results)
    
    # Determine if this is an LLM knowledge detection case
    # (LLM says BLOCK/WARN but agents scored low)
    is_llm_knowledge = False
    display_badge = None
    
    if agent_score is not None and llm_decision in ['BLOCK', 'WARN']:
        if llm_decision == 'BLOCK' and agent_score <= 2:
            is_llm_knowledge = True
            display_badge = f'🧠 Agents Missed ({agent_score}/6) - LLM Caught Fraud'
        elif llm_decision == 'WARN' and agent_score == 0:
            is_llm_knowledge = True
            display_badge = f'🧠 Agents Missed (0/6) - LLM Flagged Risk'
    
    # Handle non-standard LLM decisions (like INVESTIGATE)
    standard_decisions = ['ALLOW', 'APPROVE', 'WARN', 'BLOCK', 'DENY']
    display_decision = llm_decision
    
    if llm_decision not in standard_decisions:
        # Non-standard decision - add context from agent score
        if agent_score is not None:
            if agent_score >= 4:
                agent_action = 'BLOCK'
            elif agent_score >= 1:
                agent_action = 'WARN'
            else:
                agent_action = 'ALLOW'
            display_decision = f"{llm_decision} ({agent_action} from Agents)"
        else:
            # Can't determine agent decision
            display_decision = f"{llm_decision} (Review Required)"
    
    return {
        'display_decision': display_decision,
        'agent_score': agent_score,
        'is_llm_knowledge': is_llm_knowledge,
        'display_badge': display_badge,
        'has_metadata': False
    }


if __name__ == "__main__":
    main()
