"""
Prompt Management Dashboard Page
Allows SIU/Management to view, compare, and manage LLM prompts with versioning
"""
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import time
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from api_client import APIClient

# Initialize API client
api = APIClient()

# Helper function to format event type names
def format_event_type(event_type: str) -> str:
    """Format event type for display"""
    mapping = {
        "PAYMENT_FRAUD": "💳 Payment Fraud",
        "PII_ACCESS": "🔒 PII Access",
        "DATA_MODIFICATION": "📝 Data Modification"
    }
    return mapping.get(event_type, event_type.replace('_', ' ').title())

# Helper function to safely parse ISO format dates
def safe_parse_datetime(date_value, default="N/A"):
    """Safely parse ISO format datetime string"""
    if date_value is None:
        return default
    if not isinstance(date_value, str):
        return str(date_value) if date_value else default
    try:
        return datetime.fromisoformat(date_value).strftime('%Y-%m-%d %H:%M')
    except (ValueError, TypeError):
        return default

st.set_page_config(
    page_title="Prompt Management",
    page_icon="📚",
    layout="wide"
)

st.title("📚 Prompt Management System")
st.markdown("**Manage and version LLM prompts for fraud detection**")

# Tabs for different prompt management functions
tab1, tab2, tab3, tab4 = st.tabs([
    "📋 Active Prompts",
    "📜 Version History",
    "🔍 Compare Versions",
    "📊 Audit Trail"
])

# ==================== TAB 1: Active Prompts ====================
with tab1:
    st.header("Currently Active Prompts")
    st.markdown("**Select a prompt below to view full details**")
    
    # Add refresh button
    col_refresh1, col_refresh2 = st.columns([6, 1])
    with col_refresh2:
        if st.button("🔄 Refresh", use_container_width=True, help="Force refresh from database"):
            if 'force_refresh' not in st.session_state:
                st.session_state['force_refresh'] = True
            else:
                st.session_state['force_refresh'] = not st.session_state.get('force_refresh', False)
            st.rerun()
    
    # Initialize session state for selected prompt
    if 'selected_prompt_type' not in st.session_state:
        st.session_state['selected_prompt_type'] = 'PAYMENT_FRAUD'
    
    # Define event types
    event_types = [
        ("PAYMENT_FRAUD", "💳 Payment Fraud"),
        ("PII_ACCESS", "🔒 PII Access"),
        ("DATA_MODIFICATION", "📝 Data Modification")
    ]
    
    # Load all prompts with force_refresh if needed
    force_refresh = st.session_state.get('force_refresh', False)
    prompts_data = {}
    for event_type, display_name in event_types:
        try:
            prompt = api.get_active_prompt(event_type, force_refresh=force_refresh)
            
            prompts_data[event_type] = {
                'data': prompt,
                'display_name': display_name,
                'loaded': True,
                'error': None
            }
        except Exception as e:
            prompts_data[event_type] = {
                'data': None,
                'display_name': display_name,
                'loaded': False,
                'error': str(e)
            }
    
    # Reset force_refresh flag after loading
    if force_refresh:
        st.session_state['force_refresh'] = False
    
    # ========== TOP SECTION: Selectable Cards ==========
    st.markdown("---")
    col1, col2, col3 = st.columns(3)
    
    for idx, (event_type, display_name) in enumerate(event_types):
        col = [col1, col2, col3][idx]
        prompt_info = prompts_data[event_type]
        
        with col:
            # Create a card-like container
            is_selected = st.session_state['selected_prompt_type'] == event_type
            
            # Card styling
            if is_selected:
                st.markdown(f"""
                <div style="padding: 1rem; border: 3px solid #1f77b4; border-radius: 0.5rem; background-color: #e8f4f8; text-align: center;">
                    <h3>{display_name}</h3>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div style="padding: 1rem; border: 1px solid #ddd; border-radius: 0.5rem; background-color: #f9f9f9; text-align: center;">
                    <h3>{display_name}</h3>
                </div>
                """, unsafe_allow_html=True)
            
            # Show basic info
            if prompt_info['loaded'] and prompt_info['data']:
                prompt = prompt_info['data']
                st.markdown(f"**Version:** `{prompt.get('version', 'N/A')}`")
                st.markdown(f"**Status:** `{prompt.get('status', 'N/A')}`")
                st.markdown(f"**Examples:** {prompt.get('examples_count', 0)}")
            else:
                st.warning("⚠️ Not configured")
            
            # Select button
            if st.button("📋 View Details", key=f"select_{event_type}", use_container_width=True):
                st.session_state['selected_prompt_type'] = event_type
                st.rerun()
    
    st.markdown("---")
    
    # ========== BOTTOM SECTION: Detailed View ==========
    selected_type = st.session_state['selected_prompt_type']
    selected_info = prompts_data[selected_type]
    
    if not selected_info['loaded']:
        st.error(f"❌ Error loading {selected_info['display_name']}")
        st.code(selected_info['error'])
        st.info("💡 Make sure the backend server is running and DynamoDB tables are created.")
    elif not selected_info['data']:
        st.warning(f"No active prompt configured for {selected_info['display_name']}")
        st.info("Create a new prompt in the 'Create/Edit Prompt' tab to get started.")
    else:
        prompt = selected_info['data']
        
        # Header with title and metadata
        st.markdown(f"## 📋 Prompt Details: {selected_info['display_name']}")
        
        # Metadata row
        meta_col1, meta_col2, meta_col3 = st.columns(3)
        with meta_col1:
            st.metric("Version", prompt.get('version', 'N/A'))
        with meta_col2:
            st.metric("Status", prompt.get('status', 'N/A'))
        with meta_col3:
            st.metric("Examples", prompt.get('examples_count', 0))
        
        # Additional metadata
        with st.expander("📊 Additional Metadata", expanded=False):
            meta_info_col1, meta_info_col2 = st.columns(2)
            with meta_info_col1:
                st.markdown(f"**Prompt ID:** `{prompt.get('prompt_id', 'N/A')}`")
                st.markdown(f"**Created:** {safe_parse_datetime(prompt.get('created_at'))}")
            with meta_info_col2:
                if prompt.get('activated_at'):
                    st.markdown(f"**Activated:** {safe_parse_datetime(prompt.get('activated_at'))}")
                if prompt.get('activated_by'):
                    st.markdown(f"**Activated By:** {prompt.get('activated_by')}")
        
        st.markdown("---")
        
        # Description Section
        st.markdown("### 📝 Description")
        st.info(prompt.get('description', 'No description provided'))
        
        st.markdown("---")
        
        # Prompt Template Section (Full Width, Easy to Read)
        st.markdown("### 📄 Prompt Template")
        
        # Try both 'template' and 'system_prompt' keys for compatibility
        template_text = prompt.get('template') or prompt.get('system_prompt', 'No template available')
        
        # Show which field is being used (for debugging)
        if prompt.get('template'):
            source_field = "template"
        elif prompt.get('system_prompt'):
            source_field = "system_prompt"
        else:
            source_field = "none"
        
        st.caption(f"📍 Source: `{source_field}` field | Length: {len(template_text)} characters")
        
        # Use text_area for better readability and scrolling
        st.text_area(
            label="System Prompt",
            value=template_text,
            height=300,
            disabled=True,
            key=f"template_display_{selected_type}",
            label_visibility="collapsed"
        )
        
        st.markdown("---")
        
        # Few-Shot Examples Section (READ-ONLY for Active Prompts)
        few_shot_examples = prompt.get('few_shot_examples')
        if few_shot_examples and isinstance(few_shot_examples, list) and len(few_shot_examples) > 0:
            st.markdown("### 🎯 Few-Shot Examples")
            st.info("💡 **Tip:** To edit examples, go to **Version History** tab, select a DRAFT version, and click **Edit**")
            
            with st.expander(f"View {len(few_shot_examples)} Examples", expanded=False):
                for i, example in enumerate(few_shot_examples, 1):
                    st.markdown(f"**Example {i}:**")
                    col1, col2 = st.columns([3, 1])
                    with col1:
                        st.markdown(f"**Decision:** `{example.get('correct_decision', example.get('decision', 'UNKNOWN'))}`")
                        st.markdown(f"**Fraud Type:** `{example.get('fraud_type', 'N/A')}`")
                        st.markdown(f"**Scenario:** {example.get('scenario', 'N/A')}")
                    with col2:
                        st.markdown(f"**Source:** `{example.get('source', 'N/A')}`")
                        if example.get('reward_score'):
                            st.markdown(f"**Reward:** `{example.get('reward_score')}`")
                    
                    # Show reasoning in read-only text area
                    st.markdown("**Reasoning:**")
                    st.text_area(
                        label=f"Reasoning for Example {i}",
                        value=example.get('reasoning', 'N/A'),
                        height=80,
                        disabled=True,
                        key=f"active_view_reasoning_{i}",
                        label_visibility="collapsed"
                    )
                    
                    if i < len(few_shot_examples):
                        st.markdown("---")
        else:
            st.markdown("### 🎯 Few-Shot Examples")
            st.info("No few-shot examples available for this prompt")

        
        st.markdown("---")
        
        # Model Configuration
        with st.expander("🔧 Model Configuration", expanded=False):
            st.info("**System Model:** AWS Bedrock Claude 3 Sonnet")
            st.markdown("**Current Configuration:**")
            
            config_col1, config_col2 = st.columns(2)
            with config_col1:
                st.markdown("**Model:** `anthropic.claude-3-sonnet-20240229-v1:0`")
                st.markdown("**Temperature:** 0.3")
            with config_col2:
                st.markdown("**Max Tokens:** 1500")
                st.markdown("**Top P:** 0.8")

# ==================== TAB 2: Version History ====================
with tab2:
    st.header("Prompt Version History")
    st.markdown("View all historical versions of prompts for each event type.")
    
    # Event type selector
    event_type_options = {
        "💳 Payment Fraud": "PAYMENT_FRAUD",
        "🔒 PII Access": "PII_ACCESS",
        "📝 Data Modification": "DATA_MODIFICATION"
    }
    
    selected_event_display = st.selectbox(
        "Select Event Type",
        options=list(event_type_options.keys()),
        key="version_history_event"
    )
    selected_event = event_type_options[selected_event_display]
    
    limit = st.slider("Number of versions to display", 5, 50, 20)
    
    # Debug toggle
    show_debug = st.checkbox("🔍 Show Debug Info", value=False)
    
    # Initialize session state for versions
    if 'loaded_versions' not in st.session_state:
        st.session_state['loaded_versions'] = None
    if 'loaded_event_type' not in st.session_state:
        st.session_state['loaded_event_type'] = None
    
    # Load button - stores results in session state
    if st.button("🔄 Load Version History", type="primary"):
        try:
            versions = api.list_prompt_versions(selected_event, limit=limit)
            # Store in session state
            st.session_state['loaded_versions'] = versions
            st.session_state['loaded_event_type'] = selected_event
            
            if show_debug:
                st.markdown("### 🐛 Debug Info")
                st.json(versions)
            
        except Exception as e:
            st.error(f"Failed to load versions: {str(e)}")
            st.session_state['loaded_versions'] = None
    
    # Display versions from session state (persists across reruns)
    versions = st.session_state.get('loaded_versions')
    loaded_event = st.session_state.get('loaded_event_type')
    
    if versions and loaded_event == selected_event:
        st.success(f"Found {len(versions)} versions for {selected_event}")
        
        # Display as table
        df_data = []
        for v in versions:
            # Handle few_shot_examples being False, None, or a list
            examples = v.get('few_shot_examples')
            examples_count = len(examples) if isinstance(examples, list) else 0
            
            df_data.append({
                "Version": v['version'],
                "Status": v['status'],
                "Examples": examples_count,
                "Created": safe_parse_datetime(v.get('created_at')),
                "Description": v.get('description', '')[:50] + "..." if len(v.get('description', '')) > 50 else v.get('description', ''),
                "Prompt ID": v['prompt_id']
            })
        
        df = pd.DataFrame(df_data)
        st.dataframe(df, use_container_width=True)
        
        # Detailed view
        st.markdown("---")
        st.subheader("Detailed Version View")
        
        selected_version = st.selectbox(
            "Select version to view details",
            options=[v['version'] for v in versions],
            format_func=lambda x: f"Version {x}"
        )
        
        selected_prompt = next((v for v in versions if v['version'] == selected_version), None)
        
        if selected_prompt:
            col1, col2 = st.columns([2, 1])
            
            with col1:
                st.markdown("**Prompt Template:**")
                # Try both 'template' and 'system_prompt' keys for compatibility
                template = selected_prompt.get('template') or selected_prompt.get('system_prompt', 'No template available')
                st.code(template, language="text")
            
            with col2:
                st.markdown("**Metadata:**")
                st.json({
                    "prompt_id": selected_prompt['prompt_id'],
                    "version": selected_prompt['version'],
                    "status": selected_prompt['status'],
                    "created_at": selected_prompt.get('created_at', 'N/A'),
                    "description": selected_prompt.get('description', '')
                })
                
                # Show Few-Shot Examples Count
                examples = selected_prompt.get('few_shot_examples')
                examples_count = len(examples) if isinstance(examples, list) else 0
                st.metric("Few-Shot Examples", examples_count)
                
                # Actions - Check if there are unsaved changes
                has_unsaved_changes = st.session_state.get(f"modified_examples_{selected_prompt['prompt_id']}") is not None
                
                if selected_prompt['status'] != 'ACTIVE':
                    if st.button("✅ Activate This Prompt", key="activate_btn", type="primary", use_container_width=True):
                        try:
                            prompt_id = selected_prompt.get('prompt_id')
                            st.info(f"🔵 Activating prompt: {prompt_id}")
                            print(f"[UI] 🔵 Activation button clicked! prompt_id: {prompt_id}")
                            
                            # If there are unsaved changes (DRAFT with edits), save them first
                            if has_unsaved_changes:
                                modified_examples = st.session_state[f"modified_examples_{prompt_id}"]
                                st.info(f"💾 Saving {len(modified_examples)} updated examples first...")
                                print(f"[UI] 💾 Saving {len(modified_examples)} modified examples before activation")
                                
                                api.update_prompt_examples(
                                    prompt_id=prompt_id,
                                    few_shot_examples=modified_examples,
                                    updated_by=st.session_state.get('user_id', 'admin')
                                )
                            
                            # Now activate the prompt
                            activated = api.activate_prompt(
                                prompt_id=prompt_id,
                                activated_by=st.session_state.get('user_id', 'admin')
                            )
                            print(f"[UI] ✅ Activation successful! Result: {activated}")
                            
                            # Clear edit state
                            st.session_state[f"editing_examples_{prompt_id}"] = False
                            st.session_state[f"modified_examples_{prompt_id}"] = None
                            
                            st.success(f"✅ Activated version {activated.get('version', 'N/A')}!")
                            time.sleep(1)
                            st.rerun()
                        except Exception as e:
                            print(f"[UI] ❌ Activation failed! Error: {str(e)}")
                            st.error(f"❌ Failed to activate: {str(e)}")
                            import traceback
                            print(f"[UI] Traceback: {traceback.format_exc()}")
                            with st.expander("🐛 Error Details"):
                                st.code(traceback.format_exc())
            
            # Show Few-Shot Examples with Edit functionality for DRAFT prompts
            st.markdown("---")
            few_shot_examples = selected_prompt.get('few_shot_examples')
            
            if few_shot_examples and isinstance(few_shot_examples, list) and len(few_shot_examples) > 0:
                st.markdown("### 🎯 Few-Shot Examples")
                
                # Initialize session state for editing
                edit_key = f"editing_examples_{selected_prompt['prompt_id']}"
                modified_key = f"modified_examples_{selected_prompt['prompt_id']}"
                
                if edit_key not in st.session_state:
                    st.session_state[edit_key] = False
                if modified_key not in st.session_state:
                    st.session_state[modified_key] = None
                
                # Show edit button only for DRAFT prompts
                if selected_prompt['status'] == 'DRAFT':
                    edit_col1, edit_col2 = st.columns([6, 1])
                    with edit_col2:
                        if st.button("✏️ Edit", key=f"toggle_edit_{selected_prompt['prompt_id']}", use_container_width=True):
                            st.session_state[edit_key] = not st.session_state[edit_key]
                            if st.session_state[edit_key]:
                                st.session_state[modified_key] = [dict(ex) for ex in few_shot_examples]
                            else:
                                st.session_state[modified_key] = None
                            st.rerun()
                
                # EDIT MODE (only for DRAFT)
                if st.session_state[edit_key] and selected_prompt['status'] == 'DRAFT':
                    st.info("📝 **Edit Mode** - Modify or remove examples below. Click **'Activate This Prompt'** (above) to save your changes and activate this version.")
                    
                    modified_examples = st.session_state[modified_key]
                    examples_to_remove = []
                    
                    for i, example in enumerate(modified_examples, 1):
                        st.markdown(f"#### Example {i}")
                        col_remove, col_empty = st.columns([1, 5])
                        with col_remove:
                            if st.button(f"🗑️ Remove", key=f"remove_ex_{selected_prompt['prompt_id']}_{i}"):
                                examples_to_remove.append(i-1)
                        
                        col_decision, col_fraud = st.columns(2)
                        with col_decision:
                            # Map legacy values before using in selectbox
                            DECISION_MAP = {
                                'APPROVE': 'ALLOW',
                                'DENY': 'BLOCK',
                                'ESCALATE': 'WARN',
                                'ALLOW': 'ALLOW',
                                'WARN': 'WARN',
                                'BLOCK': 'BLOCK'
                            }
                            
                            # Get current decision and map it
                            current_decision = example.get('correct_decision', example.get('decision', 'BLOCK'))
                            mapped_decision = DECISION_MAP.get(current_decision, 'BLOCK')
                            
                            new_decision = st.selectbox(
                                "Decision",
                                ["ALLOW", "WARN", "BLOCK"],
                                index=["ALLOW", "WARN", "BLOCK"].index(mapped_decision),
                                key=f"decision_{selected_prompt['prompt_id']}_{i}"
                            )
                            example['correct_decision'] = new_decision
                            # Remove old 'decision' field if present
                            if 'decision' in example:
                                del example['decision']
                        
                        with col_fraud:
                            new_fraud_type = st.text_input(
                                "Fraud Type",
                                value=example.get('fraud_type', 'UNKNOWN'),
                                key=f"fraud_type_{selected_prompt['prompt_id']}_{i}"
                            )
                            example['fraud_type'] = new_fraud_type
                        
                        new_scenario = st.text_area(
                            "Scenario",
                            value=example.get('scenario', ''),
                            height=100,
                            key=f"scenario_{selected_prompt['prompt_id']}_{i}"
                        )
                        example['scenario'] = new_scenario
                        
                        new_reasoning = st.text_area(
                            "Reasoning",
                            value=example.get('reasoning', ''),
                            height=100,
                            key=f"reasoning_{selected_prompt['prompt_id']}_{i}"
                        )
                        example['reasoning'] = new_reasoning
                        
                        # Remove confidence if present (not needed in LLM)
                        if 'confidence' in example:
                            del example['confidence']
                        
                        if i < len(modified_examples):
                            st.markdown("---")
                    
                    # Remove marked examples
                    for idx in sorted(examples_to_remove, reverse=True):
                        del modified_examples[idx]
                        st.session_state[modified_key] = modified_examples
                        st.rerun()
                    
                    # Show info about changes
                    st.markdown("---")
                    st.info(f"📝 **{len(modified_examples)} examples ready** - Click 'Activate This Prompt' button above to save changes and activate this version.")
                    
                    # Show discard button
                    if st.button("🗑️ Discard Changes", key=f"discard_{selected_prompt['prompt_id']}", type="secondary"):
                        st.session_state[edit_key] = False
                        st.session_state[modified_key] = None
                        st.rerun()
                
                # VIEW MODE (for all prompts)
                else:
                    with st.expander(f"View {len(few_shot_examples)} Examples", expanded=False):
                        for i, example in enumerate(few_shot_examples, 1):
                            st.markdown(f"**Example {i}:**")
                            col1, col2 = st.columns([3, 1])
                            with col1:
                                st.markdown(f"**Decision:** `{example.get('correct_decision', example.get('decision', 'UNKNOWN'))}`")
                                st.markdown(f"**Fraud Type:** `{example.get('fraud_type', 'N/A')}`")
                                st.markdown(f"**Scenario:** {example.get('scenario', 'N/A')}")
                            with col2:
                                st.markdown(f"**Source:** `{example.get('source', 'N/A')}`")
                                if example.get('reward_score'):
                                    st.markdown(f"**Reward:** `{example.get('reward_score')}`")
                            
                            st.markdown("**Reasoning:**")
                            st.text_area(
                                label=f"Reasoning for Example {i}",
                                value=example.get('reasoning', 'N/A'),
                                height=80,
                                disabled=True,
                                key=f"view_reasoning_{selected_prompt['prompt_id']}_{i}",
                                label_visibility="collapsed"
                            )
                            
                            if i < len(few_shot_examples):
                                st.markdown("---")
            else:
                st.info("No few-shot examples in this version")

# ==================== TAB 3: Compare Versions ====================
with tab3:
    st.header("Compare Prompt Versions")
    st.markdown("Compare two prompt versions side by side to see differences.")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Version 1")
        event_type_1 = st.selectbox("Event Type", event_types, key="compare_event_1", format_func=lambda x: x[1])
        
        try:
            versions_1 = api.list_prompt_versions(event_type_1[0], limit=20)
            version_1 = st.selectbox(
                "Select Version",
                options=[v['prompt_id'] for v in versions_1],
                format_func=lambda x: next((f"v{v['version']} - {v['status']}" for v in versions_1 if v['prompt_id'] == x), x),
                key="compare_v1"
            )
        except Exception as e:
            st.error(f"Failed to load versions: {str(e)}")
            version_1 = None
    
    with col2:
        st.subheader("Version 2")
        event_type_2 = st.selectbox("Event Type", event_types, key="compare_event_2", format_func=lambda x: x[1])
        
        try:
            versions_2 = api.list_prompt_versions(event_type_2[0], limit=20)
            version_2 = st.selectbox(
                "Select Version",
                options=[v['prompt_id'] for v in versions_2],
                format_func=lambda x: next((f"v{v['version']} - {v['status']}" for v in versions_2 if v['prompt_id'] == x), x),
                key="compare_v2"
            )
        except Exception as e:
            st.error(f"Failed to load versions: {str(e)}")
            version_2 = None
    
    if st.button("🔍 Compare Prompts", type="primary") and version_1 and version_2:
        try:
            comparison = api.compare_prompts(version_1, version_2)
            
            st.success("Comparison loaded successfully!")
            
            # Display differences
            st.markdown("### 📊 Differences Summary")
            diff_cols = st.columns(3)
            with diff_cols[0]:
                st.metric("Version Change", comparison['differences']['version_diff'])
            with diff_cols[1]:
                st.metric("Status Change", comparison['differences']['status_diff'])
            with diff_cols[2]:
                st.metric("Template Words Changed", comparison['differences']['template_word_changes'])
            
            st.markdown("---")
            
            # Side by side comparison
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown(f"### Version {comparison['prompt_1'].get('version', 'N/A')}")
                st.markdown(f"**Status:** `{comparison['prompt_1'].get('status', 'N/A')}`")
                st.markdown(f"**Created:** {safe_parse_datetime(comparison['prompt_1'].get('created_at'))}")
                st.markdown("**Template:**")
                # Try both 'template' and 'system_prompt' keys
                template_1 = comparison['prompt_1'].get('template') or comparison['prompt_1'].get('system_prompt', 'No template available')
                st.code(template_1, language="text")
            
            with col2:
                st.markdown(f"### Version {comparison['prompt_2'].get('version', 'N/A')}")
                st.markdown(f"**Status:** `{comparison['prompt_2'].get('status', 'N/A')}`")
                st.markdown(f"**Created:** {safe_parse_datetime(comparison['prompt_2'].get('created_at'))}")
                st.markdown("**Template:**")
                # Try both 'template' and 'system_prompt' keys
                template_2 = comparison['prompt_2'].get('template') or comparison['prompt_2'].get('system_prompt', 'No template available')
                st.code(template_2, language="text")
            
        except Exception as e:
            st.error(f"Failed to compare prompts: {str(e)}")

# ==================== TAB 4: Create/Edit Prompt ====================
with tab4:
    st.header("Create or Update Prompt")
    
    mode = st.radio("Mode", ["Create New Prompt", "Update Existing Prompt"], horizontal=True)
    
    if mode == "Create New Prompt":
        st.markdown("### Create a New Prompt Version")
        
        event_type = st.selectbox("Event Type", event_types, key="create_event", format_func=lambda x: x[1])
        version = st.text_input("Version (e.g., 1.1, 2.0)", value="1.1")
        created_by = st.text_input("Created By", value=st.session_state.get('user_id', 'admin'))
        description = st.text_area("Description", placeholder="Describe what this prompt does or what changed...")
        
        template = st.text_area(
            "Prompt Template",
            placeholder="Enter the LLM prompt template here...",
            height=300
        )
        
        status = st.selectbox("Status", ["DRAFT", "ACTIVE"], key="create_status")
        
        if st.button("✅ Create Prompt", type="primary"):
            if not template or not event_type:
                st.error("Event type and template are required!")
            else:
                try:
                    new_prompt = api.create_prompt(
                        event_type=event_type[0],
                        template=template,
                        version=version,
                        description=description,
                        created_by=created_by,
                        status=status
                    )
                    st.success(f"✅ Created prompt version {new_prompt['version']} for {event_type[1]}!")
                    st.json(new_prompt)
                except Exception as e:
                    st.error(f"Failed to create prompt: {str(e)}")
    
    else:  # Update mode
        st.markdown("### Update Existing Prompt")
        
        event_type = st.selectbox("Event Type", event_types, key="update_event", format_func=lambda x: x[1])
        
        try:
            prompts = api.list_prompts(event_type=event_type[0], status="ACTIVE", limit=10)
            
            if prompts:
                prompt_to_update = st.selectbox(
                    "Select Prompt to Update",
                    options=[p['prompt_id'] for p in prompts],
                    format_func=lambda x: next((f"v{p['version']} - {p.get('description', 'No description')[:50]}" for p in prompts if p['prompt_id'] == x), x)
                )
                
                selected = next((p for p in prompts if p['prompt_id'] == prompt_to_update), None)
                
                if selected:
                    st.info(f"Updating prompt version {selected.get('version', 'N/A')}")
                    
                    updated_by = st.text_input("Updated By", value=st.session_state.get('user_id', 'admin'), key="updated_by")
                    description = st.text_area("Description", value=selected.get('description', ''), key="update_desc")
                    
                    template = st.text_area(
                        "Prompt Template",
                        value=selected.get('template', ''),
                        height=300,
                        key="update_template"
                    )
                    
                    if st.button("💾 Update Prompt", type="primary"):
                        try:
                            updated = api.update_prompt(
                                prompt_id=prompt_to_update,
                                template=template,
                                description=description,
                                updated_by=updated_by)
                            st.success(f"✅ Updated prompt! New version: {updated['version']}")
                            
                            # Mark all pending learning queue items for this event type as implemented
                            try:
                                learning_items = api.get_learning_queue(
                                    event_type=event_type[0],
                                    status="PENDING_REVIEW",  # Only get pending items
                                    limit=500
                                )
                                
                                # Filter for items that haven't been incorporated yet
                                # Check the correct field name: 'incorporated_into_prompt'
                                pending_items = [
                                    item for item in learning_items 
                                    if item.get('incorporated_into_prompt', 'false') != 'true'
                                    and item.get('status') != 'IMPLEMENTED'
                                ]
                                
                                if pending_items:
                                    marked_count = 0
                                    for item in pending_items:
                                        queue_id = item.get('queue_id')
                                        if queue_id:
                                            try:
                                                api.mark_as_implemented(
                                                    queue_id=queue_id,
                                                    implemented_by=updated_by,
                                                    notes=f"Incorporated into prompt version {updated['version']}"
                                                )
                                                marked_count += 1
                                            except Exception as mark_error:
                                                st.warning(f"Could not mark item {queue_id}: {mark_error}")
                                    
                                    if marked_count > 0:
                                        st.success(f"✅ Marked {marked_count} learning queue item(s) as implemented")
                            except Exception as queue_error:
                                st.warning(f"Note: Could not update learning queue items: {queue_error}")
                            
                            st.json(updated)
                        except Exception as e:
                            st.error(f"Failed to update prompt: {str(e)}")
            else:
                st.info("No active prompts found for this event type.")
                
        except Exception as e:
            st.error(f"Failed to load prompts: {str(e)}")

# ==================== TAB 4: Audit Trail ====================
with tab4:
    st.header("Prompt Audit Trail")
    st.markdown("Track all changes made to prompts for compliance and auditing.")
    
    event_type = st.selectbox("Event Type", event_types, key="audit_event", format_func=lambda x: x[1])
    limit = st.slider("Number of audit records", 10, 200, 50, key="audit_limit")
    
    if st.button("📊 Load Audit Trail", type="primary"):
        try:
            audit_trail = api.get_prompt_audit_trail(event_type[0], limit=limit)
            
            if audit_trail:
                st.success(f"Found {len(audit_trail)} audit records")
                
                # Convert to DataFrame
                df = pd.DataFrame(audit_trail)
                df['created_at'] = pd.to_datetime(df['created_at']).dt.strftime('%Y-%m-%d %H:%M:%S')
                
                # Display table
                st.dataframe(df, use_container_width=True)
                
                # Timeline visualization
                st.markdown("### 📈 Version Timeline")
                fig = px.timeline(
                    df,
                    x_start="created_at",
                    x_end="created_at",
                    y="version",
                    color="status",
                    title=f"Prompt Version Timeline for {event_type[1]}"
                )
                st.plotly_chart(fig, use_container_width=True)
                
                # Statistics
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Total Versions", len(audit_trail))
                with col2:
                    active_count = len([a for a in audit_trail if a['status'] == 'ACTIVE'])
                    st.metric("Active Versions", active_count)
                with col3:
                    unique_creators = len(set([a['created_by'] for a in audit_trail if a['created_by']]))
                    st.metric("Unique Contributors", unique_creators)
                
            else:
                st.info("No audit records found.")
                
        except Exception as e:
            st.error(f"Failed to load audit trail: {str(e)}")

# Sidebar with statistics
st.sidebar.header("📊 Prompt Statistics")
try:
    stats = api.get_prompt_statistics()
    st.sidebar.metric("Total Prompts", stats.get('total_prompts', 0))
    st.sidebar.metric("Active Prompts", stats.get('active_prompts', 0))
    st.sidebar.metric("Total Versions", stats.get('total_versions', 0))
    st.sidebar.metric("Event Types", stats.get('event_types', 0))
except:
    st.sidebar.info("Statistics not available")
