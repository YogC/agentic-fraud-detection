# Scripts Directory

This directory contains utility scripts for setting up and managing the fraud detection system.

## 📋 Available Scripts

### `setup_enhanced_prompts.py`

**Purpose:** Create or update default prompts in DynamoDB with production-ready configurations.

**What it does:**
1. Deletes all existing prompts from `FraudDetectionPrompts` table
2. Creates 3 enhanced default prompts:
   - **PAYMENT_FRAUD** - Payment fraud detection with comprehensive risk analysis
   - **PII_ACCESS** - PII access monitoring with insider threat detection
   - **DATA_MODIFICATION** - Data integrity monitoring with fraud pattern detection

**Features:**
- ✅ Detailed system prompts with decision frameworks
- ✅ 2 few-shot examples per event type (BLOCK and APPROVE scenarios)
- ✅ Production-ready guidance for SIU investigators
- ✅ Proper field mappings for UI compatibility

**Usage:**
```powershell
# From the Fraud-Internal-Detection directory
cd "c:\Yogesh\GenAI\Fraud Detection\Fraud-Internal-Detection"

# Run the script
python scripts\setup_enhanced_prompts.py
```

**When to use:**
- Initial setup of the system
- After clearing the prompts table
- When upgrading to enhanced prompt versions
- To reset prompts to baseline configuration

**Output:**
- Creates 3 ACTIVE prompts in DynamoDB
- Each prompt includes system prompt, few-shot examples, and metadata
- All prompts ready to use immediately

---

## 🔧 Other Scripts

### MCP and Environment Setup Scripts
- `fix_mcp_new.ps1` - Fix MCP package issues
- `setup_venv.bat` - Set up Python virtual environment
- `start_mcp_server.bat` - Start MCP server

### Testing Scripts
- Various test scripts for API scenarios and UI improvements

---

## 📝 Notes

- Always run scripts from the `Fraud-Internal-Detection` root directory
- Ensure AWS credentials are configured before running database scripts
- The `setup_enhanced_prompts.py` script will prompt for confirmation before making changes

---

## 🆘 Troubleshooting

**Error: "Float types are not supported"**
- Fixed in current version - uses Decimal types for DynamoDB compatibility

**Error: "Missing the key version_id"**
- Fixed in current version - includes all required DynamoDB keys

**Error: "No prompts found after creation"**
- Check AWS credentials and DynamoDB table permissions
- Verify `FraudDetectionPrompts` table exists in `us-east-1` region
