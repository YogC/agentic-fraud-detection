# Last Mile Payment Agent - Comprehensive Test Cases

## Overview
This document contains comprehensive test cases for the **Last Mile Payment Agent**, which detects risky payment actions after claim approval, including post-approval payee changes.

## Agent Information
- **Agent Name**: LastMilePaymentAgent
- **Primary Function**: Analyze last-mile payment risks
- **Risk Factors Analyzed**:
  - Payee destination changed AFTER claim approved
  - Short time window from approval to payee change (≤10 minutes)
  - Fast payment method (ACH_SAME_DAY, INSTANT, WIRE, RTP)
  - No customer verification for payee change

## Test Case Structure
Each test case includes:
- Test ID and description
- Input payload
- Expected output
- Risk level (LOW/MED/HIGH)
- Reason for risk assessment

---

## Test Cases

### Category 1: Baseline and Normal Operations

#### Test Case 1: Normal Approved Claim - No Risk
**Test ID**: LMP_TC_001  
**Description**: Approved claim with no payee changes - should return LOW risk  
**Risk Level**: LOW

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": null,
  "payment_method": "CHECK",
  "payment_release_request": false,
  "verification_flag": true,
  "payee_changed_after_approval": false
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "LOW",
  "reasons": [
    "No significant last-mile payment risks detected"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": null,
    "is_fast_payment_method": false,
    "payee_changed_post_approval": false,
    "verification_recorded": true,
    "risk_points": 0
  }
}
```

---

#### Test Case 2: Pending Claim - No Risk
**Test ID**: LMP_TC_002  
**Description**: Claim still pending approval - should return LOW risk  
**Risk Level**: LOW

**Input**:
```json
{
  "claim_status": "PENDING",
  "approval_timestamp": null,
  "payee_change_timestamp": null,
  "payment_method": "ACH",
  "payment_release_request": false,
  "verification_flag": true,
  "payee_changed_after_approval": false
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "LOW",
  "reasons": [
    "No significant last-mile payment risks detected"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": null,
    "is_fast_payment_method": false,
    "payee_changed_post_approval": false,
    "verification_recorded": true,
    "risk_points": 0
  }
}
```

---

### Category 2: Single Risk Factor (MEDIUM Risk)

#### Test Case 3: Payee Changed After Approval - MED Risk
**Test ID**: LMP_TC_003  
**Description**: Payee changed after claim approved, but with verification and no other risk factors  
**Risk Level**: MED

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": "2024-01-15T11:00:00Z",
  "payment_method": "CHECK",
  "payment_release_request": false,
  "verification_flag": true,
  "payee_changed_after_approval": true
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "MED",
  "reasons": [
    "⚠️ Payee destination changed AFTER claim was approved (last-mile risk)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": 60.0,
    "is_fast_payment_method": false,
    "payee_changed_post_approval": true,
    "verification_recorded": true,
    "risk_points": 1
  }
}
```

---

#### Test Case 4: Fast Payment Method with Release - MED Risk
**Test ID**: LMP_TC_004  
**Description**: Fast payment method (INSTANT) with payment release but no payee change  
**Risk Level**: MED

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": null,
  "payment_method": "INSTANT",
  "payment_release_request": true,
  "verification_flag": true,
  "payee_changed_after_approval": false
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "MED",
  "reasons": [
    "⚠️ Fast payment method detected: INSTANT (funds released quickly, hard to reverse)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": null,
    "is_fast_payment_method": true,
    "payee_changed_post_approval": false,
    "verification_recorded": true,
    "risk_points": 1
  }
}
```

---

### Category 3: Multiple Risk Factors (HIGH Risk)

#### Test Case 5: Post-Approval Payee Change + Short Time Window - HIGH Risk
**Test ID**: LMP_TC_005  
**Description**: Payee changed 5 minutes after approval - multiple risk factors  
**Risk Level**: HIGH

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": "2024-01-15T10:05:00Z",
  "payment_method": "ACH",
  "payment_release_request": false,
  "verification_flag": true,
  "payee_changed_after_approval": true
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "HIGH",
  "reasons": [
    "⚠️ Payee destination changed AFTER claim was approved (last-mile risk)",
    "⚠️ Payee changed within 5.0 minutes of approval (risky window: <=10 min)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": 5.0,
    "is_fast_payment_method": false,
    "payee_changed_post_approval": true,
    "verification_recorded": true,
    "risk_points": 2
  }
}
```

---

#### Test Case 6: Post-Approval Change + No Verification - HIGH Risk
**Test ID**: LMP_TC_006  
**Description**: Payee changed after approval without customer verification  
**Risk Level**: HIGH

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": "2024-01-15T10:15:00Z",
  "payment_method": "CHECK",
  "payment_release_request": false,
  "verification_flag": false,
  "payee_changed_after_approval": true
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "HIGH",
  "reasons": [
    "⚠️ Payee destination changed AFTER claim was approved (last-mile risk)",
    "⚠️ No customer verification recorded for payee change (potential unauthorized modification)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": 15.0,
    "is_fast_payment_method": false,
    "payee_changed_post_approval": true,
    "verification_recorded": false,
    "risk_points": 2
  }
}
```

---

#### Test Case 7: Post-Approval Change + Fast Payment Method - HIGH Risk
**Test ID**: LMP_TC_007  
**Description**: Payee changed after approval with WIRE transfer (fast payment)  
**Risk Level**: HIGH

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": "2024-01-15T10:20:00Z",
  "payment_method": "WIRE",
  "payment_release_request": true,
  "verification_flag": true,
  "payee_changed_after_approval": true
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "HIGH",
  "reasons": [
    "⚠️ Payee destination changed AFTER claim was approved (last-mile risk)",
    "⚠️ Fast payment method detected: WIRE (funds released quickly, hard to reverse)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": 20.0,
    "is_fast_payment_method": true,
    "payee_changed_post_approval": true,
    "verification_recorded": true,
    "risk_points": 2
  }
}
```

---

#### Test Case 8: Maximum Risk - All Factors Present - HIGH Risk
**Test ID**: LMP_TC_008  
**Description**: All risk factors present - payee change in 3 minutes, INSTANT payment, no verification  
**Risk Level**: HIGH

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": "2024-01-15T10:03:00Z",
  "payment_method": "INSTANT",
  "payment_release_request": true,
  "verification_flag": false,
  "payee_changed_after_approval": true
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "HIGH",
  "reasons": [
    "⚠️ Payee destination changed AFTER claim was approved (last-mile risk)",
    "⚠️ Payee changed within 3.0 minutes of approval (risky window: <=10 min)",
    "⚠️ Fast payment method detected: INSTANT (funds released quickly, hard to reverse)",
    "⚠️ No customer verification recorded for payee change (potential unauthorized modification)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": 3.0,
    "is_fast_payment_method": true,
    "payee_changed_post_approval": true,
    "verification_recorded": false,
    "risk_points": 4
  }
}
```

---

### Category 4: Payment Method Variations

#### Test Case 9: ACH_SAME_DAY Payment Method - MED Risk
**Test ID**: LMP_TC_009  
**Description**: ACH_SAME_DAY is a fast payment method  
**Risk Level**: MED

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": null,
  "payment_method": "ACH_SAME_DAY",
  "payment_release_request": true,
  "verification_flag": true,
  "payee_changed_after_approval": false
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "MED",
  "reasons": [
    "⚠️ Fast payment method detected: ACH_SAME_DAY (funds released quickly, hard to reverse)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": null,
    "is_fast_payment_method": true,
    "payee_changed_post_approval": false,
    "verification_recorded": true,
    "risk_points": 1
  }
}
```

---

#### Test Case 10: RTP (Real-Time Payment) Method - MED Risk
**Test ID**: LMP_TC_010  
**Description**: RTP (Real-Time Payment) is a fast payment method  
**Risk Level**: MED

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": null,
  "payment_method": "RTP",
  "payment_release_request": true,
  "verification_flag": true,
  "payee_changed_after_approval": false
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "MED",
  "reasons": [
    "⚠️ Fast payment method detected: RTP (funds released quickly, hard to reverse)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": null,
    "is_fast_payment_method": true,
    "payee_changed_post_approval": false,
    "verification_recorded": true,
    "risk_points": 1
  }
}
```

---

#### Test Case 11: Standard ACH - No Fast Payment Risk
**Test ID**: LMP_TC_011  
**Description**: Standard ACH is not considered a fast payment method  
**Risk Level**: LOW

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": null,
  "payment_method": "ACH",
  "payment_release_request": true,
  "verification_flag": true,
  "payee_changed_after_approval": false
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "LOW",
  "reasons": [
    "No significant last-mile payment risks detected"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": null,
    "is_fast_payment_method": false,
    "payee_changed_post_approval": false,
    "verification_recorded": true,
    "risk_points": 0
  }
}
```

---

### Category 5: Time Window Edge Cases

#### Test Case 12: Payee Change at 10 Minute Boundary - HIGH Risk
**Test ID**: LMP_TC_012  
**Description**: Payee changed exactly 10 minutes after approval (boundary condition)  
**Risk Level**: HIGH

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": "2024-01-15T10:10:00Z",
  "payment_method": "CHECK",
  "payment_release_request": false,
  "verification_flag": true,
  "payee_changed_after_approval": true
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "HIGH",
  "reasons": [
    "⚠️ Payee destination changed AFTER claim was approved (last-mile risk)",
    "⚠️ Payee changed within 10.0 minutes of approval (risky window: <=10 min)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": 10.0,
    "is_fast_payment_method": false,
    "payee_changed_post_approval": true,
    "verification_recorded": true,
    "risk_points": 2
  }
}
```

---

#### Test Case 13: Payee Change at 11 Minutes - MED Risk
**Test ID**: LMP_TC_013  
**Description**: Payee changed 11 minutes after approval (outside risky window)  
**Risk Level**: MED

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": "2024-01-15T10:11:00Z",
  "payment_method": "CHECK",
  "payment_release_request": false,
  "verification_flag": true,
  "payee_changed_after_approval": true
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "MED",
  "reasons": [
    "⚠️ Payee destination changed AFTER claim was approved (last-mile risk)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": 11.0,
    "is_fast_payment_method": false,
    "payee_changed_post_approval": true,
    "verification_recorded": true,
    "risk_points": 1
  }
}
```

---

#### Test Case 14: Payee Change After 1 Hour - MED Risk
**Test ID**: LMP_TC_014  
**Description**: Payee changed well after approval (60+ minutes) but still post-approval  
**Risk Level**: MED

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": "2024-01-15T11:30:00Z",
  "payment_method": "CHECK",
  "payment_release_request": false,
  "verification_flag": true,
  "payee_changed_after_approval": true
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "MED",
  "reasons": [
    "⚠️ Payee destination changed AFTER claim was approved (last-mile risk)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": 90.0,
    "is_fast_payment_method": false,
    "payee_changed_post_approval": true,
    "verification_recorded": true,
    "risk_points": 1
  }
}
```

---

### Category 6: Edge Cases and Data Validation

#### Test Case 15: Missing Approval Timestamp
**Test ID**: LMP_TC_015  
**Description**: Approval timestamp is null or missing  
**Risk Level**: LOW

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": null,
  "payee_change_timestamp": "2024-01-15T10:05:00Z",
  "payment_method": "ACH",
  "payment_release_request": false,
  "verification_flag": true,
  "payee_changed_after_approval": false
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "LOW",
  "reasons": [
    "No significant last-mile payment risks detected"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": null,
    "is_fast_payment_method": false,
    "payee_changed_post_approval": false,
    "verification_recorded": true,
    "risk_points": 0
  }
}
```

---

#### Test Case 16: Empty Payment Method
**Test ID**: LMP_TC_016  
**Description**: Payment method is empty string  
**Risk Level**: LOW

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": null,
  "payment_method": "",
  "payment_release_request": false,
  "verification_flag": true,
  "payee_changed_after_approval": false
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "LOW",
  "reasons": [
    "No significant last-mile payment risks detected"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": null,
    "is_fast_payment_method": false,
    "payee_changed_post_approval": false,
    "verification_recorded": true,
    "risk_points": 0
  }
}
```

---

#### Test Case 17: Case-Insensitive Payment Method
**Test ID**: LMP_TC_017  
**Description**: Payment method in lowercase should still be detected (instant)  
**Risk Level**: MED

**Input**:
```json
{
  "claim_status": "approved",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": null,
  "payment_method": "instant",
  "payment_release_request": true,
  "verification_flag": true,
  "payee_changed_after_approval": false
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "MED",
  "reasons": [
    "⚠️ Fast payment method detected: INSTANT (funds released quickly, hard to reverse)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": null,
    "is_fast_payment_method": true,
    "payee_changed_post_approval": false,
    "verification_recorded": true,
    "risk_points": 1
  }
}
```

---

#### Test Case 18: Fast Payment Without Release Request - LOW Risk
**Test ID**: LMP_TC_018  
**Description**: Fast payment method but payment_release_request is false  
**Risk Level**: LOW

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": null,
  "payment_method": "WIRE",
  "payment_release_request": false,
  "verification_flag": true,
  "payee_changed_after_approval": false
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "LOW",
  "reasons": [
    "No significant last-mile payment risks detected"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": null,
    "is_fast_payment_method": true,
    "payee_changed_post_approval": false,
    "verification_recorded": true,
    "risk_points": 0
  }
}
```

---

### Category 7: Complex Scenarios

#### Test Case 19: Payee Change Before Approval (Pre-Approval) - LOW Risk
**Test ID**: LMP_TC_019  
**Description**: Payee changed before approval (negative time delta) - should not trigger last-mile risk  
**Risk Level**: LOW

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:10:00Z",
  "payee_change_timestamp": "2024-01-15T10:00:00Z",
  "payment_method": "INSTANT",
  "payment_release_request": true,
  "verification_flag": false,
  "payee_changed_after_approval": false
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "MED",
  "reasons": [
    "⚠️ Fast payment method detected: INSTANT (funds released quickly, hard to reverse)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": -10.0,
    "is_fast_payment_method": true,
    "payee_changed_post_approval": false,
    "verification_recorded": false,
    "risk_points": 1
  }
}
```

---

#### Test Case 20: Rejected Claim with Payee Change - LOW Risk
**Test ID**: LMP_TC_020  
**Description**: Claim rejected, payee changed after rejection - should not trigger approval-based risk  
**Risk Level**: LOW

**Input**:
```json
{
  "claim_status": "REJECTED",
  "approval_timestamp": null,
  "payee_change_timestamp": "2024-01-15T10:05:00Z",
  "payment_method": "INSTANT",
  "payment_release_request": true,
  "verification_flag": false,
  "payee_changed_after_approval": false
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "MED",
  "reasons": [
    "⚠️ Fast payment method detected: INSTANT (funds released quickly, hard to reverse)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": null,
    "is_fast_payment_method": true,
    "payee_changed_post_approval": false,
    "verification_recorded": false,
    "risk_points": 1
  }
}
```

---

#### Test Case 21: Three Risk Factors Combined - HIGH Risk
**Test ID**: LMP_TC_021  
**Description**: Three risk factors: post-approval change, fast payment, no verification  
**Risk Level**: HIGH

**Input**:
```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2024-01-15T10:00:00Z",
  "payee_change_timestamp": "2024-01-15T11:00:00Z",
  "payment_method": "ACH_SAME_DAY",
  "payment_release_request": true,
  "verification_flag": false,
  "payee_changed_after_approval": true
}
```

**Expected Output**:
```json
{
  "last_mile_risk": "HIGH",
  "reasons": [
    "⚠️ Payee destination changed AFTER claim was approved (last-mile risk)",
    "⚠️ Fast payment method detected: ACH_SAME_DAY (funds released quickly, hard to reverse)",
    "⚠️ No customer verification recorded for payee change (potential unauthorized modification)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": 60.0,
    "is_fast_payment_method": true,
    "payee_changed_post_approval": true,
    "verification_recorded": false,
    "risk_points": 3
  }
}
```

---

## Test Execution Guide

### Prerequisites
1. Fraud detection API server running
2. Database with test claim records
3. API testing tool (Postman/Insomnia) configured

### Endpoint Information
- **Endpoint**: `/api/v1/lastmile-payment/analyze`
- **Method**: POST
- **Content-Type**: application/json

### Running Tests
1. Import the Insomnia collection (see `insomnia_collection.json`)
2. Execute tests in order from TC_001 to TC_021
3. Verify actual output matches expected output for each test
4. Document any deviations or failures

### Success Criteria
- All 21 test cases pass
- Risk levels match expected values
- Computed deltas are accurate
- All risk factors are correctly identified
- Edge cases handled gracefully

---

## Coverage Summary

| Category | Test Cases | Risk Levels |
|----------|------------|-------------|
| Baseline | 2 | LOW |
| Single Risk Factor | 2 | MED |
| Multiple Risk Factors | 4 | HIGH |
| Payment Methods | 3 | LOW-MED |
| Time Window Edge Cases | 3 | MED-HIGH |
| Edge Cases | 4 | LOW-MED |
| Complex Scenarios | 3 | LOW-HIGH |
| **Total** | **21** | **All Levels** |

### Risk Factor Coverage
- ✅ Post-approval payee change detection
- ✅ Short time window detection (≤10 minutes)
- ✅ Fast payment method detection (ACH_SAME_DAY, INSTANT, WIRE, RTP)
- ✅ Verification flag validation
- ✅ Multiple risk factor combinations
- ✅ Edge case handling (null timestamps, empty values)
- ✅ Case-insensitive input handling

---

## Notes
- All timestamps use ISO8601 format with UTC timezone
- Risk points system: 0 = LOW, 1 = MED, ≥2 = HIGH
- Fast payment methods: ACH_SAME_DAY, INSTANT, WIRE, RTP
- Risky time window: ≤10 minutes from approval to payee change
- Payment release request must be true for fast payment risk to trigger

## Privacy Compliance
- All test data uses fictional claim IDs and timestamps
- No PII (Personally Identifiable Information) included
- Test cases are production-ready and privacy-compliant
