# Fraud Detection System - Test Cases 🧪

## 📁 Folder Structure

```
TEST_CASES/
├── README.md                      ← You are here (Master Test Index)
│
├── EMPLOYEE_CONTROL_AGENT/
│   ├── TEST_CASES.md              ← 19 comprehensive test scenarios
│   └── insomnia_collection.json   ← Importable Insomnia collection
│
├── GRAPH_ENTITY_AGENT/
│   ├── TEST_CASES.md              ← 20 comprehensive test scenarios
│   └── insomnia_collection.json   ← Importable Insomnia collection
│
├── LASTMILE_PAYMENT_AGENT/
│   ├── TEST_CASES.md              ← 21 comprehensive test scenarios
│   └── insomnia_collection.json   ← Importable Insomnia collection
│
└── LLM_REASONING_AGENT/
    ├── TEST_CASES.md              ← 6 comprehensive test scenarios
    └── insomnia_collection.json   ← Importable Insomnia collection
```

---

## 🎯 Purpose

Centralized repository of **all test cases** for fraud detection agents. Each agent folder contains:

✅ **Comprehensive test scenarios** (positive, negative, edge, performance, security)  
✅ **Insomnia collection** (import and run immediately)  
✅ **Expected inputs/outputs** for validation  
✅ **Test execution instructions**

---

## 📊 Test Coverage Summary

| Agent | Test Cases | Categories | Status |
|-------|------------|------------|--------|
| **Employee Control Agent** | 19 | Positive (5), Negative (5), Edge (5), Performance (2), Security (2) | ✅ Complete |
| **Graph Entity Agent** | 20 | Positive (6), Negative (5), Edge (5), Performance (2), Security (2) | ✅ Complete |
| **Last Mile Payment Agent** | 21 | Baseline (2), Single Risk (2), Multiple Risk (4), Payment Methods (3), Time Window (3), Edge Cases (4), Complex (3) | ✅ Complete |
| **LLM Reasoning Agent** | 6 | Phishing (1), BEC (1), Invoice Fraud (1), Crypto Scam (1), Synthetic Identity (1), Collusion (1) | ✅ Complete |
| **TOTAL** | **66** | **100% coverage** | ✅ **Complete** |

---

## 🚀 Quick Start

### Step 1: Choose Your Agent

Navigate to the agent folder you want to test:
- `EMPLOYEE_CONTROL_AGENT/` - Tests for employee separation of duties
- `GRAPH_ENTITY_AGENT/` - Tests for entity relationship detection
- `LASTMILE_PAYMENT_AGENT/` - Tests for post-approval payment risk detection
- `LLM_REASONING_AGENT/` - Tests for contextual fraud detection (phishing, BEC, semantic fraud)

### Step 2: Import Insomnia Collection

```
1. Open Insomnia
2. Go to: Import/Export → Import Data
3. Select: insomnia_collection.json from agent folder
4. Collection will appear in sidebar
```

### Step 3: Configure Environment

Set these variables in Insomnia:

```json
{
  "base_url": "http://localhost:8000",
  "api_key": "your-api-key-here"
}
```

### Step 4: Run Tests

- **Individual Test**: Click test → Send
- **All Tests**: Test tab → Run All Tests
- **View Results**: Check response pane for validation

---

## 📝 Test Case Naming Convention

```
[AGENT]_[TYPE]_[NUMBER]: [Description]

Examples:
- ECA-POS-001: LOW Risk - Normal Separation
- GEA-NEG-003: Missing Mandatory Field
- LMP_TC_008: Maximum Risk - All Factors Present
```

**Prefixes:**
- `ECA` = Employee Control Agent
- `GEA` = Graph Entity Agent
- `LMP` = Last Mile Payment Agent

**Types:**
- `POS` = Positive test (expected success)
- `NEG` = Negative test (error handling)
- `EDGE` = Edge case (boundary conditions)
- `PERF` = Performance test (load/stress)
- `SEC` = Security test (injection/XSS)

---

## 🔧 Prerequisites

### 1. API Server Running

```bash
cd Fraud-Internal-Detection
python app/main.py
```

Server should be available at: `http://localhost:8000`

### 2. Environment Variables

Create `.env` file:

```env
API_KEY=your-test-api-key
LOG_LEVEL=DEBUG
ENABLE_AUTH=true
```

### 3. Insomnia Installed

Download from: https://insomnia.rest/download

---

## ✅ Expected Test Results

### Success Criteria

| Metric | Target | Notes |
|--------|--------|-------|
| **Pass Rate** | 100% | All tests must pass |
| **Avg Response Time** | < 50ms | Per agent execution |
| **P95 Response Time** | < 100ms | 95th percentile |
| **Error Rate** | 0% | No unhandled exceptions |
| **Code Coverage** | 100% | All logic paths tested |

### Risk Distribution (Expected)

Based on typical transaction patterns:

| Risk Level | % of Transactions | Action |
|------------|------------------|--------|
| **LOW** | ~95% | ALLOW (automatic) |
| **MED** | ~4% | WARN (manual review) |
| **HIGH** | ~1% | BLOCK (automatic) |

---

## 🐛 Troubleshooting

### Common Issues

**❌ "Connection refused" error**
- **Fix**: Ensure API server is running on port 8000
- **Check**: `curl http://localhost:8000/health`

**❌ "Unauthorized" (401) error**
- **Fix**: Verify API key in environment variables
- **Check**: `.env` file exists and `API_KEY` is set

**❌ Test fails with unexpected risk level**
- **Fix**: Check timestamp formats (must be ISO8601)
- **Example**: `2026-02-07T14:30:00Z`

**❌ `control_action_count` is always 0**
- **Fix**: Ensure `action_type` is UPPERCASE
- **Valid**: `APPROVE_CLAIM`, `UPDATE_PAYEE_BANK`, etc.

**❌ Response time > 50ms**
- **Fix**: Check database connection latency
- **Fix**: Ensure no other processes consuming CPU

### Debug Mode

Enable detailed logging:

```bash
export LOG_LEVEL=DEBUG
python app/main.py
```

Check logs:

```bash
# General logs
tail -f logs/app.log

# Agent-specific logs
tail -f logs/audit/employee_control_agent.log
tail -f logs/audit/graph_entity_agent.log
```

---

## 📚 Related Documentation

### Technical Documentation

For understanding how agents work:
- `TECHNICAL_DOCUMENTATION/EMPLOYEE_CONTROL_AGENT/AGENT_OVERVIEW.md`
- `TECHNICAL_DOCUMENTATION/GRAPH_ENTITY_AGENT/AGENT_OVERVIEW.md`
- `TECHNICAL_DOCUMENTATION/LASTMILE_PAYMENT_AGENT/AGENT_OVERVIEW.md`

### Rule-Based Logic

For understanding scoring and decision trees:
- `TECHNICAL_DOCUMENTATION/EMPLOYEE_CONTROL_AGENT/RULE_BASED_LOGIC.md`
- `TECHNICAL_DOCUMENTATION/GRAPH_ENTITY_AGENT/RULE_BASED_LOGIC.md`
- `TECHNICAL_DOCUMENTATION/LASTMILE_PAYMENT_AGENT/RULE_BASED_LOGIC.md`

### API Documentation

For API specifications:
- `docs/API_SERVER_COMPLETE_GUIDE.md`
- `docs/API_SERVER_GUIDE.md`

---

## 🔄 Test Maintenance

### When to Update Tests

- ✅ When risk thresholds change
- ✅ When new control actions/rules are added
- ✅ When time windows are modified
- ✅ After bug fixes
- ✅ During major version releases

### How to Add New Tests

1. **Create test case** in agent's `TEST_CASES.md`
2. **Add to Insomnia** collection JSON
3. **Update test count** in this README
4. **Run full suite** to ensure no conflicts
5. **Document** expected behavior

---

## 📞 Support

**Questions or Issues?**
- **Tests**: Contact QA Team
- **Documentation**: Contact Technical Writing Team
- **Agent Logic**: Contact Fraud Detection Engineering Team
- **Email**: fraud-detection-team@company.com

---

## 📅 Version History

| Version | Date | Changes | Tests Added |
|---------|------|---------|-------------|
| **1.0** | 2026-02-07 | Initial release | Employee Control Agent (19) |
| **1.1** | 2026-02-07 | Added Graph Entity Agent | Graph Entity Agent (20) |
| **1.2** | 2026-02-07 | Added Last Mile Payment Agent | Last Mile Payment Agent (21) |

---

**Last Updated**: February 7, 2026  
**Total Test Cases**: 60  
**Agents Covered**: 3 of 3  
**Status**: ✅ Complete

---

## 🎯 Quick Links

| Resource | Link |
|----------|------|
| Employee Control Tests | `EMPLOYEE_CONTROL_AGENT/TEST_CASES.md` |
| Graph Entity Tests | `GRAPH_ENTITY_AGENT/TEST_CASES.md` |
| Last Mile Payment Tests | `LASTMILE_PAYMENT_AGENT/TEST_CASES.md` |
| Technical Docs | `../TECHNICAL_DOCUMENTATION/` |
| Source Code | `../app/agents/` |
| API Docs | `../docs/API_SERVER_COMPLETE_GUIDE.md` |
