# Graph Entity Agent - Complete Test Cases 🧪

## Test Suite Overview

**Total Test Cases**: 20  
**Coverage**: 100% of agent logic  
**Test Categories**: Positive, Negative, Edge Cases, Performance, Security

---

## Test Categories

| Category | Count | Purpose |
|----------|-------|---------|
| **Positive Tests** | 6 | Validate correct risk classification |
| **Negative Tests** | 5 | Error handling and validation |
| **Edge Cases** | 5 | Boundary conditions and special scenarios |
| **Performance Tests** | 2 | Load and concurrency testing |
| **Security Tests** | 2 | Injection and sanitization |
| **TOTAL** | **20** | Complete coverage |

---

# POSITIVE TEST CASES ✅

## Test Case GEA-POS-001: LOW Risk - First Time Use

**Test ID**: `GEA-POS-001`  
**Category**: Positive  
**Risk Level**: LOW  
**Objective**: Verify that a first-time account with no history returns LOW risk

### Input

```json
{
  "bank_account_hash": "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2",
  "claim_id": "CLM-2026-001",
  "claimant_id": "CLMT-10001",
  "employee_id": "EMP-5001",
  "account_pattern": "FIRST_USE",
  "payee_changed_post_approval": false
}
```

### Expected Output

```json
{
  "entity_risk": "LOW",
  "reasons": [
    "No significant entity linkage risks detected"
  ],
  "link_metrics": {
    "distinct_claims_count": 1,
    "distinct_claimants_count": 1,
    "distinct_employees_count": 1,
    "same_employee_reuse_count": 1,
    "account_pattern": "FIRST_USE",
    "is_new_account": true,
    "risk_points": 0
  }
}
```

### Validation Criteria

- ✅ `entity_risk` = "LOW"
- ✅ `risk_points` = 0
- ✅ No rules triggered
- ✅ Response time < 50ms

---

## Test Case GEA-POS-002: MED Risk - Rule 2 Triggered (Multiple Claims)

**Test ID**: `GEA-POS-002`  
**Category**: Positive  
**Risk Level**: MED  
**Objective**: Verify Rule 2 detection (same account, multiple claims)

### Setup

**Step 1**: Send first transaction
```json
{
  "bank_account_hash": "b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3",
  "claim_id": "CLM-2026-100",
  "claimant_id": "CLMT-20001",
  "employee_id": "EMP-6001",
  "account_pattern": "FIRST_USE",
  "payee_changed_post_approval": false
}
```

**Step 2**: Send second transaction (same account, different claim)
```json
{
  "bank_account_hash": "b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3",
  "claim_id": "CLM-2026-101",
  "claimant_id": "CLMT-20001",
  "employee_id": "EMP-6002",
  "account_pattern": "REUSED_ACROSS_CLAIMS",
  "payee_changed_post_approval": false
}
```

### Expected Output (Step 2)

```json
{
  "entity_risk": "MED",
  "reasons": [
    "⚠️ Bank account used in 2 distinct claims (possible pattern of reuse)"
  ],
  "link_metrics": {
    "distinct_claims_count": 2,
    "distinct_claimants_count": 1,
    "distinct_employees_count": 2,
    "same_employee_reuse_count": 1,
    "account_pattern": "REUSED_ACROSS_CLAIMS",
    "is_new_account": false,
    "risk_points": 1
  }
}
```

### Validation Criteria

- ✅ `entity_risk` = "MED"
- ✅ `risk_points` = 1
- ✅ Rule 2 triggered
- ✅ `distinct_claims_count` = 2

---

## Test Case GEA-POS-003: MED Risk - Rule 1 Triggered (Multiple Claimants)

**Test ID**: `GEA-POS-003`  
**Category**: Positive  
**Risk Level**: MED  
**Objective**: Verify Rule 1 detection (fraud ring - different claimants, same account)

### Setup

**Step 1**: First claimant
```json
{
  "bank_account_hash": "c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4",
  "claim_id": "CLM-2026-200",
  "claimant_id": "CLMT-30001",
  "employee_id": "EMP-7001",
  "account_pattern": "FIRST_USE",
  "payee_changed_post_approval": false
}
```

**Step 2**: Second claimant (DIFFERENT), same account
```json
{
  "bank_account_hash": "c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4",
  "claim_id": "CLM-2026-201",
  "claimant_id": "CLMT-30002",
  "employee_id": "EMP-7002",
  "account_pattern": "REUSED_ACROSS_CLAIMS",
  "payee_changed_post_approval": false
}
```

### Expected Output (Step 2)

```json
{
  "entity_risk": "MED",
  "reasons": [
    "🚨 Bank account reused across 2 different claimants (possible money mule or fraud ring)",
    "⚠️ Bank account used in 2 distinct claims (possible pattern of reuse)"
  ],
  "link_metrics": {
    "distinct_claims_count": 2,
    "distinct_claimants_count": 2,
    "distinct_employees_count": 2,
    "same_employee_reuse_count": 1,
    "account_pattern": "REUSED_ACROSS_CLAIMS",
    "is_new_account": false,
    "risk_points": 3
  }
}
```

### Validation Criteria

- ✅ `entity_risk` = "MED" or "HIGH" (3 points is boundary)
- ✅ `risk_points` = 3
- ✅ Rule 1 and Rule 2 triggered
- ✅ `distinct_claimants_count` = 2

---

## Test Case GEA-POS-004: HIGH Risk - Rule 3 Triggered (Employee Collusion)

**Test ID**: `GEA-POS-004`  
**Category**: Positive  
**Risk Level**: HIGH  
**Objective**: Verify Rule 3 detection (same employee, multiple claims to same account)

### Setup

**Step 1**: First transaction by employee
```json
{
  "bank_account_hash": "d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5",
  "claim_id": "CLM-2026-300",
  "claimant_id": "CLMT-40001",
  "employee_id": "EMP-8888",
  "account_pattern": "FIRST_USE",
  "payee_changed_post_approval": false
}
```

**Step 2**: Second transaction by SAME employee, same account
```json
{
  "bank_account_hash": "d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5",
  "claim_id": "CLM-2026-301",
  "claimant_id": "CLMT-40002",
  "employee_id": "EMP-8888",
  "account_pattern": "REUSED_ACROSS_CLAIMS",
  "payee_changed_post_approval": false
}
```

### Expected Output (Step 2)

```json
{
  "entity_risk": "HIGH",
  "reasons": [
    "🚨 Bank account reused across 2 different claimants (possible money mule or fraud ring)",
    "⚠️ Bank account used in 2 distinct claims (possible pattern of reuse)",
    "🚨 Same employee (EMP-8888) repeatedly directed payments to this account (2 times)"
  ],
  "link_metrics": {
    "distinct_claims_count": 2,
    "distinct_claimants_count": 2,
    "distinct_employees_count": 1,
    "same_employee_reuse_count": 2,
    "account_pattern": "REUSED_ACROSS_CLAIMS",
    "is_new_account": false,
    "risk_points": 5
  }
}
```

### Validation Criteria

- ✅ `entity_risk` = "HIGH"
- ✅ `risk_points` = 5
- ✅ Rules 1, 2, and 3 triggered
- ✅ `distinct_employees_count` = 1

---

## Test Case GEA-POS-005: MED Risk - Rule 4 Triggered (New Account + Post-Approval Change)

**Test ID**: `GEA-POS-005`  
**Category**: Positive  
**Risk Level**: MED  
**Objective**: Verify Rule 4 detection (account hijacking pattern)

### Input

```json
{
  "bank_account_hash": "e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6",
  "claim_id": "CLM-2026-400",
  "claimant_id": "CLMT-50001",
  "employee_id": "EMP-9001",
  "account_pattern": "FIRST_USE",
  "payee_changed_post_approval": true
}
```

### Expected Output

```json
{
  "entity_risk": "MED",
  "reasons": [
    "⚠️ New bank account with post-approval payee change (elevated risk for first-time account)"
  ],
  "link_metrics": {
    "distinct_claims_count": 1,
    "distinct_claimants_count": 1,
    "distinct_employees_count": 1,
    "same_employee_reuse_count": 1,
    "account_pattern": "FIRST_USE",
    "is_new_account": true,
    "risk_points": 1
  }
}
```

### Validation Criteria

- ✅ `entity_risk` = "MED"
- ✅ `risk_points` = 1
- ✅ Rule 4 triggered
- ✅ `is_new_account` = true

---

## Test Case GEA-POS-006: HIGH Risk - All Rules Triggered (Perfect Storm)

**Test ID**: `GEA-POS-006`  
**Category**: Positive  
**Risk Level**: HIGH  
**Objective**: Verify maximum risk detection when all 4 rules trigger

### Setup

Execute 3 transactions to build registry state:

**Transaction 1**:
```json
{
  "bank_account_hash": "f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7",
  "claim_id": "CLM-2026-500",
  "claimant_id": "CLMT-60001",
  "employee_id": "EMP-9999",
  "account_pattern": "FIRST_USE",
  "payee_changed_post_approval": true
}
```

**Transaction 2**:
```json
{
  "bank_account_hash": "f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7",
  "claim_id": "CLM-2026-501",
  "claimant_id": "CLMT-60002",
  "employee_id": "EMP-9999",
  "account_pattern": "REUSED_ACROSS_CLAIMS",
  "payee_changed_post_approval": false
}
```

**Transaction 3** (Test Target):
```json
{
  "bank_account_hash": "f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7",
  "claim_id": "CLM-2026-502",
  "claimant_id": "CLMT-60003",
  "employee_id": "EMP-9999",
  "account_pattern": "REUSED_ACROSS_CLAIMS",
  "payee_changed_post_approval": false
}
```

### Expected Output (Transaction 3)

```json
{
  "entity_risk": "HIGH",
  "reasons": [
    "🚨 Bank account reused across 3 different claimants (possible money mule or fraud ring)",
    "⚠️ Bank account used in 3 distinct claims (possible pattern of reuse)",
    "🚨 Same employee (EMP-9999) repeatedly directed payments to this account (3 times)",
    "⚠️ New bank account with post-approval payee change (elevated risk for first-time account)"
  ],
  "link_metrics": {
    "distinct_claims_count": 3,
    "distinct_claimants_count": 3,
    "distinct_employees_count": 1,
    "same_employee_reuse_count": 3,
    "account_pattern": "REUSED_ACROSS_CLAIMS",
    "is_new_account": false,
    "risk_points": 6
  }
}
```

### Validation Criteria

- ✅ `entity_risk` = "HIGH"
- ✅ `risk_points` = 6 (maximum)
- ✅ All 4 rules triggered
- ✅ Multiple critical alerts

---

# NEGATIVE TEST CASES ❌

## Test Case GEA-NEG-001: Missing Mandatory Field (bank_account_hash)

**Test ID**: `GEA-NEG-001`  
**Category**: Negative  
**Objective**: Verify error handling when mandatory field is missing

### Input

```json
{
  "claim_id": "CLM-2026-600",
  "claimant_id": "CLMT-70001",
  "employee_id": "EMP-10001",
  "account_pattern": "FIRST_USE"
}
```

### Expected Output

```json
{
  "entity_risk": "LOW",
  "reasons": [
    "Error in analysis: 'bank_account_hash'"
  ],
  "link_metrics": {}
}
```

### Validation Criteria

- ✅ Error handled gracefully (no crash)
- ✅ Default to LOW risk (fail-safe)
- ✅ Error message in reasons
- ✅ HTTP 200 (not 500)

---

## Test Case GEA-NEG-002: Missing claim_id

**Test ID**: `GEA-NEG-002`  
**Category**: Negative

### Input

```json
{
  "bank_account_hash": "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2",
  "claimant_id": "CLMT-70002",
  "employee_id": "EMP-10002",
  "account_pattern": "FIRST_USE"
}
```

### Expected Output

```json
{
  "entity_risk": "LOW",
  "reasons": [
    "Error in analysis: 'claim_id'"
  ],
  "link_metrics": {}
}
```

---

## Test Case GEA-NEG-003: Invalid account_pattern Value

**Test ID**: `GEA-NEG-003`  
**Category**: Negative

### Input

```json
{
  "bank_account_hash": "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2",
  "claim_id": "CLM-2026-700",
  "claimant_id": "CLMT-70003",
  "employee_id": "EMP-10003",
  "account_pattern": "INVALID_PATTERN"
}
```

### Expected Output

Should still process (treat as unknown pattern):

```json
{
  "entity_risk": "LOW",
  "reasons": [
    "No significant entity linkage risks detected"
  ],
  "link_metrics": {
    "distinct_claims_count": 1,
    "distinct_claimants_count": 1,
    "distinct_employees_count": 1,
    "account_pattern": "INVALID_PATTERN",
    "is_new_account": false,
    "risk_points": 0
  }
}
```

---

## Test Case GEA-NEG-004: Malformed JSON

**Test ID**: `GEA-NEG-004`  
**Category**: Negative

### Input

```
{
  "bank_account_hash": "a1b2c3...",
  "claim_id": "CLM-2026-800",
  "claimant_id": "CLMT-70004"
  // Missing closing brace
```

### Expected Output

HTTP 400 Bad Request

```json
{
  "error": "Invalid JSON",
  "message": "Request body is not valid JSON"
}
```

---

## Test Case GEA-NEG-005: Empty String for Mandatory Fields

**Test ID**: `GEA-NEG-005`  
**Category**: Negative

### Input

```json
{
  "bank_account_hash": "",
  "claim_id": "",
  "claimant_id": "CLMT-70005",
  "employee_id": "EMP-10005",
  "account_pattern": "FIRST_USE"
}
```

### Expected Output

```json
{
  "entity_risk": "LOW",
  "reasons": [
    "Error in analysis: empty required field"
  ],
  "link_metrics": {}
}
```

---

# EDGE CASES 🔍

## Test Case GEA-EDGE-001: Exactly at Threshold (2 claimants)

**Test ID**: `GEA-EDGE-001`  
**Category**: Edge Case  
**Objective**: Verify behavior at exact threshold boundary

### Setup

Transaction 1 and 2 with `distinct_claimants = 2`

### Expected Output

Rule 1 should trigger at exactly 2 claimants:

```json
{
  "entity_risk": "MED",
  "reasons": [
    "🚨 Bank account reused across 2 different claimants (possible money mule or fraud ring)",
    "⚠️ Bank account used in 2 distinct claims (possible pattern of reuse)"
  ],
  "link_metrics": {
    "distinct_claimants_count": 2,
    "risk_points": 3
  }
}
```

---

## Test Case GEA-EDGE-002: Same Claimant, Multiple Claims (No Rule 1)

**Test ID**: `GEA-EDGE-002`  
**Category**: Edge Case

### Setup

2 claims, same claimant, same account

### Expected Output

Only Rule 2 triggers (not Rule 1):

```json
{
  "entity_risk": "MED",
  "reasons": [
    "⚠️ Bank account used in 2 distinct claims (possible pattern of reuse)"
  ],
  "link_metrics": {
    "distinct_claims_count": 2,
    "distinct_claimants_count": 1,
    "risk_points": 1
  }
}
```

---

## Test Case GEA-EDGE-003: Null employee_id

**Test ID**: `GEA-EDGE-003`  
**Category**: Edge Case

### Input

```json
{
  "bank_account_hash": "a1b2c3d4...",
  "claim_id": "CLM-2026-900",
  "claimant_id": "CLMT-80001",
  "employee_id": null,
  "account_pattern": "FIRST_USE"
}
```

### Expected Output

Should default to 'unknown' and process normally

---

## Test Case GEA-EDGE-004: Very Long Hash (256 characters)

**Test ID**: `GEA-EDGE-004`  
**Category**: Edge Case

### Input

```json
{
  "bank_account_hash": "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0",
  "claim_id": "CLM-2026-950",
  "claimant_id": "CLMT-80002",
  "account_pattern": "FIRST_USE"
}
```

### Expected Output

Should process without truncation

---

## Test Case GEA-EDGE-005: Registry Reset Mid-Session

**Test ID**: `GEA-EDGE-005`  
**Category**: Edge Case

### Scenario

1. Build up registry with multiple entries
2. Call `GraphEntityLinkAgent.reset_registry()`
3. Send same transaction again

### Expected Output

After reset, should behave as first-time use:

```json
{
  "entity_risk": "LOW",
  "reasons": [
    "No significant entity linkage risks detected"
  ],
  "link_metrics": {
    "distinct_claims_count": 1,
    "distinct_claimants_count": 1,
    "distinct_employees_count": 1,
    "risk_points": 0
  }
}
```

---

# PERFORMANCE TESTS ⚡

## Test Case GEA-PERF-001: Large Registry (1000 accounts)

**Test ID**: `GEA-PERF-001`  
**Category**: Performance  
**Objective**: Verify performance with large registry

### Setup

Pre-populate registry with 1000 unique accounts

### Test

Send query for account #500

### Expected Performance

- ✅ Response time < 50ms
- ✅ Memory usage < 100MB
- ✅ Correct result returned

---

## Test Case GEA-PERF-002: Concurrent Requests (100 simultaneous)

**Test ID**: `GEA-PERF-002`  
**Category**: Performance

### Setup

Send 100 concurrent requests with different accounts

### Expected Performance

- ✅ All requests succeed
- ✅ P95 latency < 100ms
- ✅ No race conditions
- ✅ Registry integrity maintained

---

# SECURITY TESTS 🔒

## Test Case GEA-SEC-001: SQL Injection Attempt

**Test ID**: `GEA-SEC-001`  
**Category**: Security

### Input

```json
{
  "bank_account_hash": "'; DROP TABLE accounts; --",
  "claim_id": "CLM-2026-999",
  "claimant_id": "CLMT-90001",
  "account_pattern": "FIRST_USE"
}
```

### Expected Output

Treat as normal hash (no SQL execution):

```json
{
  "entity_risk": "LOW",
  "reasons": [
    "No significant entity linkage risks detected"
  ],
  "link_metrics": {
    "distinct_claims_count": 1
  }
}
```

---

## Test Case GEA-SEC-002: XSS Attempt in Reasons Field

**Test ID**: `GEA-SEC-002`  
**Category**: Security

### Input

```json
{
  "bank_account_hash": "<script>alert('XSS')</script>",
  "claim_id": "CLM-2026-1000",
  "claimant_id": "CLMT-90002",
  "account_pattern": "FIRST_USE"
}
```

### Expected Output

Hash should be sanitized/escaped in output

---

# Test Execution Instructions

## Prerequisites

1. **Reset Registry** before each test run:
   ```python
   GraphEntityLinkAgent.reset_registry()
   ```

2. **API Server** must be running:
   ```bash
   python app/main.py
   ```

3. **Insomnia Collection**: Import `insomnia_collection_graph_entity.json`

## Running Tests

### Individual Test

```bash
curl -X POST http://localhost:8000/api/v1/analyze-graph-entity \
  -H "Content-Type: application/json" \
  -d @test_case_gea_pos_001.json
```

### Full Suite

```bash
python run_graph_entity_tests.py
```

## Success Criteria

| Metric | Target |
|--------|--------|
| Pass Rate | 100% |
| Avg Response Time | < 50ms |
| P95 Response Time | < 100ms |
| Error Rate | 0% |

---

**Last Updated**: February 7, 2026  
**Test Suite Version**: 1.0  
**Total Tests**: 20
