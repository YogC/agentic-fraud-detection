# Employee Control Agent - Test Case Suite

## Overview
This document contains **comprehensive test cases** for the Employee Control Agent, covering all possible scenarios. Each test case can be executed via Insomnia, Postman, or any REST client.

---

## Table of Contents
1. [Test Environment Setup](#test-environment-setup)
2. [Positive Test Cases](#positive-test-cases)
3. [Negative Test Cases](#negative-test-cases)
4. [Edge Cases](#edge-cases)
5. [Performance Test Cases](#performance-test-cases)
6. [Security Test Cases](#security-test-cases)

---

## Test Environment Setup

### API Endpoint
```
POST http://localhost:8000/api/v1/analyze-employee-control
Content-Type: application/json
```

### Authentication
```
Authorization: Bearer <your-api-key>
```

---

## Positive Test Cases

### Test Case 1: Normal Separation of Duties (LOW Risk)

**Test ID**: `ECA-POS-001`  
**Description**: Different employees handle different control actions  
**Expected Result**: `control_risk: LOW`, `score: 0`

**Request Body**:
```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-9999",
    "timestamp": "2026-02-07T14:45:00Z",
    "claim_id": "CLM-123456",
    "payment_id": "PAY-789012"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-1111",
      "timestamp": "2026-02-07T14:30:00Z",
      "claim_id": "CLM-123456"
    },
    {
      "action_type": "UPDATE_PAYEE_BANK",
      "employee_id": "EMP-2222",
      "timestamp": "2026-02-07T14:35:00Z",
      "claim_id": "CLM-123456"
    }
  ],
  "actor_role": "Payment Processor"
}
```

**Expected Response**:
```json
{
  "control_risk": "LOW",
  "reasons": [
    "Normal separation of duties maintained"
  ],
  "metrics": {
    "control_action_count": 1,
    "time_window_minutes": 0.0,
    "actions_detected": ["RELEASE_PAYMENT"],
    "employee_id": "EMP-9999",
    "actor_role": "Payment Processor"
  }
}
```

**Validation**:
- ✅ `control_risk` = "LOW"
- ✅ `control_action_count` = 1
- ✅ `actions_detected` contains only "RELEASE_PAYMENT"
- ✅ Response time < 50ms

---

### Test Case 2: Moderate Risk - Two Control Actions (MED Risk)

**Test ID**: `ECA-POS-002`  
**Description**: Same employee performs 2 control actions within time window  
**Expected Result**: `control_risk: MED`, `score: 5`

**Request Body**:
```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07T14:45:00Z",
    "claim_id": "CLM-123456",
    "payment_id": "PAY-789012"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:30:00Z",
      "claim_id": "CLM-123456"
    },
    {
      "action_type": "UPDATE_PAYEE_BANK",
      "employee_id": "EMP-9999",
      "timestamp": "2026-02-07T14:35:00Z",
      "claim_id": "CLM-123456"
    }
  ],
  "actor_role": "Claims Adjuster"
}
```

**Expected Response**:
```json
{
  "control_risk": "MED",
  "reasons": [
    "Employee performed 2 control actions within 15.0 minutes: APPROVE_CLAIM, RELEASE_PAYMENT",
    "Medium risk: Lack of separation of duties"
  ],
  "metrics": {
    "control_action_count": 2,
    "time_window_minutes": 15.0,
    "actions_detected": ["APPROVE_CLAIM", "RELEASE_PAYMENT"],
    "employee_id": "EMP-5678",
    "actor_role": "Claims Adjuster"
  }
}
```

**Validation**:
- ✅ `control_risk` = "MED"
- ✅ `control_action_count` = 2
- ✅ `time_window_minutes` ≈ 15.0
- ✅ `reasons` contains "Lack of separation of duties"

---

### Test Case 3: High Risk - Three Control Actions (HIGH Risk)

**Test ID**: `ECA-POS-003`  
**Description**: Same employee performs 3+ control actions (end-to-end control)  
**Expected Result**: `control_risk: HIGH`, `score: 10`

**Request Body**:
```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07T14:50:00Z",
    "claim_id": "CLM-123456",
    "payment_id": "PAY-789012"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:30:00Z",
      "claim_id": "CLM-123456"
    },
    {
      "action_type": "UPDATE_PAYEE_BANK",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:40:00Z",
      "claim_id": "CLM-123456"
    }
  ],
  "actor_role": "Claims Adjuster"
}
```

**Expected Response**:
```json
{
  "control_risk": "HIGH",
  "reasons": [
    "Employee performed 3 control actions within 20.0 minutes: APPROVE_CLAIM, UPDATE_PAYEE_BANK, RELEASE_PAYMENT",
    "High concentration risk: Same employee has end-to-end control"
  ],
  "metrics": {
    "control_action_count": 3,
    "time_window_minutes": 20.0,
    "actions_detected": ["APPROVE_CLAIM", "UPDATE_PAYEE_BANK", "RELEASE_PAYMENT"],
    "employee_id": "EMP-5678",
    "actor_role": "Claims Adjuster"
  }
}
```

**Validation**:
- ✅ `control_risk` = "HIGH"
- ✅ `control_action_count` = 3
- ✅ `time_window_minutes` ≈ 20.0
- ✅ `reasons` contains "end-to-end control"
- ⚠️ Should trigger immediate alert

---

### Test Case 4: Empty Session Actions (LOW Risk)

**Test ID**: `ECA-POS-004`  
**Description**: No previous session actions (first action of session)  
**Expected Result**: `control_risk: LOW`, `score: 0`

**Request Body**:
```json
{
  "current_action": {
    "action_type": "APPROVE_CLAIM",
    "employee_id": "EMP-1111",
    "timestamp": "2026-02-07T14:00:00Z",
    "claim_id": "CLM-123456",
    "payment_id": "PAY-789012"
  },
  "session_actions": [],
  "actor_role": "Claims Adjuster"
}
```

**Expected Response**:
```json
{
  "control_risk": "LOW",
  "reasons": [
    "Normal separation of duties maintained"
  ],
  "metrics": {
    "control_action_count": 1,
    "time_window_minutes": 0.0,
    "actions_detected": ["APPROVE_CLAIM"],
    "employee_id": "EMP-1111",
    "actor_role": "Claims Adjuster"
  }
}
```

**Validation**:
- ✅ `control_risk` = "LOW"
- ✅ Handles empty array gracefully
- ✅ No errors thrown

---

### Test Case 5: All Five Control Actions (CRITICAL HIGH Risk)

**Test ID**: `ECA-POS-005`  
**Description**: Same employee performs all 5 control actions  
**Expected Result**: `control_risk: HIGH`, `score: 10`

**Request Body**:
```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07T15:00:00Z",
    "claim_id": "CLM-123456",
    "payment_id": "PAY-789012"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:30:00Z",
      "claim_id": "CLM-123456"
    },
    {
      "action_type": "UPDATE_PAYEE_BANK",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:35:00Z",
      "claim_id": "CLM-123456"
    },
    {
      "action_type": "UPDATE_PAYEE_ADDRESS",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:45:00Z",
      "claim_id": "CLM-123456"
    },
    {
      "action_type": "UPDATE_PAYEE_PHONE",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:50:00Z",
      "claim_id": "CLM-123456"
    }
  ],
  "actor_role": "Claims Adjuster"
}
```

**Expected Response**:
```json
{
  "control_risk": "HIGH",
  "reasons": [
    "Employee performed 5 control actions within 30.0 minutes: APPROVE_CLAIM, UPDATE_PAYEE_BANK, UPDATE_PAYEE_ADDRESS, UPDATE_PAYEE_PHONE, RELEASE_PAYMENT",
    "High concentration risk: Same employee has end-to-end control"
  ],
  "metrics": {
    "control_action_count": 5,
    "time_window_minutes": 30.0,
    "actions_detected": [
      "APPROVE_CLAIM",
      "UPDATE_PAYEE_BANK",
      "UPDATE_PAYEE_ADDRESS",
      "UPDATE_PAYEE_PHONE",
      "RELEASE_PAYMENT"
    ],
    "employee_id": "EMP-5678",
    "actor_role": "Claims Adjuster"
  }
}
```

**Validation**:
- ✅ `control_risk` = "HIGH"
- ✅ `control_action_count` = 5 (maximum possible)
- 🚨 **CRITICAL ALERT** - All controls bypassed

---

## Negative Test Cases

### Test Case 6: Missing Required Field - employee_id

**Test ID**: `ECA-NEG-001`  
**Description**: Missing mandatory `employee_id` in current_action  
**Expected Result**: Error response or graceful handling

**Request Body**:
```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "timestamp": "2026-02-07T14:45:00Z",
    "claim_id": "CLM-123456"
  },
  "session_actions": [],
  "actor_role": "Payment Processor"
}
```

**Expected Response**:
```json
{
  "error": "Missing required field: employee_id",
  "status": 400
}
```

**Validation**:
- ✅ Returns HTTP 400 Bad Request
- ✅ Error message is clear
- ✅ No system crash

---

### Test Case 7: Invalid Timestamp Format

**Test ID**: `ECA-NEG-002`  
**Description**: Invalid ISO8601 timestamp format  
**Expected Result**: Defaults to current time or returns error

**Request Body**:
```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07 14:45:00",
    "claim_id": "CLM-123456"
  },
  "session_actions": [],
  "actor_role": "Payment Processor"
}
```

**Expected Response**:
```json
{
  "control_risk": "LOW",
  "reasons": ["Normal separation of duties maintained"],
  "metrics": {
    "control_action_count": 1,
    "time_window_minutes": 0.0,
    "actions_detected": ["RELEASE_PAYMENT"],
    "employee_id": "EMP-5678",
    "actor_role": "Payment Processor"
  }
}
```

**Validation**:
- ✅ Agent handles gracefully (uses fallback timestamp)
- ✅ No error thrown
- ⚠️ Warning logged

---

### Test Case 8: Invalid Action Type

**Test ID**: `ECA-NEG-003`  
**Description**: Non-control action type  
**Expected Result**: `control_risk: LOW` (action ignored)

**Request Body**:
```json
{
  "current_action": {
    "action_type": "VIEW_CLAIM",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07T14:45:00Z",
    "claim_id": "CLM-123456"
  },
  "session_actions": [
    {
      "action_type": "DOWNLOAD_REPORT",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:30:00Z",
      "claim_id": "CLM-123456"
    }
  ],
  "actor_role": "Claims Viewer"
}
```

**Expected Response**:
```json
{
  "control_risk": "LOW",
  "reasons": ["Normal separation of duties maintained"],
  "metrics": {
    "control_action_count": 0,
    "time_window_minutes": 0.0,
    "actions_detected": [],
    "employee_id": "EMP-5678",
    "actor_role": "Claims Viewer"
  }
}
```

**Validation**:
- ✅ Non-control actions are ignored
- ✅ `control_action_count` = 0
- ✅ `actions_detected` is empty

---

### Test Case 9: Missing session_actions Array

**Test ID**: `ECA-NEG-004`  
**Description**: `session_actions` field is missing entirely  
**Expected Result**: Defaults to empty array

**Request Body**:
```json
{
  "current_action": {
    "action_type": "APPROVE_CLAIM",
    "employee_id": "EMP-1111",
    "timestamp": "2026-02-07T14:00:00Z",
    "claim_id": "CLM-123456"
  },
  "actor_role": "Claims Adjuster"
}
```

**Expected Response**:
```json
{
  "control_risk": "LOW",
  "reasons": ["Normal separation of duties maintained"],
  "metrics": {
    "control_action_count": 1,
    "time_window_minutes": 0.0,
    "actions_detected": ["APPROVE_CLAIM"],
    "employee_id": "EMP-1111",
    "actor_role": "Claims Adjuster"
  }
}
```

**Validation**:
- ✅ Graceful handling of missing field
- ✅ Defaults to empty array behavior

---

### Test Case 10: Malformed JSON

**Test ID**: `ECA-NEG-005`  
**Description**: Invalid JSON syntax  
**Expected Result**: HTTP 400 Bad Request

**Request Body**:
```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07T14:45:00Z"
    "claim_id": "CLM-123456"
  }
}
```
*(Note: Missing comma after timestamp)*

**Expected Response**:
```json
{
  "error": "Invalid JSON syntax",
  "status": 400
}
```

**Validation**:
- ✅ Returns HTTP 400
- ✅ Clear error message

---

## Edge Cases

### Test Case 11: Actions Outside Time Window (LOW Risk)

**Test ID**: `ECA-EDGE-001`  
**Description**: Previous actions are >30 minutes old  
**Expected Result**: `control_risk: LOW` (old actions excluded)

**Request Body**:
```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07T15:30:00Z",
    "claim_id": "CLM-123456"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:00:00Z",
      "claim_id": "CLM-123456"
    },
    {
      "action_type": "UPDATE_PAYEE_BANK",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:30:00Z",
      "claim_id": "CLM-123456"
    }
  ],
  "actor_role": "Claims Adjuster"
}
```

**Expected Response**:
```json
{
  "control_risk": "LOW",
  "reasons": ["Normal separation of duties maintained"],
  "metrics": {
    "control_action_count": 1,
    "time_window_minutes": 0.0,
    "actions_detected": ["RELEASE_PAYMENT"],
    "employee_id": "EMP-5678",
    "actor_role": "Claims Adjuster"
  }
}
```

**Validation**:
- ✅ Actions >30 minutes old are excluded
- ✅ Only current action counted
- ✅ Time window logic works correctly

---

### Test Case 12: Duplicate Action Types (De-duplication)

**Test ID**: `ECA-EDGE-002`  
**Description**: Same employee performs same action multiple times  
**Expected Result**: Only count unique action types

**Request Body**:
```json
{
  "current_action": {
    "action_type": "UPDATE_PAYEE_ADDRESS",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07T14:50:00Z",
    "claim_id": "CLM-123456"
  },
  "session_actions": [
    {
      "action_type": "UPDATE_PAYEE_ADDRESS",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:30:00Z",
      "claim_id": "CLM-123456"
    },
    {
      "action_type": "UPDATE_PAYEE_ADDRESS",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:40:00Z",
      "claim_id": "CLM-123456"
    }
  ],
  "actor_role": "Data Entry"
}
```

**Expected Response**:
```json
{
  "control_risk": "LOW",
  "reasons": ["Normal separation of duties maintained"],
  "metrics": {
    "control_action_count": 1,
    "time_window_minutes": 20.0,
    "actions_detected": ["UPDATE_PAYEE_ADDRESS"],
    "employee_id": "EMP-5678",
    "actor_role": "Data Entry"
  }
}
```

**Validation**:
- ✅ De-duplication works correctly
- ✅ Count = 1 (not 3)
- ✅ Multiple corrections to same field is acceptable

---

### Test Case 13: Mixed Employee IDs (LOW Risk)

**Test ID**: `ECA-EDGE-003`  
**Description**: Multiple employees with similar actions  
**Expected Result**: Only current employee's actions counted

**Request Body**:
```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07T14:50:00Z",
    "claim_id": "CLM-123456"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-1111",
      "timestamp": "2026-02-07T14:30:00Z",
      "claim_id": "CLM-123456"
    },
    {
      "action_type": "UPDATE_PAYEE_BANK",
      "employee_id": "EMP-2222",
      "timestamp": "2026-02-07T14:35:00Z",
      "claim_id": "CLM-123456"
    },
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-3333",
      "timestamp": "2026-02-07T14:40:00Z",
      "claim_id": "CLM-123456"
    }
  ],
  "actor_role": "Payment Processor"
}
```

**Expected Response**:
```json
{
  "control_risk": "LOW",
  "reasons": ["Normal separation of duties maintained"],
  "metrics": {
    "control_action_count": 1,
    "time_window_minutes": 0.0,
    "actions_detected": ["RELEASE_PAYMENT"],
    "employee_id": "EMP-5678",
    "actor_role": "Payment Processor"
  }
}
```

**Validation**:
- ✅ Only EMP-5678's actions counted
- ✅ Other employees' actions ignored
- ✅ Employee ID matching works correctly

---

### Test Case 14: Exact 30-Minute Boundary

**Test ID**: `ECA-EDGE-004`  
**Description**: Action exactly 30 minutes apart  
**Expected Result**: Should be included (<=30 minutes)

**Request Body**:
```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07T15:00:00Z",
    "claim_id": "CLM-123456"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:30:00Z",
      "claim_id": "CLM-123456"
    }
  ],
  "actor_role": "Claims Adjuster"
}
```

**Expected Response**:
```json
{
  "control_risk": "MED",
  "reasons": [
    "Employee performed 2 control actions within 30.0 minutes: APPROVE_CLAIM, RELEASE_PAYMENT",
    "Medium risk: Lack of separation of duties"
  ],
  "metrics": {
    "control_action_count": 2,
    "time_window_minutes": 30.0,
    "actions_detected": ["APPROVE_CLAIM", "RELEASE_PAYMENT"],
    "employee_id": "EMP-5678",
    "actor_role": "Claims Adjuster"
  }
}
```

**Validation**:
- ✅ 30-minute boundary included (<=)
- ✅ `control_action_count` = 2
- ✅ Risk correctly identified as MED

---

### Test Case 15: Case Sensitivity - Action Types

**Test ID**: `ECA-EDGE-005`  
**Description**: Action types in lowercase  
**Expected Result**: Should not match (case-sensitive)

**Request Body**:
```json
{
  "current_action": {
    "action_type": "release_payment",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07T14:45:00Z",
    "claim_id": "CLM-123456"
  },
  "session_actions": [
    {
      "action_type": "approve_claim",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:30:00Z",
      "claim_id": "CLM-123456"
    }
  ],
  "actor_role": "Claims Adjuster"
}
```

**Expected Response**:
```json
{
  "control_risk": "LOW",
  "reasons": ["Normal separation of duties maintained"],
  "metrics": {
    "control_action_count": 0,
    "time_window_minutes": 0.0,
    "actions_detected": [],
    "employee_id": "EMP-5678",
    "actor_role": "Claims Adjuster"
  }
}
```

**Validation**:
- ✅ Case-sensitive matching enforced
- ✅ Lowercase actions ignored
- ⚠️ Ensure clients send UPPERCASE

---

## Performance Test Cases

### Test Case 16: Large Session History (100 actions)

**Test ID**: `ECA-PERF-001`  
**Description**: Test performance with 100 session actions  
**Expected Result**: Response time < 50ms

**Request Body**: *(Abbreviated - full version has 100 session_actions)*
```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07T15:00:00Z",
    "claim_id": "CLM-123456"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:30:00Z",
      "claim_id": "CLM-123456"
    }
    // ... (98 more actions)
  ],
  "actor_role": "Claims Adjuster"
}
```

**Validation**:
- ✅ Response time < 50ms
- ✅ No performance degradation
- ✅ Memory usage stable

---

### Test Case 17: Concurrent Requests

**Test ID**: `ECA-PERF-002`  
**Description**: Send 100 concurrent requests  
**Expected Result**: All requests succeed, no errors

**Test Instructions**:
1. Use Apache JMeter or Insomnia Runner
2. Send 100 concurrent instances of Test Case 1
3. Measure: Success rate, avg response time, error rate

**Validation**:
- ✅ Success rate = 100%
- ✅ Avg response time < 100ms
- ✅ No timeout errors

---

## Security Test Cases

### Test Case 18: SQL Injection Attempt

**Test ID**: `ECA-SEC-001`  
**Description**: Attempt SQL injection in employee_id  
**Expected Result**: Input sanitized, no database compromise

**Request Body**:
```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678'; DROP TABLE users; --",
    "timestamp": "2026-02-07T14:45:00Z",
    "claim_id": "CLM-123456"
  },
  "session_actions": [],
  "actor_role": "Claims Adjuster"
}
```

**Expected Response**:
```json
{
  "control_risk": "LOW",
  "reasons": ["Normal separation of duties maintained"],
  "metrics": {
    "control_action_count": 1,
    "time_window_minutes": 0.0,
    "actions_detected": ["RELEASE_PAYMENT"],
    "employee_id": "EMP-5678'; DROP TABLE users; --",
    "actor_role": "Claims Adjuster"
  }
}
```

**Validation**:
- ✅ Treated as literal string
- ✅ No database query execution
- ✅ System secure

---

### Test Case 19: XSS Attempt

**Test ID**: `ECA-SEC-002`  
**Description**: Attempt XSS in actor_role  
**Expected Result**: Input escaped/sanitized

**Request Body**:
```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07T14:45:00Z",
    "claim_id": "CLM-123456"
  },
  "session_actions": [],
  "actor_role": "<script>alert('XSS')</script>"
}
```

**Expected Response**:
```json
{
  "control_risk": "LOW",
  "reasons": ["Normal separation of duties maintained"],
  "metrics": {
    "control_action_count": 1,
    "time_window_minutes": 0.0,
    "actions_detected": ["RELEASE_PAYMENT"],
    "employee_id": "EMP-5678",
    "actor_role": "&lt;script&gt;alert('XSS')&lt;/script&gt;"
  }
}
```

**Validation**:
- ✅ Script tags escaped
- ✅ No JavaScript execution
- ✅ Output safe for display

---

## Test Summary

| Category | Total Tests | Priority |
|----------|-------------|----------|
| **Positive Cases** | 5 | P0 |
| **Negative Cases** | 5 | P1 |
| **Edge Cases** | 5 | P1 |
| **Performance Cases** | 2 | P2 |
| **Security Cases** | 2 | P0 |
| **TOTAL** | **19** | - |

---

## Running Tests in Insomnia

### Step 1: Import Test Collection
1. Open Insomnia
2. Click **Import/Export** → **Import Data**
3. Select `insomnia_collection.json` (see next file)
4. All test cases will be imported

### Step 2: Configure Environment
1. Click **Manage Environments**
2. Set:
   - `base_url`: `http://localhost:8000`
   - `api_key`: `<your-api-key>`

### Step 3: Run Individual Tests
1. Select test case from sidebar
2. Click **Send**
3. Verify response matches expected output

### Step 4: Run All Tests
1. Click **Test** tab
2. Click **Run All Tests**
3. Review results in test runner

---

**Document Version**: 1.0  
**Last Updated**: February 7, 2026  
**Author**: QA Team - Fraud Detection System
