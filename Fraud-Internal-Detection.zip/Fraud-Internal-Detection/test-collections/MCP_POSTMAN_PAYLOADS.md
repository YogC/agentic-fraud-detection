# Postman MCP Payloads for Fraud Detection

This document provides **ready-to-use JSON payloads** for testing the `check_payout_fraud` MCP tool in Postman, matching the demo scenarios from `DEMO_WALKTHROUGH.md`.

---

## 🚀 Quick Setup

### Step 1: Start MCP Server in HTTP Mode

```powershell
cd "c:\Yogesh\GenAI\Fraud Detection\Fraud-Internal-Detection"
python app\mcp\fraud_detection_server.py --http --port 8001
```

**Verify server is running:**
- You should see: `🌐 HTTP/SSE Mode ENABLED`
- Server URL: `http://localhost:8001/sse`

---

### Step 2: Configure Postman MCP

1. **Enable MCP in Postman:**
   - Open Postman Settings → Features
   - Enable **Model Context Protocol (MCP)** feature flag

2. **Add MCP Server:**
   - Go to **MCP Servers** section
   - Click **Add Server**
   - Enter URL: `http://localhost:8001/sse`
   - Transport: **SSE (Server-Sent Events)**
   - Click **Connect**

3. **Discover Tools:**
   - Postman will automatically discover 6 MCP tools
   - Find: `check_payout_fraud`

---

### Step 3: Call Tool with Payloads

1. Select `check_payout_fraud` from MCP tools list
2. Copy one of the payloads below
3. Paste into the **Arguments** field in Postman
4. Click **Call Tool**
5. View response with decision, reasoning, and agent breakdown

**⚠️ CRITICAL: Postman MCP Payload Format**

**❌ DO NOT wrap in MCP protocol structure!**

Postman MCP automatically handles the MCP protocol wrapper. You should **ONLY** paste the raw JSON arguments, **NOT** wrapped in `method`/`params`/`arguments`.

**❌ WRONG (will cause -32602 error):**
```json
{
  "method": "tools/call",
  "params": {
    "name": "check_payout_fraud",
    "arguments": {
      "current_action": {...},
      "session_actions": [...]
    }
  }
}
```

**✅ CORRECT (paste this directly):**
```json
{
  "current_action": {...},
  "session_actions": [...],
  "actor_role": "...",
  "claim_status": "..."
}
```

**⚠️ Important: MCP Payload Format**

The payloads in this document are **simplified for MCP** and only include fields that the MCP tool schema accepts. Fields like `amount`, `vendor_name`, `description`, `currency`, and `bank_account_last4` are **not included** because they are not part of the MCP tool definition.

**MCP-Accepted Fields:**
- `current_action` (required)
- `session_actions` (required)
- `actor_role` (required)
- `claim_status` (required)
- `claimant_id` (optional)
- `bank_account_hash` (optional)
- `payment_method` (optional)
- `payee_changed_after_approval` (optional)
- `approval_timestamp` (optional)
- `payee_change_timestamp` (optional)
- `verification_flag` (optional)
- `is_new_account` (optional)
- `recipient_name` (optional) - **NEW:** Vendor/payee name for customer policy checks
- `payment_description` (optional) - **NEW:** Transaction description (may include customer context)
- `payment_amount` (optional) - **NEW:** Payment amount for context and risk assessment
- `save_to_db` (optional) - **NEW:** Enable database persistence for learning loop testing

**For REST API Testing:** Use the payloads in `Fraud_Detection_API_Tests.insomnia_collection.json` which include all metadata fields.

---

## 📋 Demo Payloads

### ⚠️ Important: Historical Seeding Required

**For DEMO-001 and DEMO-003 to work correctly, you MUST seed historical data first!**

The Graph Entity Agent tracks bank account usage **in memory**. Without historical data:
- DEMO-001 will return **ALLOW** (first employee to account - no pattern detected)
- DEMO-003 will not detect the reuse pattern correctly

**Solution:** Run the **SETUP payloads** first (see DEMO-001 section below), then run the actual demo payload.

---

## 💾 Important: Database Persistence Control

**All payloads below run in DRY-RUN mode by default** (no database save).

**To enable DB persistence**, add this parameter to any payload:
```json
"save_to_db": true
```

**When to use `save_to_db=true`:**
- ✅ Testing learning loop (need dashboard visibility)
- ✅ Running end-to-end integration tests
- ✅ Demonstrating complete fraud workflow
- ✅ Validating SIU feedback cycle

**When to skip it (default):**
- ✅ Quick LLM reasoning validation
- ✅ High-volume testing without DB clutter
- ✅ Testing without DynamoDB setup
- ✅ Iterating on prompt engineering

**Example with DB persistence enabled:**
```json
{
  "current_action": {...},
  "session_actions": [...],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "bank_account_hash": "ba_...",
  "save_to_db": true  ← Add this line to enable database save
}
```

---

## DEMO-001: Bank Account Reuse Fraud (High-Risk Insider)

### 🎯 Scenario
**3 employees using same bank account = collusion fraud ring**

**Expected Outcome:**
- **Before Learning:** WARN (Graph Agent detects HIGH risk, but LLM unsure)
- **After Learning:** BLOCK (LLM learned this pattern = confirmed fraud)

---

### ⚠️ STEP 1: Seed Historical Data FIRST

**Run these 2 payloads BEFORE running DEMO-001:**

#### SETUP-001A: First Employee Historical Transaction

```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-101",
    "employee_name": "Sarah Martinez",
    "timestamp": "2026-01-13T09:30:00Z",
    "claim_id": "CLM_SETUP_001A",
    "payment_id": "PAY_SETUP_001A"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-999",
      "employee_name": "Manager Alice",
      "timestamp": "2026-01-13T09:00:00Z",
      "claim_id": "CLM_SETUP_001A"
    }
  ],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "claimant_id": "CLMT_SARAH_MARTINEZ",
  "payment_method": "ACH",
  "bank_account_hash": "ba_7f8e9d4892c3a5b1e6f0d2a8b4c9e7f3",
  "save_to_db": true
}
```

**Expected Result:** ALLOW (first employee to account - normal)

---

#### SETUP-001B: Second Employee Historical Transaction

```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-203",
    "employee_name": "David Chen",
    "timestamp": "2026-01-23T14:15:00Z",
    "claim_id": "CLM_SETUP_001B",
    "payment_id": "PAY_SETUP_001B"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-888",
      "employee_name": "Manager Bob",
      "timestamp": "2026-01-23T14:00:00Z",
      "claim_id": "CLM_SETUP_001B"
    }
  ],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "claimant_id": "CLMT_DAVID_CHEN",
  "payment_method": "ACH",
  "bank_account_hash": "ba_7f8e9d4892c3a5b1e6f0d2a8b4c9e7f3",
  "save_to_db": true
}
```

**Expected Result:** WARN (second employee to same account - pattern emerges)

---

### ✅ STEP 2: Run DEMO-001 (After Seeding)

**Now the stage is set: 2 employees have used this account. When 3rd employee tries, it triggers HIGH risk.**

#### DEMO-001: Third Employee - Fraud Ring Detected

```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-457",
    "employee_name": "Robert Johnson",
    "timestamp": "2026-02-10T10:30:00Z",
    "claim_id": "CLM-2026-0457",
    "payment_id": "PAY-2026-0457"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-999",
      "employee_name": "Manager Smith",
      "timestamp": "2026-02-10T10:00:00Z",
      "claim_id": "CLM-2026-0457"
    }
  ],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "claimant_id": "CLMT_ROBERT_JOHNSON",
  "payment_method": "ACH",
  "bank_account_hash": "ba_7f8e9d4892c3a5b1e6f0d2a8b4c9e7f3",
  "save_to_db": true
  // Add "save_to_db": true here to enable dashboard visibility
}
```

**Expected Result (Before Learning):**
```json
{
  "decision": "WARN",
  "confidence": 0.65,
  "total_score": 3,
  "per_agent": {
    "graph_entity": {
      "risk": "HIGH",
      "score": 3,
      "reasons": [
        "🚨 Bank account reused across 3 different claimants",
        "⚠️ Bank account used in 3 distinct claims",
        "⚠️ 3 different employees associated with this account"
      ]
    },
    "employee_control": {"risk": "LOW", "score": 0},
    "lastmile_payment": {"risk": "LOW", "score": 0}
  },
  "reasoning": "Graph Entity Agent detected HIGH risk: 3 unrelated employees using same bank account..."
}
```

**Expected Result (After Learning):**
```json
{
  "decision": "BLOCK",
  "confidence": 0.92,
  "reasoning": "Multiple unrelated employees using same bank account detected. Based on previous confirmed fraud cases, this pattern indicates HIGH RISK for collusion or external fraud ring..."
}
```

---

## DEMO-002: High-Value New Vendor (Semantic Risk vs. Strong Controls)

### 🎯 Scenario
**New vendor + high value = requires manual review, even with proper approvals**

**Expected Outcome:**
- **Before Learning:** ALLOW (rules pass, auto-approved)
- **After Learning:** WARN (semantic risk detected, escalate for verification)

---

### Payload

```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-892",
    "employee_name": "Jennifer Williams",
    "timestamp": "2026-02-10T15:00:00Z",
    "claim_id": "CLM-2026-0892",
    "payment_id": "PAY-2026-0892"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-100",
      "employee_name": "Supervisor Jane Smith",
      "timestamp": "2026-02-05T10:30:00Z",
      "claim_id": "CLM-2026-0892"
    },
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-200",
      "employee_name": "Director Mike Johnson",
      "timestamp": "2026-02-05T14:15:00Z",
      "claim_id": "CLM-2026-0892"
    },
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-300",
      "employee_name": "VP Finance Sarah Chen",
      "timestamp": "2026-02-06T09:00:00Z",
      "claim_id": "CLM-2026-0892"
    }
  ],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "claimant_id": "CLMT_ABC_CONSTRUCTION",
  "payment_method": "ACH",
  "bank_account_hash": "ba_abc123construction5678hash",
  "is_new_account": true,
  "recipient_name": "ABC Construction Services",
  "payment_amount": 15000.00,
  "payment_description": "Building B renovation - materials and labor. New vendor added 15 days ago. First payment of this size. Construction industry. Three-level approval chain complete: Supervisor Jane Smith, Director Mike Johnson, VP Finance Sarah Chen. Vendor onboarding documents verified: W-9 Form, Certificate of Insurance, Business License (State of NY #BL-123456), 3 business references contacted. Board-approved capital project with assigned PM (Tom Wilson). Purchase Order #45829 matches invoice exactly.",
  "save_to_db": true
}
```

**Expected Result (Before Learning):**
```json
{
  "decision": "ALLOW",
  "confidence": 0.90,
  "total_score": 0,
  "reasoning": "Transaction passes all rule-based checks: proper separation of duties, no post-approval changes, first use of account. All agents returned LOW risk."
}
```

**Expected Result (After Learning):**
```json
{
  "decision": "WARN",
  "confidence": 0.75,
  "reasoning": "Transaction passes all rule-based checks with proper controls. However, semantic risk pattern detected: new vendor (15 days) + high value ($15K) + construction industry. Based on learned fraud investigation best practices, this pattern warrants manual SIU review for vendor verification before final approval. Strong controls noted: 3-level approval chain, complete vendor onboarding, documented capital project.",
  "semantic_risk_factors": [
    "new_vendor_under_30_days",
    "high_value_over_10k",
    "construction_industry"
  ],
  "positive_controls": [
    "three_level_approval_chain",
    "vendor_onboarding_complete",
    "documented_capital_project"
  ]
}
```

---

## DEMO-003: Customer Vendor Exclusion Policy

### 🎯 Scenario
**Legitimate vendor, but customer banned them due to past disputes**

**Expected Outcome:**
- **Before Learning:** ALLOW (vendor legitimate, approvals proper)
- **After Learning:** BLOCK (customer policy violation detected)

---

### Payload

```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-623",
    "employee_name": "Patricia Lee",
    "timestamp": "2026-02-10T14:30:00Z",
    "claim_id": "CLM-2026-0623",
    "payment_id": "PAY-2026-0623"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-777",
      "employee_name": "Manager Tom Wilson",
      "timestamp": "2026-02-10T14:00:00Z",
      "claim_id": "CLM-2026-0623"
    }
  ],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "claimant_id": "CLMT_ABC_MANUFACTURING",
  "payment_method": "ACH",
  "bank_account_hash": "ba_4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f",
  "recipient_name": "XYZ Staffing Agency",
  "payment_description": "Temporary staffing services - Q1 2026 - Customer: ABC Manufacturing Corp",
  "payment_amount": 12000.00,
  "save_to_db": true
}
```

**Expected Result (Before Learning):**
```json
{
  "decision": "ALLOW",
  "confidence": 0.88,
  "total_score": 0,
  "reasoning": "Transaction approved. Vendor XYZ Staffing Agency is legitimate with valid approval. All compliance checks passed.",
  "agent_results": {
    "employee_control": {"risk_level": "LOW"},
    "lastmile_payment": {"risk_level": "LOW"},
    "graph_entity": {"risk_level": "LOW"}
  }
}
```

**Expected Result (After Learning):**
```json
{
  "decision": "BLOCK",
  "confidence": 0.91,
  "reasoning": "Payment BLOCKED due to customer policy violation. CustomerABC has XYZ Staffing Agency on their vendor exclusion list (reason: Previous quality issues). Customer-specific exclusions must be honored regardless of vendor legitimacy or approval status. Customer relationship policy overrides fraud checks.",
  "risk_factors": [
    "CUSTOMER_VENDOR_EXCLUSION",
    "POLICY_VIOLATION"
  ],
  "agent_results": {
    "employee_control": {"risk_level": "LOW"},
    "lastmile_payment": {"risk_level": "LOW"},
    "graph_entity": {"risk_level": "LOW"}
  }
}
```

---

## 🔍 Additional Test Cases

### Clean Transaction (Expected: ALLOW)

**Legitimate payment with proper controls - should always ALLOW**

```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-555",
    "employee_name": "Alice Cooper",
    "timestamp": "2026-02-10T11:00:00Z",
    "claim_id": "CLM-2026-0555",
    "payment_id": "PAY-2026-0555"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-888",
      "employee_name": "Manager Bob",
      "timestamp": "2026-02-10T10:30:00Z",
      "claim_id": "CLM-2026-0555"
    }
  ],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "claimant_id": "CLMT_ALICE_COOPER",
  "payment_method": "CHECK",
  "bank_account_hash": "ba_clean_transaction_hash_1111",
  "save_to_db": true
}
```

**Expected Result:** ALLOW (no risk factors detected)

---

### Last-Mile Payment Fraud (Expected: BLOCK)

**Payee changed AFTER approval + fast payment method**

```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-789",
    "employee_name": "Mark Stevens",
    "timestamp": "2026-02-10T16:05:00Z",
    "claim_id": "CLM-2026-0789",
    "payment_id": "PAY-2026-0789"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-666",
      "employee_name": "Manager Linda",
      "timestamp": "2026-02-10T16:00:00Z",
      "claim_id": "CLM-2026-0789"
    },
    {
      "action_type": "MODIFY_PAYEE",
      "employee_id": "EMP-789",
      "employee_name": "Mark Stevens",
      "timestamp": "2026-02-10T16:03:00Z",
      "claim_id": "CLM-2026-0789"
    }
  ],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "claimant_id": "CLMT_MARK_STEVENS",
  "payment_method": "ACH_SAME_DAY",
  "bank_account_hash": "ba_lastmile_fraud_hash_7777",
  "payee_changed_after_approval": true,
  "approval_timestamp": "2026-02-10T16:00:00Z",
  "payee_change_timestamp": "2026-02-10T16:03:00Z",
  "verification_flag": false,
  "save_to_db": true
}
```

**Expected Result:** BLOCK (LastMile Payment Agent detects HIGH risk)

---

### Separation of Duties Violation (Expected: BLOCK)

**Same employee approves AND releases payment**

```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-333",
    "employee_name": "John Fraudster",
    "timestamp": "2026-02-10T12:30:00Z",
    "claim_id": "CLM-2026-0333",
    "payment_id": "PAY-2026-0333"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-333",
      "employee_name": "John Fraudster",
      "timestamp": "2026-02-10T12:00:00Z",
      "claim_id": "CLM-2026-0333"
    }
  ],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "claimant_id": "CLMT_JOHN_FRAUDSTER",
  "payment_method": "WIRE",
  "bank_account_hash": "ba_insider_fraud_hash_9999",
  "save_to_db": true
}
```

**Expected Result:** BLOCK (Employee Control Agent detects HIGH risk - same employee for approve + release)

---

## 🧠 Phase 6: LLM Knowledge Detection

**These test cases validate the LLM's ability to detect sophisticated fraud patterns that rule-based agents miss.**

LLM-only fraud detection demonstrates advanced pattern recognition beyond simple rule violations:
- **Crypto recovery scams** (advance-fee fraud patterns)
- **BEC social engineering** (manipulation tactics and urgency flags)
- **Phishing scripts** (compromised account stories)

---

### Test Case F: Crypto Recovery Scam (LLM BLOCKS)

**🎯 Scenario:** Crypto recovery service claiming to help recover lost investments

**Expected Outcome:**
- **Agents Score:** 0/6 (all agents return LOW risk - no rule violations)
- **LLM Decision:** BLOCK 🧠
- **Why:** LLM recognizes advance-fee fraud pattern common in crypto scams

**⚠️ Note:** MCP may return WARN instead of BLOCK due to missing context. The REST API includes a `notes` field with additional details: "Claimant says they lost money in crypto scam and this company will help recover it" which helps the LLM detect the advance-fee fraud pattern more confidently.

#### Payload

```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP008",
    "employee_name": "Payment Processor 008",
    "timestamp": "2026-02-04T14:00:00Z",
    "claim_id": "CLM_F_006",
    "payment_id": "PAY_F_006"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP007",
      "employee_name": "Approver 007",
      "timestamp": "2026-02-04T09:00:00Z",
      "claim_id": "CLM_F_006"
    }
  ],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "claimant_id": "CLMT_F_006",
  "bank_account_hash": "acct_hash_crypto_recovery_offshore",
  "payment_method": "WIRE",
  "payment_amount": 35000.00,
  "recipient_name": "Global Crypto Recovery Solutions LLC",
  "payment_description": "Investment recovery services - Bitcoin trading platform compensation. Claimant claims they lost money in crypto scam and Global Crypto Recovery will help recover it for upfront fee. Offshore wire transfer to UNKNOWN country.",
  "verification_flag": true,
  "save_to_db": true
}
```

**Expected Result:**
```json
{
  "decision": "BLOCK",
  "confidence": 0.88,
  "total_score": 0,
  "per_agent": {
    "employee_control": {"risk": "LOW", "score": 0},
    "lastmile_payment": {"risk": "LOW", "score": 0},
    "graph_entity": {"risk": "LOW", "score": 0}
  },
  "reasoning": "⚠️ ADVANCE-FEE FRAUD PATTERN DETECTED: Despite passing all rule-based checks, this transaction exhibits classic crypto recovery scam indicators. 'Global Crypto Recovery Solutions' offering 'investment recovery services' for Bitcoin losses is a well-known advance-fee fraud scheme. Victims are told they can recover lost crypto investments by paying upfront fees to recovery companies. These companies typically: 1) Target crypto scam victims, 2) Request wire transfers to offshore accounts, 3) Disappear after receiving payment. The $35,000 payment to an unknown recipient country with vague 'Bitcoin trading platform compensation' description matches this pattern. BLOCK recommended to prevent victim from losing additional funds to secondary scam.",
  "risk_factors": [
    "CRYPTO_RECOVERY_SCAM",
    "ADVANCE_FEE_FRAUD",
    "OFFSHORE_WIRE_TRANSFER",
    "VICTIM_TARGETING"
  ],
  "llm_detected": true
}
```

---

### Test Case H: BEC Social Engineering (LLM BLOCKS)

**🎯 Scenario:** Urgent CEO-approved payment with time pressure and confidentiality flags

**Expected Outcome:**
- **Agents Score:** 0/6 (proper approvals, no rule violations)
- **LLM Decision:** BLOCK 🧠
- **Why:** LLM recognizes Business Email Compromise (BEC) manipulation tactics

**⚠️ Note:** MCP may return WARN instead of BLOCK due to missing context. The REST API includes a `notes` field: "Executive request - time sensitive. Must complete by end of business today." and `vendor_relationship_months: 0.5` which help the LLM detect BEC patterns more confidently.

#### Payload

```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP011",
    "employee_name": "Payment Processor 011",
    "timestamp": "2026-02-04T16:45:00Z",
    "claim_id": "CLM_H_008",
    "payment_id": "PAY_H_008"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP012",
      "employee_name": "Approver 012",
      "timestamp": "2026-02-04T14:00:00Z",
      "claim_id": "CLM_H_008"
    }
  ],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "claimant_id": "CLMT_H_008",
  "bank_account_hash": "acct_hash_strategic_new_vendor",
  "payment_method": "WIRE",
  "payment_amount": 125000.00,
  "recipient_name": "Strategic Consulting Partners LLC",
  "payment_description": "URGENT: CEO-approved vendor payment for confidential acquisition deal. Process immediately per CFO directive. Executive request - time sensitive. Must complete by end of business today. New vendor (2 weeks old).",
  "is_new_account": true,
  "verification_flag": true,
  "save_to_db": true
}
```

**Expected Result:**
```json
{
  "decision": "BLOCK",
  "confidence": 0.91,
  "total_score": 0,
  "per_agent": {
    "employee_control": {"risk": "LOW", "score": 0},
    "lastmile_payment": {"risk": "LOW", "score": 0},
    "graph_entity": {"risk": "LOW", "score": 0}
  },
  "reasoning": "🚨 BUSINESS EMAIL COMPROMISE (BEC) DETECTED: This transaction exhibits multiple red flags consistent with CEO fraud/BEC attacks: 1) URGENCY PRESSURE: 'URGENT', 'Process immediately', 'must complete by end of business today', 2) AUTHORITY EXPLOITATION: Name-drops CEO and CFO to bypass normal controls, 3) CONFIDENTIALITY TACTIC: 'confidential acquisition deal' discourages verification, 4) TIME PRESSURE: 'time sensitive' prevents due diligence, 5) NEW VENDOR: 0.5 months relationship with generic name, 6) LARGE AMOUNT: $125,000 wire transfer. BEC attacks manipulate employees using social engineering to authorize fraudulent payments. Even with proper approvals, the combination of urgency language, executive name-dropping, confidentiality claims, and new vendor status is a textbook BEC scenario. Recommend independent verification via separate communication channel before processing.",
  "risk_factors": [
    "BEC_SOCIAL_ENGINEERING",
    "URGENCY_PRESSURE",
    "AUTHORITY_EXPLOITATION",
    "CONFIDENTIALITY_BYPASS",
    "NEW_VENDOR_HIGH_VALUE"
  ],
  "llm_detected": true
}
```

---

### Test Case I: Phishing Script (LLM BLOCKS)

**🎯 Scenario:** Account compromised story with urgency to redirect payment to "secure" account

**Expected Outcome:**
- **Agents Score:** 2/6 (LastMile Agent detects payee change)
- **LLM Decision:** BLOCK 🧠
- **Why:** LLM recognizes phishing script pattern and social engineering

**⚠️ Note:** MCP may return WARN instead of BLOCK due to missing context. The REST API includes a `notes` field: "Claimant called stating their bank account was compromised by hackers. They need the payout sent to a new 'secure' account immediately to prevent the fraudsters from stealing their money. Customer verified identity with SSN and claim number over phone. Urgent situation - customer is distressed." This detailed phishing script helps the LLM detect the pattern more confidently.

#### Payload

```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP013",
    "employee_name": "Payment Processor 013",
    "timestamp": "2026-02-04T15:00:00Z",
    "claim_id": "CLM_I_009",
    "payment_id": "PAY_I_009"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP014",
      "employee_name": "Approver 014",
      "timestamp": "2026-02-04T10:00:00Z",
      "claim_id": "CLM_I_009"
    }
  ],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "claimant_id": "CLMT_I_009",
  "bank_account_hash": "acct_hash_phishing_new_secure",
  "payment_method": "ACH",
  "payment_amount": 45000.00,
  "payment_description": "Claimant called: bank account compromised by hackers, needs payout sent to new 'secure' account immediately to prevent fraudsters from stealing money. Customer verified identity with SSN and claim number over phone. Urgent - customer distressed.",
  "payee_changed_after_approval": true,
  "is_new_account": true,
  "verification_flag": true,
  "save_to_db": true
}
```

**Expected Result:**
```json
{
  "decision": "BLOCK",
  "confidence": 0.94,
  "total_score": 2,
  "per_agent": {
    "employee_control": {"risk": "LOW", "score": 0},
    "lastmile_payment": {"risk": "MEDIUM", "score": 2, "reasons": ["Payee changed after approval"]},
    "graph_entity": {"risk": "LOW", "score": 0}
  },
  "reasoning": "🚨 PHISHING SCRIPT DETECTED: This transaction exhibits classic phishing fraud indicators. The claimant called with a scripted story: 'bank account was compromised by hackers' → needs immediate redirect to 'new secure account' → creates artificial urgency ('prevent fraudsters from stealing money') → customer 'distressed' (emotional manipulation). This is a textbook phishing attack where fraudsters impersonate the legitimate claimant to redirect payment. Red flags: 1) ACCOUNT COMPROMISE STORY: Common pretext to justify account change, 2) URGENCY: 'immediately' prevents verification, 3) EMOTIONAL MANIPULATION: 'distressed customer' pressures staff, 4) NEW ACCOUNT: First use of 'secure' account, 5) PHONE VERIFICATION ONLY: SSN/claim# can be stolen, 6) PAYEE CHANGED POST-APPROVAL: Classic last-mile fraud. Combined with LastMile Agent detecting payee change (2/6 risk score), this is HIGH CONFIDENCE fraud. BLOCK and verify via alternative contact method (email/address on file, not phone number provided by caller).",
  "risk_factors": [
    "PHISHING_SCRIPT_PATTERN",
    "ACCOUNT_COMPROMISE_PRETEXT",
    "URGENCY_MANIPULATION",
    "EMOTIONAL_PRESSURE",
    "PAYEE_CHANGED_AFTER_APPROVAL",
    "FIRST_USE_ACCOUNT"
  ],
  "llm_detected": true
}
```

---

### ⚠️ Important: MCP vs REST API Context Differences

**Why MCP may return WARN instead of BLOCK for Phase 6 tests:**

The MCP tool schema **does not include the `notes` field** that the REST API uses. This field contains critical context for LLM fraud detection:

| Field | MCP Support | REST API Support | Impact on Phase 6 |
|-------|-------------|------------------|-------------------|
| `notes` | ❌ **Not supported** | ✅ Supported | **Critical** - Contains phishing scripts, urgency details, victim context |
| `recipient_country` | ❌ Not supported | ✅ Supported | Moderate - Helps detect offshore scams |
| `vendor_relationship_months` | ❌ Not supported | ✅ Supported | Moderate - Helps detect new vendor risks |
| `invoice_details` | ❌ Not supported | ✅ Supported | Low - Additional invoice context |
| `employee_pattern` | ❌ Not supported | ✅ Supported | Low - Metadata for tracking |

**Workaround:** The updated MCP payloads above include additional context in the `payment_description` field to compensate for the missing `notes` field. This should improve LLM detection, but results may still vary compared to REST API.

**For production fraud detection:** Use the **REST API** (`http://localhost:8000/api/v1/payout/decide`) which includes all context fields and provides the most accurate LLM reasoning.

**For testing MCP specifically:** These payloads demonstrate MCP capabilities, but understand that the LLM may be less confident without full context (WARN vs BLOCK).

---

## 📊 Understanding MCP Responses

### Response Structure

```json
{
  "decision": "ALLOW | WARN | BLOCK",
  "confidence": 0.0-1.0,
  "total_score": 0-6,
  "per_agent": {
    "employee_control": {
      "risk": "LOW | MEDIUM | HIGH",
      "score": 0-2,
      "reasons": ["..."]
    },
    "lastmile_payment": {
      "risk": "LOW | MEDIUM | HIGH",
      "score": 0-2,
      "reasons": ["..."]
    },
    "graph_entity": {
      "risk": "LOW | MEDIUM | HIGH",
      "score": 0-3,
      "reasons": ["..."]
    }
  },
  "reasoning": "Natural language explanation...",
  "risk_factors": ["..."],
  "learned_from": "SIU_FEEDBACK" (if after learning)
}
```

### Score Interpretation

| Total Score | Decision | Meaning |
|-------------|----------|---------|
| **0** | ALLOW | No risk detected |
| **1-2** | WARN | Minor risk, manual review recommended |
| **3-4** | WARN/BLOCK | Moderate risk, likely fraud |
| **5-6** | BLOCK | High risk, confirmed fraud pattern |

---

## 🔧 Troubleshooting

### Issue: "MCP error -32602: Invalid request parameters"

**Root Cause:** You're wrapping the payload in MCP protocol structure, but Postman MCP handles that automatically.

**❌ WRONG Format:**
```json
{
  "method": "tools/call",
  "params": {
    "name": "check_payout_fraud",
    "arguments": {
      "current_action": {...}
    }
  }
}
```

**✅ CORRECT Format - Only paste the arguments:**
```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-457",
    "employee_name": "Robert Johnson",
    "timestamp": "2026-02-10T10:30:00Z",
    "claim_id": "CLM-2026-0457",
    "payment_id": "PAY-2026-0457"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-999",
      "employee_name": "Manager Smith",
      "timestamp": "2026-02-10T10:00:00Z",
      "claim_id": "CLM-2026-0457"
    }
  ],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "claimant_id": "CLMT_ROBERT_JOHNSON",
  "payment_method": "ACH",
  "bank_account_hash": "ba_7f8e9d4892c3a5b1e6f0d2a8b4c9e7f3"
}
```

**Fix:**
1. Copy ONLY the JSON arguments (not the MCP wrapper)
2. Paste into Postman MCP **Arguments** field
3. Click **Call Tool**

---

### Issue: "Connection failed to http://localhost:8001/sse"

**Fix:**
1. Verify MCP server is running: `python app\mcp\fraud_detection_server.py --http --port 8001`
2. Check server logs for errors
3. Try reconnecting in Postman MCP settings

---

### Issue: "Tool not found: check_payout_fraud"

**Fix:**
1. Click **Refresh Tools** in Postman MCP
2. Verify server discovered 6 tools
3. Restart MCP server if needed

---

### Issue: "DEMO-001 returns ALLOW instead of WARN"

**Fix:**
1. ⚠️ **You forgot to seed historical data!**
2. Run **SETUP-001A** and **SETUP-001B** payloads first
3. Then run DEMO-001 payload
4. Without seeding, Graph Entity Agent sees first use → LOW risk → ALLOW

---

### Issue: "Response doesn't match expected outcome"

**Explanation:**
- **Before Learning:** System uses baseline prompt (3 examples) → suboptimal decisions
- **After Learning:** System uses updated prompt (4+ examples) → improved decisions
- Run the demo scenarios, submit SIU feedback, activate new prompt, then re-test

---

### Issue: "No LangSmith traces appearing"

**Root Cause:** MCP server needs to load `.env` file to access LangSmith configuration.

**Fix:**

1. **Verify `.env` file exists** in project root:
   ```powershell
   cd "c:\Yogesh\GenAI\Fraud Detection\Fraud-Internal-Detection"
   type .env | findstr /i "LANGCHAIN"
   ```
   
   Should show:
   ```
   LANGCHAIN_TRACING_V2=true
   LANGCHAIN_PROJECT=fraud-detection-demo
   LANGCHAIN_API_KEY=lsv2_pt_...
   ```

2. **Restart MCP server** (it now loads `.env` on startup):
   ```powershell
   # Stop current server (Ctrl+C)
   # Then restart:
   python app\mcp\fraud_detection_server.py --http --port 8001
   ```
   
   You should see:
   ```
   ✅ Environment loaded - LangSmith tracing: true
   ```

3. **Run a test transaction** in Postman MCP

4. **Check LangSmith**:
   - Go to https://smith.langchain.com/
   - Select project: `fraud-detection-demo` (or your configured project name)
   - Traces should appear within a few seconds

**Still not working?**

Check Python dependencies:
```powershell
pip list | findstr langsmith
```

Should show: `langsmith  0.x.x`

If missing:
```powershell
pip install langsmith
```

---

### Issue: "Transaction not appearing in Dashboard despite save_to_db=true"

**Fix:**

1. **Verify response includes `"saved_to_db": true`:**
   ```json
   {
     "decision": "WARN",
     "saved_to_db": true  ← Should be present
   }
   ```

2. **Check MCP server logs** for DB save confirmation:
   ```
   ✅ MCP transaction saved to DB: PAY-2026-0457 (Decision: WARN)
   ```

3. **Refresh Streamlit Dashboard:**
   - Go to http://localhost:8501
   - Click "Refresh Data"
   - Look for your payment_id

4. **Check DynamoDB directly** (if still not visible):
   ```powershell
   aws dynamodb scan --table-name fraud-detection-decisions --region us-east-1
   ```

5. **Verify DynamoDB credentials** in `.env`:
   ```
   AWS_REGION=us-east-1
   AWS_ACCESS_KEY_ID=...
   AWS_SECRET_ACCESS_KEY=...
   ```

**Still not working?** Check server logs for error:
```
❌ Failed to save MCP transaction to DB: [error details]
```

---

### Issue: "Database error when using save_to_db=true"

**Root Cause:** DynamoDB not configured or credentials missing.

**Fix:**

1. **For local testing without AWS:**
   - Use `save_to_db=false` (default dry-run mode)
   - All fraud detection still works, just no persistence

2. **To enable DynamoDB:**
   - Ensure `.env` has AWS credentials
   - Or use DynamoDB Local: `docker run -p 8000:8000 amazon/dynamodb-local`
   - Update `dynamodb_config.py` to point to local endpoint

3. **Verify table exists:**
   ```powershell
   aws dynamodb describe-table --table-name fraud-detection-decisions
   ```

---

### Issue: "Unsupported method: undefined"

**Root Cause:** Postman MCP is not detecting which tool you want to call. This usually means you're not using the MCP tool interface correctly.

**Fix:**

1. **Verify you're in MCP mode:**
   - Go to Postman **MCP Servers** section (left sidebar)
   - Do NOT create a new HTTP request
   - Do NOT use Collections

2. **Refresh the MCP connection:**
   - Click **Disconnect** on your `http://localhost:8001/sse` server
   - Click **Connect** again
   - Verify it shows **6 tools discovered**

3. **Select the tool explicitly:**
   - Expand your MCP server in the list
   - Find and click **`check_payout_fraud`**
   - You should see an **Arguments** text area
   - Paste your JSON payload there (no wrapper needed)
   - Click **Call Tool** button

4. **If still not working:**
   - Restart the MCP server
   - Clear Postman cache: Settings → Data → Clear Cached Data
   - Re-add the MCP server connection

**Common Mistakes:**
- ❌ Creating a POST request to `/sse` endpoint
- ❌ Using Collections instead of MCP Servers
- ❌ Not selecting a tool before pasting payload
- ✅ Must use **MCP Servers → check_payout_fraud → Arguments**

---

## 💡 Key Differences: MCP vs REST API

| Feature | MCP Testing | REST API Testing |
|---------|-------------|------------------|
| **Transport** | Server-Sent Events (SSE) | HTTP POST |
| **Database** | ✅ Optional (via `save_to_db` flag) | ✅ Always saves to DynamoDB |
| **Learning Loop** | ✅ Available with `save_to_db=true` | ✅ Full feedback cycle |
| **LLM Reasoning** | ✅ **YES - LLM is called!** | ✅ YES - LLM is called |
| **LangSmith Traces** | ✅ **YES - Traces created!** | ✅ YES - Traces created |
| **Use Case** | Quick validation, demos, optional persistence | Production workflow |

---

## 🆕 Database Persistence for MCP (Optional Feature)

**New in this version:** MCP now supports **optional database persistence** via the `save_to_db` parameter!

### 🎯 When to Use `save_to_db=true`

✅ **Use DB Persistence When:**
- Testing the **full learning loop** (fraud detection → SIU feedback → prompt update)
- Validating **dashboard visibility** (transactions appear in Streamlit UI)
- Running **end-to-end integration tests** that mirror production
- Demonstrating **complete fraud investigation workflow** to stakeholders

❌ **Skip DB Persistence When:**
- Quick LLM reasoning validation (just want to see decision logic)
- Iterating on prompt engineering without data accumulation
- Running high-volume tests without cluttering the database
- Testing without DynamoDB setup/credentials

### 📋 How to Enable DB Persistence

Simply add `"save_to_db": true` to your MCP payload:

```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-457",
    "employee_name": "Robert Johnson",
    "timestamp": "2026-02-10T10:30:00Z",
    "claim_id": "CLM-2026-0457",
    "payment_id": "PAY-2026-0457"
  },
  "session_actions": [...],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "claimant_id": "CLMT_ROBERT_JOHNSON",
  "bank_account_hash": "ba_7f8e9d4892c3a5b1e6f0d2a8b4c9e7f3",
  "save_to_db": true  ← Enables database persistence
}
```

**Response includes confirmation:**
```json
{
  "decision": "WARN",
  "confidence": 0.65,
  "total_score": 3,
  "saved_to_db": true,  ← Confirms data was saved
  "per_agent": {...}
}
```

### 🔄 Complete Learning Loop with MCP

With `save_to_db=true`, you can now run the **full fraud detection lifecycle** via MCP:

1. **Run Demo Scenarios** (with `save_to_db=true`)
   - Transactions are saved to DynamoDB
   - Appear in Streamlit Dashboard

2. **Submit SIU Feedback** (via Dashboard or REST API)
   - Mark transactions as confirmed fraud/legitimate
   - System extracts learning examples

3. **Activate Updated Prompt** (via Dashboard)
   - New examples added to LLM context
   - System uses learned patterns

4. **Re-run Scenarios** (with `save_to_db=true`)
   - Verify improved decisions
   - Compare before/after learning

**No code changes needed!** MCP now behaves like REST API when `save_to_db=true`.

---

**⚠️ Important Clarification:**

**MCP DOES call the LLM Reasoning Agent and creates LangSmith traces!** 

The MCP server uses the same `PayoutDecisionOrchestrator` as the REST API, which:
1. ✅ Runs all 3 rule-based agents (Employee Control, LastMile Payment, Graph Entity)
2. ✅ **Calls the LLM Reasoning Agent** to analyze the results and provide sophisticated fraud detection
3. ✅ **Creates LangSmith traces** showing the full prompt, LLM response, and reasoning
4. ✅ Combines rule-based + LLM decisions using confidence scoring
5. ✅ **NEW: Optionally saves to database** when `save_to_db=true`

**What MCP DOESN'T do by default:**
- ❌ **NO Database Persistence** (unless `save_to_db=true`)
- ❌ **NO Dashboard Visibility** (unless `save_to_db=true`)
- ❌ **NO Learning Loop** (unless `save_to_db=true`)
- ❌ **NO API Layer** - Bypasses FastAPI, calls orchestrator directly

**Why No Database by Default?**

MCP calls the orchestrator **directly**, bypassing the REST API layer. Database persistence is now **optional**:

```
MCP Flow (Dry-Run Mode - Default):
  Postman → fraud_detection_server.py → Orchestrator → Return decision
  
MCP Flow (With DB Persistence - save_to_db=true):
  Postman → fraud_detection_server.py → Orchestrator → Save to DB → Return decision
  
REST API Flow (Always Persists):
  HTTP POST → FastAPI → internal_api.py → Orchestrator → Save to DB → Return decision
```

**MCP Default Mode (Dry-Run) is for:**
- ✅ Quick testing without database setup
- ✅ Validating LLM reasoning with LangSmith
- ✅ Demo fraud detection logic
- ✅ Ephemeral testing (no data persistence)

**MCP with `save_to_db=true` is for:**
- ✅ Full learning loop testing
- ✅ Dashboard visibility
- ✅ End-to-end integration testing
- ✅ Production-like workflow validation

**For production use:** Always use REST API at `http://localhost:8000/api/v1/payout/decision`

---

## � Quick Copy: Add DB Persistence

**To enable database save for ANY payload, add this line before the closing `}`:**

```json
  "save_to_db": true
```

**Before (Dry-Run Mode):**
```json
{
  "current_action": {...},
  "session_actions": [...],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "claimant_id": "CLMT_ROBERT_JOHNSON",
  "bank_account_hash": "ba_7f8e9d4892c3a5b1e6f0d2a8b4c9e7f3"
}
```

**After (Full Integration Mode):**
```json
{
  "current_action": {...},
  "session_actions": [...],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "claimant_id": "CLMT_ROBERT_JOHNSON",
  "bank_account_hash": "ba_7f8e9d4892c3a5b1e6f0d2a8b4c9e7f3",
  "save_to_db": true  ← Add this line
}
```

**Response Confirmation:**
When `save_to_db=true` is used, the response includes:
```json
{
  "decision": "WARN",
  "saved_to_db": true,  ← Confirms data was saved to DynamoDB
  "per_agent": {...}
}
```

**Where to Check:**
- ✅ Streamlit Dashboard: `http://localhost:8501`
- ✅ MCP server logs: Look for `✅ MCP transaction saved to DB: PAY-2026-0457`
- ✅ DynamoDB: `aws dynamodb scan --table-name fraud-detection-decisions`

---

## �📚 Related Documents

- **`DEMO_WALKTHROUGH.md`** - Step-by-step demo script with SIU feedback notes
- **`MCP_SERVER_MODES.md`** - MCP server modes and endpoint reference
- **`DEMO_TEST_CASES.json`** - Reference data with detailed test case documentation
- **`Fraud_Detection_API_Tests.insomnia_collection.json`** - Insomnia collection with all requests

---

## ✅ Quick Checklist

Before running demos:

- [ ] MCP server running in HTTP mode on port 8001
- [ ] Postman MCP configured and connected
- [ ] Tools discovered (should see 6 tools)
- [ ] For DEMO-001: Run SETUP-001A and SETUP-001B first
- [ ] For DEMO-003: Ensure metadata includes customer exclusion list
- [ ] Copy payloads from this document (not from JSON files)
- [ ] **NEW:** Decide if you need `"save_to_db": true` (for dashboard + learning loop)

**Testing Modes:**

| Mode | Use `save_to_db` | When to Use |
|------|------------------|-------------|
| **Dry-Run** | `false` (default) | Quick LLM validation, no DB needed |
| **Full Integration** | `true` | End-to-end testing, learning loop, dashboard |

---

**Last Updated:** February 11, 2026  
**Version:** 2.0 (Added optional DB persistence)
