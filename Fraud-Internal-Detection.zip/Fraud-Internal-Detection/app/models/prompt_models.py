"""
Pydantic models for Prompt Management System

Defines data models for:
- Prompt versions
- Learning queue items
- Performance metrics
- API requests/responses
"""

from pydantic import BaseModel, Field, validator, ConfigDict
from typing import List, Dict, Optional, Any
from datetime import datetime
from decimal import Decimal
from enum import Enum


class PromptStatus(str, Enum):
    """Prompt version status"""
    ACTIVE = "ACTIVE"
    TESTING = "TESTING"
    DRAFT = "DRAFT"
    ARCHIVED = "ARCHIVED"


class VersionType(str, Enum):
    """Type of version change"""
    MAJOR = "MAJOR"  # Breaking changes
    MINOR = "MINOR"  # New features
    PATCH = "PATCH"  # Bug fixes


class QueueStatus(str, Enum):
    """Learning queue item status"""
    PENDING_REVIEW = "PENDING_REVIEW"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    ADDED_TO_PROMPT = "ADDED_TO_PROMPT"


# ============================================================================
# Few-Shot Example Models
# ============================================================================

class FewShotExample(BaseModel):
    """A single few-shot learning example"""
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "event_id": "PAY-TEST-001",
                "scenario": "Large wire transfer to offshore account",
                "amount": 15000,
                "recipient": "Unknown offshore account",
                "indicators": ["unknown_recipient", "high_amount", "offshore"],
                "decision": "BLOCK",
                "outcome": "CONFIRMED_FRAUD",
                "reasoning": "Multiple fraud indicators present",
                "confidence": 0.95
            }
        }
    )
    
    event_id: Optional[str] = None
    scenario: str
    amount: Optional[float] = None
    recipient: Optional[str] = None
    indicators: List[str] = []
    decision: str  # BLOCK, WARN, ALLOW
    outcome: str  # CONFIRMED_FRAUD, LEGITIMATE, FALSE_POSITIVE
    reasoning: str
    confidence: float = Field(ge=0.0, le=1.0)


# ============================================================================
# Prompt Version Models
# ============================================================================

class ModelConfig(BaseModel):
    """LLM model configuration"""
    model_name: str = "gpt-4"
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    max_tokens: int = Field(default=500, ge=100, le=4000)
    top_p: float = Field(default=0.9, ge=0.0, le=1.0)


class AccuracyMetrics(BaseModel):
    """Accuracy metrics for a prompt version"""
    total_decisions: int = 0
    correct_decisions: int = 0
    incorrect_decisions: int = 0
    accuracy_percent: float = 0.0
    false_positives: int = 0
    false_negatives: int = 0
    avg_confidence: float = 0.0


class PromptVersion(BaseModel):
    """Complete prompt version"""
    model_config = ConfigDict(use_enum_values=True)
    
    event_type: str
    version_id: str
    prompt_id: str
    prompt_version: str
    system_prompt: str
    few_shot_examples: List[FewShotExample] = []
    is_active: str = "false"  # DynamoDB doesn't support boolean in GSI
    status: PromptStatus = PromptStatus.DRAFT
    version_type: VersionType = VersionType.MINOR
    
    # Metadata
    created_at: int
    created_by: str
    activated_at: Optional[int] = None
    activated_by: Optional[str] = None
    change_reason: str
    change_notes: Optional[str] = None
    
    # Learning
    learning_cases_added: List[str] = []
    examples_count: int = 0
    
    # Performance
    accuracy_metrics: Optional[AccuracyMetrics] = None
    
    # Configuration
    llm_model_config: ModelConfig = Field(default_factory=ModelConfig)
    
    # Version history
    parent_version_id: Optional[str] = None
    accuracy_change: Optional[str] = None
    improvement_summary: Optional[str] = None


class PromptVersionSummary(BaseModel):
    """Summary of a prompt version for list views"""
    event_type: str
    version_id: str
    prompt_id: str
    prompt_version: str
    status: PromptStatus
    is_active: bool
    created_at: int
    created_by: str
    accuracy_percent: Optional[float] = None
    examples_count: int = 0
    change_reason: str


# ============================================================================
# Learning Queue Models
# ============================================================================

class ExampleData(BaseModel):
    """Extracted data for creating a learning example"""
    scenario: str
    amount: Optional[float] = None
    recipient: Optional[str] = None
    indicators: List[str] = []
    reasoning: str


class LearningQueueItem(BaseModel):
    """Item in the learning queue"""
    queue_id: str
    created_at: int
    
    # Case reference
    event_id: str
    event_timestamp: int
    event_type: str
    
    # Learning value
    reward_score: int
    actual_outcome: str
    llm_decision: str
    is_correct: bool
    
    # Case details - optional until generated
    example_data: Optional[ExampleData] = None
    
    # Queue status
    status: QueueStatus = QueueStatus.PENDING_REVIEW
    reviewed_by: Optional[str] = None
    reviewed_at: Optional[int] = None
    review_notes: Optional[str] = None
    reviewer_notes: Optional[str] = None  # SIU feedback from review submission
    
    # Target prompt
    target_event_type: str
    target_prompt_version: Optional[str] = None
    added_to_prompt_at: Optional[int] = None
    
    model_config = ConfigDict(use_enum_values=True)


# ============================================================================
# Performance Metrics Models
# ============================================================================

class DailyMetrics(BaseModel):
    """Daily performance metrics for a prompt"""
    prompt_id: str
    date: str  # YYYY-MM-DD
    event_type: str
    prompt_version: str
    
    # Decision counts
    total_decisions: int = 0
    correct_decisions: int = 0
    incorrect_decisions: int = 0
    accuracy_percent: float = 0.0
    
    # Decision breakdown
    blocks: int = 0
    allows: int = 0
    warns: int = 0
    
    # Outcome breakdown
    confirmed_fraud: int = 0
    false_positives: int = 0
    false_negatives: int = 0
    legitimate: int = 0
    
    # Confidence metrics
    avg_confidence: float = 0.0
    high_confidence_decisions: int = 0  # > 0.8
    low_confidence_decisions: int = 0   # < 0.5
    
    # Performance
    avg_processing_time_ms: Optional[float] = None
    max_processing_time_ms: Optional[float] = None


# ============================================================================
# API Request Models
# ============================================================================

class CreatePromptRequest(BaseModel):
    """Request to create a new prompt version"""
    event_type: str
    prompt_version: str
    system_prompt: str
    few_shot_examples: List[FewShotExample] = []
    change_reason: str
    change_notes: Optional[str] = None
    created_by: str
    parent_version_id: Optional[str] = None
    status: PromptStatus = PromptStatus.DRAFT
    llm_model_config: Optional[ModelConfig] = None


class ActivatePromptRequest(BaseModel):
    """Request to activate a prompt version"""
    prompt_id: str
    approver_id: str
    approval_notes: str


class RollbackPromptRequest(BaseModel):
    """Request to rollback to a previous version"""
    event_type: str
    target_version_id: str
    rollback_reason: str
    rollback_by: str


class ReviewLearningCaseRequest(BaseModel):
    """Request to review a learning queue item"""
    queue_id: str
    action: str  # APPROVE or REJECT
    reviewer_id: str
    review_notes: str
    
    @validator('action')
    def validate_action(cls, v):
        if v not in ['APPROVE', 'REJECT']:
            raise ValueError('action must be APPROVE or REJECT')
        return v


class GeneratePromptRequest(BaseModel):
    """Request to generate new prompt from learning queue"""
    event_type: str
    queue_ids: List[str]
    prompt_version: str
    created_by: str
    change_reason: Optional[str] = None
    max_examples: int = Field(default=20, ge=5, le=50)


# ============================================================================
# API Response Models
# ============================================================================

class PromptResponse(BaseModel):
    """Response containing prompt details"""
    model_config = {"extra": "allow"}  # Allow and preserve extra fields in serialization
    
    prompt_id: str
    event_type: str
    prompt_version: str
    version: Optional[str] = None  # UI compatibility - duplicate of prompt_version
    system_prompt: str
    template: Optional[str] = None  # UI compatibility - duplicate of system_prompt
    description: Optional[str] = None  # Prompt description for UI
    few_shot_examples: List[Dict[str, Any]]
    llm_model_config: Dict[str, Any]
    status: str
    is_active: bool
    created_at: int
    created_by: str
    examples_count: int


class PromptHistoryResponse(BaseModel):
    """Response containing version history"""
    event_type: str
    versions: List[PromptVersionSummary]
    total_versions: int


class PromptComparisonResponse(BaseModel):
    """Response comparing two prompt versions"""
    version_1: PromptVersionSummary
    version_2: PromptVersionSummary
    differences: Dict[str, Any]


class LearningQueueResponse(BaseModel):
    """Response containing learning queue items"""
    items: List[LearningQueueItem]
    total_items: int
    pending_count: int
    approved_count: int


class PerformanceAnalyticsResponse(BaseModel):
    """Response containing performance analytics"""
    event_type: str
    prompt_version: str
    date_range: List[str]
    daily_metrics: List[DailyMetrics]
    summary: Dict[str, Any]


class LearningImpactResponse(BaseModel):
    """Response showing learning impact"""
    reviewer_id: Optional[str]
    contributions: List[Dict[str, Any]]
    total_impact: Dict[str, Any]


class StandardResponse(BaseModel):
    """Standard API response"""
    status: str = "success"
    message: str
    data: Optional[Dict[str, Any]] = None
