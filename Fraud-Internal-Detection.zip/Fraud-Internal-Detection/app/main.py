"""
Payout Fraud Detection API
Last-mile payment fraud detection for insurance claims.
PEP (Policy Enforcement Point) implementation with full observability.
"""

# Load environment variables from .env file FIRST (before any other imports)
from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional
from datetime import datetime
from contextlib import asynccontextmanager
import logging
import time
import uuid

from agents.payout_orchestrator import PayoutDecisionOrchestrator
from utils.audit_logger import get_audit_logger
from utils.monitoring import get_performance_monitor, get_cost_monitor
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
from services.prompt_service import PromptService
from database.dynamodb_client import get_dynamodb_client

# Import feedback API router
from api.feedback_endpoint import router as feedback_router
# Import decisions and learning API routers (DynamoDB integration)
from api.v1.decisions import router as decisions_router
from api.v1.learning import router as learning_router
# Import internal API router (for fraud detection system)
from api.internal_api import router as internal_router
# Import prompt management and learning queue routers
from api.v1.prompts import router as prompts_router
from api.v1.learning_queue import router as learning_queue_router

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize monitoring and audit logging
audit_logger = get_audit_logger()
perf_monitor = get_performance_monitor()
cost_monitor = get_cost_monitor()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler for startup and shutdown events."""
    # Startup
    logger.info("=" * 60)
    logger.info("=== Payout Fraud Detection API (PEP) Starting ===")
    logger.info("=" * 60)
    logger.info("Architecture: Policy Enforcement Point (PEP)")
    logger.info("Agents: Employee Control, Last-Mile Payment, Graph Entity")
    logger.info("Features: Audit Logging, Performance Monitoring, Cost Tracking")
    logger.info("Observability: Prometheus metrics at /metrics")
    logger.info("=" * 60)
    
    # Initialize system
    try:
        audit_logger.log_api_request(
            endpoint="/startup",
            method="SYSTEM",
            claim_id=None,
            source_ip="localhost",
            user_agent="system"
        )
    except Exception as e:
        logger.warning(f"Audit logger not available: {e}")
    
    yield
    
    # Shutdown
    logger.info("=" * 60)
    logger.info("=== Payout Fraud Detection API (PEP) Shutting Down ===")
    logger.info("=" * 60)
    
    # Print final stats
    stats = perf_monitor.get_stats()
    cost_summary = cost_monitor.get_cost_summary()
    
    logger.info(f"Total Requests: {stats.get('total_requests', 0)}")
    logger.info(f"Total Cost: ${cost_summary.get('total_cost', 0):.4f}")
    logger.info("=" * 60)


# Initialize FastAPI app with lifespan handler
app = FastAPI(
    title="Payout Fraud Detection API (PEP)",
    description="3-Agent Policy Enforcement Point for last-mile payment fraud detection with full observability",
    version="2.0.0",
    lifespan=lifespan
)


# Include feedback API router
app.include_router(feedback_router, prefix="/api/v1/feedback", tags=["feedback"])

# Include decisions and learning API routers (for UI - DynamoDB integration)
app.include_router(decisions_router, prefix="/api/v1", tags=["Decisions"])
app.include_router(learning_router, prefix="/api/v1", tags=["Learning"])

# Include internal API router (for fraud detection system)
app.include_router(internal_router)

# Include prompt management and learning queue routers
app.include_router(prompts_router, prefix="/api/v1", tags=["Prompt Management"])
app.include_router(learning_queue_router, prefix="/api/v1", tags=["Learning Queue"])


# Pydantic models
class PayoutDecisionRequest(BaseModel):
    """Model for payout decision request."""
    current_action: Dict[str, Any] = Field(..., description="Current action (RELEASE_PAYMENT, UPDATE_PAYEE_*, etc.)")
    session_actions: List[Dict[str, Any]] = Field(default_factory=list, description="Session action trail")
    actor_role: str = Field(..., description="Actor role")
    claim_status: str = Field(..., description="Claim status")
    approval_timestamp: Optional[str] = Field(None, description="Approval timestamp")
    payee_change_timestamp: Optional[str] = Field(None, description="Payee change timestamp")
    payment_method: str = Field(..., description="Payment method")
    payment_amount: Optional[float] = Field(None, description="Payment amount")
    payment_release_request: bool = Field(False, description="Payment release requested")
    verification_flag: bool = Field(False, description="Customer verification recorded")
    payee_changed_after_approval: bool = Field(False, description="Payee changed after approval")
    bank_account_hash: str = Field(..., description="Hashed bank account")
    routing_hash: Optional[str] = Field(None, description="Hashed routing number (optional - enhances graph analysis)")
    payee_address_hash: Optional[str] = Field(None, description="Hashed payee address (optional - enhances graph analysis)")
    payee_phone_hash: Optional[str] = Field(None, description="Hashed payee phone (optional - enhances graph analysis)")
    claimant_id: str = Field(..., description="Claimant ID")
    transaction_id: Optional[str] = Field(None, description="Transaction ID")
    
    # === FRAUD-RELEVANT FIELDS (for LLM analysis - NO PII/PCI) ===
    payment_description: Optional[str] = Field(None, description="Payment/invoice description (fraud-relevant text)")
    notes: Optional[str] = Field(None, description="Transaction notes (fraud-relevant text)")
    recipient_name: Optional[str] = Field(None, description="Recipient/vendor name (business entity, not personal PII)")
    vendor_relationship_months: Optional[float] = Field(None, description="Vendor relationship duration in months")
    
    # === COMPLIANCE-SAFE FIELDS (for LLM prompts) ===
    # These derived/aggregated fields replace PII in LLM prompts
    transaction_reference: Optional[str] = Field(None, description="Non-sensitive transaction reference (e.g., 'REF-001')")
    employee_pattern: Optional[str] = Field(None, description="Employee behavior pattern: 'SINGLE_EMPLOYEE', 'PROPER_SEPARATION', 'CONCENTRATION'")
    account_pattern: Optional[str] = Field(None, description="Account usage pattern: 'FIRST_USE' (new account), 'ESTABLISHED', 'REUSED_ACROSS_CLAIMS' (required for new account detection)")
    amount_category: Optional[str] = Field(None, description="Amount category: 'SMALL', 'MEDIUM', 'LARGE', 'STRUCTURING_THRESHOLD'")
    workflow_separation: Optional[str] = Field(None, description="Workflow separation: 'PROPER', 'SAME_EMPLOYEE_ALL_STEPS', 'PARTIAL'")
    time_window_mins: Optional[int] = Field(None, description="Time window in minutes (aggregated, not specific timestamps)")


# API Endpoints
@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "service": "Payout Fraud Detection API",
        "version": "2.0.0",
        "status": "operational",
        "endpoints": {
            "decide": "/api/v1/payout/decide",
            "health": "/api/v1/health"
        }
    }


@app.get("/api/v1/health")
async def health_check():
    """Health check endpoint with performance stats."""
    stats = perf_monitor.get_stats()
    cost_summary = cost_monitor.get_cost_summary()
    
    return {
        "status": "healthy",
        "service": "payout-fraud-detection-pep",
        "timestamp": datetime.now(datetime.UTC).isoformat() if hasattr(datetime, 'UTC') else datetime.utcnow().isoformat() + 'Z',
        "performance": stats,
        "cost_tracking": cost_summary
    }


@app.get("/health")
async def health_check_root():
    """Root-level health check endpoint for UI and monitoring tools."""
    return {
        "status": "healthy",
        "service": "payout-fraud-detection-pep",
        "timestamp": datetime.now(datetime.UTC).isoformat() if hasattr(datetime, 'UTC') else datetime.utcnow().isoformat() + 'Z'
    }


@app.get("/metrics")
async def metrics():
    """
    Prometheus metrics endpoint.
    Exposes performance and operational metrics.
    """
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.post("/api/v1/payout/decide")
async def decide_payout(request: PayoutDecisionRequest, http_request: Request):
    """
    PEP Decision Endpoint (Policy Enforcement Point)
    
    Intercepts payment submissions at boundary and enforces policy decisions.
    
    Evaluates payment release risk using 3 agents:
    1. Employee Control Concentration Agent
    2. Last-Mile Payment Risk Agent
    3. Graph & Entity Link Agent
    
    Returns: ALLOW, WARN, or BLOCK decision with full audit trail
    """
    request_id = str(uuid.uuid4())
    start_time = time.time()
    
    try:
        # Extract request details
        claim_id = request.current_action.get('claim_id', 'unknown')
        payment_id = request.current_action.get('payment_id', 'unknown')
        actor_id = request.current_action.get('employee_id', 'unknown')
        actor_role = request.actor_role
        
        # Start monitoring
        perf_monitor.start_request(request_id)
        
        # Log API request
        audit_logger.log_api_request(
            endpoint="/api/v1/payout/decide",
            method="POST",
            claim_id=claim_id,
            source_ip=http_request.client.host if http_request.client else None,
            user_agent=http_request.headers.get("user-agent")
        )
        
        logger.info(f"[PEP] Payment decision request intercepted - Claim: {claim_id}, Payment: {payment_id}, Actor: {actor_id}")
        
        # Initialize orchestrator
        orchestrator = PayoutDecisionOrchestrator()
        
        # Prepare input
        input_data = request.dict()
        
        # Execute PEP consultation (agents analyze risk)
        result = await orchestrator.execute(input_data)
        
        # ====== Save decision to DynamoDB for UI visibility ======
        try:
            db = get_dynamodb_client()
            
            # Determine status based on decision
            if result.get('decision') in ['BLOCK', 'WARN']:
                status = 'PENDING_REVIEW'
            else:
                status = 'AUTO_APPROVED'
            
            # Prepare decision data for DynamoDB
            decision_data = {
                'event_id': payment_id,
                'event_type': 'PAYMENT_FRAUD',
                'entity_type': 'PAYMENT',
                'risk_category': 'FINANCIAL',
                'event_data': input_data,
                'detection_results': result.get('per_agent', {}),
                'llm_decision': result.get('decision'),
                'final_decision': result.get('decision'),
                'total_score': result.get('total_score', 0),
                'llm_confidence': result.get('llm_confidence', 0.0),
                'llm_reasoning': ', '.join(result.get('reasons', [])),
                'status': status,
                'display_metadata': {
                    'claim_id': claim_id,
                    'actor_id': actor_id,
                    'actor_role': actor_role,
                    'payment_amount': input_data.get('payment_amount'),
                    'payment_method': input_data.get('payment_method')
                }
            }
            
            saved_to_db = db.save_decision(decision_data)
            logger.info(f"[PEP] Decision saved to DynamoDB: {payment_id}, Status: {status}")
        except Exception as db_error:
            # Log error but don't fail the request
            logger.error(f"[PEP] Failed to save decision to DynamoDB: {str(db_error)}")
        # ====== END: Database persistence ======
        
        # Calculate execution time
        execution_time = time.time() - start_time
        execution_time_ms = execution_time * 1000
        
        # Record PEP decision metrics
        perf_monitor.record_pep_decision(
            decision=result.get('decision'),
            score=result.get('total_score'),
            duration_seconds=execution_time
        )
        
        # Record cost
        cost_monitor.record_request(execution_time)
        
        # Log PEP decision to audit trail
        audit_logger.log_pep_decision(
            claim_id=claim_id,
            payment_id=payment_id,
            decision=result.get('decision'),
            total_score=result.get('total_score'),
            agent_results=result.get('per_agent', {}),
            actor_id=actor_id,
            actor_role=actor_role,
            reasons=result.get('reasons', []),
            evidence=result.get('evidence', {}),
            request_data=input_data
        )
        
        # Log API response
        audit_logger.log_api_response(
            endpoint="/api/v1/payout/decide",
            status_code=200,
            claim_id=claim_id,
            execution_time_ms=execution_time_ms,
            decision=result.get('decision')
        )
        
        # End monitoring
        perf_monitor.end_request(
            request_id=request_id,
            endpoint="/api/v1/payout/decide",
            method="POST",
            status_code=200
        )
        
        logger.info(
            f"[PEP] Policy decision enforced - Claim: {claim_id}, Decision: {result.get('decision')}, "
            f"Score: {result.get('total_score')}, Time: {execution_time_ms:.2f}ms"
        )
        
        return result
        
    except Exception as e:
        execution_time = time.time() - start_time
        
        # Log error to audit trail
        audit_logger.log_error(
            error_type=type(e).__name__,
            error_message=str(e),
            claim_id=claim_id if 'claim_id' in locals() else None,
            stack_trace=None,
            context={"request_id": request_id}
        )
        
        # Record error metric
        perf_monitor.record_error(type(e).__name__)
        
        # End monitoring
        if 'request_id' in locals():
            perf_monitor.end_request(
                request_id=request_id,
                endpoint="/api/v1/payout/decide",
                method="POST",
                status_code=500
            )
        
        logger.error(f"[PEP] Error in payout decision: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
