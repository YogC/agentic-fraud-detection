"""
Learning Service - Automated learning pipeline

Handles:
- Processing SIU reviews for learning opportunities
- Managing learning queue
- Auto-generating new prompt versions
- Tracking learning impact
"""

import time
import uuid
from typing import Dict, List, Optional
from datetime import datetime

from repositories.prompt_repository import PromptRepository
from services.prompt_service import PromptService
from models.prompt_models import (
    LearningQueueItem, GeneratePromptRequest,
    ReviewLearningCaseRequest
)


class LearningService:
    """Service for automated prompt learning from SIU feedback"""
    
    def __init__(self):
        self.prompt_repo = PromptRepository()
        self.prompt_service = PromptService()
        self.high_value_threshold = 50  # Reward score threshold
    
    # ========================================================================
    # Review Processing
    # ========================================================================
    
    async def process_review_for_learning(
        self,
        event_id: str,
        timestamp: int,
        review_data: Dict
    ) -> Optional[Dict]:
        """
        Called after SIU submits a review.
        Adds high-value cases to learning queue.
        
        Criteria for learning queue:
        - Reward score >= 50 or <= -50
        - Clear outcome (CONFIRMED_FRAUD or LEGITIMATE)
        - High confidence decision
        
        Returns:
            Queue item if added, None otherwise
        """
        reward_score = review_data.get('reward_score', 0)
        
        # Check if this is a high-value learning case
        if abs(reward_score) >= self.high_value_threshold:
            # Extract example data from review
            example_data = self._extract_example_data(review_data)
            
            queue_item = {
                'event_id': event_id,
                'event_timestamp': timestamp,
                'event_type': review_data.get('event_type', 'PAYMENT_FRAUD'),
                'reward_score': reward_score,
                'actual_outcome': review_data['actual_outcome'],
                'llm_decision': review_data['llm_decision'],
                'is_correct': reward_score > 0,
                'example_data': example_data,
                'status': 'PENDING_REVIEW',
                'target_event_type': review_data.get('event_type', 'PAYMENT_FRAUD')
            }
            
            result = await self.prompt_repo.add_to_learning_queue(queue_item)
            return result
        
        return None
    
    # ========================================================================
    # Learning Queue Management
    # ========================================================================
    
    async def get_learning_queue(
        self,
        event_type: Optional[str] = None,
        status: str = "PENDING_REVIEW",
        limit: int = 50
    ) -> List[Dict]:
        """Get items from learning queue"""
        return await self.prompt_repo.get_learning_queue(
            event_type=event_type,
            status=status,
            limit=limit
        )
    
    async def mark_as_implemented(
        self,
        queue_id: str,
        implemented_by: str,
        notes: Optional[str] = None
    ) -> Optional[Dict]:
        """
        Mark a learning queue item as implemented (incorporated into a prompt).
        
        Args:
            queue_id: ID of the queue item
            implemented_by: User who incorporated it
            notes: Optional notes about the incorporation
        
        Returns:
            Updated queue item or None if not found
        """
        try:
            from boto3.dynamodb.conditions import Key
            
            # Get the item first to get the created_at timestamp
            response = self.prompt_repo.queue_table.query(
                KeyConditionExpression=Key('queue_id').eq(queue_id),
                Limit=1
            )
            
            if not response or 'Items' not in response or len(response['Items']) == 0:
                return None
            
            item = response['Items'][0]
            created_at = item.get('created_at')
            
            if not created_at:
                return None
            
            # Update the status to IMPLEMENTED
            updated = self.prompt_repo.queue_table.update_item(
                Key={
                    'queue_id': queue_id,
                    'created_at': created_at
                },
                UpdateExpression='''
                    SET #status = :status,
                        incorporated_into_prompt = :incorporated,
                        implemented_by = :implemented_by,
                        implemented_at = :implemented_at,
                        implementation_notes = :notes
                ''',
                ExpressionAttributeNames={
                    '#status': 'status'
                },
                ExpressionAttributeValues={
                    ':status': 'IMPLEMENTED',
                    ':incorporated': 'true',
                    ':implemented_by': implemented_by,
                    ':implemented_at': int(time.time()),
                    ':notes': notes or ''
                },
                ReturnValues='ALL_NEW'
            )
            
            return updated.get('Attributes')
        except Exception as e:
            print(f"Error marking item as implemented: {e}")
            return None

    
    async def review_learning_case(
        self,
        queue_id: str,
        created_at: int,
        action: str,
        reviewer_id: str,
        review_notes: str
    ) -> Dict:
        """
        SIU approves/rejects a case for prompt inclusion.
        
        Args:
            queue_id: ID of the queue item
            created_at: Timestamp when item was created
            action: APPROVE or REJECT
            reviewer_id: ID of the SIU reviewer
            review_notes: Notes from reviewer
        """
        return await self.prompt_repo.update_queue_status(
            queue_id=queue_id,
            created_at=created_at,
            action=action,
            reviewer_id=reviewer_id,
            review_notes=review_notes
        )
    
    # ========================================================================
    # Prompt Generation
    # ========================================================================
    
    async def generate_prompt_from_queue(
        self,
        event_type: str,
        queue_ids: List[str],
        prompt_version: str,
        created_by: str,
        change_reason: Optional[str] = None,
        max_examples: int = 20
    ) -> Dict:
        """
        Generate a new prompt version from approved learning cases.
        
        Args:
            event_type: Type of fraud event
            queue_ids: List of queue item IDs to include
            prompt_version: Version number for new prompt (e.g., "v2.4")
            created_by: User creating the prompt
            change_reason: Reason for creating new version
            max_examples: Maximum number of examples to include
        
        Returns:
            Newly created prompt version
        """
        # Get current active prompt
        current_prompt = await self.prompt_service.get_active_prompt(event_type, use_cache=False)
        
        if not current_prompt:
            return {
                'error': f'No active prompt found for {event_type}'
            }
        
        # Get approved queue items
        approved_cases = await self._get_queue_items_by_ids(queue_ids)
        
        # Convert queue items to few-shot examples
        new_examples = self._convert_cases_to_examples(approved_cases)
        
        # Merge with existing examples
        existing_examples = current_prompt.get('few_shot_examples', [])
        merged_examples = self._merge_examples(
            existing=existing_examples,
            new=new_examples,
            max_examples=max_examples
        )
        
        # Create new prompt version
        new_prompt_data = {
            'event_type': event_type,
            'prompt_version': prompt_version,
            'system_prompt': current_prompt['system_prompt'],
            'few_shot_examples': merged_examples,
            'change_reason': change_reason or f'Auto-generated: Added {len(new_examples)} examples from learning queue',
            'created_by': created_by,
            'parent_version_id': current_prompt.get('version_id'),
            'status': 'DRAFT',
            'is_active': 'false',
            'learning_cases_added': queue_ids,
            'examples_count': len(merged_examples),
            'model_config': current_prompt.get('model_config', {})
        }
        
        new_prompt = await self.prompt_repo.create_prompt_version(new_prompt_data)
        
        # Mark queue items as added to prompt
        await self.prompt_repo.mark_queue_items_as_added(
            queue_ids=queue_ids,
            prompt_version=prompt_version
        )
        
        return new_prompt
    
    async def auto_generate_prompt_if_ready(
        self,
        event_type: str,
        threshold: int = 5
    ) -> Optional[Dict]:
        """
        Automatically generate new prompt version when
        enough approved cases are in queue.
        
        Args:
            event_type: Type of fraud event
            threshold: Minimum approved cases needed (default: 5)
        
        Returns:
            New prompt if generated, None otherwise
        """
        # Get approved cases from queue
        approved_cases = await self.prompt_repo.get_learning_queue(
            event_type=event_type,
            status='APPROVED',
            limit=100
        )
        
        if len(approved_cases) < threshold:
            return None
        
        # Get current version to increment
        current_prompt = await self.prompt_service.get_active_prompt(event_type, use_cache=False)
        current_version = current_prompt.get('prompt_version', 'v1.0')
        new_version = self._increment_version(current_version)
        
        # Extract queue IDs
        queue_ids = [case['queue_id'] for case in approved_cases[:threshold]]
        
        # Generate new prompt
        return await self.generate_prompt_from_queue(
            event_type=event_type,
            queue_ids=queue_ids,
            prompt_version=new_version,
            created_by='system_auto',
            change_reason=f'Automatic learning: {len(queue_ids)} high-value cases'
        )
    
    # ========================================================================
    # Learning Impact Analytics
    # ========================================================================
    
    async def get_learning_impact(
        self,
        reviewer_id: Optional[str] = None,
        event_type: Optional[str] = None
    ) -> Dict:
        """
        Show which SIU reviews contributed to prompt improvements.
        
        Args:
            reviewer_id: Filter by specific reviewer (optional)
            event_type: Filter by event type (optional)
        
        Returns:
            Impact summary with contributions
        """
        # Get all cases that were added to prompts
        added_cases = await self.prompt_repo.get_learning_queue(
            event_type=event_type,
            status='ADDED_TO_PROMPT',
            limit=100
        )
        
        # Filter by reviewer if specified
        if reviewer_id:
            added_cases = [
                case for case in added_cases
                if case.get('reviewed_by') == reviewer_id
            ]
        
        # Calculate impact
        contributions = []
        for case in added_cases:
            contribution = {
                'event_id': case['event_id'],
                'event_type': case['event_type'],
                'added_to_prompt': case.get('target_prompt_version'),
                'reward_score': case['reward_score'],
                'reviewed_by': case.get('reviewed_by'),
                'impact': {
                    'accuracy_improvement': 'TBD',  # Would calculate from metrics
                    'used_in_decisions': 0,  # Would track usage
                    'prevented_fraud': 0  # Would calculate from outcomes
                }
            }
            contributions.append(contribution)
        
        total_impact = {
            'prompts_contributed': len(set(c.get('added_to_prompt') for c in contributions if c.get('added_to_prompt'))),
            'examples_added': len(contributions),
            'accuracy_improvement': 'TBD',
            'fraud_prevented': 0
        }
        
        return {
            'reviewer_id': reviewer_id or 'all',
            'event_type': event_type or 'all',
            'contributions': contributions,
            'total_impact': total_impact
        }
    
    # ========================================================================
    # Private Helper Methods
    # ========================================================================
    
    def _extract_example_data(self, review_data: Dict) -> Dict:
        """
        Extract COMPLIANCE-SAFE data for creating a learning example.
        NO PII or sensitive identifiers are included.
        """
        event_data = review_data.get('event_data', {})
        detection_results = review_data.get('detection_results', {})
        
        # Build scenario description using COMPLIANCE-SAFE patterns only
        scenario_parts = []
        
        # Use amount_category instead of exact amount
        amount_category = event_data.get('amount_category', 'MEDIUM')
        scenario_parts.append(f"{amount_category} amount payment")
        
        # Use account_pattern instead of specific account
        account_pattern = event_data.get('account_pattern', 'UNKNOWN')
        if account_pattern != 'UNKNOWN':
            scenario_parts.append(f"Account: {account_pattern}")
        
        # Use employee_pattern instead of specific employee
        employee_pattern = event_data.get('employee_pattern', 'UNKNOWN')
        if employee_pattern != 'UNKNOWN':
            scenario_parts.append(f"Employee: {employee_pattern}")
        
        scenario = ' | '.join(scenario_parts) or review_data.get('llm_reasoning', 'Unknown scenario')
        
        # Extract indicators (behavioral patterns, no PII)
        indicators = []
        for key, value in detection_results.items():
            if 'FAIL' in str(value).upper() or 'SUSPICIOUS' in str(value).upper():
                indicators.append(key.replace('_check', ''))
        
        return {
            'scenario': scenario[:200],  # Limit length
            'amount_category': amount_category,  # COMPLIANCE-SAFE: category, not amount
            'account_pattern': account_pattern,   # COMPLIANCE-SAFE: pattern, not account
            'employee_pattern': employee_pattern, # COMPLIANCE-SAFE: pattern, not employee ID
            'workflow_separation': event_data.get('workflow_separation', 'UNKNOWN'),
            'indicators': indicators,
            'reasoning': review_data.get('llm_reasoning', '')[:500]
        }
    
    async def _get_queue_items_by_ids(self, queue_ids: List[str]) -> List[Dict]:
        """Get queue items by their IDs"""
        items = []
        for queue_id in queue_ids:
            # Query by queue_id
            result = await self.prompt_repo.queue_table.query(
                KeyConditionExpression='queue_id = :qid',
                ExpressionAttributeValues={':qid': queue_id},
                Limit=1
            )
            if result.get('Items'):
                items.append(result['Items'][0])
        return items
    
    def _convert_cases_to_examples(self, cases: List[Dict]) -> List[Dict]:
        """
        Convert reviewed cases to COMPLIANCE-SAFE few-shot examples.
        NO PII or sensitive identifiers are included.
        """
        examples = []
        
        for case in cases:
            example_data = case.get('example_data', {})
            
            example = {
                'event_id': case['event_id'],  # Internal reference only
                'scenario': example_data.get('scenario', 'Unknown'),
                'amount_category': example_data.get('amount_category', 'MEDIUM'),  # COMPLIANCE-SAFE
                'account_pattern': example_data.get('account_pattern', 'UNKNOWN'),  # COMPLIANCE-SAFE
                'employee_pattern': example_data.get('employee_pattern', 'UNKNOWN'),  # COMPLIANCE-SAFE
                'workflow_separation': example_data.get('workflow_separation', 'UNKNOWN'),  # COMPLIANCE-SAFE
                'indicators': example_data.get('indicators', []),
                'correct_decision': case['llm_decision'],  # FIXED: Use correct_decision
                'outcome': case['actual_outcome'],
                'reasoning': example_data.get('reasoning', ''),
                'fraud_type': case.get('event_type', 'UNKNOWN'),  # Add fraud_type
                'source': 'learning_queue',  # Track source
                'source_queue_id': case.get('queue_id', case.get('event_id'))  # Track original queue item
                # NOTE: confidence removed - not needed in LLM prompt
            }
            examples.append(example)
        
        return examples
    
    def _merge_examples(
        self,
        existing: List[Dict],
        new: List[Dict],
        max_examples: int = 20
    ) -> List[Dict]:
        """
        Merge existing and new examples intelligently.
        
        Strategy:
        1. Remove duplicates (similar scenarios)
        2. Keep high-performing examples
        3. Ensure diversity (different fraud patterns)
        4. Limit to max_examples
        """
        # Simple append strategy for MVP
        # TODO: Implement smart merging in Phase 2
        merged = list(existing) + list(new)
        
        # Remove duplicates based on event_id
        seen_ids = set()
        unique_merged = []
        for ex in merged:
            event_id = ex.get('event_id')
            if event_id and event_id not in seen_ids:
                unique_merged.append(ex)
                seen_ids.add(event_id)
            elif not event_id:  # No event_id, include anyway
                unique_merged.append(ex)
        
        # Limit to max
        if len(unique_merged) > max_examples:
            # Keep most recent
            unique_merged = unique_merged[-max_examples:]
        
        return unique_merged
    
    def _increment_version(self, current_version: str) -> str:
        """Increment version number (e.g., v2.3 → v2.4)"""
        try:
            parts = current_version.replace('v', '').split('.')
            major, minor = int(parts[0]), int(parts[1])
            return f"v{major}.{minor + 1}"
        except:
            return "v2.0"
    
    async def get_learning_insights(self) -> Dict:
        """Get learning queue insights and statistics"""
        return await self.prompt_repo.get_learning_insights()
