"""
Prompt Service - Business logic for prompt management

Handles:
- Retrieving active prompts for fraud detection
- Caching prompts for performance
- Formatting prompts for LLM consumption
- Prompt version management
"""

import time
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta

from repositories.prompt_repository import PromptRepository
from models.prompt_models import (
    PromptVersion, FewShotExample, CreatePromptRequest,
    ActivatePromptRequest, RollbackPromptRequest
)


class PromptService:
    """Service for managing and retrieving fraud detection prompts"""
    
    def __init__(self):
        self.prompt_repo = PromptRepository()
        self._cache = {}  # Simple in-memory cache
        self._cache_ttl = 300  # 5 minutes cache TTL
    
    # ========================================================================
    # Public Methods - Prompt Retrieval
    # ========================================================================
    
    async def get_active_prompt(
        self,
        event_type: str,
        use_cache: bool = True
    ) -> Optional[Dict]:
        """
        Get the currently active prompt for an event type.
        Used by fraud detection agent during decision making.
        
        Args:
            event_type: PAYMENT_FRAUD, PII_ACCESS, DATA_MODIFICATION
            use_cache: Whether to use cached version (default: True)
        
        Returns:
            Dict with system_prompt, few_shot_examples, model_config
        """
        try:
            cache_key = f"active_prompt:{event_type}"
            
            # Check cache first
            if use_cache and cache_key in self._cache:
                cached = self._cache[cache_key]
                if time.time() - cached['timestamp'] < self._cache_ttl:
                    # Map field even for cached prompts
                    return self._map_config_field(cached['prompt'])
            
            # Fetch from database
            try:
                prompt = await self.prompt_repo.get_active_prompt(event_type)
            except Exception as e:
                print(f"Error fetching from database, using default: {e}")
                prompt = None
            
            if not prompt:
                # Fallback to default prompt if none exists
                print(f"No prompt found in database for {event_type}, using default")
                prompt = self._get_default_prompt(event_type)
            
            # Map model_config to llm_model_config for API compatibility
            prompt = self._map_config_field(prompt)
            
            # Cache it
            self._cache[cache_key] = {
                'prompt': prompt,
                'timestamp': time.time()
            }
            
            return prompt
        except Exception as e:
            print(f"Error in get_active_prompt: {e}")
            # Last resort - return default prompt
            return self._get_default_prompt(event_type)
    
    async def list_prompts(
        self,
        event_type: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict]:
        """List all prompts with optional filtering"""
        prompts = await self.prompt_repo.list_prompts(
            event_type=event_type,
            status=status,
            limit=limit
        )
        # Map model_config to llm_model_config for API compatibility
        return [self._map_config_field(p) for p in prompts]
    
    async def list_prompt_versions(
        self,
        event_type: str,
        limit: int = 50
    ) -> List[Dict]:
        """List all versions of prompts for a specific event type"""
        versions = await self.prompt_repo.get_prompt_history(
            event_type=event_type,
            limit=limit,
            include_archived=True
        )
        # Map model_config to llm_model_config for API compatibility
        return [self._map_config_field(v) for v in versions]
    
    async def get_prompt_by_id(self, prompt_id: str) -> Optional[Dict]:
        """Get a specific prompt version by ID"""
        prompt = await self.prompt_repo.get_prompt_by_id(prompt_id)
        return self._map_config_field(prompt) if prompt else None
    
    # ========================================================================
    # Private Helper Methods
    # ========================================================================
    
    def _map_config_field(self, prompt: Dict) -> Dict:
        """
        Map fields for API and UI compatibility:
        - model_config -> llm_model_config
        - system_prompt <-> template (ensure both exist)
        - prompt_version -> version (ensure both exist)
        """
        if not prompt:
            return prompt
        
        # Map model_config to llm_model_config
        if 'model_config' in prompt and 'llm_model_config' not in prompt:
            prompt['llm_model_config'] = prompt['model_config']
        
        # Ensure both system_prompt and template fields exist (for UI compatibility)
        if 'system_prompt' in prompt and 'template' not in prompt:
            prompt['template'] = prompt['system_prompt']
        elif 'template' in prompt and 'system_prompt' not in prompt:
            prompt['system_prompt'] = prompt['template']
        
        # Ensure both version and prompt_version exist
        if 'prompt_version' in prompt and 'version' not in prompt:
            prompt['version'] = prompt['prompt_version']
        elif 'version' in prompt and 'prompt_version' not in prompt:
            prompt['prompt_version'] = prompt['version']
        
        return prompt
    
    # ========================================================================
    # Public Methods - Prompt Formatting for LLM
    # ========================================================================
    
    async def format_prompt_for_llm(
        self,
        event_type: str,
        transaction_data: Dict,
        use_cache: bool = True
    ) -> Dict:
        """
        Format prompt with few-shot examples for LLM consumption.
        
        Args:
            event_type: Event type (PAYMENT_FRAUD, etc.)
            transaction_data: Transaction data to format
            use_cache: Whether to use cached prompt (default: True)
                      Set to False to always load fresh from DB (e.g., for MCP server)
        
        Returns:
            {
                'system': system prompt,
                'messages': [
                    {'role': 'system', 'content': '...'},
                    {'role': 'user', 'content': 'Example 1...'},
                    {'role': 'assistant', 'content': 'Decision: BLOCK'},
                    ...
                    {'role': 'user', 'content': 'Current transaction...'}
                ],
                'model_config': {...}
            }
        """
        prompt = await self.get_active_prompt(event_type, use_cache=use_cache)
        
        if not prompt:
            prompt = self._get_default_prompt(event_type)
        
        messages = []
        
        # System prompt
        messages.append({
            'role': 'system',
            'content': prompt['system_prompt']
        })
        
        # Add few-shot examples
        for example in prompt.get('few_shot_examples', []):
            # User message: scenario
            messages.append({
                'role': 'user',
                'content': self._format_example_scenario(example)
            })
            
            # Assistant message: decision
            messages.append({
                'role': 'assistant',
                'content': self._format_example_decision(example)
            })
        
        # Current transaction
        messages.append({
            'role': 'user',
            'content': self._format_transaction(transaction_data)
        })
        
        return {
            'system': prompt['system_prompt'],
            'messages': messages,
            'model_config': prompt.get('model_config', {}),
            'prompt_id': prompt.get('prompt_id'),
            'prompt_version': prompt.get('prompt_version')
        }
    
    # ========================================================================
    # Public Methods - Prompt Management
    # ========================================================================
    
    async def create_prompt_version(self, request: CreatePromptRequest) -> Dict:
        """Create a new prompt version"""
        prompt_data = {
            'event_type': request.event_type,
            'prompt_version': request.prompt_version,
            'system_prompt': request.system_prompt,
            'few_shot_examples': [ex.dict() for ex in request.few_shot_examples],
            'change_reason': request.change_reason,
            'change_notes': request.change_notes,
            'created_by': request.created_by,
            'parent_version_id': request.parent_version_id,
            'status': request.status,
            'is_active': 'false',
            'examples_count': len(request.few_shot_examples),
            'model_config': request.llm_model_config.dict() if request.llm_model_config else {}
        }
        
        return await self.prompt_repo.create_prompt_version(prompt_data)
    
    async def activate_prompt(
        self,
        event_type: str = None,
        version_id: str = None,
        approver_id: str = None,
        approval_notes: str = None,
        prompt_id: str = None,
        activated_by: str = None
    ) -> Dict:
        """
        Activate a prompt version.
        Invalidates cache for the event type.
        
        Supports two calling patterns:
        1. activate_prompt(event_type, version_id, approver_id, approval_notes) - legacy
        2. activate_prompt(prompt_id=..., activated_by=...) - new API pattern
        """
        import logging
        logger = logging.getLogger(__name__)
        
        # Handle new API pattern
        if prompt_id and activated_by:
            logger.info(f"[ACTIVATE_SERVICE] Activating prompt_id: {prompt_id}")
            
            # Get the prompt to extract event_type and version_id
            prompt = await self.prompt_repo.get_prompt_by_id(prompt_id)
            if not prompt:
                raise ValueError(f"Prompt not found: {prompt_id}")
            
            event_type = prompt.get('event_type')
            version_id = prompt.get('version_id')
            approver_id = activated_by
            approval_notes = f"Activated via API by {activated_by}"
            
            logger.info(f"[ACTIVATE_SERVICE] Extracted - event_type: {event_type}, version_id: {version_id}")
        
        # Validate we have all required params
        if not all([event_type, version_id, approver_id]):
            raise ValueError(f"Missing required parameters for activation - event_type: {event_type}, version_id: {version_id}, approver_id: {approver_id}")
        
        logger.info(f"[ACTIVATE_SERVICE] Calling repository activate_prompt with event_type: {event_type}, version_id: {version_id}")
        
        result = await self.prompt_repo.activate_prompt(
            event_type=event_type,
            version_id=version_id,
            approver_id=approver_id,
            approval_notes=approval_notes or ""
        )
        
        logger.info(f"[ACTIVATE_SERVICE] Activation result status: {result.get('status')}, is_active: {result.get('is_active')}")
        
        # Mark any associated learning queue items as implemented
        queue_ids = result.get('source_queue_ids', [])
        if queue_ids:
            logger.info(f"[ACTIVATE_SERVICE] Found {len(queue_ids)} learning queue items to mark as implemented")
            from services.learning_service import LearningService
            learning_service = LearningService()
            
            for queue_id in queue_ids:
                try:
                    await learning_service.mark_as_implemented(
                        queue_id=queue_id,
                        implemented_by=activated_by,
                        notes=f"Incorporated into prompt {result.get('prompt_version', 'unknown')} and activated"
                    )
                    logger.info(f"[ACTIVATE_SERVICE] Marked queue item {queue_id} as implemented")
                except Exception as e:
                    logger.warning(f"[ACTIVATE_SERVICE] Could not mark queue item {queue_id} as implemented: {e}")
        
        # Invalidate cache
        await self.invalidate_cache(event_type)
        
        # Map field for API compatibility
        return self._map_config_field(result)
    
    async def rollback_prompt(
        self,
        event_type: str,
        target_version_id: str,
        rollback_reason: str,
        rollback_by: str
    ) -> Dict:
        """Rollback to a previous prompt version"""
        # This is essentially activating an old version
        result = await self.prompt_repo.activate_prompt(
            event_type=event_type,
            version_id=target_version_id,
            approver_id=rollback_by,
            approval_notes=f"ROLLBACK: {rollback_reason}"
        )
        
        # Invalidate cache
        await self.invalidate_cache(event_type)
        
        return result
    
    async def archive_prompt(
        self,
        event_type: str = None,
        version_id: str = None,
        prompt_id: str = None,
        archived_by: str = None
    ) -> Dict:
        """
        Archive a prompt version.
        
        Supports two calling patterns:
        1. archive_prompt(event_type, version_id) - legacy
        2. archive_prompt(prompt_id=..., archived_by=...) - new API pattern
        """
        # Handle new API pattern
        if prompt_id:
            # Get the prompt to extract event_type and version_id
            prompt = await self.prompt_repo.get_prompt_by_id(prompt_id)
            if not prompt:
                raise ValueError(f"Prompt not found: {prompt_id}")
            
            event_type = prompt.get('event_type')
            version_id = prompt.get('version_id')
        
        # Validate we have all required params
        if not all([event_type, version_id]):
            raise ValueError("Missing required parameters for archival")
        
        result = await self.prompt_repo.archive_prompt(event_type, version_id)
        
        # Return the archived prompt for API compatibility
        if result:
            archived_prompt = await self.prompt_repo.get_prompt_by_id(prompt_id or f"{event_type}_{version_id}")
            return self._map_config_field(archived_prompt) if archived_prompt else result
        return result
    
    async def compare_prompts(
        self,
        prompt_id_1: str,
        prompt_id_2: str
    ) -> Dict:
        """Compare two prompt versions"""
        prompt1 = await self.prompt_repo.get_prompt_by_id(prompt_id_1)
        prompt2 = await self.prompt_repo.get_prompt_by_id(prompt_id_2)
        
        if not prompt1 or not prompt2:
            return {
                'error': 'One or both prompts not found'
            }
        
        # Calculate differences
        examples1 = set(ex.get('event_id', ex.get('scenario')) for ex in prompt1.get('few_shot_examples', []))
        examples2 = set(ex.get('event_id', ex.get('scenario')) for ex in prompt2.get('few_shot_examples', []))
        
        added = examples2 - examples1
        removed = examples1 - examples2
        
        differences = {
            'examples_added': list(added),
            'examples_removed': list(removed),
            'examples_modified': [],
            'system_prompt_changed': prompt1.get('system_prompt') != prompt2.get('system_prompt'),
            'accuracy_change': self._calculate_accuracy_change(prompt1, prompt2)
        }
        
        return {
            'version_1': {
                'prompt_version': prompt1.get('prompt_version'),
                'created_at': prompt1.get('created_at'),
                'accuracy': prompt1.get('accuracy_metrics', {}).get('accuracy_percent', 0)
            },
            'version_2': {
                'prompt_version': prompt2.get('prompt_version'),
                'created_at': prompt2.get('created_at'),
                'accuracy': prompt2.get('accuracy_metrics', {}).get('accuracy_percent', 0)
            },
            'differences': differences
        }
    
    # ========================================================================
    # Public Methods - Analytics
    # ========================================================================
    
    async def get_prompt_performance(
        self,
        event_type: str,
        prompt_version: Optional[str] = None,
        days: int = 30
    ) -> Dict:
        """Get performance metrics for a prompt"""
        # This would query the PromptPerformanceMetrics table
        # For now, return placeholder
        return {
            'event_type': event_type,
            'prompt_version': prompt_version or 'current',
            'date_range': [
                (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d'),
                datetime.now().strftime('%Y-%m-%d')
            ],
            'daily_metrics': [],
            'summary': {
                'avg_accuracy': 0.0,
                'total_decisions': 0,
                'improvement_vs_previous': '0%'
            }
        }
    
    # ========================================================================
    # Private Helper Methods
    # ========================================================================
    
    def _format_example_scenario(self, example: Dict) -> str:
        """Format a learning example as user input"""
        scenario = example.get('scenario', '')
        amount = example.get('amount', 'N/A')
        recipient = example.get('recipient', 'N/A')
        indicators = ', '.join(example.get('indicators', []))
        
        return f"""
Transaction Details:
- Scenario: {scenario}
- Amount: ${amount}
- Recipient: {recipient}
- Risk Indicators: {indicators}

Analyze this transaction for fraud risk.
"""
    
    def _format_example_decision(self, example: Dict) -> str:
        """Format example decision as assistant response"""
        # Use 'correct_decision' (new field) or fallback to 'decision' (legacy)
        decision = example.get('correct_decision', example.get('decision', 'UNKNOWN'))
        reasoning = example.get('reasoning', '')
        
        # Don't include confidence in LLM prompt (internal metadata only)
        return f"""
Decision: {decision}
Reasoning: {reasoning}
"""
    
    def _format_transaction(self, data: Dict) -> str:
        """Format current transaction for LLM analysis"""
        # Extract context (transaction details) from the llm_input structure
        context = data.get('context', {})
        agent_results = data.get('agent_results', {})
        rule_score = data.get('rule_score', 0)
        rule_decision = data.get('rule_decision', 'UNKNOWN')
        reasons = data.get('reasons', [])
        
        # Build transaction summary
        transaction_parts = []
        
        # Payment details - prioritize actual amount over range
        if context.get('payment_amount'):
            transaction_parts.append(f"Amount: ${context['payment_amount']:,.2f}")
        elif context.get('amount_range'):
            transaction_parts.append(f"Amount Range: {context['amount_range']}")
            
        if context.get('recipient_name'):
            transaction_parts.append(f"Recipient: {context['recipient_name']}")
        if context.get('vendor_name') and context.get('vendor_name') != context.get('recipient_name'):
            transaction_parts.append(f"Vendor: {context['vendor_name']}")
        if context.get('payment_method'):
            transaction_parts.append(f"Payment Method: {context['payment_method']}")
        if context.get('payment_description') and context.get('payment_description') != 'N/A':
            transaction_parts.append(f"Description: {context['payment_description']}")
        if context.get('claim_status'):
            transaction_parts.append(f"Claim Status: {context['claim_status']}")
        
        # Build agent results summary - extract risk from nested structure
        agent_parts = []
        for agent_name, agent_data in agent_results.items():
            if isinstance(agent_data, dict):
                # Try different risk field names based on agent type
                risk = (agent_data.get('risk') or 
                       agent_data.get('control_risk') or 
                       agent_data.get('last_mile_risk') or 
                       agent_data.get('entity_risk') or 
                       'UNKNOWN')
                
                # Try different score field names
                score = agent_data.get('score', 0)
                if score == 0 and 'risk_points' in agent_data.get('link_metrics', {}):
                    score = agent_data['link_metrics']['risk_points']
                
                agent_parts.append(f"{agent_name}: {risk} risk (score: {score})")
        
        # Build reasons list
        reasons_text = ""
        if reasons:
            reasons_text = "\n\nKey Risk Factors:\n" + chr(10).join(f"- {reason}" for reason in reasons)
        
        # Format the transaction query
        formatted = f"""Current Transaction to Analyze:

Transaction Details:
{chr(10).join(f"- {part}" for part in transaction_parts) if transaction_parts else "- No transaction details available"}

Agent Detection Results:
{chr(10).join(f"- {part}" for part in agent_parts) if agent_parts else "- No agent results available"}

Rule-Based Assessment: {rule_decision} (total risk score: {rule_score}/6){reasons_text}

Please provide your fraud risk analysis in the following JSON format:
{{
  "recommendation": "ALLOW|WARN|BLOCK",
  "risk_level": "LOW|MED|HIGH",
  "confidence": 0.0-1.0,
  "reasoning": "Brief explanation of your decision"
}}"""
        
        return formatted
    
    def _get_default_prompt(self, event_type: str) -> Dict:
        """Fallback default prompt if none exists in database"""
        import time
        
        default_model_config = {
            "model_name": "gpt-4",
            "temperature": 0.7,
            "max_tokens": 500
        }
        
        # Use Unix timestamp (integer) for consistency with PromptResponse model
        current_timestamp = int(time.time())
        
        default_prompts = {
            "PAYMENT_FRAUD": {
                "prompt_id": "default_payment_fraud",
                "prompt_version": "1.0.0",
                "event_type": "PAYMENT_FRAUD",
                "system_prompt": "You are a fraud detection agent. Analyze payment transactions for fraud risk. Evaluate transaction patterns, amounts, recipients, and timing to identify potential fraudulent activity.",
                "few_shot_examples": [],
                "model_config": default_model_config,
                "llm_model_config": default_model_config,
                "status": "ACTIVE",
                "is_active": True,
                "created_at": current_timestamp,
                "created_by": "system",
                "examples_count": 0
            },
            "PII_ACCESS": {
                "prompt_id": "default_pii_access",
                "prompt_version": "1.0.0",
                "event_type": "PII_ACCESS",
                "system_prompt": "You are a data security agent. Analyze employee access to personally identifiable information (PII) for potential data breaches or unauthorized access. Evaluate access patterns, data sensitivity, and employee roles.",
                "few_shot_examples": [],
                "model_config": default_model_config,
                "llm_model_config": default_model_config,
                "status": "ACTIVE",
                "is_active": True,
                "created_at": current_timestamp,
                "created_by": "system",
                "examples_count": 0
            },
            "DATA_MODIFICATION": {
                "prompt_id": "default_data_modification",
                "prompt_version": "1.0.0",
                "event_type": "DATA_MODIFICATION",
                "system_prompt": "You are a data integrity agent. Analyze employee modifications to critical system data for potential fraud or malicious activity. Evaluate modification patterns, data sensitivity, authorization levels, and business justification.",
                "few_shot_examples": [],
                "model_config": default_model_config,
                "llm_model_config": default_model_config,
                "status": "ACTIVE",
                "is_active": True,
                "created_at": current_timestamp,
                "created_by": "system",
                "examples_count": 0
            }
        }
        
        # Return the specific prompt or fall back to PAYMENT_FRAUD
        return default_prompts.get(event_type, default_prompts["PAYMENT_FRAUD"])
    
    def _calculate_accuracy_change(self, prompt1: Dict, prompt2: Dict) -> str:
        """Calculate accuracy change between two prompts"""
        acc1 = prompt1.get('accuracy_metrics', {}).get('accuracy_percent', 0)
        acc2 = prompt2.get('accuracy_metrics', {}).get('accuracy_percent', 0)
        
        if acc1 == 0:
            return "N/A"
        
        change = acc2 - acc1
        return f"{'+' if change >= 0 else ''}{change:.1f}%"
    
    async def invalidate_cache(self, event_type: str):
        """Invalidate cache when prompt is updated"""
        cache_key = f"active_prompt:{event_type}"
        if cache_key in self._cache:
            del self._cache[cache_key]
    
    async def get_prompt_statistics(self) -> Dict:
        """Get overall prompt statistics"""
        return await self.prompt_repo.get_prompt_statistics()

    async def create_prompt(
        self,
        event_type: str,
        template: str,
        version: str = None,
        description: str = None,
        created_by: str = "system",
        status: str = "DRAFT",
        few_shot_examples: List[Dict] = None
    ) -> Dict:
        """
        Create a new prompt version.
        Used by API endpoints to create prompts with a simpler interface.
        
        Args:
            event_type: Event type (PAYMENT_FRAUD, PII_ACCESS, DATA_MODIFICATION)
            template: System prompt template
            version: Version string (auto-generated if not provided)
            description: Description of the prompt
            created_by: Creator identifier
            status: Status (DRAFT, ACTIVE, ARCHIVED)
            few_shot_examples: List of few-shot examples
        
        Returns:
            Created prompt
        """
        # Auto-generate version if not provided
        if not version:
            # Get latest version for this event type
            existing = await self.prompt_repo.get_prompt_history(event_type, limit=1)
            if existing:
                latest_version = existing[0].get('prompt_version', '1.0')
                # Increment minor version
                parts = latest_version.split('.')
                major = int(parts[0])
                minor = int(parts[1]) if len(parts) > 1 else 0
                version = f"{major}.{minor + 1}"
            else:
                version = "1.0"
        
        # Build prompt data
        prompt_data = {
            'event_type': event_type,
            'prompt_version': version,
            'system_prompt': template,
            'template': template,  # Duplicate for compatibility
            'version': version,  # Duplicate for compatibility
            'few_shot_examples': few_shot_examples or [],
            'description': description or f"Prompt version {version}",
            'created_by': created_by,
            'status': status,
            'is_active': 'false',  # DynamoDB expects string 'true'/'false', not boolean
            'examples_count': len(few_shot_examples or []),
            'model_config': {
                "model_name": "gpt-4",
                "temperature": 0.7,
                "max_tokens": 500
            }
        }
        
        result = await self.prompt_repo.create_prompt_version(prompt_data)
        return self._map_config_field(result)

    async def update_prompt(
        self,
        prompt_id: str,
        template: str = None,
        description: str = None,
        updated_by: str = "system",
        few_shot_examples: List[Dict] = None
    ) -> Dict:
        """
        Update an existing prompt.
        Creates a new version if the prompt is ACTIVE.
        Updates in place if the prompt is DRAFT.
        
        Args:
            prompt_id: Prompt identifier
            template: New template (optional)
            description: New description (optional)
            updated_by: User updating the prompt
            few_shot_examples: New examples (optional)
        
        Returns:
            Updated prompt
        """
        # Get the current prompt
        current = await self.prompt_repo.get_prompt_by_id(prompt_id)
        if not current:
            raise ValueError(f"Prompt not found: {prompt_id}")
        
        # If ACTIVE, create a new version
        if current.get('status') == 'ACTIVE':
            return await self.create_prompt(
                event_type=current['event_type'],
                template=template or current['system_prompt'],
                version=None,  # Auto-increment
                description=description or f"Updated from {current.get('prompt_version')}",
                created_by=updated_by,
                status='DRAFT',
                few_shot_examples=few_shot_examples or current.get('few_shot_examples', [])
            )
        
        # If DRAFT, update in place
        update_data = {}
        if template:
            update_data['system_prompt'] = template
            update_data['template'] = template
        if description:
            update_data['description'] = description
        if few_shot_examples is not None:
            update_data['few_shot_examples'] = few_shot_examples
            update_data['examples_count'] = len(few_shot_examples)
        
        if not update_data:
            return self._map_config_field(current)
        
        result = await self.prompt_repo.update_prompt_fields(
            event_type=current['event_type'],
            version_id=current['version_id'],
            updates=update_data
        )
        
        return self._map_config_field(result)

    async def add_example_to_prompt(
        self,
        event_type: str,
        example: Dict,
        created_by: str = "learning_queue"
    ) -> Dict:
        """
        Add a few-shot example to the active prompt for an event type.
        Creates a new DRAFT version with the example appended.
        
        This is used by the Learning Queue to convert SIU feedback into
        new few-shot examples for prompts.
        
        Args:
            event_type: Event type (PAYMENT_FRAUD, PII_ACCESS, DATA_MODIFICATION)
            example: Few-shot example to add (dict with scenario, decision, reasoning, etc.)
            created_by: Creator identifier (defaults to "learning_queue")
        
        Returns:
            New DRAFT prompt version with the example added
        """
        # Get the active prompt
        active_prompt = await self.get_active_prompt(event_type, use_cache=False)
        if not active_prompt:
            raise ValueError(f"No active prompt found for event type: {event_type}")
        
        # Get current examples and append the new one
        current_examples = active_prompt.get('few_shot_examples', [])
        new_examples = current_examples + [example]
        
        # Get current version and increment minor version
        current_version = active_prompt.get('prompt_version', '1.0')
        parts = current_version.split('.')
        major = int(parts[0])
        minor = int(parts[1]) if len(parts) > 1 else 0
        new_version = f"{major}.{minor + 1}"
        
        # Create new DRAFT version with the appended example
        description = f"Added example from Learning Queue (previous: {current_version})"
        
        new_prompt = await self.create_prompt(
            event_type=event_type,
            template=active_prompt.get('system_prompt'),
            version=new_version,
            description=description,
            created_by=created_by,
            status='DRAFT',
            few_shot_examples=new_examples
        )
        
        return new_prompt

    async def update_prompt_from_learning_queue(
        self,
        event_type: str,
        template: str = None,
        example: Dict = None,
        description: str = None,
        created_by: str = "learning_queue",
        queue_id: str = None
    ) -> Dict:
        """
        Update prompt from Learning Queue - can update template and/or add examples.
        Creates a new DRAFT version with the changes.
        
        This method allows Learning Queue to:
        1. Update just the prompt template (system prompt)
        2. Add just a new few-shot example
        3. Update both template and add an example
        
        Args:
            event_type: Event type (PAYMENT_FRAUD, PII_ACCESS, DATA_MODIFICATION)
            template: New system prompt template (optional)
            example: Few-shot example to add (optional)
            description: Change description (optional)
            created_by: Creator identifier (defaults to "learning_queue")
            queue_id: Learning queue item ID (optional, tracked for marking as implemented)
        
        Returns:
            New DRAFT prompt version with the changes applied
        """
        import logging
        logger = logging.getLogger(__name__)
        # Get the active prompt
        active_prompt = await self.get_active_prompt(event_type, use_cache=False)
        if not active_prompt:
            raise ValueError(f"No active prompt found for event type: {event_type}")
        
        # At least one change must be provided
        if not template and not example:
            raise ValueError("Must provide either template or example (or both)")
        
        # Get current version and increment minor version
        current_version = active_prompt.get('prompt_version', '1.0')
        parts = current_version.split('.')
        major = int(parts[0])
        minor = int(parts[1]) if len(parts) > 1 else 0
        new_version = f"{major}.{minor + 1}"
        
        # Determine what's being updated
        changes = []
        if template:
            changes.append("template")
        if example:
            changes.append("example")
        
        # Use provided description or generate one
        if not description:
            change_type = " and ".join(changes)
            description = f"Updated {change_type} from Learning Queue (previous: {current_version})"
        
        # Use new template or keep existing
        new_template = template if template else active_prompt.get('system_prompt')
        
        # Add example to existing examples or keep existing
        current_examples = active_prompt.get('few_shot_examples', [])
        new_examples = current_examples + [example] if example else current_examples
        
        # Create new DRAFT version with the changes
        new_prompt = await self.create_prompt(
            event_type=event_type,
            template=new_template,
            version=new_version,
            description=description,
            created_by=created_by,
            status='DRAFT',
            few_shot_examples=new_examples
        )
        
        # If queue_id provided, update the prompt to track it
        if queue_id and new_prompt:
            try:
                event_type_key = new_prompt.get('event_type')
                version_id_key = new_prompt.get('version_id')
                logger.info(f"[QUEUE_TRACKING] Adding queue_id {queue_id} to prompt (event_type={event_type_key}, version_id={version_id_key})")
                
                # Get existing source_queue_ids or create new list
                existing_queue_ids = new_prompt.get('source_queue_ids', [])
                if queue_id not in existing_queue_ids:
                    existing_queue_ids.append(queue_id)
                
                logger.info(f"[QUEUE_TRACKING] source_queue_ids list: {existing_queue_ids}")
                
                # Update the prompt with source_queue_ids
                # Note: FraudDetectionPrompts table uses event_type and version_id as composite key
                from boto3.dynamodb.conditions import Key
                self.prompt_repo.prompts_table.update_item(
                    Key={
                        'event_type': event_type_key,
                        'version_id': version_id_key
                    },
                    UpdateExpression='SET source_queue_ids = :queue_ids',
                    ExpressionAttributeValues={
                        ':queue_ids': existing_queue_ids
                    }
                )
                logger.info(f"[QUEUE_TRACKING] ✅ Successfully updated prompt with source_queue_ids")
                
                # Update the returned prompt object
                new_prompt['source_queue_ids'] = existing_queue_ids
            except Exception as e:
                logger.error(f"[QUEUE_TRACKING] ❌ Could not update prompt with queue_id tracking: {e}")
                import traceback
                logger.error(f"[QUEUE_TRACKING] Traceback: {traceback.format_exc()}")
        
        return new_prompt

    async def update_prompt_examples(
        self,
        prompt_id: str,
        few_shot_examples: List[Dict],
        updated_by: str = "admin"
    ) -> Dict:
        """
        Update few-shot examples in a prompt.
        Delegates to update_prompt with just the examples parameter.
        
        Args:
            prompt_id: Prompt identifier
            few_shot_examples: New list of few-shot examples
            updated_by: User making the update
        
        Returns:
            Updated prompt
        """
        return await self.update_prompt(
            prompt_id=prompt_id,
            few_shot_examples=few_shot_examples,
            updated_by=updated_by
        )
