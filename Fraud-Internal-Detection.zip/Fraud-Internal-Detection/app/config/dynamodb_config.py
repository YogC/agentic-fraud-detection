"""
DynamoDB Configuration
Centralizes DynamoDB settings and connection parameters
"""
import os

# DynamoDB Configuration
DYNAMODB_CONFIG = {
    'region_name': os.getenv('AWS_REGION', 'us-east-1'),  # Use same region as Bedrock
    'table_name': os.getenv('DYNAMODB_TABLE_NAME', 'fraud-detection-events'),
    
    # Indexes
    'event_type_index': 'event_type-timestamp-index',
    'status_index': 'status-timestamp-index',
    'reviewer_index': 'reviewer_id-timestamp-index',
    
    # Retry configuration
    'max_retries': 3,
    'retry_delay': 1,  # seconds
}

# Event Types (Fraud Categories)
class EventType:
    # Primary event types
    PAYMENT_FRAUD = "PAYMENT_FRAUD"
    PII_ACCESS = "PII_ACCESS"
    DATA_MODIFICATION = "DATA_MODIFICATION"
    DATA_EXPORT = "DATA_EXPORT"
    SENSITIVE_DATA_VIEW = "SENSITIVE_DATA_VIEW"
    UNAUTHORIZED_ACCESS = "UNAUTHORIZED_ACCESS"
    REGULATORY_VIOLATION = "REGULATORY_VIOLATION"
    
    # Simple aliases for convenience
    PAYMENT = "PAYMENT_FRAUD"
    DATA_ACCESS = "PII_ACCESS"

# Entity Types
class EntityType:
    PAYMENT = "PAYMENT"
    USER_ACCESS = "USER_ACCESS"
    DATA_RECORD = "DATA_RECORD"
    DATA_EXPORT = "DATA_EXPORT"
    REGULATORY_REPORT = "REGULATORY_REPORT"
    SYSTEM_ACCESS = "SYSTEM_ACCESS"

# Risk Categories
class RiskCategory:
    FINANCIAL = "FINANCIAL"
    DATA_PRIVACY = "DATA_PRIVACY"
    REGULATORY_COMPLIANCE = "REGULATORY_COMPLIANCE"
    SECURITY = "SECURITY"
    OPERATIONAL = "OPERATIONAL"

# Decision status values
class DecisionStatus:
    PENDING_REVIEW = "PENDING_REVIEW"
    AUTO_APPROVED = "AUTO_APPROVED"
    APPROVED = "APPROVED"
    DENIED = "DENIED"
    UNDER_INVESTIGATION = "UNDER_INVESTIGATION"

# SIU actions - Clearer terminology for fraud assessment
class SIUAction:
    # Transaction decisions (what to do with the transaction)
    APPROVE = "APPROVE"  # Allow the transaction (not fraud)
    DENY = "DENY"  # Block the transaction (confirmed fraud)
    
    # Assessment decisions (clearer alternatives - backward compatible)
    CONFIRM_FRAUD = "DENY"  # Alias: SIU confirms it's fraud (same as DENY)
    FALSE_POSITIVE = "APPROVE"  # Alias: SIU says it's legitimate (same as APPROVE)
    
    # Other actions
    ESCALATE = "ESCALATE"
    REQUEST_INFO = "REQUEST_INFO"

# Actual outcomes (after investigation)
class ActualOutcome:
    CONFIRMED_FRAUD = "CONFIRMED_FRAUD"
    FALSE_POSITIVE = "FALSE_POSITIVE"
    INCONCLUSIVE = "INCONCLUSIVE"
    LEGITIMATE = "LEGITIMATE"
