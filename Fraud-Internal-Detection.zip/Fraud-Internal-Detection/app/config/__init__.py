"""
Configuration Package
Exports configuration constants and classes for the fraud detection system.
"""

from .dynamodb_config import (
    DYNAMODB_CONFIG,
    DecisionStatus,
    EventType,
    EntityType,
    RiskCategory,
    SIUAction,
    ActualOutcome
)

__all__ = [
    'DYNAMODB_CONFIG',
    'DecisionStatus',
    'EventType',
    'EntityType',
    'RiskCategory',
    'SIUAction',
    'ActualOutcome'
]
