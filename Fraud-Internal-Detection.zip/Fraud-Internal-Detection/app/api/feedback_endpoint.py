"""
Feedback API Endpoint
REST API for investigators to submit fraud detection outcomes.
Enables context-based learning by collecting real-world feedback.
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, Dict, Any
from datetime import datetime
import logging

from feedback.reward_system import RewardSystem
from feedback.feedback_store import FeedbackStore

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/api/v1/feedback", tags=["feedback"])

# Initialize systems
reward_system = RewardSystem()
feedback_store = FeedbackStore()


# ============================================
# Request/Response Models
# ============================================

class FeedbackRequest(BaseModel):
    """Investigator feedback submission."""
    
    payment_id: str = Field(..., description="Payment ID that was analyzed")
    decision: str = Field(..., description="Original decision (ALLOW/WARN/BLOCK)")
    actual_outcome: str = Field(
        ...,
        description="Actual outcome (CONFIRMED_FRAUD, FALSE_POSITIVE, CONFIRMED_LEGITIMATE, UNDER_INVESTIGATION)"
    )
    investigator_id: str = Field(..., description="Investigator identifier")
    investigator_notes: str = Field(..., description="Investigator's notes and findings")
    
    # Optional fields
    fraud_pattern: Optional[str] = Field(None, description="Type of fraud pattern identified")
    confidence: Optional[str] = Field(None, description="Investigator's confidence (LOW/MED/HIGH)")
    estimated_loss: Optional[float] = Field(None, description="Estimated fraud loss amount")
    related_cases: Optional[list] = Field(None, description="Related case IDs")
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "payment_id": "PAY-123",
                "decision": "BLOCK",
                "actual_outcome": "CONFIRMED_FRAUD",
                "investigator_id": "INV-456",
                "investigator_notes": "Employee was colluding with external party to launder funds via cryptocurrency wallet. Multiple similar attempts detected from same employee.",
                "fraud_pattern": "crypto_wallet_laundering",
                "confidence": "HIGH",
                "estimated_loss": 29997.00,
                "related_cases": ["PAY-115", "PAY-132"]
            }
        }
    )


class FeedbackResponse(BaseModel):
    """Response after processing feedback."""
    
    status: str
    feedback_id: str
    payment_id: str
    reward_calculated: int
    prompt_updated: bool
    message: str
    timestamp: str
    
    # Statistics
    total_feedback_count: int
    pattern_statistics: Optional[Dict[str, Any]] = None


class FeedbackStatsResponse(BaseModel):
    """Statistics about feedback and learning."""
    
    total_cases: int
    confirmed_fraud: int
    false_positives: int
    accuracy_rate: float
    top_patterns: list
    recent_feedback: list


# ============================================
# Endpoints
# ============================================

@router.post("/", response_model=FeedbackResponse)
async def submit_feedback(
    feedback: FeedbackRequest,
    background_tasks: BackgroundTasks
):
    """
    Submit investigator feedback for a fraud detection decision.
    
    This endpoint allows fraud investigators to report the actual outcome
    of a payment analysis. The system uses this feedback to improve future
    predictions through context-based learning.
    
    **Learning Process:**
    1. Calculate reward based on decision accuracy
    2. Add high-value cases to prompt examples
    3. Update pattern statistics
    4. Improve future LLM prompts with real cases
    
    **Outcome Types:**
    - `CONFIRMED_FRAUD`: Payment was actual fraud
    - `FALSE_POSITIVE`: Payment was legitimate (incorrectly flagged)
    - `CONFIRMED_LEGITIMATE`: Payment confirmed legitimate
    - `UNDER_INVESTIGATION`: Still being investigated
    """
    try:
        logger.info(f"Received feedback for payment {feedback.payment_id} from {feedback.investigator_id}")
        
        # Validate decision
        valid_decisions = ['ALLOW', 'WARN', 'BLOCK']
        if feedback.decision.upper() not in valid_decisions:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid decision. Must be one of: {valid_decisions}"
            )
        
        # Validate outcome
        valid_outcomes = [
            'CONFIRMED_FRAUD', 'FALSE_POSITIVE', 
            'CONFIRMED_LEGITIMATE', 'UNDER_INVESTIGATION'
        ]
        if feedback.actual_outcome.upper() not in valid_outcomes:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid outcome. Must be one of: {valid_outcomes}"
            )
        
        # Get original decision data
        original_decision = feedback_store.get_decision(feedback.payment_id)
        
        if not original_decision:
            logger.warning(f"No original decision found for {feedback.payment_id}")
            # Continue anyway - we can still record the feedback
        
        # Process feedback and calculate reward
        feedback_result = reward_system.process_feedback(
            payment_id=feedback.payment_id,
            decision=feedback.decision,
            actual_outcome=feedback.actual_outcome,
            investigator_notes=feedback.investigator_notes,
            fraud_pattern=feedback.fraud_pattern,
            additional_data={
                'investigator_id': feedback.investigator_id,
                'confidence': feedback.confidence,
                'estimated_loss': feedback.estimated_loss,
                'related_cases': feedback.related_cases,
                'original_decision_data': original_decision
            }
        )
        
        # Store feedback
        feedback_id = feedback_store.store_feedback(
            feedback_result=feedback_result,
            original_decision=original_decision
        )
        
        # Update prompt examples if high reward
        prompt_updated = False
        if feedback_result.get('add_to_prompts'):
            background_tasks.add_task(
                feedback_store.update_prompt_examples,
                feedback_id=feedback_id,
                feedback_result=feedback_result,
                original_decision=original_decision
            )
            prompt_updated = True
            logger.info(f"Feedback {feedback_id} will be added to prompt examples (reward: {feedback_result['reward']})")
        
        # Get updated statistics
        stats = feedback_store.get_statistics()
        
        # Build response
        response = FeedbackResponse(
            status="success",
            feedback_id=feedback_id,
            payment_id=feedback.payment_id,
            reward_calculated=feedback_result['reward'],
            prompt_updated=prompt_updated,
            message=f"Feedback processed successfully. Reward: {feedback_result['reward']:+d}",
            timestamp=datetime.utcnow().isoformat() + 'Z',
            total_feedback_count=stats.get('total_cases', 0),
            pattern_statistics=stats.get('patterns', {}).get(feedback.fraud_pattern) if feedback.fraud_pattern else None
        )
        
        logger.info(
            f"Feedback processed: {feedback_id}, reward={feedback_result['reward']}, "
            f"add_to_prompts={prompt_updated}"
        )
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error processing feedback: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to process feedback: {str(e)}"
        )


@router.get("/stats", response_model=FeedbackStatsResponse)
async def get_feedback_stats():
    """
    Get statistics about feedback and learning progress.
    
    Returns metrics about:
    - Total feedback cases collected
    - Accuracy rates (correct vs incorrect decisions)
    - Top fraud patterns detected
    - Recent feedback submissions
    """
    try:
        stats = feedback_store.get_statistics()
        
        total_cases = stats.get('total_cases', 0)
        confirmed_fraud = stats.get('confirmed_fraud', 0)
        false_positives = stats.get('false_positives', 0)
        
        # Calculate accuracy
        correct_decisions = stats.get('correct_decisions', 0)
        accuracy_rate = (correct_decisions / total_cases * 100) if total_cases > 0 else 0
        
        # Get top patterns
        patterns = stats.get('patterns', {})
        top_patterns = sorted(
            [
                {
                    'pattern': name,
                    'count': data.get('count', 0),
                    'accuracy': data.get('accuracy', 0)
                }
                for name, data in patterns.items()
            ],
            key=lambda x: x['count'],
            reverse=True
        )[:10]
        
        # Get recent feedback
        recent_feedback = feedback_store.get_recent_feedback(limit=10)
        
        return FeedbackStatsResponse(
            total_cases=total_cases,
            confirmed_fraud=confirmed_fraud,
            false_positives=false_positives,
            accuracy_rate=round(accuracy_rate, 2),
            top_patterns=top_patterns,
            recent_feedback=recent_feedback
        )
        
    except Exception as e:
        logger.error(f"Error getting feedback stats: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get statistics: {str(e)}"
        )


@router.get("/{payment_id}")
async def get_feedback_by_payment(payment_id: str):
    """
    Get feedback for a specific payment.
    
    Args:
        payment_id: Payment identifier
    
    Returns:
        Feedback data if exists, 404 if not found
    """
    try:
        feedback = feedback_store.get_feedback_by_payment(payment_id)
        
        if not feedback:
            raise HTTPException(
                status_code=404,
                detail=f"No feedback found for payment {payment_id}"
            )
        
        return feedback
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving feedback for {payment_id}: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to retrieve feedback: {str(e)}"
        )


@router.delete("/{feedback_id}")
async def delete_feedback(feedback_id: str):
    """
    Delete a feedback entry (admin only).
    
    Args:
        feedback_id: Feedback identifier
    
    Returns:
        Success message
    """
    try:
        result = feedback_store.delete_feedback(feedback_id)
        
        if not result:
            raise HTTPException(
                status_code=404,
                detail=f"Feedback {feedback_id} not found"
            )
        
        return {
            "status": "success",
            "message": f"Feedback {feedback_id} deleted",
            "timestamp": datetime.utcnow().isoformat() + 'Z'
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting feedback {feedback_id}: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to delete feedback: {str(e)}"
        )
