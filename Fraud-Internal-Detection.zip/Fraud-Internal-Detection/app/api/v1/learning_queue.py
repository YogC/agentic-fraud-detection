"""
Learning Queue API Endpoints
Provides REST API for managing the SIU feedback and prompt learning system.
"""
from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from datetime import datetime
import logging

from models.prompt_models import (
    LearningQueueItem,
    ReviewLearningCaseRequest,
    GeneratePromptRequest,
    LearningQueueResponse,
    LearningImpactResponse,
    StandardResponse
)
from services.learning_service import LearningService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/learning", tags=["Learning Queue"])

# Initialize service
learning_service = LearningService()


@router.get("/queue", response_model=List[LearningQueueItem])
async def get_learning_queue(
    status: Optional[str] = Query(None, description="Filter by status: PENDING, APPROVED, REJECTED, IMPLEMENTED"),
    event_type: Optional[str] = Query(None, description="Filter by event type"),
    limit: int = Query(100, ge=1, le=500)
):
    """
    Get learning queue items with optional filtering.
    Shows SIU feedback that can be used to improve prompts.
    
    Args:
        status: Status filter
        event_type: Event type filter
        limit: Maximum items
    
    Returns:
        List of learning queue items
    """
    try:
        items = await learning_service.get_learning_queue(
            status=status,
            event_type=event_type,
            limit=limit
        )
        return items
    except Exception as e:
        logger.error(f"Error getting learning queue: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# UNUSED: Old complex workflow endpoint - commented out for simplified workflow
# @router.get("/queue/pending", response_model=List[LearningQueueItem])
# async def get_pending_learning_items(
#     limit: int = Query(50, ge=1, le=200)
# ):
#     """Get pending learning queue items requiring review."""
#     try:
#         items = await learning_service.get_learning_queue(
#             status="PENDING",
#             limit=limit
#         )
#         return items
#     except Exception as e:
#         logger.error(f"Error getting pending items: {e}")
#         raise HTTPException(status_code=500, detail=str(e))


# UNUSED: Old complex workflow endpoint - commented out for simplified workflow
# @router.get("/queue/{queue_id}", response_model=LearningQueueItem)
# async def get_learning_item(queue_id: str):
#     """Get a specific learning queue item by ID."""
#     try:
#         item = await learning_service.get_learning_item(queue_id)
#         if not item:
#             raise HTTPException(
#                 status_code=404,
#                 detail=f"Learning item not found: {queue_id}"
#             )
#         return item
#     except HTTPException:
#         raise
#     except Exception as e:
#         logger.error(f"Error getting learning item: {e}")
#         raise HTTPException(status_code=500, detail=str(e))


# UNUSED: Old complex workflow endpoint - commented out for simplified workflow
# @router.post("/queue", response_model=StandardResponse)
# async def add_to_learning_queue(
#     event_id: str = Query(..., description="Event ID to add to learning queue"),
#     event_timestamp: int = Query(..., description="Event timestamp")
# ):
#     """Add a new item to the learning queue."""
#     try:
#         result = await learning_service.add_decision_to_queue(
#             event_id=event_id,
#             event_timestamp=event_timestamp
#         )
#         return StandardResponse(
#             status="success",
#             message=f"Added to learning queue: {result.get('queue_id')}",
#             data=result
#         )
#     except ValueError as e:
#         raise HTTPException(status_code=400, detail=str(e))
#     except Exception as e:
#         logger.error(f"Error adding to learning queue: {e}")
#         raise HTTPException(status_code=500, detail=str(e))


# UNUSED: Old complex workflow endpoint - commented out for simplified workflow
# @router.post("/queue/{queue_id}/review", response_model=LearningQueueItem)
# async def review_learning_item(queue_id: str, request: ReviewLearningCaseRequest):
#     """Review and process a learning queue item."""
#     try:
#         item = await learning_service.review_learning_item(
#             queue_id=queue_id,
#             reviewed_by=request.reviewed_by,
#             status=request.status,
#             review_notes=request.review_notes
#         )
#         if not item:
#             raise HTTPException(
#                 status_code=404,
#                 detail=f"Learning item not found: {queue_id}"
#             )
#         return item
#     except HTTPException:
#         raise
#     except ValueError as e:
#         raise HTTPException(status_code=400, detail=str(e))
#     except Exception as e:
#         logger.error(f"Error reviewing learning item: {e}")
#         raise HTTPException(status_code=500, detail=str(e))


@router.post("/queue/{queue_id}/implement", response_model=dict)
async def implement_learning(
    queue_id: str,
    implemented_by: str = Query(..., description="User implementing the learning"),
    notes: Optional[str] = Query(None, description="Implementation notes")
):
    """
    Mark a learning item as implemented.
    This means the suggestion has been incorporated into a prompt.
    
    Args:
        queue_id: Queue item identifier
        implemented_by: User implementing
        notes: Implementation notes
    
    Returns:
        Success response with updated item
    """
    try:
        logger.info(f"[IMPLEMENT] ========================================")
        logger.info(f"[IMPLEMENT] Marking learning item as implemented")
        logger.info(f"[IMPLEMENT] queue_id: {queue_id}")
        logger.info(f"[IMPLEMENT] implemented_by: {implemented_by}")
        logger.info(f"[IMPLEMENT] notes: {notes}")
        
        item = await learning_service.mark_as_implemented(
            queue_id=queue_id,
            implemented_by=implemented_by,
            notes=notes
        )
        
        if not item:
            logger.error(f"[IMPLEMENT] ❌ Learning item not found: {queue_id}")
            raise HTTPException(
                status_code=404,
                detail=f"Learning item not found: {queue_id}"
            )
        
        logger.info(f"[IMPLEMENT] ✅ Successfully marked as implemented")
        logger.info(f"[IMPLEMENT] ========================================")
        
        return {
            "success": True,
            "message": "Learning item marked as implemented",
            "item": item
        }
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"[IMPLEMENT] ❌ ValueError: {e}", exc_info=True)
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"[IMPLEMENT] ❌ Unexpected error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# UNUSED: Old complex workflow endpoint - commented out for simplified workflow
# @router.post("/generate-prompt/{queue_id}", response_model=dict)
# async def generate_improved_prompt(
#     queue_id: str,
#     generated_by: str = Query(..., description="User generating prompt")
# ):
#     """Generate an improved prompt based on learning item feedback."""
#     try:
#         result = await learning_service.generate_improved_prompt(
#             queue_id=queue_id,
#             generated_by=generated_by
#         )
#         
#         if not result:
#             raise HTTPException(
#                 status_code=404,
#                 detail=f"Learning item not found: {queue_id}"
#             )
#         
#         return result
#     except HTTPException:
#         raise
#     except ValueError as e:
#         raise HTTPException(status_code=400, detail=str(e))
#     except Exception as e:
#         logger.error(f"Error generating prompt: {e}")
#         raise HTTPException(status_code=500, detail=str(e))


# UNUSED: Old complex workflow endpoint - commented out for simplified workflow
# @router.get("/analytics/impact", response_model=LearningImpactResponse)
# async def get_prompt_impact_analytics(
#     event_type: Optional[str] = Query(None, description="Filter by event type")
# ):
#     """Get analytics on prompt learning impact."""
#     try:
#         analytics = await learning_service.get_impact_analytics(event_type=event_type)
#         return analytics
#     except Exception as e:
#         logger.error(f"Error getting impact analytics: {e}")
#         raise HTTPException(status_code=500, detail=str(e))


# UNUSED: Old complex workflow endpoint - commented out for simplified workflow
# @router.get("/statistics/summary")
# async def get_learning_statistics():
#     """Get summary statistics for the learning system."""
#     try:
#         stats = await learning_service.get_learning_statistics()
#         return stats
#     except Exception as e:
#         logger.error(f"Error getting learning statistics: {e}")
#         raise HTTPException(status_code=500, detail=str(e))


# UNUSED: Old complex workflow endpoint - commented out for simplified workflow
# @router.get("/insights")
# async def get_learning_insights():
#     """Get actionable insights from the learning queue."""
#     try:
#         insights = await learning_service.get_learning_insights()
#         return insights
#     except Exception as e:
#         logger.error(f"Error getting insights: {e}")
#         raise HTTPException(status_code=500, detail=str(e))


# UNUSED: Old complex workflow endpoint - commented out for simplified workflow
# @router.post("/batch/process")
# async def process_learning_batch(
#     event_type: Optional[str] = Query(None, description="Event type to process"),
#     batch_size: int = Query(10, ge=1, le=50),
#     processed_by: str = Query(..., description="User processing batch")
# ):
#     """Process a batch of learning items."""
#     try:
#         results = await learning_service.process_learning_batch(
#             event_type=event_type,
#             batch_size=batch_size,
#             processed_by=processed_by
#         )
#         return {
#             "success": True,
#             "processed_count": len(results),
#             "results": results
#         }
#     except Exception as e:
#         logger.error(f"Error processing batch: {e}")
#         raise HTTPException(status_code=500, detail=str(e))
