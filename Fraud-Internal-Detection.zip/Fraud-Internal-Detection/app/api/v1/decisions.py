"""
Decisions API - Endpoints for retrieving fraud detection decisions
Supports the Streamlit dashboard with pending cases, statistics, and history.
"""

from fastapi import APIRouter, HTTPException, Query
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from decimal import Decimal
import boto3
from boto3.dynamodb.conditions import Key, Attr
import logging
import time

# Import reward calculation for learning queue
from feedback.reward_system import calculate_reward_score

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/decisions", tags=["decisions"])

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
events_table = dynamodb.Table('fraud-detection-events')


def _normalize_decision_format(item: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize decision format from DynamoDB for dashboard consumption.
    Extracts data from nested structures and ensures all required fields exist.
    
    Args:
        item: Raw DynamoDB item
        
    Returns:
        Normalized decision dict with flat structure
    """
    
    def convert_decimal(obj):
        """Convert Decimal to int or float"""
        if isinstance(obj, Decimal):
            return int(obj) if obj % 1 == 0 else float(obj)
        return obj
    
    # Extract nested structures
    event_data = item.get('event_data', {})
    display_metadata = item.get('display_metadata', {})
    detection_results = item.get('detection_results', {})
    
    # Handle nested llm_decision format (backward compatibility)
    llm_decision_value = item.get('llm_decision')
    llm_confidence_value = item.get('llm_confidence', 0.0)
    llm_reasoning_value = item.get('llm_reasoning', '')
    
    if isinstance(llm_decision_value, dict):
        # Nested format - flatten it (extract before overwriting variable)
        nested_decision = llm_decision_value.get('decision', llm_decision_value.get('llm_decision', 'UNKNOWN'))
        nested_confidence = llm_decision_value.get('confidence', llm_decision_value.get('llm_confidence', 0.0))
        nested_reasoning = llm_decision_value.get('reasoning', llm_decision_value.get('llm_reasoning', ''))
        
        llm_decision_value = nested_decision
        llm_confidence_value = nested_confidence if nested_confidence else llm_confidence_value
        llm_reasoning_value = nested_reasoning if nested_reasoning else llm_reasoning_value
    
    # Use llm_decision or fall back to final_decision
    decision = llm_decision_value or item.get('final_decision', 'UNKNOWN')
    
    # Convert timestamp to int (handle Decimal from DynamoDB)
    timestamp = convert_decimal(item.get('timestamp', 0))
    
    # Build normalized response
    normalized = {
        # IDs and basic info
        'event_id': item.get('event_id'),
        'timestamp': int(timestamp),
        'created_at': item.get('created_at', datetime.fromtimestamp(timestamp).isoformat() if timestamp else datetime.utcnow().isoformat()),
        'event_type': item.get('event_type', 'PAYMENT_FRAUD'),
        'entity_id': item.get('entity_id'),
        'entity_type': item.get('entity_type'),
        'risk_category': item.get('risk_category'),
        
        # Decision info
        'llm_decision': decision,
        'llm_confidence': float(convert_decimal(llm_confidence_value)) if llm_confidence_value else 0.0,
        'llm_reasoning': llm_reasoning_value or 'No reasoning provided',
        'llm_key_factors': item.get('llm_key_factors', []),
        'final_decision': item.get('final_decision', decision),
        
        # Status
        'status': item.get('status', 'PENDING_REVIEW'),
        'review_status': item.get('review_status', 'PENDING'),
        'risk_level': item.get('risk_level', 'UNKNOWN'),
        
        # Agent scores (for dashboard compatibility)
        'total_score': convert_decimal(item.get('total_score')) if item.get('total_score') is not None else 0,
        
        # Event data (extract from nested structure, convert Decimals)
        'event_data': {
            'claim_id': event_data.get('claim_id', display_metadata.get('claim_id', 'N/A')),
            'vendor_name': display_metadata.get('vendor_name', 'N/A'),
            'amount': convert_decimal(event_data.get('payment_amount', display_metadata.get('payment_amount', 0))),
            'payment_description': display_metadata.get('payment_description', 'N/A'),
            'payment_method': event_data.get('payment_method', 'N/A'),
            'employee_id': event_data.get('actor_id', display_metadata.get('employee_id', 'N/A')),
            'actor_role': event_data.get('actor_role', 'N/A'),
        },
        
        # Also include the raw event_data and display_metadata for dashboard
        'display_metadata': display_metadata,
        
        # Detection results (extract from nested structure, convert Decimals)
        'detection_results': {
            'employee_control': detection_results.get('employee_control', {}),
            'graph_entity': detection_results.get('graph_entity', {}),
            'lastmile_payment': detection_results.get('lastmile_payment', {}),
            'employee_control_score': convert_decimal(detection_results.get('employee_control', {}).get('score', 0)),
            'graph_entity_score': convert_decimal(detection_results.get('graph_entity', {}).get('score', 0)),
            'lastmile_payment_score': convert_decimal(detection_results.get('lastmile_payment', {}).get('score', 0)),
            'total_score': convert_decimal(item.get('total_score', 0)),
        },
        
        # Review info (if reviewed)
        'reviewer_id': item.get('reviewer_id'),
        'reviewer_action': item.get('reviewer_action'),
        'reviewer_notes': item.get('reviewer_notes'),
        'reviewed_at': item.get('reviewed_at'),
        'actual_outcome': item.get('actual_outcome'),
        'reward_score': convert_decimal(item.get('reward_score')) if item.get('reward_score') else None,
    }
    
    return normalized


@router.get("/")
async def get_all_decisions(
    limit: int = Query(default=100, ge=1, le=1000),
    decision_type: Optional[str] = Query(default=None, regex="^(ALLOW|WARN|BLOCK)$"),
    risk_level: Optional[str] = Query(default=None, regex="^(LOW|MED|HIGH)$")
) -> List[Dict[str, Any]]:
    """
    Get all fraud detection decisions with optional filtering.
    This is the main endpoint for fetching all cases.
    """
    try:
        logger.info(f"Fetching all decisions (limit={limit}, decision={decision_type}, risk={risk_level})")
        
        # Build filter expression
        filter_expr = None
        if decision_type:
            filter_expr = Attr('decision').eq(decision_type)
        if risk_level:
            risk_filter = Attr('llm_risk_level').eq(risk_level) | Attr('risk_level').eq(risk_level)
            filter_expr = filter_expr & risk_filter if filter_expr else risk_filter
        
        # Scan with filters
        if filter_expr:
            response = events_table.scan(FilterExpression=filter_expr, Limit=limit)
        else:
            response = events_table.scan(Limit=limit)
        
        items = response.get('Items', [])
        
        # Sort by timestamp (newest first) - convert Decimal to int for sorting
        items.sort(key=lambda x: int(x.get('timestamp', 0)) if isinstance(x.get('timestamp', 0), Decimal) else x.get('timestamp', 0), reverse=True)
        
        # Format for dashboard using normalization
        all_decisions = [_normalize_decision_format(item) for item in items]
        
        logger.info(f"Returning {len(all_decisions)} decisions")
        
        # Return list directly for dashboard compatibility
        return all_decisions
        
    except Exception as e:
        logger.error(f"Error fetching all decisions: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch all decisions: {str(e)}")


@router.get("/pending")
async def get_pending_decisions(
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0)
) -> Dict[str, Any]:
    """
    Get pending fraud detection decisions that need manual SIU review.
    Returns cases with PENDING_REVIEW status.
    """
    try:
        logger.info(f"Fetching pending decisions (limit={limit}, offset={offset})")
        
        # Query by status index (more efficient than scan)
        response = events_table.scan(
            FilterExpression=Attr('status').eq('PENDING_REVIEW')
        )
        
        items = response.get('Items', [])
        logger.info(f"Found {len(items)} items with PENDING_REVIEW status")
        
        # Sort by timestamp (newest first) - convert Decimal to int for sorting
        items.sort(key=lambda x: int(x.get('timestamp', 0)) if isinstance(x.get('timestamp', 0), Decimal) else x.get('timestamp', 0), reverse=True)
        
        # Paginate
        paginated_items = items[offset:offset + limit]
        
        # Format for dashboard (normalize and extract nested data)
        pending_cases = []
        for item in paginated_items:
            # Normalize the decision format (handle nested structures)
            normalized_item = _normalize_decision_format(item)
            pending_cases.append(normalized_item)
        
        logger.info(f"Returning {len(pending_cases)} pending cases")
        
        # Return as dict with metadata for dashboard compatibility
        return {
            'success': True,
            'total': len(items),
            'limit': limit,
            'offset': offset,
            'cases': pending_cases
        }
        
    except Exception as e:
        logger.error(f"Error fetching pending decisions: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch pending decisions: {str(e)}")


@router.get("/event-types/{event_type}")
async def get_decisions_by_event_type(
    event_type: str,
    limit: int = Query(default=100, ge=1, le=1000)
) -> List[Dict[str, Any]]:
    """
    Get decisions filtered by event type.
    """
    try:
        logger.info(f"Fetching decisions for event type: {event_type} (limit={limit})")
        
        response = events_table.scan(
            FilterExpression=Attr('event_type').eq(event_type),
            Limit=limit
        )
        
        items = response.get('Items', [])
        
        # Sort by timestamp (newest first)
        items.sort(key=lambda x: int(x.get('timestamp', 0)) if isinstance(x.get('timestamp', 0), Decimal) else x.get('timestamp', 0), reverse=True)
        
        decisions = [_normalize_decision_format(item) for item in items]
        
        logger.info(f"Returning {len(decisions)} decisions for event type: {event_type}")
        return decisions
        
    except Exception as e:
        logger.error(f"Error fetching decisions by event type: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch decisions by event type: {str(e)}")


@router.get("/status/{status}")
async def get_decisions_by_status(
    status: str,
    limit: int = Query(default=100, ge=1, le=1000)
) -> List[Dict[str, Any]]:
    """
    Get decisions filtered by status.
    """
    try:
        logger.info(f"Fetching decisions with status: {status} (limit={limit})")
        
        response = events_table.scan(
            FilterExpression=Attr('status').eq(status),
            Limit=limit
        )
        
        items = response.get('Items', [])
        
        # Sort by timestamp (newest first)
        items.sort(key=lambda x: int(x.get('timestamp', 0)) if isinstance(x.get('timestamp', 0), Decimal) else x.get('timestamp', 0), reverse=True)
        
        decisions = [_normalize_decision_format(item) for item in items]
        
        logger.info(f"Returning {len(decisions)} decisions with status: {status}")
        return decisions
        
    except Exception as e:
        logger.error(f"Error fetching decisions by status: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch decisions by status: {str(e)}")


@router.get("/reviewer/{reviewer_id}")
async def get_decisions_by_reviewer(
    reviewer_id: str,
    limit: int = Query(default=50, ge=1, le=500)
) -> List[Dict[str, Any]]:
    """
    Get decisions reviewed by a specific reviewer.
    """
    try:
        logger.info(f"Fetching decisions reviewed by: {reviewer_id} (limit={limit})")
        
        response = events_table.scan(
            FilterExpression=Attr('reviewer_id').eq(reviewer_id),
            Limit=limit
        )
        
        items = response.get('Items', [])
        
        # Sort by reviewed_at timestamp (newest first)
        items.sort(key=lambda x: int(x.get('reviewed_at', 0)) if isinstance(x.get('reviewed_at', 0), Decimal) else x.get('reviewed_at', 0), reverse=True)
        
        decisions = [_normalize_decision_format(item) for item in items]
        
        logger.info(f"Returning {len(decisions)} decisions reviewed by: {reviewer_id}")
        return decisions
        
    except Exception as e:
        logger.error(f"Error fetching decisions by reviewer: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch decisions by reviewer: {str(e)}")


@router.get("/statistics/summary")
async def get_statistics_summary(
    days: int = Query(default=7, ge=1, le=90)
) -> Dict[str, Any]:
    """
    Get summary statistics for fraud detection decisions.
    Returns counts, percentages, and trends.
    """
    try:
        logger.info(f"Fetching statistics summary for last {days} days")
        
        # Calculate timestamp for the time window
        cutoff_timestamp = int((datetime.now() - timedelta(days=days)).timestamp())
        
        # Scan all recent events
        response = events_table.scan(
            FilterExpression=Attr('timestamp').gte(cutoff_timestamp)
        )
        
        items = response.get('Items', [])
        
        # Calculate statistics
        total_decisions = len(items)
        allow_count = sum(1 for item in items if item.get('decision') == 'ALLOW')
        warn_count = sum(1 for item in items if item.get('decision') == 'WARN')
        block_count = sum(1 for item in items if item.get('decision') == 'BLOCK')
        
        # Risk level breakdown
        high_risk_count = sum(1 for item in items if item.get('llm_risk_level') == 'HIGH' or item.get('risk_level') == 'HIGH')
        med_risk_count = sum(1 for item in items if item.get('llm_risk_level') == 'MED' or item.get('risk_level') == 'MED')
        low_risk_count = sum(1 for item in items if item.get('llm_risk_level') == 'LOW' or item.get('risk_level') == 'LOW')
        
        # Average confidence
        confidences = [float(item.get('llm_confidence', 0)) for item in items if item.get('llm_confidence')]
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0
        
        # LLM usage
        llm_used_count = sum(1 for item in items if item.get('llm_recommendation'))
        
        logger.info(f"Statistics: {total_decisions} total, {allow_count} allowed, {warn_count} warned, {block_count} blocked")
        
        return {
            'success': True,
            'period_days': days,
            'total_decisions': total_decisions,
            'decisions': {
                'allow': allow_count,
                'warn': warn_count,
                'block': block_count,
                'allow_percentage': (allow_count / total_decisions * 100) if total_decisions > 0 else 0,
                'warn_percentage': (warn_count / total_decisions * 100) if total_decisions > 0 else 0,
                'block_percentage': (block_count / total_decisions * 100) if total_decisions > 0 else 0,
            },
            'risk_levels': {
                'high': high_risk_count,
                'medium': med_risk_count,
                'low': low_risk_count,
            },
            'llm_metrics': {
                'total_used': llm_used_count,
                'usage_percentage': (llm_used_count / total_decisions * 100) if total_decisions > 0 else 0,
                'average_confidence': round(avg_confidence, 3)
            },
            'timestamp': int(datetime.now().timestamp())
        }
        
    except Exception as e:
        logger.error(f"Error fetching statistics: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch statistics: {str(e)}")


@router.get("/history")
async def get_decision_history(
    limit: int = Query(default=100, ge=1, le=1000),
    decision_type: Optional[str] = Query(default=None, regex="^(ALLOW|WARN|BLOCK)$"),
    risk_level: Optional[str] = Query(default=None, regex="^(LOW|MED|HIGH)$")
) -> Dict[str, Any]:
    """
    Get historical fraud detection decisions with optional filtering.
    """
    try:
        logger.info(f"Fetching decision history (limit={limit}, decision={decision_type}, risk={risk_level})")
        
        # Build filter expression
        filter_expr = None
        if decision_type:
            filter_expr = Attr('decision').eq(decision_type)
        if risk_level:
            risk_filter = Attr('llm_risk_level').eq(risk_level) | Attr('risk_level').eq(risk_level)
            filter_expr = filter_expr & risk_filter if filter_expr else risk_filter
        
        # Scan with filters
        if filter_expr:
            response = events_table.scan(FilterExpression=filter_expr, Limit=limit)
        else:
            response = events_table.scan(Limit=limit)
        
        items = response.get('Items', [])
        
        # Sort by timestamp (newest first) - convert Decimal to int for sorting
        items.sort(key=lambda x: int(x.get('timestamp', 0)) if isinstance(x.get('timestamp', 0), Decimal) else x.get('timestamp', 0), reverse=True)
        
        # Format for dashboard using normalization
        history = [_normalize_decision_format(item) for item in items]
        
        logger.info(f"Returning {len(history)} historical decisions")
        
        # Return list directly for dashboard compatibility
        return history
        
    except Exception as e:
        logger.error(f"Error fetching decision history: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch decision history: {str(e)}")


@router.get("/{event_id}")
async def get_decision_details(event_id: str) -> Dict[str, Any]:
    """
    Get detailed information about a specific fraud detection decision.
    """
    try:
        logger.info(f"Fetching details for event: {event_id}")
        
        response = events_table.get_item(Key={'event_id': event_id})
        
        if 'Item' not in response:
            raise HTTPException(status_code=404, detail=f"Decision not found: {event_id}")
        
        item = response['Item']
        
        # Format detailed response
        details = {
            'event_id': item.get('event_id'),
            'event_type': item.get('event_type', 'PAYMENT_FRAUD'),
            'claim_id': item.get('claim_id'),
            'vendor_name': item.get('vendor_name'),
            'amount': item.get('amount'),
            'payment_description': item.get('payment_description'),
            'payment_method': item.get('payment_method'),
            'timestamp': item.get('timestamp'),
            'employee_id': item.get('employee_id'),
            'decision': {
                'final_decision': item.get('decision'),
                'risk_level': item.get('llm_risk_level', item.get('risk_level')),
                'confidence': item.get('llm_confidence'),
            },
            'llm_analysis': {
                'recommendation': item.get('llm_recommendation'),
                'analysis': item.get('llm_analysis'),
                'reasoning': item.get('llm_reasoning'),
                'key_factors': item.get('llm_key_factors', []),
                'confidence': item.get('llm_confidence'),
            },
            'agent_scores': {
                'employee_control': {
                    'score': item.get('employee_control_score', 0),
                    'risk': item.get('employee_control_risk', 'UNKNOWN'),
                },
                'graph_entity': {
                    'score': item.get('graph_entity_score', 0),
                    'risk': item.get('graph_entity_risk', 'UNKNOWN'),
                },
                'lastmile_payment': {
                    'score': item.get('lastmile_payment_score', 0),
                    'risk': item.get('lastmile_payment_risk', 'UNKNOWN'),
                },
            },
            'rule_based': {
                'decision': item.get('rule_decision'),
                'score': item.get('rule_score'),
            },
            'metadata': {
                'processing_time_ms': item.get('processing_time_ms'),
                'prompt_id': item.get('prompt_id'),
                'prompt_version': item.get('prompt_version'),
            }
        }
        
        logger.info(f"Returning details for event: {event_id}")
        return {'success': True, 'decision': details}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching decision details: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch decision details: {str(e)}")


@router.post("/review")
async def submit_review(review_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Submit SIU review for a fraud detection decision.
    Updates the decision in DynamoDB and optionally adds to learning queue.
    
    Required fields in review_data:
    - event_id: The event identifier
    - timestamp: The event timestamp (part of composite key)
    - reviewer_id: ID of the reviewer
    - reviewer_action: Action taken (APPROVE, DENY, INVESTIGATE, etc.)
    """
    try:
        event_id = review_data.get('event_id')
        timestamp = review_data.get('timestamp')
        reviewer_id = review_data.get('reviewer_id')
        reviewer_action = review_data.get('reviewer_action')
        reviewer_notes = review_data.get('reviewer_notes', '')
        actual_outcome = review_data.get('actual_outcome')
        add_to_learning_queue = review_data.get('add_to_learning_queue', False)
        
        # Validate required fields - including timestamp for composite key
        if not all([event_id, timestamp, reviewer_id, reviewer_action]):
            raise HTTPException(
                status_code=400, 
                detail="Missing required fields: event_id, timestamp, reviewer_id, reviewer_action"
            )
        
        # Ensure timestamp is int (handle Decimal from DynamoDB)
        timestamp_int = int(timestamp) if timestamp else None
        if not timestamp_int:
            raise HTTPException(status_code=400, detail="Invalid timestamp value")
        
        logger.info(f"Submitting review for event: {event_id} (timestamp: {timestamp_int}) by {reviewer_id} - Action: {reviewer_action}, Actual Outcome: {actual_outcome}, Add to Queue: {add_to_learning_queue}")
        
        # Get the existing decision using composite key
        response = events_table.get_item(
            Key={
                'event_id': event_id,
                'timestamp': timestamp_int
            }
        )
        if 'Item' not in response:
            raise HTTPException(
                status_code=404, 
                detail=f"Decision not found: {event_id} at timestamp {timestamp_int}"
            )
        
        # Update the decision with review information using composite key
        update_expr = "SET reviewer_id = :reviewer_id, reviewer_action = :action, reviewer_notes = :notes, reviewed_at = :reviewed_at, #status = :status"
        expr_values = {
            ':reviewer_id': reviewer_id,
            ':action': reviewer_action,
            ':notes': reviewer_notes,
            ':reviewed_at': int(time.time()),
            ':status': 'APPROVED' if reviewer_action == 'APPROVE' else 'DENIED' if reviewer_action == 'DENY' else 'UNDER_INVESTIGATION'
        }
        expr_names = {'#status': 'status'}
        
        if actual_outcome:
            update_expr += ", actual_outcome = :outcome"
            expr_values[':outcome'] = actual_outcome
        
        events_table.update_item(
            Key={
                'event_id': event_id,
                'timestamp': timestamp_int
            },
            UpdateExpression=update_expr,
            ExpressionAttributeValues=expr_values,
            ExpressionAttributeNames=expr_names
        )
        
        # Add to learning queue if requested
        if add_to_learning_queue:
            try:
                learning_queue_table = dynamodb.Table('PromptLearningQueue')
                item = response['Item']
                
                # Get LLM decision from the event (normalize format first)
                llm_decision_field = item.get('llm_decision')
                if isinstance(llm_decision_field, dict):
                    # Nested format
                    llm_decision = llm_decision_field.get('decision') or llm_decision_field.get('llm_decision') or 'UNKNOWN'
                else:
                    # Direct value or fallback to final_decision
                    llm_decision = llm_decision_field or item.get('final_decision') or item.get('decision') or 'UNKNOWN'
                
                logger.info(f"Extracted llm_decision for learning queue: {llm_decision} (actual_outcome: {actual_outcome})")
                
                # Calculate reward score based on LLM decision and actual outcome
                reward_score = 0
                if actual_outcome:
                    reward_score = calculate_reward_score(
                        llm_decision=llm_decision,
                        actual_outcome=actual_outcome
                    )
                    logger.info(f"Calculated reward_score: {reward_score} for {llm_decision} -> {actual_outcome}")
                
                # Determine priority based on reward score
                if abs(reward_score) >= 100:
                    priority = 'HIGH'
                elif abs(reward_score) >= 50:
                    priority = 'MEDIUM'
                else:
                    priority = 'LOW'
                
                # Extract scenario description from the event
                scenario_parts = []
                if item.get('claim_id'):
                    scenario_parts.append(f"Claim {item.get('claim_id')}")
                if item.get('payment_id'):
                    scenario_parts.append(f"Payment {item.get('payment_id')}")
                if item.get('employee_id'):
                    scenario_parts.append(f"by Employee {item.get('employee_id')}")
                scenario_description = ' - '.join(scenario_parts) if scenario_parts else 'Payment transaction'
                
                queue_item = {
                    'queue_id': f"REVIEW_{event_id}_{int(time.time())}",
                    'event_id': event_id,
                    'created_at': int(time.time()),
                    'event_timestamp': timestamp_int,
                    
                    # Event details
                    'event_type': item.get('event_type', 'PAYMENT_FRAUD'),
                    'claim_id': item.get('claim_id', 'N/A'),
                    'vendor_name': item.get('vendor_name', 'N/A'),
                    'payment_id': item.get('payment_id', 'N/A'),
                    'employee_id': item.get('employee_id', 'N/A'),
                    
                    # LLM fields (ensure both field names for compatibility)
                    'llm_recommendation': llm_decision,
                    'llm_decision': llm_decision,  # UI expects this field
                    'llm_reasoning': item.get('llm_reasoning', 'No reasoning provided'),
                    'llm_confidence': Decimal(str(item.get('llm_confidence', 0.0))) if item.get('llm_confidence') else Decimal('0.0'),
                    
                    # Decisions
                    'rule_decision': item.get('rule_decision', 'UNKNOWN'),
                    'human_decision': actual_outcome if actual_outcome else reviewer_action,
                    'actual_outcome': actual_outcome if actual_outcome else reviewer_action,  # UI expects this field
                    
                    # Feedback and scoring
                    'reward_score': reward_score,  # CRITICAL: Now included
                    'priority': priority,
                    'is_correct': reward_score > 0,
                    
                    # Review details
                    'review_status': 'PENDING',
                    'feedback_text': reviewer_notes,
                    'reviewer_notes': reviewer_notes,  # UI expects this field
                    'siu_feedback': reviewer_notes,  # UI expects this field
                    'reviewed_by': reviewer_id,
                    'reviewed_at': int(time.time()),
                    
                    # Scenario description for learning
                    'scenario_description': scenario_description,
                    
                    # Metadata
                    'incorporated_into_prompt': 'false',
                    'status': 'PENDING_REVIEW',  # For repository queries
                    'target_event_type': item.get('event_type', 'PAYMENT_FRAUD')
                }
                
                learning_queue_table.put_item(Item=queue_item)
                logger.info(f"Added to learning queue: {queue_item['queue_id']} with reward_score={reward_score}")
            except Exception as e:
                logger.error(f"Failed to add to learning queue: {e}")
                import traceback
                logger.error(traceback.format_exc())
                # Don't fail the review submission if learning queue fails
        
        logger.info(f"Review submitted successfully for event: {event_id}")
        
        return {
            'success': True,
            'message': f'Review submitted successfully',
            'event_id': event_id,
            'reviewer_action': reviewer_action,
            'status': 'APPROVED' if reviewer_action == 'APPROVE' else 'DENIED' if reviewer_action == 'DENY' else 'UNDER_INVESTIGATION'
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error submitting review: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to submit review: {str(e)}")
