"""
Prompt Management API Endpoints
Provides REST API for managing LLM prompts with versioning and audit trail.
"""
from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from datetime import datetime
import logging

from models.prompt_models import (
    PromptVersion,
    PromptVersionSummary,
    CreatePromptRequest,
    ActivatePromptRequest,
    RollbackPromptRequest,
    PromptResponse,
    PromptHistoryResponse,
    PromptComparisonResponse,
    StandardResponse
)
from services.prompt_service import PromptService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/prompts", tags=["Prompt Management"])

# Initialize service
prompt_service = PromptService()


@router.get("/", response_model=List[PromptResponse])
async def list_prompts(
    event_type: Optional[str] = Query(None, description="Filter by event type"),
    status: Optional[str] = Query("ACTIVE", description="Filter by status: ACTIVE, ARCHIVED, DRAFT"),
    limit: int = Query(100, ge=1, le=500, description="Maximum number of prompts to return")
):
    """
    List all prompts with optional filtering.
    
    Args:
        event_type: Optional event type filter (PAYMENT_FRAUD, PII_ACCESS, DATA_MODIFICATION)
        status: Status filter (ACTIVE, ARCHIVED, DRAFT)
        limit: Maximum results
    
    Returns:
        List of prompts matching criteria
    """
    try:
        prompts = await prompt_service.list_prompts(
            event_type=event_type,
            status=status,
            limit=limit
        )
        return prompts
    except Exception as e:
        logger.error(f"Error listing prompts: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/event-types/{event_type}/active", response_model=PromptResponse)
async def get_active_prompt(event_type: str):
    """
    Get the currently active prompt for a specific event type.
    This is the prompt being used in production.
    
    Args:
        event_type: Event type (PAYMENT_FRAUD, PII_ACCESS, DATA_MODIFICATION)
    
    Returns:
        Active prompt for the event type
    """
    try:
        logger.info(f"Fetching active prompt for event_type: {event_type}")
        prompt = await prompt_service.get_active_prompt(event_type)
        
        if not prompt:
            logger.warning(f"No prompt returned for event_type: {event_type}, this should not happen as default should be returned")
            raise HTTPException(
                status_code=404,
                detail=f"No active prompt found for event type: {event_type}"
            )
        
        logger.info(f"Successfully retrieved prompt for {event_type}: {prompt.get('prompt_id')}")
        return prompt
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting active prompt for {event_type}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/event-types/{event_type}/versions", response_model=List[PromptResponse])
async def list_prompt_versions(
    event_type: str,
    limit: int = Query(50, ge=1, le=100, description="Maximum number of versions")
):
    """
    List all versions of prompts for a specific event type.
    Ordered by version descending (newest first).
    
    Args:
        event_type: Event type
        limit: Maximum number of versions
    
    Returns:
        List of prompt versions
    """
    try:
        versions = await prompt_service.list_prompt_versions(
            event_type=event_type,
            limit=limit
        )
        return versions
    except Exception as e:
        logger.error(f"Error listing prompt versions: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{prompt_id}", response_model=PromptResponse)
async def get_prompt_by_id(prompt_id: str):
    """
    Get a specific prompt by ID.
    
    Args:
        prompt_id: Prompt identifier
    
    Returns:
        Prompt details
    """
    try:
        prompt = await prompt_service.get_prompt_by_id(prompt_id)
        if not prompt:
            raise HTTPException(
                status_code=404,
                detail=f"Prompt not found: {prompt_id}"
            )
        return prompt
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting prompt: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/", response_model=PromptResponse)
async def create_prompt(request: CreatePromptRequest):
    """
    Create a new prompt.
    
    Args:
        request: Prompt creation request
    
    Returns:
        Created prompt
    """
    try:
        prompt = await prompt_service.create_prompt(
            event_type=request.event_type,
            template=request.template,
            version=request.version,
            description=request.description,
            created_by=request.created_by,
            status=request.status
        )
        return prompt
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating prompt: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{prompt_id}", response_model=PromptResponse)
async def update_prompt(prompt_id: str, request: CreatePromptRequest):
    """
    Update an existing prompt (creates a new version if active).
    
    Args:
        prompt_id: Prompt identifier
        request: Update request
    
    Returns:
        Updated prompt
    """
    try:
        prompt = await prompt_service.update_prompt(
            prompt_id=prompt_id,
            template=request.template,
            description=request.description,
            updated_by=request.updated_by
        )
        if not prompt:
            raise HTTPException(
                status_code=404,
                detail=f"Prompt not found: {prompt_id}"
            )
        return prompt
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating prompt: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{prompt_id}/activate", response_model=PromptResponse)
async def activate_prompt(prompt_id: str, activated_by: str = Query(..., description="User activating prompt")):
    """
    Activate a prompt version (sets as active for its event type).
    Deactivates the currently active prompt.
    
    Args:
        prompt_id: Prompt identifier
        activated_by: User performing activation
    
    Returns:
        Activated prompt
    """
    try:
        prompt = await prompt_service.activate_prompt(
            prompt_id=prompt_id,
            activated_by=activated_by
        )
        if not prompt:
            raise HTTPException(
                status_code=404,
                detail=f"Prompt not found: {prompt_id}"
            )
        return prompt
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error activating prompt: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{prompt_id}/archive", response_model=PromptResponse)
async def archive_prompt(prompt_id: str, archived_by: str = Query(..., description="User archiving prompt")):
    """
    Archive a prompt (cannot archive active prompts).
    
    Args:
        prompt_id: Prompt identifier
        archived_by: User performing archival
    
    Returns:
        Archived prompt
    """
    try:
        prompt = await prompt_service.archive_prompt(
            prompt_id=prompt_id,
            archived_by=archived_by
        )
        if not prompt:
            raise HTTPException(
                status_code=404,
                detail=f"Prompt not found: {prompt_id}"
            )
        return prompt
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error archiving prompt: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/event-types/{event_type}/add-example", response_model=PromptResponse)
async def add_example_to_prompt(
    event_type: str,
    example: dict,
    created_by: str = Query("learning_queue", description="User adding the example")
):
    """
    Add a few-shot example to the active prompt for an event type.
    Creates a new DRAFT version with the example appended.
    
    This endpoint is used by the Learning Queue to convert SIU feedback
    into new few-shot examples for prompts.
    
    Args:
        event_type: Event type (PAYMENT_FRAUD, PII_ACCESS, DATA_MODIFICATION)
        example: Few-shot example to add (dict with input/output/reasoning)
        created_by: User adding the example (defaults to "learning_queue")
    
    Returns:
        New DRAFT prompt version with the example added
    """
    try:
        logger.info(f"Adding example to prompt for event_type: {event_type}")
        
        new_version = await prompt_service.add_example_to_prompt(
            event_type=event_type,
            example=example,
            created_by=created_by
        )
        
        if not new_version:
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create new version with example for event type: {event_type}"
            )
        
        logger.info(f"Successfully created new DRAFT version: {new_version.get('prompt_id')}")
        return new_version
        
    except ValueError as e:
        logger.error(f"Validation error adding example: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error adding example to prompt: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/event-types/{event_type}/update-from-learning", response_model=PromptResponse)
async def update_prompt_from_learning_queue(
    event_type: str,
    payload: dict,
    created_by: str = Query("learning_queue", description="User updating the prompt")
):
    """
    Update prompt from Learning Queue - can update template and/or add examples.
    Creates a new DRAFT version with the changes.
    
    This endpoint is used by the Learning Queue to:
    1. Update the prompt template (system prompt)
    2. Add new few-shot examples
    3. Or both
    
    Args:
        event_type: Event type (PAYMENT_FRAUD, PII_ACCESS, DATA_MODIFICATION)
        payload: Dict containing:
            - template (optional): New system prompt template
            - example (optional): Few-shot example to add
            - description (optional): Change description
            - queue_id (optional): Learning queue item ID (for tracking)
        created_by: User making the update (defaults to "learning_queue")
    
    Returns:
        New DRAFT prompt version with the changes applied
    """
    try:
        logger.info(f"Updating prompt from Learning Queue for event_type: {event_type}")
        logger.info(f"Payload keys: {list(payload.keys())}")
        
        new_version = await prompt_service.update_prompt_from_learning_queue(
            event_type=event_type,
            template=payload.get('template'),
            example=payload.get('example'),
            description=payload.get('description'),
            created_by=created_by,
            queue_id=payload.get('queue_id')
        )
        
        if not new_version:
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create new version for event type: {event_type}"
            )
        
        logger.info(f"Successfully created new DRAFT version: {new_version.get('prompt_id')}")
        return new_version
        
    except ValueError as e:
        logger.error(f"Validation error updating prompt: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating prompt from learning queue: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/compare", response_model=PromptComparisonResponse)
async def compare_prompts(prompt_id_1: str = Query(...), prompt_id_2: str = Query(...)):
    """
    Compare two prompt versions side by side.
    Useful for reviewing changes and understanding prompt evolution.
    
    Args:
        prompt_id_1: First prompt ID
        prompt_id_2: Second prompt ID
    
    Returns:
        Comparison response with both prompts
    """
    try:
        prompt1 = await prompt_service.get_prompt_by_id(prompt_id_1)
        prompt2 = await prompt_service.get_prompt_by_id(prompt_id_2)
        
        if not prompt1 or not prompt2:
            raise HTTPException(
                status_code=404,
                detail="One or both prompts not found"
            )
        
        # Calculate differences
        template_diff = len(set(prompt1.template.split()) - set(prompt2.template.split()))
        
        return PromptComparisonResponse(
            prompt_1=prompt1,
            prompt_2=prompt2,
            differences={
                "template_word_changes": template_diff,
                "version_diff": f"{prompt1.version} → {prompt2.version}",
                "status_diff": f"{prompt1.status} → {prompt2.status}"
            }
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error comparing prompts: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/audit/{event_type}", response_model=List[dict])
async def get_prompt_audit_trail(
    event_type: str,
    limit: int = Query(100, ge=1, le=500)
):
    """
    Get audit trail for prompt changes for a specific event type.
    Shows who made changes, when, and what was changed.
    
    Args:
        event_type: Event type
        limit: Maximum records
    
    Returns:
        Audit trail entries
    """
    try:
        versions = await prompt_service.list_prompt_versions(
            event_type=event_type,
            limit=limit
        )
        
        audit_trail = []
        for prompt in versions:
            entry = {
                "prompt_id": prompt.prompt_id,
                "version": prompt.version,
                "status": prompt.status,
                "created_at": prompt.created_at,
                "created_by": prompt.created_by,
                "activated_at": prompt.activated_at,
                "activated_by": prompt.activated_by,
                "description": prompt.description,
                "template_preview": prompt.template[:100] + "..." if len(prompt.template) > 100 else prompt.template
            }
            audit_trail.append(entry)
        
        return audit_trail
    except Exception as e:
        logger.error(f"Error getting audit trail: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/statistics/summary")
async def get_prompt_statistics():
    """
    Get summary statistics for prompt management.
    
    Returns:
        Statistics including total prompts, versions, active prompts, etc.
    """
    try:
        stats = await prompt_service.get_prompt_statistics()
        return stats
    except Exception as e:
        logger.error(f"Error getting statistics: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{prompt_id}/examples", response_model=PromptResponse)
async def update_prompt_examples(
    prompt_id: str,
    payload: dict
):
    """
    Update few-shot examples in a prompt.
    Creates a new version with updated examples.
    
    Args:
        prompt_id: Prompt identifier
        payload: Dict containing:
            - few_shot_examples: List of few-shot examples
            - updated_by: User making the update
    
    Returns:
        Updated prompt version
    """
    try:
        logger.info(f"Updating examples for prompt: {prompt_id}")
        
        # Get the existing prompt
        existing_prompt = await prompt_service.get_prompt_by_id(prompt_id)
        if not existing_prompt:
            raise HTTPException(
                status_code=404,
                detail=f"Prompt not found: {prompt_id}"
            )
        
        # Update the few-shot examples
        few_shot_examples = payload.get('few_shot_examples', [])
        updated_by = payload.get('updated_by', 'admin')
        
        # Use the prompt service to update the examples
        updated_prompt = await prompt_service.update_prompt_examples(
            prompt_id=prompt_id,
            few_shot_examples=few_shot_examples,
            updated_by=updated_by
        )
        
        if not updated_prompt:
            raise HTTPException(
                status_code=500,
                detail=f"Failed to update examples for prompt: {prompt_id}"
            )
        
        logger.info(f"Successfully updated examples for prompt: {prompt_id}")
        return updated_prompt
        
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating examples: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating examples: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))
