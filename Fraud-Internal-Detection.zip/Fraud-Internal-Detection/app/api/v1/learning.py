"""
Learning API - Endpoints for prompt learning and performance insights
Supports the Streamlit dashboard with learning queue and model performance data.
"""

from fastapi import APIRouter, HTTPException, Query
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import boto3
from boto3.dynamodb.conditions import Key, Attr
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/learning", tags=["learning"])

# Initialize DynamoDB clients
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
learning_queue_table = dynamodb.Table('PromptLearningQueue')
metrics_table = dynamodb.Table('PromptPerformanceMetrics')
events_table = dynamodb.Table('fraud-detection-events')


@router.get("/insights")
async def get_learning_insights(
    days: int = Query(default=7, ge=1, le=90)
) -> Dict[str, Any]:
    """
    Get AI learning insights including model performance, accuracy trends,
    and recommendations for prompt improvements.
    """
    try:
        logger.info(f"Fetching learning insights for last {days} days")
        
        cutoff_timestamp = int((datetime.now() - timedelta(days=days)).timestamp())
        
        # Get recent events with LLM decisions
        events_response = events_table.scan(
            FilterExpression=Attr('timestamp').gte(cutoff_timestamp) & 
                           Attr('llm_recommendation').exists()
        )
        events = events_response.get('Items', [])
        
        # Get learning queue items
        queue_response = learning_queue_table.scan(
            FilterExpression=Attr('created_at').gte(cutoff_timestamp)
        )
        queue_items = queue_response.get('Items', [])
        
        # Calculate insights
        total_llm_decisions = len(events)
        
        # Agreement analysis
        agreement_count = sum(1 for e in events if e.get('llm_recommendation') == e.get('rule_decision'))
        disagreement_count = total_llm_decisions - agreement_count
        
        # Confidence distribution
        high_confidence = sum(1 for e in events if float(e.get('llm_confidence', 0)) > 0.85)
        medium_confidence = sum(1 for e in events if 0.6 <= float(e.get('llm_confidence', 0)) <= 0.85)
        low_confidence = sum(1 for e in events if float(e.get('llm_confidence', 0)) < 0.6)
        
        # Risk distribution
        high_risk = sum(1 for e in events if e.get('llm_risk_level') == 'HIGH')
        med_risk = sum(1 for e in events if e.get('llm_risk_level') == 'MED')
        low_risk = sum(1 for e in events if e.get('llm_risk_level') == 'LOW')
        
        # Learning opportunities
        pending_feedback = sum(1 for q in queue_items if q.get('review_status') == 'PENDING')
        reviewed_feedback = sum(1 for q in queue_items if q.get('review_status') == 'REVIEWED')
        incorporated = sum(1 for q in queue_items if q.get('incorporated_into_prompt') == 'true')
        
        # False positive/negative estimates (based on human review if available)
        reviewed_items = [q for q in queue_items if q.get('human_decision')]
        false_positives = sum(1 for q in reviewed_items 
                            if q.get('llm_recommendation') == 'BLOCK' and q.get('human_decision') == 'ALLOW')
        false_negatives = sum(1 for q in reviewed_items 
                            if q.get('llm_recommendation') == 'ALLOW' and q.get('human_decision') == 'BLOCK')
        
        # Calculate accuracy if we have reviewed items
        accuracy = None
        if len(reviewed_items) > 0:
            correct = len(reviewed_items) - false_positives - false_negatives
            accuracy = (correct / len(reviewed_items)) * 100
        
        # Top fraud patterns detected
        fraud_patterns = {}
        for event in events:
            if event.get('llm_recommendation') in ['BLOCK', 'WARN']:
                factors = event.get('llm_key_factors', [])
                for factor in factors:
                    fraud_patterns[factor] = fraud_patterns.get(factor, 0) + 1
        
        # Sort patterns by frequency
        top_patterns = sorted(fraud_patterns.items(), key=lambda x: x[1], reverse=True)[:10]
        
        logger.info(f"Generated insights: {total_llm_decisions} decisions, {pending_feedback} pending feedback")
        
        return {
            'success': True,
            'period_days': days,
            'summary': {
                'total_llm_decisions': total_llm_decisions,
                'llm_rule_agreement': agreement_count,
                'llm_rule_disagreement': disagreement_count,
                'agreement_rate': (agreement_count / total_llm_decisions * 100) if total_llm_decisions > 0 else 0,
            },
            'confidence_distribution': {
                'high_confidence': high_confidence,
                'medium_confidence': medium_confidence,
                'low_confidence': low_confidence,
            },
            'risk_distribution': {
                'high_risk': high_risk,
                'medium_risk': med_risk,
                'low_risk': low_risk,
            },
            'learning_queue': {
                'pending_review': pending_feedback,
                'reviewed': reviewed_feedback,
                'incorporated_into_prompt': incorporated,
                'total_feedback_items': len(queue_items),
            },
            'accuracy_metrics': {
                'false_positives': false_positives,
                'false_negatives': false_negatives,
                'accuracy_percentage': round(accuracy, 2) if accuracy else None,
                'reviewed_cases': len(reviewed_items),
            },
            'top_fraud_patterns': [
                {'pattern': pattern, 'count': count}
                for pattern, count in top_patterns
            ],
            'recommendations': _generate_recommendations(
                total_llm_decisions,
                agreement_count,
                low_confidence,
                pending_feedback,
                false_positives,
                false_negatives
            ),
            'timestamp': int(datetime.now().timestamp())
        }
        
    except Exception as e:
        logger.error(f"Error fetching learning insights: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch learning insights: {str(e)}")


@router.get("/queue")
async def get_learning_queue(
    limit: int = Query(default=50, ge=1, le=500),
    status: Optional[str] = Query(default=None, regex="^(PENDING_REVIEW|APPROVED|REJECTED|IMPLEMENTED)$"),
    include_incorporated: bool = Query(default=False, description="Include already incorporated items")
) -> Dict[str, Any]:
    """
    Get items from the learning queue that need human review or have been reviewed.
    By default, excludes already incorporated items.
    """
    try:
        logger.info(f"Fetching learning queue (limit={limit}, status={status}, include_incorporated={include_incorporated})")
        
        # Build filter expression
        if status:
            # Use 'status' field (not 'review_status') to match DynamoDB schema
            filter_expr = Attr('status').eq(status)
        elif not include_incorporated:
            # Exclude incorporated items by default
            filter_expr = Attr('incorporated_into_prompt').ne('true')
        else:
            filter_expr = None
        
        # Scan with filter
        if filter_expr:
            response = learning_queue_table.scan(
                FilterExpression=filter_expr,
                Limit=limit
            )
        else:
            response = learning_queue_table.scan(Limit=limit)
        
        items = response.get('Items', [])
        
        # Sort by absolute reward_score (highest priority first)
        # Higher absolute scores indicate more valuable learning opportunities
        items.sort(key=lambda x: abs(float(x.get('reward_score', 0))), reverse=True)
        
        # Format for dashboard
        queue_items = []
        for item in items:
            queue_items.append({
                'queue_id': item.get('queue_id'),
                'event_id': item.get('event_id'),
                'claim_id': item.get('claim_id', 'N/A'),
                'vendor_name': item.get('vendor_name', 'N/A'),
                'event_type': item.get('event_type', 'PAYMENT_FRAUD'),
                
                # LLM fields (match dashboard expectations)
                'llm_recommendation': item.get('llm_recommendation'),
                'llm_decision': item.get('llm_recommendation'),  # Dashboard expects this field name
                'llm_reasoning': item.get('llm_reasoning', 'No reasoning'),
                'llm_confidence': item.get('llm_confidence', 0.0),
                
                # Decisions
                'rule_decision': item.get('rule_decision'),
                'human_decision': item.get('human_decision'),
                'actual_outcome': item.get('human_decision'),  # Dashboard expects this field name
                
                # Review status
                'review_status': item.get('review_status', 'PENDING'),
                'feedback_text': item.get('feedback_text'),
                'reviewer_notes': item.get('reviewer_notes', item.get('feedback_text', '')),
                'siu_feedback': item.get('siu_feedback', item.get('feedback_text', '')),
                
                # Metadata
                'reward_score': item.get('reward_score', 0),
                'priority': item.get('priority', 'MEDIUM'),
                'scenario_description': item.get('scenario_description', 'Payment transaction'),
                'created_at': item.get('created_at'),
                'reviewed_at': item.get('reviewed_at'),
                'reviewed_by': item.get('reviewed_by'),
                'incorporated': item.get('incorporated_into_prompt') == 'true',
            })
        
        logger.info(f"Returning {len(queue_items)} learning queue items")
        
        return {
            'success': True,
            'count': len(queue_items),
            'items': queue_items
        }
        
    except Exception as e:
        logger.error(f"Error fetching learning queue: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch learning queue: {str(e)}")


@router.get("/performance/trends")
async def get_performance_trends(
    days: int = Query(default=30, ge=7, le=90)
) -> Dict[str, Any]:
    """
    Get performance trends over time for LLM and rule-based decisions.
    """
    try:
        logger.info(f"Fetching performance trends for last {days} days")
        
        cutoff_timestamp = int((datetime.now() - timedelta(days=days)).timestamp())
        
        # Get events grouped by day
        response = events_table.scan(
            FilterExpression=Attr('timestamp').gte(cutoff_timestamp)
        )
        events = response.get('Items', [])
        
        # Group by day
        daily_stats = {}
        for event in events:
            timestamp = event.get('timestamp', 0)
            date = datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d')
            
            if date not in daily_stats:
                daily_stats[date] = {
                    'date': date,
                    'total': 0,
                    'allow': 0,
                    'warn': 0,
                    'block': 0,
                    'llm_used': 0,
                    'avg_confidence': [],
                }
            
            daily_stats[date]['total'] += 1
            decision = event.get('decision')
            if decision == 'ALLOW':
                daily_stats[date]['allow'] += 1
            elif decision == 'WARN':
                daily_stats[date]['warn'] += 1
            elif decision == 'BLOCK':
                daily_stats[date]['block'] += 1
            
            if event.get('llm_recommendation'):
                daily_stats[date]['llm_used'] += 1
                if event.get('llm_confidence'):
                    daily_stats[date]['avg_confidence'].append(float(event.get('llm_confidence')))
        
        # Calculate averages
        trends = []
        for date, stats in sorted(daily_stats.items()):
            confidence_list = stats.pop('avg_confidence')
            stats['avg_confidence'] = sum(confidence_list) / len(confidence_list) if confidence_list else 0.0
            trends.append(stats)
        
        logger.info(f"Returning {len(trends)} days of performance trends")
        
        return {
            'success': True,
            'period_days': days,
            'trends': trends
        }
        
    except Exception as e:
        logger.error(f"Error fetching performance trends: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch performance trends: {str(e)}")


@router.post("/queue/{queue_id}/implement")
async def mark_queue_item_as_implemented(
    queue_id: str,
    implemented_by: str = Query(..., description="User ID who implemented the change"),
    notes: Optional[str] = Query(default=None, description="Implementation notes")
) -> Dict[str, Any]:
    """
    Mark a learning queue item as implemented/incorporated.
    This prevents it from appearing again when loading feedback items.
    """
    try:
        logger.info(f"Marking learning queue item {queue_id} as implemented by {implemented_by}")
        
        # Check if item exists - need to query since we only have queue_id
        from boto3.dynamodb.conditions import Key
        response = learning_queue_table.query(
            KeyConditionExpression=Key('queue_id').eq(queue_id),
            Limit=1
        )
        
        if 'Items' not in response or len(response['Items']) == 0:
            raise HTTPException(status_code=404, detail=f"Learning queue item not found: {queue_id}")
        
        item = response['Items'][0]
        created_at = item.get('created_at')
        
        # Update the item - need both keys
        import time
        update_expr = "SET incorporated_into_prompt = :incorporated, #status = :status, reviewed_at = :reviewed_at, reviewed_by = :reviewed_by"
        expr_names = {'#status': 'status'}  # status is a reserved word
        expr_values = {
            ':incorporated': 'true',
            ':status': 'IMPLEMENTED',
            ':reviewed_at': int(time.time()),
            ':reviewed_by': implemented_by
        }
        
        if notes:
            update_expr += ", reviewer_notes = :notes"
            expr_values[':notes'] = notes
        
        learning_queue_table.update_item(
            Key={
                'queue_id': queue_id,
                'created_at': created_at
            },
            UpdateExpression=update_expr,
            ExpressionAttributeNames=expr_names,
            ExpressionAttributeValues=expr_values
        )
        
        logger.info(f"Successfully marked {queue_id} as implemented")
        
        return {
            'success': True,
            'message': 'Learning queue item marked as implemented',
            'queue_id': queue_id,
            'item': item
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error marking queue item as implemented: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to mark item as implemented: {str(e)}")
    

def _generate_recommendations(
    total_decisions: int,
    agreement_count: int,
    low_confidence_count: int,
    pending_feedback: int,
    false_positives: int,
    false_negatives: int
) -> List[str]:
    """Generate actionable recommendations based on metrics."""
    recommendations = []
    
    if total_decisions == 0:
        recommendations.append("No LLM decisions yet. Start testing fraud scenarios to build insights.")
        return recommendations
    
    agreement_rate = (agreement_count / total_decisions * 100) if total_decisions > 0 else 0
    
    if agreement_rate < 70:
        recommendations.append(
            f"⚠️ LLM-Rule agreement is only {agreement_rate:.1f}%. Review disagreement cases to identify prompt improvements."
        )
    
    if low_confidence_count > total_decisions * 0.3:
        recommendations.append(
            f"⚠️ {low_confidence_count} decisions have low confidence (<60%). Consider adding more few-shot examples to the prompt."
        )
    
    if pending_feedback > 10:
        recommendations.append(
            f"📝 {pending_feedback} cases are awaiting human review. Review these to improve prompt accuracy."
        )
    
    if false_positives > 5:
        recommendations.append(
            f"⚠️ {false_positives} false positives detected. Adjust prompt to reduce over-blocking."
        )
    
    if false_negatives > 3:
        recommendations.append(
            f"🚨 {false_negatives} false negatives detected. Strengthen fraud detection rules in the prompt."
        )
    
    if agreement_rate >= 85 and low_confidence_count < total_decisions * 0.1:
        recommendations.append(
            "✅ Model performance is excellent! Continue monitoring and incorporating edge cases."
        )
    
    return recommendations
