"""
Internal API Endpoints
Used by the fraud detection system to store decisions (not exposed to external users)
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, Optional
import logging
from datetime import datetime

from database.dynamodb_client import get_dynamodb_client

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/internal/fraud-detection", tags=["internal"])


class FraudDetectionResult(BaseModel):
    """Internal model for storing fraud detection results"""
    event_id: str
    timestamp: int
    event_type: str = "PAYMENT_FRAUD"
    entity_id: Optional[str] = None
    entity_type: Optional[str] = None
    risk_category: Optional[str] = None
    event_data: dict = {}
    detection_results: dict = {}
    llm_decision: str
    llm_confidence: float
    llm_reasoning: str
    final_decision: str
    status: str


@router.post("/store")
async def store_fraud_detection(detection: FraudDetectionResult):
    """
    Store fraud detection result in database
    Called by the fraud detection orchestrator after processing
    
    Args:
        detection: Fraud detection result
        
    Returns:
        Stored decision
    """
    try:
        db = get_dynamodb_client()
        
        # Convert timestamp to datetime (use UTC to avoid Windows timestamp issues)
        try:
            from datetime import datetime as dt, timezone
            created_at = dt.fromtimestamp(detection.timestamp, tz=timezone.utc).isoformat()
        except (ValueError, OSError, OverflowError) as e:
            # If timestamp conversion fails, use current time
            logger.warning(f"Invalid timestamp {detection.timestamp}, using current time: {str(e)}")
            created_at = dt.now(timezone.utc).isoformat()
        
        # Prepare decision data
        decision_data = {
            'event_id': detection.event_id,
            'timestamp': detection.timestamp,
            'event_type': detection.event_type,
            'entity_id': detection.entity_id or detection.event_id,
            'entity_type': detection.entity_type or 'PAYMENT',
            'risk_category': detection.risk_category or 'UNKNOWN',
            'event_data': detection.event_data,
            'detection_results': detection.detection_results,
            'llm_decision': detection.llm_decision,
            'llm_confidence': detection.llm_confidence,
            'llm_reasoning': detection.llm_reasoning,
            'final_decision': detection.final_decision,
            'status': detection.status,
            'created_at': created_at
        }
        
        # Store in DynamoDB
        stored = db.store_decision(decision_data)
        
        logger.info(f"Stored fraud detection: {detection.event_id} - {detection.final_decision}")
        
        return stored
        
    except Exception as e:
        logger.error(f"Error storing fraud detection: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error storing detection: {str(e)}")


@router.delete("/clear-test-data")
async def clear_test_data():
    """
    Clear all test data from DynamoDB
    WARNING: This deletes ALL fraud detection records!
    Use only for testing/development
    
    Returns:
        Number of items deleted
    """
    try:
        db = get_dynamodb_client()
        
        # Get all decisions
        all_decisions = db.get_all_decisions(limit=1000)
        
        deleted_count = 0
        for decision in all_decisions:
            try:
                db.delete_decision(
                    event_id=decision['event_id'],
                    timestamp=decision['timestamp']
                )
                deleted_count += 1
            except Exception as e:
                logger.error(f"Error deleting {decision['event_id']}: {str(e)}")
        
        logger.info(f"🗑️ Cleared {deleted_count} test records from DynamoDB")
        
        return {
            "status": "success",
            "message": f"All test data cleared from DynamoDB",
            "items_deleted": deleted_count
        }
        
    except Exception as e:
        logger.error(f"Error clearing test data: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error clearing data: {str(e)}")
