﻿"""
AWS Bedrock LLM Agent for Claude 3.5 Sonnet
Handles communication with AWS Bedrock for fraud detection analysis.
Enhanced with logging, compliance safeguards, and LangSmith tracing.
"""

import json
import logging
import time
import os
from typing import Dict, Any, Optional
import boto3
from botocore.exceptions import ClientError
from services.prompt_service import PromptService

# LangSmith imports for trace visualization
try:
    from langsmith import traceable
    from langsmith.run_helpers import get_current_run_tree
    LANGSMITH_AVAILABLE = True
except ImportError:
    LANGSMITH_AVAILABLE = False
    logger = logging.getLogger(__name__)
    logger.warning("LangSmith not available. Install with: pip install langsmith")

logger = logging.getLogger(__name__)


class BedrockLLMAgent:
    """AWS Bedrock integration for Claude 3.5 Sonnet fraud detection."""
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize Bedrock client and PromptService."""
        self.config = config or {}
        self.model_id = self.config.get('model_id', 'anthropic.claude-3-5-sonnet-20240620-v1:0')
        self.region = self.config.get('region', 'us-east-1')
        self.max_tokens = self.config.get('max_tokens', 2048)
        self.temperature = self.config.get('temperature', 0.3)
        
        # Control prompt caching behavior
        # Set to False for MCP server to get immediate prompt updates
        # Set to True for REST API to use caching for performance
        self.use_prompt_cache = self.config.get('use_prompt_cache', True)
        
        # Token tracking
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.total_requests = 0
        
        # Initialize PromptService for loading prompts from DynamoDB
        self.prompt_service = PromptService()
        
        # Configure LangSmith tracing (if available)
        self._configure_langsmith()
        
        try:
            self.bedrock_client = boto3.client(
                service_name='bedrock-runtime',
                region_name=self.region
            )
            logger.info(f"Bedrock LLM initialized: {self.model_id} | region={self.region}")
            if LANGSMITH_AVAILABLE:
                logger.info("✅ LangSmith tracing enabled")
        except Exception as e:
            logger.error(f"Failed to initialize Bedrock: {e}")
            raise
    
    def _configure_langsmith(self):
        """Configure LangSmith tracing from environment variables."""
        if LANGSMITH_AVAILABLE:
            # LangSmith is controlled by environment variables
            # LANGCHAIN_TRACING_V2=true to enable
            # LANGCHAIN_API_KEY=your-key
            # LANGCHAIN_PROJECT=your-project-name
            tracing_enabled = os.getenv('LANGCHAIN_TRACING_V2', 'false').lower() == 'true'
            if tracing_enabled:
                logger.info("LangSmith tracing configured from environment variables")
            else:
                logger.info("LangSmith tracing disabled (set LANGCHAIN_TRACING_V2=true to enable)")
    
    def _sanitize_for_tracing(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Sanitize sensitive data before sending to LangSmith traces.
        Removes PII/PCI data to ensure compliance.
        """
        if not isinstance(data, dict):
            return data
        
        # Fields to completely redact
        pii_fields = {
            'bank_account_hash', 'routing_hash', 'bank_account_number',
            'routing_number', 'ssn', 'employee_id', 'claimant_id',
            'account_number', 'card_number', 'cvv'
        }
        
        # Fields to mask (show first/last few chars)
        mask_fields = {
            'transaction_id', 'payment_id', 'claim_id'
        }
        
        sanitized = {}
        for key, value in data.items():
            if key in pii_fields:
                sanitized[key] = "[REDACTED]"
            elif key in mask_fields and isinstance(value, str) and len(value) > 8:
                # Show first 3 and last 3 characters
                sanitized[key] = f"{value[:3]}...{value[-3:]}"
            elif isinstance(value, dict):
                sanitized[key] = self._sanitize_for_tracing(value)
            elif isinstance(value, list):
                sanitized[key] = [
                    self._sanitize_for_tracing(item) if isinstance(item, dict) else item
                    for item in value
                ]
            else:
                sanitized[key] = value
        
        return sanitized
    
    async def analyze(self, llm_input: Dict[str, Any]) -> Dict[str, Any]:
        """Send fraud detection analysis to Claude via Bedrock with tracing."""
        if LANGSMITH_AVAILABLE:
            # Sanitize input before tracing
            sanitized_input = self._sanitize_for_tracing(llm_input)
            return await self._analyze_with_tracing(sanitized_input)
        else:
            return await self._analyze_without_tracing(llm_input)
    
    @traceable(
        name="fraud_detection_llm_analysis",
        run_type="llm",
        tags=["fraud-detection", "bedrock", "claude-3.5-sonnet"]
    ) if LANGSMITH_AVAILABLE else lambda f: f
    async def _analyze_with_tracing(self, llm_input: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze with LangSmith tracing enabled."""
        try:
            # Get current run for metadata
            run_tree = get_current_run_tree() if LANGSMITH_AVAILABLE else None
            
            # Extract context
            context = llm_input.get('context', {})
            event_type = context.get('event_type', 'PAYMENT_FRAUD')
            transaction_id = context.get('transaction_id', 'unknown')
            amount = context.get('payment_amount', 0)
            
            # Add metadata to trace (sanitized - no PII)
            if run_tree:
                # Mask transaction_id to prevent PII exposure
                masked_txn_id = transaction_id if transaction_id == 'unknown' else f"{transaction_id[:3]}...{transaction_id[-3:]}" if len(transaction_id) > 8 else "[MASKED]"
                
                run_tree.add_metadata({
                    "event_id": masked_txn_id,
                    "event_type": event_type,
                    "amount": amount,
                    "vendor_name": context.get('vendor_name', 'N/A'),
                    "model_id": self.model_id,
                    "temperature": self.temperature,
                    "data_sanitized": True  # Flag to indicate data was sanitized
                })
            
            # Perform analysis
            result = await self._perform_analysis(llm_input, event_type)
            
            # Add outputs to trace
            if run_tree:
                run_tree.add_outputs({
                    "decision": result.get('recommendation', 'N/A'),
                    "confidence": result.get('confidence', 0.0),
                    "risk_level": result.get('risk_level', 'N/A'),
                    "reasoning": result.get('reasoning', 'N/A')[:500],  # Truncate for trace
                    "token_usage": result.get('token_usage', {}),
                    "cost_usd": result.get('token_usage', {}).get('cost_usd', 0.0)
                })
            
            return result
            
        except Exception as e:
            logger.error(f"Error in traced analysis: {e}")
            return self._create_fallback_response(str(e))
    
    async def _analyze_without_tracing(self, llm_input: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze without tracing (fallback)."""
        context = llm_input.get('context', {})
        event_type = context.get('event_type', 'PAYMENT_FRAUD')
        return await self._perform_analysis(llm_input, event_type)
    
    async def _perform_analysis(self, llm_input: Dict[str, Any], event_type: str) -> Dict[str, Any]:
        """Core analysis logic called by both traced and non-traced methods."""
        try:
            # Load prompt from DynamoDB using PromptService
            # Use cache setting from config (False for MCP server, True for REST API)
            formatted_prompt = await self.prompt_service.format_prompt_for_llm(
                event_type=event_type,
                transaction_data=llm_input,
                use_cache=self.use_prompt_cache
            )
            
            # Extract messages (includes system, few-shot examples, and current query)
            messages = formatted_prompt.get('messages', [])
            
            # Convert messages to Bedrock format
            # Bedrock uses system parameter separately for Claude
            system_message = None
            conversation_messages = []
            
            for msg in messages:
                if msg['role'] == 'system':
                    system_message = msg['content']
                else:
                    conversation_messages.append({
                        'role': msg['role'],
                        'content': msg['content']
                    })
            
            # Format the system prompt with transaction context
            if system_message:
                system_message = self._format_prompt_with_data(system_message, llm_input)
            
            few_shot_count = len([m for m in conversation_messages if m['role'] == 'assistant'])
            logger.info(f"LLM call: {event_type} | prompt_v{formatted_prompt.get('prompt_version', 'N/A')} | {len(conversation_messages)} messages | few-shot examples: {few_shot_count}")
            
            # 🔍 Add prompt details to LangSmith trace
            if LANGSMITH_AVAILABLE:
                try:
                    run_tree = get_current_run_tree()
                    if run_tree:
                        # Add the actual LLM prompt to the trace
                        run_tree.add_inputs({
                            "system_prompt": system_message[:1000] if system_message else None,  # Truncate for readability
                            "messages": conversation_messages,
                            "few_shot_examples_count": few_shot_count,
                            "prompt_version": formatted_prompt.get('prompt_version'),
                            "event_type": event_type,
                            "model_id": self.model_id,
                            "temperature": self.temperature,
                            "max_tokens": self.max_tokens
                        })
                        logger.info(f"✅ Added LLM prompt details to LangSmith trace (system prompt: {len(system_message) if system_message else 0} chars, {len(conversation_messages)} messages)")
                except Exception as e:
                    logger.warning(f"Failed to add prompt to LangSmith trace: {e}")
            
            request_body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": self.max_tokens,
                "temperature": self.temperature,
                "messages": conversation_messages
            }
            
            # Add system message if present
            if system_message:
                request_body["system"] = system_message
            
            # 📝 Log the full prompt being sent (for debugging)
            logger.info(f"📤 Sending to Bedrock:")
            logger.info(f"   System prompt: {len(system_message)} chars" if system_message else "   No system prompt")
            for i, msg in enumerate(conversation_messages):
                role = msg['role']
                content_preview = msg['content'][:100] + "..." if len(msg['content']) > 100 else msg['content']
                logger.info(f"   Message {i+1} [{role}]: {content_preview}")
            
            start_time = time.time()
            response = self.bedrock_client.invoke_model(
                modelId=self.model_id,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(request_body)
            )
            api_time = time.time() - start_time
            
            response_body = json.loads(response['body'].read())
            
            # Extract token usage from Bedrock response
            usage = response_body.get('usage', {})
            input_tokens = usage.get('input_tokens', 0)
            output_tokens = usage.get('output_tokens', 0)
            total_tokens = input_tokens + output_tokens
            
            # Track cumulative tokens
            self.total_input_tokens += input_tokens
            self.total_output_tokens += output_tokens
            self.total_requests += 1
            
            # Calculate cost (Claude 3.5 Sonnet pricing: $3/1M input, $15/1M output)
            input_cost = (input_tokens / 1_000_000) * 3.0
            output_cost = (output_tokens / 1_000_000) * 15.0
            total_cost = input_cost + output_cost
            
            logger.info(f"Bedrock response: {api_time:.2f}s | tokens: in={input_tokens}, out={output_tokens}, total={total_tokens} | cost=${total_cost:.6f}")
            
            content = response_body.get('content', [])
            if not content:
                logger.error("Empty content in Bedrock response")
                return self._create_fallback_response("Empty response from LLM")
            
            text_content = content[0].get('text', '')
            
            # Log the raw LLM response for debugging
            logger.info(f"📝 Raw LLM response (first 500 chars): {text_content[:500]}")
            
            parsed = self._parse_response(text_content, input_tokens, output_tokens, total_cost)
            
            logger.info(f"LLM analysis: {parsed.get('recommendation')} | risk={parsed.get('risk_level')} | confidence={parsed.get('confidence'):.2f}")
            
            return parsed
            
        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error']['Message']
            logger.error(f"Bedrock API error [{error_code}]: {error_message}")
            return self._create_fallback_response(f"API error: {error_code}")
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse LLM response: {e}")
            return self._create_fallback_response("Invalid JSON response")
        except Exception as e:
            logger.error(f"Unexpected error in Bedrock analysis: {e}")
            return self._create_fallback_response(str(e))
    
    def _format_prompt_with_data(self, system_prompt: str, llm_input: Dict[str, Any]) -> str:
        """Format the system prompt template with actual transaction data (optimized for tokens)."""
        agent_results = llm_input.get('agent_results', {})
        rule_score = llm_input.get('rule_score', 0)
        rule_decision = llm_input.get('rule_decision', 'ALLOW')
        context = llm_input.get('context', {})
        
        # Build compact context summary (minimize tokens)
        context_parts = []
        
        # Only include non-empty values
        if context.get('vendor_name'):
            context_parts.append(f"Vendor: {context['vendor_name']}")
        if context.get('payment_method'):
            context_parts.append(f"Method: {context['payment_method']}")
        if context.get('payment_description'):
            context_parts.append(f"Desc: {context['payment_description']}")
        if context.get('amount_range'):
            context_parts.append(f"Amount: {context['amount_range']}")
        
        # Compact flags (only if true)
        flags = []
        if context.get('has_urgency_keywords'):
            flags.append('urgency')
        if 'crypto' in str(context.get('payment_description', '')).lower():
            flags.append('crypto')
        if context.get('is_fast_payment_method'):
            flags.append('wire')
        if context.get('has_ceo_keywords'):
            flags.append('executive')
        
        if flags:
            context_parts.append(f"Flags: {', '.join(flags)}")
        
        # Compact agent results summary
        agent_summary = self._summarize_agent_results(agent_results)
        
        # Build minimal context
        context_summary = f"""Transaction: {' | '.join(context_parts)}
Agents: {agent_summary}
Rule: {rule_decision} ({rule_score}/6)"""
        
        # Append to system prompt
        if '{context}' in system_prompt or '{transaction_data}' in system_prompt:
            formatted = system_prompt.replace('{context}', context_summary)
            formatted = formatted.replace('{transaction_data}', context_summary)
        else:
            formatted = f"{system_prompt}\n\n{context_summary}"
        
        return formatted
    
    def _summarize_agent_results(self, results: Dict) -> str:
        """Compact agent summary to save tokens."""
        summaries = []
        for agent, data in results.items():
            if isinstance(data, dict):
                score = data.get('score', 0)
                risk = data.get('risk', 'LOW')
                summaries.append(f"{agent}={risk}({score})")
        return ", ".join(summaries) if summaries else "none"
    
    def _parse_response(self, text: str, input_tokens: int, output_tokens: int, cost: float) -> Dict[str, Any]:
        """Parse Claude's response into structured format and add token metadata."""
        try:
            if '```json' in text:
                start = text.find('```json') + 7
                end = text.find('```', start)
                json_str = text[start:end].strip()
            elif '{' in text and '}' in text:
                start = text.find('{')
                end = text.rfind('}') + 1
                json_str = text[start:end]
            else:
                logger.warning("No JSON found in response, using fallback")
                return self._create_fallback_response("No structured response")
            
            parsed = json.loads(json_str)
            
            required_fields = ['risk_level', 'confidence', 'recommendation']
            for field in required_fields:
                if field not in parsed:
                    logger.warning(f"Missing field '{field}' in LLM response")
                    parsed[field] = self._get_default_value(field)
            
            if 'risk_level' in parsed:
                parsed['risk_level'] = str(parsed['risk_level']).upper()
            
            if 'recommendation' in parsed:
                rec = str(parsed['recommendation']).upper()
                if rec in ['APPROVE', 'APPROVED', 'ALLOW']:
                    parsed['recommendation'] = 'ALLOW'
                elif rec in ['WARN', 'WARNING', 'REVIEW']:
                    parsed['recommendation'] = 'WARN'
                elif rec in ['BLOCK', 'BLOCKED', 'DENY', 'REJECT']:
                    parsed['recommendation'] = 'BLOCK'
            
            if 'confidence' in parsed:
                try:
                    conf = float(parsed['confidence'])
                    parsed['confidence'] = max(0.0, min(1.0, conf))
                except:
                    parsed['confidence'] = 0.5
            
            # Add token usage metadata
            parsed['token_usage'] = {
                'input_tokens': input_tokens,
                'output_tokens': output_tokens,
                'total_tokens': input_tokens + output_tokens,
                'cost_usd': round(cost, 6)
            }
            
            return parsed
            
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON from LLM response: {e}")
            return self._create_fallback_response("JSON parse error")
        except Exception as e:
            logger.error(f"Error parsing LLM response: {e}")
            return self._create_fallback_response(str(e))
    
    def _get_default_value(self, field: str):
        """Get default value for missing field."""
        defaults = {
            'risk_level': 'MED',
            'confidence': 0.5,
            'recommendation': 'WARN',
            'analysis': 'No analysis provided',
            'key_factors': [],
            'reasoning': 'Unable to generate reasoning'
        }
        return defaults.get(field, None)
    
    def _create_fallback_response(self, error_msg: str) -> Dict[str, Any]:
        """Create fallback response when LLM fails."""
        logger.warning(f"Creating fallback response due to: {error_msg}")
        return {
            'analysis': f'LLM analysis unavailable: {error_msg}',
            'risk_level': 'MED',
            'confidence': 0.3,
            'recommendation': 'WARN',
            'key_factors': ['LLM analysis failed', 'Defaulting to manual review'],
            'reasoning': f'Unable to complete LLM analysis. Reason: {error_msg}. Recommending manual review as precaution.',
            'fallback': True,
            'error': error_msg
        }
