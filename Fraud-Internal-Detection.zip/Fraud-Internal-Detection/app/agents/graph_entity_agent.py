"""
Graph & Entity Link Agent
Detects reused bank accounts across claims/claimants/employees.
Uses in-memory repository (can be replaced with real database).
Standalone agent ready for A2A communication.
"""

from typing import Dict, Any, List, Set
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class GraphEntityLinkAgent:
    """
    Analyzes entity linkage risks via bank account hashes.
    
    Detects:
    - Same bank account used across multiple claims
    - Same bank account linked to multiple claimants
    - Same bank account repeatedly used by same employee
    - New accounts with last-mile changes (post-approval)
    """
    
    # In-memory repository (replace with Redis/DB in production)
    _account_registry = {}
    
    def __init__(self, name: str = "GraphEntityLinkAgent"):
        self.name = name
        self.high_reuse_threshold = 2  # >=2 distinct claims/claimants = HIGH
    
    async def execute(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute entity link analysis.
        
        Args:
            input_data: {
                'bank_account_hash': str,
                'routing_hash': str | None,
                'payee_address_hash': str | None,
                'payee_phone_hash': str | None,
                'claim_id': str,
                'claimant_id': str,
                'employee_id': str,
                'account_pattern': str ('FIRST_USE' | 'ESTABLISHED' | 'REUSED_ACROSS_CLAIMS'),
                'payee_changed_post_approval': bool
            }
        
        Returns:
            {
                'entity_risk': 'LOW' | 'MED' | 'HIGH',
                'reasons': [str],
                'link_metrics': {
                    'distinct_claims_count': int,
                    'distinct_claimants_count': int,
                    'distinct_employees_count': int,
                    'same_employee_reuse_count': int,
                    'is_new_account': bool
                }
            }
        """
        
        try:
            bank_account_hash = input_data.get('bank_account_hash')
            claim_id = input_data.get('claim_id')
            claimant_id = input_data.get('claimant_id')
            employee_id = input_data.get('employee_id')
            account_pattern = input_data.get('account_pattern', '')
            is_new_account = (account_pattern == 'FIRST_USE')  # Derived from account_pattern
            payee_changed_post = input_data.get('payee_changed_post_approval', False)
            
            logger.info(
                f"Analyzing entity links for account hash: {bank_account_hash[:8]}..."
            )
            
            # Get or create account record
            if bank_account_hash not in self._account_registry:
                self._account_registry[bank_account_hash] = {
                    'claims': set(),
                    'claimants': set(),
                    'employees': set()
                }
            
            account_record = self._account_registry[bank_account_hash]
            
            # Add current transaction to registry
            account_record['claims'].add(claim_id)
            account_record['claimants'].add(claimant_id)
            account_record['employees'].add(employee_id)
            
            # Calculate metrics
            distinct_claims = len(account_record['claims'])
            distinct_claimants = len(account_record['claimants'])
            distinct_employees = len(account_record['employees'])
            
            # Count how many times THIS employee used this account
            same_employee_reuse = sum(
                1 for e in account_record['employees'] if e == employee_id
            )
            
            reasons = []
            risk_points = 0
            
            # Risk Rule 1: Same account, multiple different claimants
            if distinct_claimants >= self.high_reuse_threshold:
                risk_points += 2
                reasons.append(
                    f"🚨 Bank account reused across {distinct_claimants} different claimants "
                    f"(possible money mule or fraud ring)"
                )
            
            # Risk Rule 2: Same account, multiple distinct claims
            if distinct_claims >= self.high_reuse_threshold:
                risk_points += 1
                reasons.append(
                    f"⚠️ Bank account used in {distinct_claims} distinct claims "
                    f"(possible pattern of reuse)"
                )
            
            # Risk Rule 3: Same employee, same account repeatedly
            if distinct_employees == 1 and distinct_claims >= 2:
                risk_points += 2
                reasons.append(
                    f"🚨 Same employee ({employee_id}) repeatedly directed payments "
                    f"to this account ({distinct_claims} times)"
                )
            
            # Risk Rule 4: New account + last-mile change
            if is_new_account and payee_changed_post:
                risk_points += 1
                reasons.append(
                    "⚠️ New bank account with post-approval payee change "
                    "(elevated risk for first-time account)"
                )
            
            # Determine risk level
            if risk_points >= 3:
                entity_risk = 'HIGH'
            elif risk_points >= 1:
                entity_risk = 'MED'
            else:
                entity_risk = 'LOW'
                if not reasons:
                    reasons.append("No significant entity linkage risks detected")
            
            result = {
                'entity_risk': entity_risk,
                'reasons': reasons,
                'link_metrics': {
                    'distinct_claims_count': distinct_claims,
                    'distinct_claimants_count': distinct_claimants,
                    'distinct_employees_count': distinct_employees,
                    'same_employee_reuse_count': same_employee_reuse,
                    'account_pattern': account_pattern,
                    'is_new_account': is_new_account,  # Derived for clarity
                    'risk_points': risk_points
                }
            }
            
            logger.info(
                f"Entity link analysis complete: risk={entity_risk}, "
                f"points={risk_points}"
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Error in entity link analysis: {e}")
            return {
                'entity_risk': 'LOW',
                'reasons': [f"Error in analysis: {str(e)}"],
                'link_metrics': {}
            }
    
    @classmethod
    def reset_registry(cls):
        """Reset the in-memory registry (for testing)."""
        cls._account_registry = {}
