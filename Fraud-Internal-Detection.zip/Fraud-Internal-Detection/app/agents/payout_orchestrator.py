"""
Payout Decision Orchestrator
Coordinates 3 agents for last-mile payment fraud detection.
Uses simple ALLOW/WARN/BLOCK decision logic.
Modular design with direct async method calls for optimal performance.
Enhanced with audit logging, performance monitoring, and decision tree explainability.
"""

import asyncio
import os
import time
from typing import Dict, Any, Optional
from datetime import datetime
import logging
from agents.employee_control_agent import EmployeeControlAgent
from agents.lastmile_payment_agent import LastMilePaymentAgent
from agents.graph_entity_agent import GraphEntityLinkAgent
from agents.llm_reasoning_agent import LLMReasoningAgent
from utils.audit_logger import get_audit_logger
from utils.monitoring import get_performance_monitor
from utils.decision_tree_generator import DecisionTreeGenerator

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# DEBUG MODE: Set to True for verbose logging, False for production
# Can be controlled via environment variable: DEBUG_MODE=true
DEBUG_MODE = os.getenv('DEBUG_MODE', 'false').lower() == 'true'

# Get monitoring instances
audit_logger = get_audit_logger()
perf_monitor = get_performance_monitor()
decision_tree_generator = DecisionTreeGenerator()

# Request counter for human-readable logs
_request_counter = 0


class PayoutDecisionOrchestrator:
    """
    Orchestrates 3-agent payout fraud detection with full observability.
    
    Decision Logic:
    - Map agent risks: LOW=0, MED=1, HIGH=2
    - Sum totalScore from all 3 agents
    - Decision:
        totalScore <= 1 => ALLOW
        totalScore 2-3  => WARN
        totalScore >= 4 => BLOCK
    """
    
    def __init__(self, name: str = "PayoutDecisionOrchestrator", llm_config: Optional[Dict[str, Any]] = None):
        self.name = name
        
        # Initialize 3 rule-based agents
        self.employee_control_agent = EmployeeControlAgent()
        self.lastmile_payment_agent = LastMilePaymentAgent()
        self.graph_entity_agent = GraphEntityLinkAgent()
        
        # Initialize LLM reasoning agent (optional, with graceful fallback)
        try:
            logger.info("Attempting to initialize LLM Reasoning Agent...")
            self.llm_agent = LLMReasoningAgent(config=llm_config)
            if self.llm_agent and self.llm_agent.enabled:
                logger.info("✅ LLM Reasoning Agent initialized successfully and ENABLED")
            else:
                logger.warning("⚠️ LLM Reasoning Agent created but is DISABLED")
                self.llm_agent = None
        except Exception as e:
            logger.error(f"❌ LLM Reasoning Agent initialization failed: {e}")
            logger.error(f"Error type: {type(e).__name__}")
            import traceback
            logger.error(f"Traceback: {traceback.format_exc()}")
            logger.warning("Continuing with rule-based only.")
            self.llm_agent = None
        
        # Risk level to score mapping
        self.risk_score_map = {
            'LOW': 0,
            'MED': 1,
            'HIGH': 2
        }
        
        logger.info("Payout Decision Orchestrator initialized with 3 agents, LLM reasoning, and monitoring")
    
    async def execute(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute payout fraud detection.
        
        Args:
            input_data: {
                # For Employee Control Agent
                'current_action': {
                    'action_type': str,
                    'employee_id': str,
                    'timestamp': str,
                    'claim_id': str,
                    'payment_id': str
                },
                'session_actions': [action...],
                'actor_role': str,
                
                # For Last-Mile Payment Agent
                'claim_status': str,
                'approval_timestamp': str,
                'payee_change_timestamp': str,
                'payment_method': str,
                'payment_release_request': bool,
                'verification_flag': bool,
                'payee_changed_after_approval': bool,
                
                # For Graph Entity Agent
                'bank_account_hash': str,
                'routing_hash': str,
                'payee_address_hash': str,
                'payee_phone_hash': str,
                'claimant_id': str,
                'account_pattern': str (FIRST_USE | ESTABLISHED | REUSED_ACROSS_CLAIMS)
            }
        
        Returns:
            DecisionBundle: {
                'decision': 'ALLOW' | 'WARN' | 'BLOCK',
                'total_score': int,
                'per_agent': {
                    'employee_control': {...},
                    'lastmile_payment': {...},
                    'graph_entity': {...}
                },
                'reasons': [str] (merged + deduplicated),
                'evidence': {
                    'claim_id': str,
                    'payment_id': str,
                    'bank_account_hash': str,
                    'employee_id': str
                },
                'timestamp': str
            }
        """
        
        global _request_counter
        _request_counter += 1
        request_id = _request_counter
        
        try:
            # Extract common fields
            current_action = input_data.get('current_action', {})
            claim_id = current_action.get('claim_id', 'unknown')
            payment_id = current_action.get('payment_id', 'unknown')
            employee_id = current_action.get('employee_id', 'unknown')
            bank_account_hash = input_data.get('bank_account_hash', 'unknown')
            
            # Human-readable request start
            logger.info("=" * 80)
            logger.info(f"🔷 NEW FRAUD DETECTION REQUEST #{request_id}")
            logger.info("=" * 80)
            logger.info(f"Claim ID: {claim_id}")
            logger.info(f"Payment ID: {payment_id}")
            logger.info(f"Employee: {employee_id} ({input_data.get('actor_role', 'unknown')})")
            logger.info(f"Payment Method: {input_data.get('payment_method', 'N/A')}")
            logger.info("=" * 80)
            
            # Run all 3 agents in parallel
            logger.info("\n--- RUNNING 3-AGENT ANALYSIS ---")
            start_time = time.monotonic()
            agent_results = await self._run_agents(input_data)
            end_time = time.monotonic()
            
            # Log agent execution time
            execution_time = end_time - start_time
            logger.info(f"✓ Agents completed in {execution_time:.2f} seconds")
            
            # Calculate total risk score
            total_score, risk_scores = self._calculate_total_score(agent_results)
            
            # Human-readable agent results
            logger.info("\n--- AGENT RESULTS ---")
            logger.info(f"  Employee Control:  {agent_results['employee_control'].get('control_risk', 'LOW'):4s} risk (score: {risk_scores['employee_control']})")
            logger.info(f"  Last Mile Payment: {agent_results['lastmile_payment'].get('last_mile_risk', 'LOW'):4s} risk (score: {risk_scores['lastmile_payment']})")
            logger.info(f"  Graph Entity Link: {agent_results['graph_entity'].get('entity_risk', 'LOW'):4s} risk (score: {risk_scores['graph_entity']})")
            
            # Make decision based on rules
            decision = self._make_decision(total_score)
            logger.info(f"\n--- RULE-BASED DECISION ---")
            logger.info(f"Total Score: {total_score} → Decision: {decision}")
            
            # Merge and deduplicate reasons
            reasons = self._merge_reasons(agent_results)
            
            # Get LLM reasoning insights (if available)
            # Pass sanitized transaction data (PII/PCI safe)
            logger.info("\n--- LLM ANALYSIS ---")
            sanitized_data = self._sanitize_for_llm(input_data, claim_id, payment_id)
            llm_insights = await self._get_llm_insights(
                agent_results, 
                total_score, 
                decision, 
                reasons,
                {
                    'claim_id': claim_id,
                    'payment_id': payment_id,
                    'bank_account_hash': bank_account_hash,
                    'employee_id': employee_id
                },
                sanitized_data  # Pass sanitized data for fraud detection
            )
            
            # Combine rule-based decision with LLM insights
            final_decision = self._combine_decisions(decision, llm_insights, total_score)
            
            # Generate structured decision tree for explainability
            decision_tree = None
            if os.getenv('ENABLE_DECISION_TREES', 'true').lower() == 'true':
                try:
                    decision_tree = decision_tree_generator.generate(
                        agent_results=agent_results,
                        llm_result=llm_insights,
                        final_decision=final_decision,
                        rule_based_decision=decision,
                        total_score=total_score,
                        metadata={
                            'transaction_id': payment_id,
                            'event_type': input_data.get('event_type', 'PAYMENT_FRAUD'),
                            'payment_amount': sanitized_data.get('payment_amount', 0),
                            'vendor_name': sanitized_data.get('vendor_name', 'N/A')
                        }
                    )
                    logger.info(f"📊 Decision tree generated: override={decision_tree.get('decision_logic', {}).get('llm_override', False)}")
                except Exception as dt_error:
                    logger.warning(f"Failed to generate decision tree: {dt_error}")
            
            # Human-readable final decision
            logger.info(f"\n--- FINAL DECISION ---")
            if llm_insights and final_decision != decision:
                logger.info(f"🚨 {final_decision} (LLM override from {decision})")
            else:
                logger.info(f"✓ {final_decision}")
            logger.info("=" * 80)
            
            # Build decision bundle
            decision_bundle = {
                'decision': final_decision,
                'total_score': total_score,
                'llm_confidence': 0.0,  # Default value, will be overridden if LLM is available
                'per_agent': {
                    'employee_control': {
                        'risk': agent_results['employee_control'].get('control_risk'),
                        'score': risk_scores['employee_control'],
                        'reasons': agent_results['employee_control'].get('reasons', []),
                        'metrics': agent_results['employee_control'].get('metrics', {})
                    },
                    'lastmile_payment': {
                        'risk': agent_results['lastmile_payment'].get('last_mile_risk'),
                        'score': risk_scores['lastmile_payment'],
                        'reasons': agent_results['lastmile_payment'].get('reasons', []),
                        'computed_deltas': agent_results['lastmile_payment'].get('computed_deltas', {})
                    },
                    'graph_entity': {
                        'risk': agent_results['graph_entity'].get('entity_risk'),
                        'score': risk_scores['graph_entity'],
                        'reasons': agent_results['graph_entity'].get('reasons', []),
                        'link_metrics': agent_results['graph_entity'].get('link_metrics', {})
                    }
                },
                'reasons': reasons,
                'evidence': {
                    'claim_id': claim_id,
                    'payment_id': payment_id,
                    'bank_account_hash': bank_account_hash,
                    'employee_id': employee_id
                },
                'timestamp': datetime.utcnow().isoformat() + 'Z'
            }
            
            # Add LLM insights if available
            if llm_insights:
                decision_bundle['llm_insights'] = llm_insights
                # Also add top-level llm_confidence for API/dashboard compatibility
                decision_bundle['llm_confidence'] = llm_insights.get('confidence', 0.0)
                
                # Log token usage to metrics if available
                token_usage = llm_insights.get('token_usage')
                if token_usage:
                    logger.info(f"💰 LLM Token Usage: in={token_usage.get('input_tokens', 0)}, out={token_usage.get('output_tokens', 0)}, total={token_usage.get('total_tokens', 0)}, cost=${token_usage.get('cost_usd', 0):.6f}")
            
            # Add decision tree for explainability
            if decision_tree:
                decision_bundle['decision_tree'] = decision_tree
                decision_bundle['explainability'] = decision_tree.get('explainability', {})
            
            # Log decision details using proper audit logger method
            try:
                audit_logger.log_pep_decision(
                    claim_id=claim_id,
                    payment_id=payment_id,
                    decision=final_decision,
                    total_score=total_score,
                    agent_results=agent_results,
                    actor_id=employee_id,
                    actor_role=input_data.get('actor_role', 'unknown'),
                    reasons=reasons,
                    evidence=decision_bundle['evidence'],
                    request_data=input_data,
                    decision_tree=decision_tree  # Include decision tree in audit
                )
            except Exception as audit_error:
                logger.warning(f"Audit logging failed: {audit_error}")
            
            # Record metrics
            perf_monitor.record_pep_decision(final_decision, total_score, execution_time)
            
            return decision_bundle
            
        except Exception as e:
            logger.error("=" * 80)
            logger.error(f"❌ ERROR IN ORCHESTRATION: {e}")
            logger.error("=" * 80)
            return {
                'decision': 'BLOCK',  # Fail-safe: block on error
                'total_score': 999,
                'llm_confidence': 0.0,  # Default for error case
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat() + 'Z'
            }
    
    async def _run_agents(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Run all 3 agents in parallel with timing."""
        try:
            # Extract claim_id for logging
            claim_id = input_data.get('current_action', {}).get('claim_id', 'unknown')
            
            # Prepare inputs for each agent
            employee_control_input = {
                'current_action': input_data.get('current_action', {}),
                'session_actions': input_data.get('session_actions', []),
                'actor_role': input_data.get('actor_role', 'unknown')
            }
            
            lastmile_payment_input = {
                'claim_status': input_data.get('claim_status'),
                'approval_timestamp': input_data.get('approval_timestamp'),
                'payee_change_timestamp': input_data.get('payee_change_timestamp'),
                'payment_method': input_data.get('payment_method'),
                'payment_release_request': input_data.get('payment_release_request', False),
                'verification_flag': input_data.get('verification_flag', False),
                'payee_changed_after_approval': input_data.get('payee_changed_after_approval', False)
            }
            
            # Use account_pattern directly (compliance-safe field, no derivation needed)
            # account_pattern = 'FIRST_USE' indicates new account
            account_pattern = input_data.get('account_pattern', '')
            
            graph_entity_input = {
                'bank_account_hash': input_data.get('bank_account_hash'),
                'routing_hash': input_data.get('routing_hash'),
                'payee_address_hash': input_data.get('payee_address_hash'),
                'payee_phone_hash': input_data.get('payee_phone_hash'),
                'claim_id': input_data.get('current_action', {}).get('claim_id'),
                'claimant_id': input_data.get('claimant_id'),
                'employee_id': input_data.get('current_action', {}).get('employee_id'),
                'account_pattern': account_pattern,  # Single source of truth for new account detection
                'payee_changed_post_approval': input_data.get('payee_changed_after_approval', False)
            }
            
            # Time each agent execution
            start_employee = time.time()
            employee_result = await self.employee_control_agent.execute(employee_control_input)
            employee_time = time.time() - start_employee
            
            start_lastmile = time.time()
            lastmile_result = await self.lastmile_payment_agent.execute(lastmile_payment_input)
            lastmile_time = time.time() - start_lastmile
            
            start_graph = time.time()
            graph_result = await self.graph_entity_agent.execute(graph_entity_input)
            graph_time = time.time() - start_graph
            
            # Log agent execution to audit trail
            audit_logger.log_agent_analysis(
                agent_name="EmployeeControlAgent",
                claim_id=claim_id,
                risk_level=employee_result.get('control_risk', 'LOW'),
                score=self.risk_score_map.get(employee_result.get('control_risk', 'LOW'), 0),
                reasons=employee_result.get('reasons', []),
                evidence=employee_result.get('metrics', {}),
                execution_time_ms=employee_time * 1000
            )
            
            audit_logger.log_agent_analysis(
                agent_name="LastMilePaymentAgent",
                claim_id=claim_id,
                risk_level=lastmile_result.get('last_mile_risk', 'LOW'),
                score=self.risk_score_map.get(lastmile_result.get('last_mile_risk', 'LOW'), 0),
                reasons=lastmile_result.get('reasons', []),
                evidence=lastmile_result.get('computed_deltas', {}),
                execution_time_ms=lastmile_time * 1000
            )
            
            audit_logger.log_agent_analysis(
                agent_name="GraphEntityLinkAgent",
                claim_id=claim_id,
                risk_level=graph_result.get('entity_risk', 'LOW'),
                score=self.risk_score_map.get(graph_result.get('entity_risk', 'LOW'), 0),
                reasons=graph_result.get('reasons', []),
                evidence=graph_result.get('link_metrics', {}),
                execution_time_ms=graph_time * 1000
            )
            
            # Record performance metrics
            perf_monitor.record_agent_execution(
                agent_name="EmployeeControlAgent",
                risk_level=employee_result.get('control_risk', 'LOW'),
                duration_seconds=employee_time
            )
            
            perf_monitor.record_agent_execution(
                agent_name="LastMilePaymentAgent",
                risk_level=lastmile_result.get('last_mile_risk', 'LOW'),
                duration_seconds=lastmile_time
            )
            
            perf_monitor.record_agent_execution(
                agent_name="GraphEntityLinkAgent",
                risk_level=graph_result.get('entity_risk', 'LOW'),
                duration_seconds=graph_time
            )
            
            # Detect and record fraud patterns
            if employee_result.get('control_risk') == 'HIGH':
                perf_monitor.record_fraud_pattern("employee_control_concentration")
            
            if lastmile_result.get('last_mile_risk') == 'HIGH':
                perf_monitor.record_fraud_pattern("last_mile_manipulation")
            
            if graph_result.get('entity_risk') == 'HIGH':
                perf_monitor.record_fraud_pattern("entity_reuse_collision")
            
            # Return results
            return {
                'employee_control': employee_result,
                'lastmile_payment': lastmile_result,
                'graph_entity': graph_result
            }
            
        except Exception as e:
            logger.error(f"Error running agents: {e}")
            return {
                'employee_control': {'control_risk': 'LOW', 'reasons': []},
                'lastmile_payment': {'last_mile_risk': 'LOW', 'reasons': []},
                'graph_entity': {'entity_risk': 'LOW', 'reasons': []}
            }
    
    def _calculate_total_score(self, agent_results: Dict[str, Any]) -> tuple:
        """Calculate total risk score from agent results."""
        # Extract risk levels
        employee_risk = agent_results.get('employee_control', {}).get('control_risk', 'LOW')
        lastmile_risk = agent_results.get('lastmile_payment', {}).get('last_mile_risk', 'LOW')
        entity_risk = agent_results.get('graph_entity', {}).get('entity_risk', 'LOW')
        
        # Map to scores
        risk_scores = {
            'employee_control': self.risk_score_map.get(employee_risk, 0),
            'lastmile_payment': self.risk_score_map.get(lastmile_risk, 0),
            'graph_entity': self.risk_score_map.get(entity_risk, 0)
        }
        
        # Sum total
        total_score = sum(risk_scores.values())
        
        return total_score, risk_scores
    
    def _make_decision(self, total_score: int) -> str:
        """
        Make ALLOW/WARN/BLOCK decision based on total score.
        
        Decision Thresholds:
        - Score 0: ALLOW (no risk factors detected)
        - Score 1-3: WARN (some risk factors, needs review)
        - Score 4+: BLOCK (high risk, likely fraud)
        """
        if total_score == 0:
            return 'ALLOW'
        elif total_score <= 3:
            return 'WARN'
        else:  # total_score >= 4
            return 'BLOCK'
    
    def _merge_reasons(self, agent_results: Dict[str, Any]) -> list:
        """Merge and deduplicate reasons from all agents."""
        all_reasons = []
        
        # Collect reasons from each agent
        for agent_name, result in agent_results.items():
            reasons = result.get('reasons', [])
            all_reasons.extend(reasons)
        
        # Deduplicate while preserving order
        seen = set()
        unique_reasons = []
        for reason in all_reasons:
            if reason not in seen:
                seen.add(reason)
                unique_reasons.append(reason)
        
        return unique_reasons
    
    async def _get_llm_insights(
        self,
        agent_results: Dict[str, Any],
        rule_score: int,
        rule_decision: str,
        reasons: list,
        evidence: Dict[str, Any],
        sanitized_transaction_data: Dict[str, Any] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Get LLM reasoning insights (if LLM agent is available).
        
        Args:
            sanitized_transaction_data: PII/PCI-safe transaction context for fraud detection
        
        Returns:
            LLM insights dict or None if LLM unavailable/failed
        """
        if not self.llm_agent:
            return None
        
        try:
            logger.info("Requesting LLM reasoning analysis...")
            start_time = time.time()
            
            # Call LLM reasoning agent with sanitized data
            llm_result = await self.llm_agent.analyze(
                agent_results=agent_results,
                rule_score=rule_score,
                rule_decision=rule_decision,
                reasons=reasons,
                evidence=evidence,
                transaction_data=sanitized_transaction_data  # Pass sanitized data
            )
            
            execution_time = time.time() - start_time
            logger.info(f"LLM analysis completed in {execution_time:.2f}s")
            
            return llm_result
            
        except Exception as e:
            logger.error(f"LLM analysis failed: {e}. Falling back to rule-based decision.")
            return None
    
    def _combine_decisions(
        self,
        rule_decision: str,
        llm_insights: Optional[Dict[str, Any]],
        rule_score: int
    ) -> str:
        """
        Combine rule-based decision with LLM insights.
        
        UPDATED LOGIC - Trust LLM for sophisticated fraud detection:
        1. If no LLM insights, use rule decision
        2. If LLM has HIGH confidence (>0.85) and detects HIGH risk → BLOCK (regardless of rule score)
        3. If LLM has MEDIUM-HIGH confidence (0.7-0.85) and detects HIGH risk → At least WARN
        4. If LLM has LOW confidence (<0.6), defer to rules
        5. For medium confidence + medium risk, combine with rule score
        
        Args:
            rule_decision: ALLOW/WARN/BLOCK from rules
            llm_insights: LLM analysis result (or None)
            rule_score: Rule-based score (0-6)
            
        Returns:
            Final decision: ALLOW/WARN/BLOCK
        """
        # No LLM insights - use rule decision
        if not llm_insights:
            return rule_decision
        
        llm_risk = llm_insights.get('risk_level', 'MED').upper()  # Normalize to uppercase for comparison
        llm_confidence = llm_insights.get('confidence', 0.5)
        llm_recommendation = llm_insights.get('recommendation', rule_decision)
        
        # Log LLM response
        logger.info(f"LLM: risk={llm_risk}, confidence={llm_confidence:.2f}, recommendation={llm_recommendation}")
        
        # DEBUG: Detailed decision logic evaluation (only in debug mode)
        if DEBUG_MODE:
            logger.info("="*70)
            logger.info("🔍 DECISION LOGIC EVALUATION:")
            logger.info(f"   llm_risk type: {type(llm_risk)}, value: '{llm_risk}'")
            logger.info(f"   llm_confidence type: {type(llm_confidence)}, value: {llm_confidence}")
            logger.info(f"   Checking: llm_risk == 'HIGH' → {llm_risk == 'HIGH'}")
            logger.info(f"   Checking: llm_confidence >= 0.85 → {llm_confidence >= 0.85}")
            logger.info(f"   Checking: (llm_risk == 'HIGH' and llm_confidence >= 0.85) → {llm_risk == 'HIGH' and llm_confidence >= 0.85}")
            logger.info("="*70)
        
        # PRIORITY 1: High confidence LLM detection of HIGH risk → BLOCK
        # This catches sophisticated fraud that rule-based agents miss (crypto scams, BEC, phishing)
        if llm_risk == 'HIGH' and llm_confidence >= 0.85:
            if DEBUG_MODE:
                logger.info("✅ PRIORITY 1 TRIGGERED: High-confidence LLM fraud detection")
            if rule_decision != 'BLOCK':
                logger.info(f"🚨 LLM HIGH-CONFIDENCE FRAUD DETECTED → Overriding {rule_decision} to BLOCK")
                return 'BLOCK'
            return 'BLOCK'  # Already blocked by rules, maintain it
        
        # PRIORITY 2: Medium-high confidence LLM detection of HIGH risk → At least WARN
        if llm_risk == 'HIGH' and llm_confidence >= 0.7:
            if DEBUG_MODE:
                logger.info("✅ PRIORITY 2 TRIGGERED: Medium-high confidence LLM fraud detection")
            if rule_decision == 'ALLOW':
                logger.info(f"⚠️  LLM MEDIUM-HIGH CONFIDENCE FRAUD → Escalating {rule_decision} to WARN")
                return 'WARN'
            else:
                # Already WARN or BLOCK, keep existing decision
                return rule_decision
        
        # PRIORITY 3: Low confidence LLM - defer to rules
        if llm_confidence < 0.6:
            if DEBUG_MODE:
                logger.info(f"Low LLM confidence ({llm_confidence:.2f}), using rule decision: {rule_decision}")
            return rule_decision
        
        # PRIORITY 4: Medium confidence - weighted combination with rule score
        # This handles cases where both LLM and rules detect something
        if llm_risk == 'HIGH' and rule_score >= 2:
            logger.info(f"LLM + Rules both detect fraud: BLOCK (llm_risk={llm_risk}, rule_score={rule_score})")
            return 'BLOCK'
        elif llm_risk == 'HIGH' and rule_score >= 1:
            return 'WARN' if rule_decision == 'ALLOW' else rule_decision
        elif llm_risk == 'MED' and rule_score >= 4:
            return 'BLOCK'
        
        # PRIORITY 5: Trust LLM recommendation when confidence is reasonable (>=0.65)
        # This allows LLM to detect semantic fraud patterns that rules miss
        if llm_confidence >= 0.65 and llm_recommendation != rule_decision:
            logger.info(f"🧠 LLM Override: {rule_decision} → {llm_recommendation} (confidence={llm_confidence:.2f}, risk={llm_risk})")
            return llm_recommendation
        
        # Default: use rule decision
        return rule_decision
    
    def _sanitize_for_llm(self, input_data: Dict[str, Any], claim_id: str, payment_id: str) -> Dict[str, Any]:
        """
        Create PII/PCI-safe version of transaction data for LLM analysis.
        
        COMPLIANCE-SAFE: Excludes sensitive data while preserving fraud detection context.
        
        ✅ INCLUDED (Safe for LLM):
        - Invoice descriptions (fraud language detection)
        - Vendor names (fake vendor detection)
        - Payment method types (pattern detection)
        - Hashed identifiers (already anonymized)
        - Timing/urgency indicators
        - Transaction patterns
        
        ❌ EXCLUDED (PII/PCI Protected):
        - Actual account numbers
        - Actual routing numbers
        - Exact payment amounts
        - Employee IDs
        - Claimant personal info
        
        Args:
            input_data: Full transaction data from orchestrator
            claim_id: Claim identifier
            payment_id: Payment identifier
            
        Returns:
            Sanitized dict safe for LLM processing
        """
        # DEBUG: Log FULL input_data structure (only in debug mode)
        if DEBUG_MODE:
            import json
            logger.info("=" * 80)
            logger.info("🔍 DEBUG SANITIZE - FULL INPUT DATA STRUCTURE:")
            logger.info("=" * 80)
            try:
                logger.info(json.dumps(input_data, indent=2, default=str))
            except Exception as e:
                logger.info(f"Could not JSON serialize, using repr: {repr(input_data)}")
            logger.info("=" * 80)
        
        current_action = input_data.get('current_action', {})
        
        # Helper: Get amount range (not exact amount)
        def get_amount_range(amount):
            try:
                amt = float(amount) if amount else 0
                if amt < 1000:
                    return "UNDER_1K"
                elif amt < 10000:
                    return "1K_TO_10K"
                elif amt < 50000:
                    return "10K_TO_50K"
                elif amt < 100000:
                    return "50K_TO_100K"
                else:
                    return "OVER_100K"
            except:
                return "UNKNOWN"
        
        # Build sanitized context
        # Get description from multiple possible field names and locations
        payment_desc = (
            input_data.get('payment_description') or 
            input_data.get('invoice_description') or
            input_data.get('notes') or  # ← Check notes field (used in scenario I)
            current_action.get('payment_description') or
            current_action.get('invoice_description') or
            current_action.get('notes') or  # ← Also check notes in current_action
            'N/A'
        )
        
        sanitized = {
            # ✅ SAFE: Fraud detection context (no PII)
            'payment_description': payment_desc,
            'vendor_name': input_data.get('recipient_name', input_data.get('vendor_name', 'N/A')),
            'payment_method': input_data.get('payment_method', 'N/A'),
            'claim_status': input_data.get('claim_status', 'N/A'),
            
            # ✅ SAFE: Derived indicators (no sensitive data)
            'has_urgency_keywords': any(word in str(payment_desc).lower() 
                                       for word in ['urgent', 'asap', 'immediate', 'rush', 'critical']),
            'has_contact_keywords': any(word in str(payment_desc).lower()
                                       for word in ['contact', 'call', 'email', 'reach out', 'get in touch']),
            'has_encryption_keywords': any(word in str(payment_desc).lower()
                                          for word in ['encrypted', 'secure', 'private', 'confidential']),
            'has_wire_keywords': any(word in str(payment_desc).lower()
                                    for word in ['wire', 'transfer', 'swift', 'ach']),
            'has_ceo_keywords': any(word in str(payment_desc).lower()
                                   for word in ['ceo', 'cfo', 'cxo', 'executive', 'president']),
            
            # ✅ SAFE: Hashed identifiers (already anonymized in input)
            'bank_account_hash': input_data.get('bank_account_hash', 'N/A'),
            'routing_hash': input_data.get('routing_hash', 'N/A'),
            'payee_address_hash': input_data.get('payee_address_hash', 'N/A'),
            
            # ✅ SAFE: Amount range (not exact amount - PCI compliant)
            'amount_range': get_amount_range(input_data.get('payment_amount', 0)),
            
            # ✅ SAFE: Role/pattern (not actual IDs)
            'actor_role': input_data.get('actor_role', 'unknown'),
            'account_pattern': input_data.get('account_pattern', 'UNKNOWN'),
            
            # ✅ SAFE: Timing indicators
            'verification_flag': input_data.get('verification_flag', False),
            'payee_changed_after_approval': input_data.get('payee_changed_after_approval', False),
            
            # ✅ SAFE: Risk flags from agents
            'is_fast_payment_method': input_data.get('payment_method', '').upper() in ['WIRE TRANSFER', 'WIRE', 'ACH'],
        }
        
        # Log sanitization audit for compliance
        fields_excluded = [
            'bank_account_number', 'routing_number', 'exact_payment_amount',
            'employee_id', 'claimant_ssn', 'claimant_name', 'claimant_dob',
            'payee_account_number', 'payee_ssn'
        ]
        fields_included = list(sanitized.keys())
        
        try:
            audit_logger.log_sanitization_audit(
                claim_id=claim_id,
                payment_id=payment_id,
                fields_excluded=fields_excluded,
                fields_included=fields_included,
                pii_pci_excluded=True,
                sanitized_data=sanitized
            )
        except Exception as e:
            logger.warning(f"Sanitization audit logging failed: {e}")
        
        logger.info(f"✓ Sanitized {len(fields_included)} safe fields, excluded {len(fields_excluded)} PII/PCI fields")
        return sanitized
