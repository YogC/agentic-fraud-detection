"""
Agent modules for the Medical Report Analyzer
"""

