"""
AWS Bedrock LLM Reasoning Agent - Active
Uses AWS Bedrock (Claude 3) for advanced fraud pattern analysis
"""

import logging
from typing import Dict, Any, Optional
from .bedrock_llm_agent import BedrockLLMAgent

logger = logging.getLogger(__name__)


class LLMReasoningAgent:
    """
    LLM Reasoning Agent using AWS Bedrock
    Provides advanced fraud detection with natural language reasoning
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize AWS Bedrock LLM agent"""
        self.name = "llm_reasoning_agent"
        self.using_mock = False
        self.enabled = False  # Will be set to True if Bedrock initializes successfully
        
        try:
            self.bedrock_agent = BedrockLLMAgent(config)
            self.enabled = True  # Bedrock successfully initialized
            logger.info("="*70)
            logger.info(">>> LLM BACKEND ACTIVE: AWS Bedrock (Claude 3) <<<")
            logger.info(">>> NOT using Mock agent <<<")
            logger.info("="*70)
        except Exception as e:
            logger.error(f"❌ Failed to initialize Bedrock agent: {e}")
            logger.warning("="*70)
            logger.warning(">>> LLM AGENT DISABLED - Bedrock initialization failed <<<")
            logger.warning(">>> Continuing without LLM (rule-based only) <<<")
            logger.warning("="*70)
            self.bedrock_agent = None
            self.using_mock = False
            self.enabled = False  # LLM agent disabled
    
    async def analyze(
        self,
        agent_results: Dict[str, Any] = None,
        rule_score: int = 0,
        rule_decision: str = "",
        reasons: list = None,
        evidence: Dict[str, Any] = None,
        transaction_data: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Analyze transaction using AWS Bedrock LLM
        
        Args:
            agent_results: Results from rule-based agents
            rule_score: Total risk score from rules
            rule_decision: Rule-based decision (ALLOW/WARN/BLOCK)
            reasons: List of reasons from rule-based agents
            evidence: Evidence dictionary
            transaction_data: Transaction details (legacy parameter)
            
        Returns:
            LLM analysis results with risk assessment
        """
        # Build comprehensive transaction data for LLM
        llm_input = {
            'agent_results': agent_results or {},
            'rule_score': rule_score,
            'rule_decision': rule_decision,
            'reasons': reasons or [],
            'evidence': evidence or {},
            'context': transaction_data or {}  # Put transaction data under 'context' key for prompt template
        }
        
        if self.bedrock_agent:
            logger.info(">>> Using AWS Bedrock (Claude 3) for analysis <<<")
            return await self.bedrock_agent.analyze(llm_input)
        else:
            # No LLM available - return None (orchestrator will handle)
            logger.warning(">>> LLM agent not available (Bedrock disabled) <<<")
            return None
    
    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Alias for analyze() for compatibility"""
        return self.analyze(data)


def get_llm_agent(config: Optional[Dict[str, Any]] = None) -> LLMReasoningAgent:
    """
    Factory function to get LLM agent
    
    Args:
        config: Optional configuration
        
    Returns:
        AWS Bedrock LLM agent instance (with mock fallback)
    """
    return LLMReasoningAgent(config)
