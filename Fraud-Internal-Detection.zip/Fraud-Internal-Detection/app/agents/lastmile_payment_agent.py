"""
Last-Mile Payment Risk Agent
Detects risky payment actions after claim approval (post-approval payee changes).
Standalone agent ready for A2A communication.
"""

from typing import Dict, Any
from datetime import datetime
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class LastMilePaymentAgent:
    """
    Analyzes last-mile payment risks.
    
    Risk Factors:
    - Payee destination changed AFTER claim approved
    - Short time window from approval to payee change (<= 10 min)
    - Fast payment method (ACH_SAME_DAY, INSTANT, WIRE)
    - No customer verification for payee change
    """
    
    def __init__(self, name: str = "LastMilePaymentAgent"):
        self.name = name
        self.risky_time_window_minutes = 10
        self.fast_payment_methods = {'ACH_SAME_DAY', 'INSTANT', 'WIRE', 'RTP'}
    
    async def execute(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute last-mile payment risk analysis.
        
        Args:
            input_data: {
                'claim_status': str ('APPROVED', 'PENDING', etc.),
                'approval_timestamp': str (ISO8601),
                'payee_change_timestamp': str | None,
                'payment_method': str,
                'payment_release_request': bool,
                'verification_flag': bool,
                'payee_changed_after_approval': bool
            }
        
        Returns:
            {
                'last_mile_risk': 'LOW' | 'MED' | 'HIGH',
                'reasons': [str],
                'computed_deltas': {
                    'minutes_from_approval_to_payee_change': float,
                    'is_fast_payment_method': bool,
                    'payee_changed_post_approval': bool,
                    'verification_recorded': bool
                }
            }
        """
        
        try:
            claim_status = input_data.get('claim_status', '').upper()
            approval_ts_str = input_data.get('approval_timestamp')
            payee_change_ts_str = input_data.get('payee_change_timestamp')
            payment_method = input_data.get('payment_method', '').upper()
            payment_release = input_data.get('payment_release_request', False)
            verification_flag = input_data.get('verification_flag', False)
            payee_changed_after = input_data.get('payee_changed_after_approval', False)
            
            logger.info(
                f"Analyzing last-mile payment risk: claim_status={claim_status}, "
                f"payment_method={payment_method}"
            )
            
            reasons = []
            risk_points = 0
            
            # Calculate time delta if both timestamps available
            minutes_delta = None
            if approval_ts_str and payee_change_ts_str:
                approval_ts = self._parse_timestamp(approval_ts_str)
                payee_change_ts = self._parse_timestamp(payee_change_ts_str)
                minutes_delta = (payee_change_ts - approval_ts).total_seconds() / 60
            
            # Risk Factor 1: Payee changed after approval
            if payee_changed_after and claim_status == 'APPROVED':
                risk_points += 1
                reasons.append(
                    "⚠️ Payee destination changed AFTER claim was approved (last-mile risk)"
                )
            
            # Risk Factor 2: Short time window from approval to payee change
            if minutes_delta is not None and minutes_delta <= self.risky_time_window_minutes:
                risk_points += 1
                reasons.append(
                    f"⚠️ Payee changed within {minutes_delta:.1f} minutes of approval "
                    f"(risky window: <={self.risky_time_window_minutes} min)"
                )
            
            # Risk Factor 3: Fast payment method
            is_fast_payment = payment_method in self.fast_payment_methods
            if is_fast_payment and payment_release:
                risk_points += 1
                reasons.append(
                    f"⚠️ Fast payment method detected: {payment_method} "
                    "(funds released quickly, hard to reverse)"
                )
            
            # Risk Factor 4: No customer verification
            if payee_changed_after and not verification_flag:
                risk_points += 1
                reasons.append(
                    "⚠️ No customer verification recorded for payee change "
                    "(potential unauthorized modification)"
                )
            
            # Determine risk level based on points
            # FIXED: risk_points >= 2 should map to HIGH (was incorrectly >= 3)
            # This ensures proper BLOCK decisions when multiple risk factors present
            if risk_points >= 2:
                last_mile_risk = 'HIGH'
            elif risk_points >= 1:
                last_mile_risk = 'MED'
            else:
                last_mile_risk = 'LOW'
                if not reasons:
                    reasons.append("No significant last-mile payment risks detected")
            
            result = {
                'last_mile_risk': last_mile_risk,
                'reasons': reasons,
                'computed_deltas': {
                    'minutes_from_approval_to_payee_change': minutes_delta,
                    'is_fast_payment_method': is_fast_payment,
                    'payee_changed_post_approval': payee_changed_after,
                    'verification_recorded': verification_flag,
                    'risk_points': risk_points
                }
            }
            
            logger.info(
                f"Last-mile payment analysis complete: risk={last_mile_risk}, "
                f"points={risk_points}"
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Error in last-mile payment analysis: {e}")
            return {
                'last_mile_risk': 'LOW',
                'reasons': [f"Error in analysis: {str(e)}"],
                'computed_deltas': {}
            }
    
    def _parse_timestamp(self, timestamp_str: str) -> datetime:
        """Parse ISO8601 timestamp string."""
        if not timestamp_str:
            return datetime.utcnow()
        
        try:
            if timestamp_str.endswith('Z'):
                timestamp_str = timestamp_str[:-1] + '+00:00'
            return datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
        except:
            return datetime.utcnow()
