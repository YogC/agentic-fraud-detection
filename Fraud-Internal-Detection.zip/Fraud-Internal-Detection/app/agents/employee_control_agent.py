"""
Employee Control Concentration Agent
Detects when same employee performs multiple control actions in short window.
No historical baselines required - session-based only.
Standalone agent ready for A2A communication.
"""

from typing import Dict, Any, List
from datetime import datetime, timedelta
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class EmployeeControlAgent:
    """
    Analyzes employee control concentration risk.
    
    Detects: Same employee performing >=2 of:
    - APPROVE_CLAIM
    - UPDATE_PAYEE_BANK
    - UPDATE_PAYEE_ADDRESS
    - RELEASE_PAYMENT
    
    within a short time window (configurable, default 30 min).
    """
    
    def __init__(self, name: str = "EmployeeControlAgent"):
        self.name = name
        self.concentration_threshold = 2  # >=2 control actions = risk
        self.time_window_minutes = 30
        self.control_actions = {
            'APPROVE_CLAIM',
            'UPDATE_PAYEE_BANK',
            'UPDATE_PAYEE_ADDRESS', 
            'UPDATE_PAYEE_PHONE',
            'RELEASE_PAYMENT'
        }
    
    async def execute(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute control concentration analysis.
        
        Args:
            input_data: {
                'current_action': {
                    'action_type': str,
                    'employee_id': str,
                    'timestamp': str (ISO8601),
                    'claim_id': str,
                    'payment_id': str
                },
                'session_actions': [
                    {
                        'action_type': str,
                        'employee_id': str,
                        'timestamp': str,
                        'claim_id': str
                    }
                ],
                'actor_role': str
            }
        
        Returns:
            {
                'control_risk': 'LOW' | 'MED' | 'HIGH',
                'reasons': [str],
                'metrics': {
                    'control_action_count': int,
                    'time_window_minutes': float,
                    'actions_detected': [str]
                }
            }
        """
        logger.info(f"{self.name}: Analyzing control concentration")
        
        try:
            current_action = input_data.get('current_action', {})
            session_actions = input_data.get('session_actions', [])
            actor_role = input_data.get('actor_role', 'unknown')
            
            employee_id = current_action.get('employee_id')
            current_timestamp = self._parse_timestamp(current_action.get('timestamp'))
            
            logger.info(
                f"{self.name}: Analyzing for employee: {employee_id}"
            )
            
            # Filter control actions by same employee within time window
            control_actions_found = []
            
            # Check current action
            if current_action.get('action_type') in self.control_actions:
                control_actions_found.append({
                    'action': current_action.get('action_type'),
                    'timestamp': current_timestamp
                })
            
            # Check session actions
            for action in session_actions:
                if (action.get('employee_id') == employee_id and
                    action.get('action_type') in self.control_actions):
                    
                    action_timestamp = self._parse_timestamp(action.get('timestamp'))
                    
                    # Check if within time window
                    time_delta = abs((current_timestamp - action_timestamp).total_seconds() / 60)
                    
                    if time_delta <= self.time_window_minutes:
                        control_actions_found.append({
                            'action': action.get('action_type'),
                            'timestamp': action_timestamp
                        })
            
            # Remove duplicates
            unique_actions = list({a['action'] for a in control_actions_found})
            control_count = len(unique_actions)
            
            # Calculate time window span
            if len(control_actions_found) > 1:
                timestamps = [a['timestamp'] for a in control_actions_found]
                time_span = (max(timestamps) - min(timestamps)).total_seconds() / 60
            else:
                time_span = 0
            
            # Determine risk level
            reasons = []
            
            if control_count >= 3:
                control_risk = 'HIGH'
                reasons.append(
                    f"Employee performed {control_count} control actions "
                    f"within {time_span:.1f} minutes: {', '.join(unique_actions)}"
                )
                reasons.append("High concentration risk: Same employee has end-to-end control")
            
            elif control_count == 2:
                control_risk = 'MED'
                reasons.append(
                    f"Employee performed {control_count} control actions "
                    f"within {time_span:.1f} minutes: {', '.join(unique_actions)}"
                )
                reasons.append("Medium risk: Lack of separation of duties")
            
            else:
                control_risk = 'LOW'
                reasons.append("Normal separation of duties maintained")
            
            result = {
                'control_risk': control_risk,
                'reasons': reasons,
                'metrics': {
                    'control_action_count': control_count,
                    'time_window_minutes': time_span,
                    'actions_detected': unique_actions,
                    'employee_id': employee_id,
                    'actor_role': actor_role
                }
            }
            
            logger.info(
                f"Control concentration analysis complete: risk={control_risk}, "
                f"actions={control_count}"
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Error in control concentration analysis: {e}")
            return {
                'control_risk': 'LOW',
                'reasons': [f"Error in analysis: {str(e)}"],
                'metrics': {}
            }
    
    def _parse_timestamp(self, timestamp_str: str) -> datetime:
        """Parse ISO8601 timestamp string."""
        if not timestamp_str:
            return datetime.utcnow()
        
        try:
            # Handle Z suffix
            if timestamp_str.endswith('Z'):
                timestamp_str = timestamp_str[:-1] + '+00:00'
            return datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
        except:
            return datetime.utcnow()
