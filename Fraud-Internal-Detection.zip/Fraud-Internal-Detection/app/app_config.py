"""
Configuration Management Module
Handles loading and validation of configuration from YAML and environment variables.
"""

import os
from pathlib import Path
from typing import Any, Dict, List, Optional
import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, Field, field_validator


class TextractConfig(BaseModel):
    """Configuration for AWS Textract service."""
    features: List[str] = Field(default=["TABLES", "FORMS", "LAYOUT"])
    max_poll_attempts: int = Field(default=60)
    poll_interval_seconds: int = Field(default=5)


class BedrockConfig(BaseModel):
    """Configuration for AWS Bedrock service."""
    model_id: str = Field(default="anthropic.claude-3-sonnet-20240229-v1:0")
    max_tokens: int = Field(default=4000)
    temperature: float = Field(default=0.3)

    @field_validator('temperature')
    @classmethod
    def validate_temperature(cls, v: float) -> float:
        if not 0.0 <= v <= 1.0:
            raise ValueError("Temperature must be between 0.0 and 1.0")
        return v


class S3Config(BaseModel):
    """Configuration for AWS S3 service."""
    bucket_name: str = Field(default="")
    prefix: str = Field(default="medical-reports/")
    cleanup_after_processing: bool = Field(default=True)


class OutputConfig(BaseModel):
    """Configuration for output settings."""
    directory: str = Field(default="./output")
    formats: List[str] = Field(default=["json", "markdown"])


class LoggingConfig(BaseModel):
    """Configuration for logging."""
    level: str = Field(default="INFO")
    format: str = Field(default="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    file: str = Field(default="./logs/medical_report_analyzer.log")


class AgentConfig(BaseModel):
    """Configuration for individual agents."""
    name: str
    timeout_seconds: int = Field(default=300)


class AgentsConfig(BaseModel):
    """Configuration for all agents."""
    orchestrator: AgentConfig = Field(default=AgentConfig(name="Medical Report Orchestrator", timeout_seconds=600))
    aws_analyzer: AgentConfig = Field(default=AgentConfig(name="AWS Document Analyzer Agent", timeout_seconds=300))
    claim_summary: AgentConfig = Field(default=AgentConfig(name="Claim Summary Generator Agent", timeout_seconds=120))


class Config(BaseModel):
    """Main configuration class."""
    aws_endpoint: str = Field(default="")
    aws_access_key_id: str = Field(default="")
    aws_secret_access_key: str = Field(default="")
    aws_region: str = Field(default="us-east-1")
    
    textract: TextractConfig = Field(default_factory=TextractConfig)
    bedrock: BedrockConfig = Field(default_factory=BedrockConfig)
    s3: S3Config = Field(default_factory=S3Config)
    output: OutputConfig = Field(default_factory=OutputConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    agents: AgentsConfig = Field(default_factory=AgentsConfig)

    @field_validator('aws_access_key_id', 'aws_secret_access_key')
    @classmethod
    def validate_credentials(cls, v: str) -> str:
        if not v:
            raise ValueError("AWS credentials must be provided")
        return v


def load_config(config_path: Optional[str] = None) -> Config:
    """
    Load configuration from YAML file and environment variables.
    
    Args:
        config_path: Path to the configuration YAML file. If None, uses default.
    
    Returns:
        Config: Validated configuration object
    
    Raises:
        FileNotFoundError: If config file doesn't exist
        ValueError: If configuration is invalid
    """
    # Load environment variables from .env file if it exists
    load_dotenv()
    
    # Determine config file path
    if config_path is None:
        # Get project root (src/../.. from this file's location)
        project_root = Path(__file__).parent.parent
        config_path = project_root / 'config.yaml'
    else:
        config_path = Path(config_path)
    
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")
    
    # Load YAML configuration
    with open(config_path, 'r', encoding='utf-8') as f:
        config_data: Dict[str, Any] = yaml.safe_load(f)
    
    # Override with environment variables if present
    env_overrides = {
        'aws_access_key_id': os.getenv('AWS_ACCESS_KEY_ID'),
        'aws_secret_access_key': os.getenv('AWS_SECRET_ACCESS_KEY'),
        'aws_region': os.getenv('AWS_REGION'),
        'aws_endpoint': os.getenv('AWS_ENDPOINT'),
    }
    
    # Apply environment overrides
    for key, value in env_overrides.items():
        if value:
            config_data[key] = value
    
    # S3 bucket from environment
    if os.getenv('S3_BUCKET_NAME'):
        if 's3' not in config_data:
            config_data['s3'] = {}
        config_data['s3']['bucket_name'] = os.getenv('S3_BUCKET_NAME')
    
    # Bedrock model from environment
    if os.getenv('BEDROCK_MODEL_ID'):
        if 'bedrock' not in config_data:
            config_data['bedrock'] = {}
        config_data['bedrock']['model_id'] = os.getenv('BEDROCK_MODEL_ID')
    
    # Validate and create Config object
    config = Config(**config_data)
    
    return config


def get_boto3_session_config(config: Config) -> Dict[str, Any]:
    """
    Get boto3 session configuration from Config object.
    
    Args:
        config: Configuration object
    
    Returns:
        Dict containing boto3 session parameters
    """
    session_config = {
        'aws_access_key_id': config.aws_access_key_id,
        'aws_secret_access_key': config.aws_secret_access_key,
        'region_name': config.aws_region,
    }
    
    return session_config


def get_boto3_client_config(config: Config) -> Dict[str, Any]:
    """
    Get boto3 client configuration from Config object.
    
    Args:
        config: Configuration object
    
    Returns:
        Dict containing boto3 client parameters
    """
    client_config = {}
    
    if config.aws_endpoint:
        client_config['endpoint_url'] = config.aws_endpoint
    
    return client_config
