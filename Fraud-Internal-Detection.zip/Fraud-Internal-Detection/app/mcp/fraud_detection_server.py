"""
Fraud Detection MCP Server
Exposes fraud detection capabilities as MCP (Model Context Protocol) tools.

This server makes the 3-agent fraud detection system available to AI agents
via the standardized MCP protocol. LangChain agents, Claude Desktop, and other
MCP-compatible systems can discover and use these tools.

Tools Exposed:
1. check_payout_fraud - Full 3-agent fraud detection
2. check_employee_control_risk - Employee behavior analysis
3. check_lastmile_payment_risk - Payment timing/method risk
4. check_entity_link_risk - Bank account linkage detection
5. get_fraud_system_health - System health check
6. reset_entity_registry - Clear entity graph (testing only)

Updated for FastMCP 2.x compatibility
"""

import asyncio
import sys
import os
from pathlib import Path
from typing import Any, Dict, List, Optional
from datetime import datetime
import logging
from dotenv import load_dotenv

# Load environment variables (including LangSmith configuration)
load_dotenv()
logger = logging.getLogger(__name__)
logger.info(f"✅ Environment loaded - LangSmith tracing: {os.getenv('LANGCHAIN_TRACING_V2', 'not set')}")

# Import FastMCP FIRST (before modifying sys.path to avoid conflicts)
from fastmcp import FastMCP

# Add parent directory to path to import agents
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import agents
from agents.payout_orchestrator import PayoutDecisionOrchestrator
from agents.employee_control_agent import EmployeeControlAgent
from agents.lastmile_payment_agent import LastMilePaymentAgent
from agents.graph_entity_agent import GraphEntityLinkAgent

# Import database client for optional persistence
from database.dynamodb_client import DynamoDBClient

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize FastMCP server
mcp = FastMCP("fraud-detection-mcp-server")

# Configure LLM to disable prompt caching for immediate updates
# This ensures prompt changes via Dashboard are reflected immediately in MCP
llm_config = {
    'use_prompt_cache': False  # Disable cache to get fresh prompts on every request
}

# Initialize agents (singleton instances)
orchestrator = PayoutDecisionOrchestrator(llm_config=llm_config)
employee_agent = EmployeeControlAgent()
lastmile_agent = LastMilePaymentAgent()
entity_agent = GraphEntityLinkAgent()

logger.info("MCP Server initialized with 3 fraud detection agents")
logger.info("📌 Prompt caching DISABLED - prompt updates will be immediate")


# ============================================================================
# Database Persistence Helper (Optional)
# ============================================================================

async def save_transaction_to_db(payout_data: Dict[str, Any], decision_result: Dict[str, Any]) -> None:
    """
    Save MCP transaction to DynamoDB (mirrors REST API behavior).
    This enables full learning loop and dashboard visibility for MCP calls.
    
    Args:
        payout_data: Original payout request data
        decision_result: Orchestrator decision result
    """
    try:
        db_client = DynamoDBClient()
        
        # Extract key identifiers
        current_action = payout_data.get('current_action', {})
        payment_id = current_action.get('payment_id', 'MCP_UNKNOWN')
        claim_id = current_action.get('claim_id', 'MCP_UNKNOWN')
        
        # Determine status based on decision (same logic as REST API)
        decision = decision_result.get('decision', 'UNKNOWN')
        if decision in ['BLOCK', 'WARN']:
            status = 'PENDING_REVIEW'
        else:
            status = 'AUTO_APPROVED'
        
        # Prepare transaction record (same format as REST API)
        transaction_data = {
            'event_id': payment_id,
            'event_type': 'PAYMENT_FRAUD',
            'entity_id': payment_id,
            'entity_type': 'PAYMENT',
            'risk_category': 'FINANCIAL',
            'event_data': {
                'claim_id': claim_id,
                'payment_id': payment_id,
                'claimant_id': payout_data.get('claimant_id', ''),
                'payment_method': payout_data.get('payment_method', 'ACH'),
                'bank_account_hash': payout_data.get('bank_account_hash', ''),
                'current_action': current_action,
                'session_actions': payout_data.get('session_actions', []),
                'source': 'MCP',  # Track that this came from MCP
            },
            'detection_results': decision_result.get('per_agent', {}),
            'llm_decision': decision_result.get('decision', 'UNKNOWN'),
            'llm_confidence': decision_result.get('llm_confidence', 0.0),
            'llm_reasoning': decision_result.get('llm_insights', {}).get('reasoning', ''),
            'final_decision': decision_result.get('decision', 'UNKNOWN'),
            'status': status,
            'total_score': decision_result.get('total_score', 0),
            'display_metadata': {
                'employee_id': current_action.get('employee_id', ''),
                'employee_name': current_action.get('employee_name', ''),
                'claim_id': claim_id,
                'payment_id': payment_id,
            }
        }
        
        # Save to DynamoDB
        db_client.save_decision(transaction_data)
        
        logger.info(f"✅ MCP transaction saved to DB: {payment_id} (Decision: {decision}, Status: {status})")
        
    except Exception as e:
        # Don't fail the request - just log error
        logger.error(f"❌ Failed to save MCP transaction to DB: {e}", exc_info=True)


# ============================================================================
# MCP TOOL 1: Comprehensive Fraud Detection
# ============================================================================

@mcp.tool()
async def check_payout_fraud(
    current_action: Dict[str, Any],
    session_actions: List[Dict[str, Any]],
    actor_role: str,
    claim_status: str,
    approval_timestamp: Optional[str] = None,
    payee_change_timestamp: Optional[str] = None,
    payment_method: str = "ACH",
    payment_release_request: bool = False,
    verification_flag: bool = False,
    payee_changed_after_approval: bool = False,
    bank_account_hash: str = "",
    routing_hash: Optional[str] = None,
    payee_address_hash: Optional[str] = None,
    payee_phone_hash: Optional[str] = None,
    claimant_id: str = "",
    is_new_account: bool = False,
    recipient_name: Optional[str] = None,
    payment_description: Optional[str] = None,
    payment_amount: Optional[float] = None,
    save_to_db: bool = False
) -> Dict[str, Any]:
    """
    Comprehensive payout fraud detection using all 3 agents.
    
    Analyzes:
    - Employee control concentration (same employee doing multiple actions)
    - Last-mile payment risks (post-approval changes, fast methods)
    - Entity linkage (bank account reuse across claimants)
    
    Args:
        current_action: Current action being performed
            {
                'action_type': str,
                'employee_id': str,
                'timestamp': str (ISO8601),
                'claim_id': str,
                'payment_id': str
            }
        session_actions: List of actions in current session
        actor_role: Role of person performing action
        claim_status: Status of claim (APPROVED, PENDING, etc.)
        approval_timestamp: When claim was approved (ISO8601)
        payee_change_timestamp: When payee was changed (ISO8601)
        payment_method: Payment method (ACH, WIRE, ACH_SAME_DAY, etc.)
        payment_release_request: Whether payment release is requested
        verification_flag: Whether customer verification was recorded
        payee_changed_after_approval: Whether payee was changed after approval
        bank_account_hash: Hashed bank account number
        routing_hash: Hashed routing number
        payee_address_hash: Hashed payee address
        payee_phone_hash: Hashed payee phone
        claimant_id: Claimant identifier
        is_new_account: Whether this is a new bank account
        recipient_name: Vendor/payee name (for customer policy checks)
        payment_description: Transaction description (may include customer context)
        payment_amount: Payment amount in dollars (for context and risk assessment)
        save_to_db: Optional flag to save transaction to DynamoDB for dashboard 
                    visibility and learning loop. Default: False (dry-run mode).
                    Set to True for production-like testing with persistence.
    
    Returns:
        {
            'decision': 'ALLOW' | 'WARN' | 'BLOCK',
            'total_score': int (0-6),
            'per_agent': {
                'employee_control': {...},
                'lastmile_payment': {...},
                'graph_entity': {...}
            },
            'reasons': [str],
            'evidence': {...},
            'timestamp': str,
            'saved_to_db': bool (True if persisted to database)
        }
    """
    try:
        logger.info(f"MCP Tool: check_payout_fraud called for claim: {current_action.get('claim_id', 'unknown')} (save_to_db={save_to_db})")
        
        # Prepare input for orchestrator
        input_data = {
            'current_action': current_action,
            'session_actions': session_actions,
            'actor_role': actor_role,
            'claim_status': claim_status,
            'approval_timestamp': approval_timestamp,
            'payee_change_timestamp': payee_change_timestamp,
            'payment_method': payment_method,
            'payment_release_request': payment_release_request,
            'verification_flag': verification_flag,
            'payee_changed_after_approval': payee_changed_after_approval,
            'bank_account_hash': bank_account_hash,
            'routing_hash': routing_hash,
            'payee_address_hash': payee_address_hash,
            'payee_phone_hash': payee_phone_hash,
            'claimant_id': claimant_id,
            'is_new_account': is_new_account,
            'recipient_name': recipient_name,
            'payment_description': payment_description,
            'payment_amount': payment_amount
        }
        
        # Execute fraud detection
        result = await orchestrator.execute(input_data)
        
        # Conditionally save to database
        if save_to_db:
            await save_transaction_to_db(input_data, result)
            result['saved_to_db'] = True
            logger.info(f"MCP Tool: Transaction saved to DB")
        else:
            result['saved_to_db'] = False
            logger.info(f"MCP Tool: Dry-run mode - transaction NOT saved to DB")
        
        logger.info(f"MCP Tool: check_payout_fraud completed - Decision: {result.get('decision')}")
        return result
        
    except Exception as e:
        logger.error(f"Error in check_payout_fraud: {e}")
        return {
            'decision': 'BLOCK',  # Fail-safe
            'total_score': 999,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat() + 'Z'
        }


# ============================================================================
# MCP TOOL 2: Employee Control Risk Analysis
# ============================================================================

@mcp.tool()
async def check_employee_control_risk(
    current_action: Dict[str, Any],
    session_actions: List[Dict[str, Any]],
    actor_role: str
) -> Dict[str, Any]:
    """
    Analyze employee control concentration risk.
    
    Detects when same employee performs multiple control actions:
    - APPROVE_CLAIM
    - UPDATE_PAYEE_BANK
    - UPDATE_PAYEE_ADDRESS
    - UPDATE_PAYEE_PHONE
    - RELEASE_PAYMENT
    
    Within a short time window (default 30 minutes).
    
    Args:
        current_action: Current action being performed
            {
                'action_type': str,
                'employee_id': str,
                'timestamp': str (ISO8601),
                'claim_id': str,
                'payment_id': str
            }
        session_actions: List of previous actions in session
        actor_role: Role of person performing action
    
    Returns:
        {
            'control_risk': 'LOW' | 'MED' | 'HIGH',
            'reasons': [str],
            'metrics': {
                'control_action_count': int,
                'time_window_minutes': float,
                'actions_detected': [str],
                'employee_id': str,
                'actor_role': str
            }
        }
    """
    try:
        logger.info(f"MCP Tool: check_employee_control_risk called for employee: {current_action.get('employee_id')}")
        
        input_data = {
            'current_action': current_action,
            'session_actions': session_actions,
            'actor_role': actor_role
        }
        
        result = await employee_agent.execute(input_data)
        
        logger.info(f"MCP Tool: check_employee_control_risk completed - Risk: {result.get('control_risk')}")
        return result
        
    except Exception as e:
        logger.error(f"Error in check_employee_control_risk: {e}")
        return {
            'control_risk': 'LOW',
            'reasons': [f'Error in analysis: {str(e)}'],
            'metrics': {}
        }


# ============================================================================
# MCP TOOL 3: Last-Mile Payment Risk Analysis
# ============================================================================

@mcp.tool()
async def check_lastmile_payment_risk(
    claim_status: str,
    approval_timestamp: Optional[str] = None,
    payee_change_timestamp: Optional[str] = None,
    payment_method: str = "ACH",
    payment_release_request: bool = False,
    verification_flag: bool = False,
    payee_changed_after_approval: bool = False
) -> Dict[str, Any]:
    """
    Analyze last-mile payment risk factors.
    
    Risk factors:
    - Payee destination changed AFTER claim approved
    - Short time window from approval to payee change (<= 10 min)
    - Fast payment method (ACH_SAME_DAY, INSTANT, WIRE, RTP)
    - No customer verification for payee change
    
    Args:
        claim_status: Status of claim (APPROVED, PENDING, etc.)
        approval_timestamp: When claim was approved (ISO8601)
        payee_change_timestamp: When payee was changed (ISO8601)
        payment_method: Payment method (ACH, WIRE, ACH_SAME_DAY, INSTANT, RTP)
        payment_release_request: Whether payment release is requested
        verification_flag: Whether customer verification was recorded
        payee_changed_after_approval: Whether payee was changed after approval
    
    Returns:
        {
            'last_mile_risk': 'LOW' | 'MED' | 'HIGH',
            'reasons': [str],
            'computed_deltas': {
                'minutes_from_approval_to_payee_change': float,
                'is_fast_payment_method': bool,
                'payee_changed_post_approval': bool,
                'verification_recorded': bool,
                'risk_points': int
            }
        }
    """
    try:
        logger.info(f"MCP Tool: check_lastmile_payment_risk called for claim status: {claim_status}")
        
        input_data = {
            'claim_status': claim_status,
            'approval_timestamp': approval_timestamp,
            'payee_change_timestamp': payee_change_timestamp,
            'payment_method': payment_method,
            'payment_release_request': payment_release_request,
            'verification_flag': verification_flag,
            'payee_changed_after_approval': payee_changed_after_approval
        }
        
        result = await lastmile_agent.execute(input_data)
        
        logger.info(f"MCP Tool: check_lastmile_payment_risk completed - Risk: {result.get('last_mile_risk')}")
        return result
        
    except Exception as e:
        logger.error(f"Error in check_lastmile_payment_risk: {e}")
        return {
            'last_mile_risk': 'LOW',
            'reasons': [f'Error in analysis: {str(e)}'],
            'computed_deltas': {}
        }


# ============================================================================
# MCP TOOL 4: Entity Link Risk Analysis
# ============================================================================

@mcp.tool()
async def check_entity_link_risk(
    bank_account_hash: str,
    claim_id: str,
    claimant_id: str,
    employee_id: str,
    routing_hash: Optional[str] = None,
    payee_address_hash: Optional[str] = None,
    payee_phone_hash: Optional[str] = None,
    is_new_account: bool = False,
    payee_changed_post_approval: bool = False
) -> Dict[str, Any]:
    """
    Analyze entity linkage risk via bank account tracking.
    
    Detects:
    - Same bank account used across multiple claims
    - Same bank account linked to multiple claimants
    - Same bank account repeatedly used by same employee
    - New accounts with last-mile changes (post-approval)
    
    Args:
        bank_account_hash: Hashed bank account number
        claim_id: Claim identifier
        claimant_id: Claimant identifier
        employee_id: Employee processing the claim
        routing_hash: Hashed routing number
        payee_address_hash: Hashed payee address
        payee_phone_hash: Hashed payee phone
        is_new_account: Whether this is a new bank account
        payee_changed_post_approval: Whether payee was changed after approval
    
    Returns:
        {
            'entity_risk': 'LOW' | 'MED' | 'HIGH',
            'reasons': [str],
            'link_metrics': {
                'distinct_claims_count': int,
                'distinct_claimants_count': int,
                'distinct_employees_count': int,
                'same_employee_reuse_count': int,
                'is_new_account': bool,
                'risk_points': int
            }
        }
    """
    try:
        logger.info(f"MCP Tool: check_entity_link_risk called for account: {bank_account_hash[:8]}...")
        
        input_data = {
            'bank_account_hash': bank_account_hash,
            'routing_hash': routing_hash,
            'payee_address_hash': payee_address_hash,
            'payee_phone_hash': payee_phone_hash,
            'claim_id': claim_id,
            'claimant_id': claimant_id,
            'employee_id': employee_id,
            'is_new_account': is_new_account,
            'payee_changed_post_approval': payee_changed_post_approval
        }
        
        result = await entity_agent.execute(input_data)
        
        logger.info(f"MCP Tool: check_entity_link_risk completed - Risk: {result.get('entity_risk')}")
        return result
        
    except Exception as e:
        logger.error(f"Error in check_entity_link_risk: {e}")
        return {
            'entity_risk': 'LOW',
            'reasons': [f'Error in analysis: {str(e)}'],
            'link_metrics': {}
        }


# ============================================================================
# MCP TOOL 5: System Health Check
# ============================================================================

@mcp.tool()
async def get_fraud_system_health() -> Dict[str, Any]:
    """
    Get health status of fraud detection system.
    
    Returns agent availability, registry status, and system metrics.
    
    Returns:
        {
            'status': 'healthy' | 'degraded' | 'unhealthy',
            'timestamp': str,
            'agents': {
                'employee_control': 'available',
                'lastmile_payment': 'available',
                'graph_entity': 'available',
                'orchestrator': 'available'
            },
            'entity_registry': {
                'accounts_tracked': int,
                'registry_size': int
            },
            'system': {
                'uptime_seconds': float,
                'mcp_version': str
            }
        }
    """
    try:
        logger.info("MCP Tool: get_fraud_system_health called")
        
        # Check agent availability
        agents_status = {
            'employee_control': 'available' if employee_agent else 'unavailable',
            'lastmile_payment': 'available' if lastmile_agent else 'unavailable',
            'graph_entity': 'available' if entity_agent else 'unavailable',
            'orchestrator': 'available' if orchestrator else 'unavailable'
        }
        
        # Get entity registry stats
        registry_size = len(entity_agent._account_registry) if hasattr(entity_agent, '_account_registry') else 0
        
        # Determine overall status
        all_available = all(status == 'available' for status in agents_status.values())
        overall_status = 'healthy' if all_available else 'degraded'
        
        result = {
            'status': overall_status,
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'agents': agents_status,
            'entity_registry': {
                'accounts_tracked': registry_size,
                'registry_size': registry_size
            },
            'system': {
                'mcp_version': '1.0.0',
                'server_name': 'fraud-detection-mcp-server'
            }
        }
        
        logger.info(f"MCP Tool: get_fraud_system_health completed - Status: {overall_status}")
        return result
        
    except Exception as e:
        logger.error(f"Error in get_fraud_system_health: {e}")
        return {
            'status': 'unhealthy',
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'error': str(e)
        }


# ============================================================================
# MCP TOOL 6: Reset Entity Registry (Testing Only)
# ============================================================================

@mcp.tool()
async def reset_entity_registry() -> Dict[str, Any]:
    """
    Reset the in-memory entity graph registry (for testing only).
    
    Clears all bank account linkage data. Use with caution in production.
    
    Returns:
        {
            'status': 'success' | 'error',
            'message': str,
            'accounts_cleared': int,
            'timestamp': str
        }
    """
    try:
        logger.warning("MCP Tool: reset_entity_registry called - Clearing registry!")
        
        # Get count before clearing
        accounts_cleared = len(entity_agent._account_registry) if hasattr(entity_agent, '_account_registry') else 0
        
        # Clear registry
        GraphEntityLinkAgent.reset_registry()
        
        result = {
            'status': 'success',
            'message': 'Entity registry cleared successfully',
            'accounts_cleared': accounts_cleared,
            'timestamp': datetime.utcnow().isoformat() + 'Z'
        }
        
        logger.info(f"MCP Tool: reset_entity_registry completed - Cleared {accounts_cleared} accounts")
        return result
        
    except Exception as e:
        logger.error(f"Error in reset_entity_registry: {e}")
        return {
            'status': 'error',
            'message': f'Failed to reset registry: {str(e)}',
            'accounts_cleared': 0,
            'timestamp': datetime.utcnow().isoformat() + 'Z'
        }


# ============================================================================
# Server Startup
# ============================================================================

if __name__ == "__main__":
    logger.info("=" * 60)
    logger.info("Starting Fraud Detection MCP Server")
    logger.info("=" * 60)
    logger.info("Tools available:")
    logger.info("  1. check_payout_fraud - Comprehensive fraud detection")
    logger.info("  2. check_employee_control_risk - Employee behavior analysis")
    logger.info("  3. check_lastmile_payment_risk - Payment risk analysis")
    logger.info("  4. check_entity_link_risk - Bank account linkage detection")
    logger.info("  5. get_fraud_system_health - System health check")
    logger.info("  6. reset_entity_registry - Clear entity graph (testing)")
    logger.info("=" * 60)
    
    # Check for HTTP/SSE mode via command-line arguments
    import sys
    
    # Default: stdio mode (backward compatible)
    use_http_mode = False
    port = 8001  # Default port for MCP HTTP server (avoids conflict with FastAPI on 8000)
    
    # Parse command-line arguments
    for i, arg in enumerate(sys.argv):
        if arg in ["--http", "--sse"]:
            use_http_mode = True
        elif arg == "--port" and i + 1 < len(sys.argv):
            try:
                port = int(sys.argv[i + 1])
            except ValueError:
                logger.warning(f"Invalid port value: {sys.argv[i + 1]}, using default: {port}")
    
    # Run the MCP server in appropriate mode
    if use_http_mode:
        logger.info("=" * 60)
        logger.info(f"🌐 HTTP/SSE Mode ENABLED")
        logger.info(f"📡 Server URL: http://localhost:{port}/sse")
        logger.info(f"🔧 For Postman MCP: Use URL above")
        logger.info(f"⚠️  Make sure port {port} doesn't conflict with other services")
        logger.info(f"💡 FastAPI backend runs on port 8000 (separate)")
        logger.info("=" * 60)
        # Pass host and port directly to run method
        mcp.run(transport="sse", host="127.0.0.1", port=port)
    else:
        logger.info("=" * 60)
        logger.info("📋 stdio Mode (default)")
        logger.info("🐍 For Python MCP client: python app/mcp/fraud_mcp_client.py")
        logger.info("💡 For HTTP mode: python app/mcp/fraud_detection_server.py --http --port 8001")
        logger.info("=" * 60)
        mcp.run()
