"""
MCP (Model Context Protocol) Integration Module
Exposes fraud detection capabilities as MCP tools for AI agents.
"""

__version__ = "1.0.0"
