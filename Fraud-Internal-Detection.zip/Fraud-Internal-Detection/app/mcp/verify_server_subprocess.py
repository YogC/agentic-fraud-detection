"""
Verify MCP Server Subprocess Test
This script demonstrates that the MCP client spawns the server as a subprocess.
"""

import asyncio
import os
from pathlib import Path
from fraud_mcp_client import FraudDetectionMCPClient

async def verify_subprocess():
    """
    Verify that MCP client spawns server as subprocess.
    """
    print("=" * 60)
    print("MCP Server Subprocess Verification")
    print("=" * 60)
    
    # Get current process ID
    current_pid = os.getpid()
    print(f"\n1. Current Python process (client): PID {current_pid}")
    
    # List all Python processes before connection
    print("\n2. Python processes BEFORE connecting to MCP server:")
    python_procs_before = []
    for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            if proc.info['name'] and 'python' in proc.info['name'].lower():
                cmdline = ' '.join(proc.info['cmdline'] or [])
                if 'fraud' in cmdline.lower() or proc.info['pid'] == current_pid:
                    python_procs_before.append(proc.info['pid'])
                    print(f"   - PID {proc.info['pid']}: {cmdline[:80]}")
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    
    # Connect to MCP server
    print("\n3. Connecting to MCP server...")
    client = FraudDetectionMCPClient("app/mcp/fraud_detection_server.py")
    await client.connect()
    print("   ✅ Connected!")
    
    # Small delay to let server fully start
    await asyncio.sleep(1)
    
    # List all Python processes after connection
    print("\n4. Python processes AFTER connecting to MCP server:")
    python_procs_after = []
    server_pid = None
    for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'ppid']):
        try:
            if proc.info['name'] and 'python' in proc.info['name'].lower():
                cmdline = ' '.join(proc.info['cmdline'] or [])
                if 'fraud' in cmdline.lower() or proc.info['pid'] == current_pid:
                    python_procs_after.append(proc.info['pid'])
                    parent_marker = " (PARENT)" if proc.info['pid'] == current_pid else ""
                    child_marker = " (SERVER - child process)" if proc.info['ppid'] == current_pid else ""
                    print(f"   - PID {proc.info['pid']}: {cmdline[:80]}{parent_marker}{child_marker}")
                    
                    if 'fraud_detection_server.py' in cmdline and proc.info['ppid'] == current_pid:
                        server_pid = proc.info['pid']
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    
    # Identify new process
    new_pids = set(python_procs_after) - set(python_procs_before)
    
    print("\n5. Analysis:")
    if new_pids:
        print(f"   ✅ NEW Python process(es) spawned: {new_pids}")
        if server_pid:
            print(f"   ✅ MCP Server subprocess confirmed: PID {server_pid}")
            print(f"   ✅ Parent process (client): PID {current_pid}")
        else:
            print(f"   ⚠️  New process spawned but server script not detected in cmdline")
    else:
        print(f"   ⚠️  No new Python processes detected (may not have permission to see child processes)")
    
    # Test that server is working
    print("\n6. Testing MCP server functionality...")
    health = await client.get_health()
    print(f"   ✅ Health check: {health['status']}")
    print(f"   ✅ Server is responding correctly!")
    
    # Disconnect
    print("\n7. Disconnecting from MCP server...")
    await client.disconnect()
    print("   ✅ Disconnected")
    
    # Small delay to let server fully terminate
    await asyncio.sleep(1)
    
    # Check if server process is terminated
    print("\n8. Python processes AFTER disconnecting:")
    python_procs_final = []
    for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            if proc.info['name'] and 'python' in proc.info['name'].lower():
                cmdline = ' '.join(proc.info['cmdline'] or [])
                if 'fraud' in cmdline.lower() or proc.info['pid'] == current_pid:
                    python_procs_final.append(proc.info['pid'])
                    print(f"   - PID {proc.info['pid']}: {cmdline[:80]}")
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    
    terminated_pids = set(python_procs_after) - set(python_procs_final)
    
    print("\n9. Cleanup Analysis:")
    if terminated_pids:
        print(f"   ✅ Process(es) terminated after disconnect: {terminated_pids}")
        if server_pid and server_pid in terminated_pids:
            print(f"   ✅ MCP Server subprocess cleaned up correctly")
    else:
        print(f"   ℹ️  All processes still running (may take a moment to terminate)")
    
    print("\n" + "=" * 60)
    print("CONCLUSION:")
    print("=" * 60)
    if new_pids:
        print("✅ MCP client DOES spawn the server as a subprocess")
        print("✅ You do NOT need to manually start the server")
        print("✅ The server runs in the background during client connection")
    else:
        print("ℹ️  Subprocess detection may be limited by permissions")
        print("✅ Server functionality confirmed (health check passed)")
    print("=" * 60)

if __name__ == "__main__":
    asyncio.run(verify_subprocess())
