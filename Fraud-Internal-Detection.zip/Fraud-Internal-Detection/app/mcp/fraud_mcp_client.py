"""
Fraud Detection MCP Client Example
Demonstrates how to connect to and use the fraud detection MCP server.

This client shows how AI agents or other systems can discover and invoke
the fraud detection tools via the MCP protocol.
"""

import asyncio
import json
from typing import Any, Dict
from datetime import datetime
import logging

try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    MCP_AVAILABLE = True
except ImportError:
    MCP_AVAILABLE = False
    print("⚠️  MCP client library not installed. Install with: pip install mcp")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class FraudDetectionMCPClient:
    """
    MCP Client for interacting with fraud detection tools.
    
    This client demonstrates:
    1. Connecting to MCP server
    2. Discovering available tools
    3. Invoking fraud detection tools
    4. Handling responses
    """
    
    def __init__(self, server_script_path: str = "app/mcp/fraud_detection_server.py"):
        """
        Initialize MCP client.
        
        Args:
            server_script_path: Path to the MCP server script
        """
        self.server_script_path = server_script_path
        self.session = None
        self.stdio_context = None
        self.session_context = None
        
    async def connect(self):
        """Connect to the MCP server."""
        if not MCP_AVAILABLE:
            raise ImportError("MCP client library not available")
            
        logger.info(f"Connecting to MCP server: {self.server_script_path}")
        
        # Configure server parameters
        server_params = StdioServerParameters(
            command="python",
            args=[self.server_script_path],
            env=None
        )
        
        # Store context managers and create session properly
        self.stdio_context = stdio_client(server_params)
        read, write = await self.stdio_context.__aenter__()
        
        self.session_context = ClientSession(read, write)
        self.session = await self.session_context.__aenter__()
        
        # Initialize the session
        await self.session.initialize()
        
        logger.info("Connected to MCP server successfully")
        
    async def disconnect(self):
        """Disconnect from MCP server."""
        if self.session:
            # Exit session context first
            await self.session_context.__aexit__(None, None, None)
            # Then exit stdio context
            await self.stdio_context.__aexit__(None, None, None)
            logger.info("Disconnected from MCP server")
    
    async def list_tools(self) -> list:
        """
        Discover available tools from MCP server.
        
        Returns:
            List of available tool definitions
        """
        if not self.session:
            raise RuntimeError("Not connected to MCP server")
        
        logger.info("Listing available tools...")
        tools_response = await self.session.list_tools()
        
        logger.info(f"Found {len(tools_response.tools)} tools:")
        for tool in tools_response.tools:
            logger.info(f"  - {tool.name}: {tool.description}")
        
        return tools_response.tools
    
    def _extract_result(self, result) -> Dict[str, Any]:
        """
        Extract and parse result from CallToolResult.
        
        Args:
            result: CallToolResult object from MCP
        
        Returns:
            Parsed result as dictionary
        """
        # Extract content from CallToolResult
        if hasattr(result, 'content'):
            content = result.content
            if isinstance(content, list) and len(content) > 0:
                first_content = content[0]
                if hasattr(first_content, 'text'):
                    # Parse the JSON text from TextContent
                    return json.loads(first_content.text)
                else:
                    return first_content
            else:
                return content
        else:
            return result
    
    async def check_payout_fraud(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Call comprehensive payout fraud detection.
        
        Args:
            payload: Fraud detection parameters
        
        Returns:
            Fraud detection result with decision (ALLOW/WARN/BLOCK)
        """
        if not self.session:
            raise RuntimeError("Not connected to MCP server")
        
        logger.info("Calling check_payout_fraud tool...")
        
        result = await self.session.call_tool(
            "check_payout_fraud",
            arguments=payload
        )
        
        result_data = self._extract_result(result)
        
        # Now result_data should be a dictionary
        decision = result_data.get('decision', 'UNKNOWN') if isinstance(result_data, dict) else 'UNKNOWN'
        logger.info(f"Fraud check complete. Decision: {decision}")
        return result_data
    
    async def check_employee_control_risk(
        self,
        current_action: Dict[str, Any],
        session_actions: list,
        actor_role: str
    ) -> Dict[str, Any]:
        """
        Call employee control risk analysis.
        
        Args:
            current_action: Current action details
            session_actions: Session action history
            actor_role: Actor role
        
        Returns:
            Employee control risk assessment
        """
        if not self.session:
            raise RuntimeError("Not connected to MCP server")
        
        logger.info("Calling check_employee_control_risk tool...")
        
        result = await self.session.call_tool(
            "check_employee_control_risk",
            arguments={
                "current_action": current_action,
                "session_actions": session_actions,
                "actor_role": actor_role
            }
        )
        
        result_data = self._extract_result(result)
        
        risk = result_data.get('control_risk', 'UNKNOWN') if isinstance(result_data, dict) else 'UNKNOWN'
        logger.info(f"Employee risk check complete. Risk: {risk}")
        return result_data
    
    async def get_system_health(self) -> Dict[str, Any]:
        """
        Get fraud detection system health status.
        
        Returns:
            System health information
        """
        if not self.session:
            raise RuntimeError("Not connected to MCP server")
        
        logger.info("Calling get_fraud_system_health tool...")
        
        result = await self.session.call_tool(
            "get_fraud_system_health",
            arguments={}
        )
        
        result_data = self._extract_result(result)
        
        status = result_data.get('status', 'UNKNOWN') if isinstance(result_data, dict) else 'UNKNOWN'
        logger.info(f"Health check complete. Status: {status}")
        return result_data


# ============================================================================
# Example Usage Scenarios
# ============================================================================

async def example_comprehensive_fraud_check():
    """
    Example 1: Comprehensive fraud detection with all 3 agents.
    """
    print("\n" + "=" * 60)
    print("Example 1: Comprehensive Payout Fraud Detection")
    print("=" * 60)
    
    # Sample payload - medium risk scenario
    payload = {
        "current_action": {
            "action_type": "RELEASE_PAYMENT",
            "employee_id": "EMP-12345",
            "timestamp": datetime.utcnow().isoformat() + 'Z',
            "claim_id": "CLM-98765",
            "payment_id": "PAY-11111"
        },
        "session_actions": [
            {
                "action_type": "APPROVE_CLAIM",
                "employee_id": "EMP-12345",
                "timestamp": "2026-01-26T10:00:00Z",
                "claim_id": "CLM-98765"
            },
            {
                "action_type": "UPDATE_PAYEE_BANK",
                "employee_id": "EMP-12345",
                "timestamp": "2026-01-26T10:05:00Z",
                "claim_id": "CLM-98765"
            }
        ],
        "actor_role": "claims_adjuster",
        "claim_status": "APPROVED",
        "approval_timestamp": "2026-01-26T10:00:00Z",
        "payee_change_timestamp": "2026-01-26T10:05:00Z",
        "payment_method": "ACH_SAME_DAY",
        "payment_release_request": True,
        "verification_flag": False,
        "payee_changed_after_approval": True,
        "bank_account_hash": "hash_abc123",
        "routing_hash": "hash_routing_456",
        "claimant_id": "CLAIMANT-001",
        "is_new_account": True
    }
    
    client = FraudDetectionMCPClient()
    
    try:
        # Connect to server
        await client.connect()
        
        # Call fraud detection
        result = await client.check_payout_fraud(payload)
        
        # Display results
        print(f"\n✅ Fraud Detection Result:")
        print(f"   Decision: {result.get('decision')}")
        print(f"   Total Score: {result.get('total_score')}")
        print(f"\n   Per-Agent Breakdown:")
        for agent_name, agent_result in result.get('per_agent', {}).items():
            print(f"     {agent_name}: {agent_result.get('risk')} (score: {agent_result.get('score')})")
        
        print(f"\n   Reasons:")
        for reason in result.get('reasons', []):
            print(f"     - {reason}")
        
    finally:
        await client.disconnect()


async def example_employee_risk_only():
    """
    Example 2: Check only employee control risk (single agent).
    """
    print("\n" + "=" * 60)
    print("Example 2: Employee Control Risk Check Only")
    print("=" * 60)
    
    current_action = {
        "action_type": "RELEASE_PAYMENT",
        "employee_id": "EMP-99999",
        "timestamp": datetime.utcnow().isoformat() + 'Z',
        "claim_id": "CLM-55555",
        "payment_id": "PAY-22222"
    }
    
    session_actions = [
        {
            "action_type": "APPROVE_CLAIM",
            "employee_id": "EMP-99999",
            "timestamp": "2026-01-26T11:00:00Z",
            "claim_id": "CLM-55555"
        },
        {
            "action_type": "UPDATE_PAYEE_BANK",
            "employee_id": "EMP-99999",
            "timestamp": "2026-01-26T11:10:00Z",
            "claim_id": "CLM-55555"
        },
        {
            "action_type": "UPDATE_PAYEE_ADDRESS",
            "employee_id": "EMP-99999",
            "timestamp": "2026-01-26T11:15:00Z",
            "claim_id": "CLM-55555"
        }
    ]
    
    client = FraudDetectionMCPClient()
    
    try:
        await client.connect()
        
        result = await client.check_employee_control_risk(
            current_action=current_action,
            session_actions=session_actions,
            actor_role="senior_adjuster"
        )
        
        print(f"\n✅ Employee Control Risk Result:")
        print(f"   Risk Level: {result.get('control_risk')}")
        print(f"   Control Actions: {result.get('metrics', {}).get('control_action_count')}")
        print(f"\n   Reasons:")
        for reason in result.get('reasons', []):
            print(f"     - {reason}")
        
    finally:
        await client.disconnect()


async def example_health_check():
    """
    Example 3: System health check.
    """
    print("\n" + "=" * 60)
    print("Example 3: System Health Check")
    print("=" * 60)
    
    client = FraudDetectionMCPClient()
    
    try:
        await client.connect()
        
        result = await client.get_system_health()
        
        print(f"\n✅ System Health:")
        print(f"   Status: {result.get('status')}")
        print(f"\n   Agents:")
        for agent_name, status in result.get('agents', {}).items():
            print(f"     {agent_name}: {status}")
        
        print(f"\n   Entity Registry:")
        registry = result.get('entity_registry', {})
        print(f"     Accounts Tracked: {registry.get('accounts_tracked')}")
        
    finally:
        await client.disconnect()


async def example_tool_discovery():
    """
    Example 4: Discover available tools.
    """
    print("\n" + "=" * 60)
    print("Example 4: Tool Discovery")
    print("=" * 60)
    
    client = FraudDetectionMCPClient()
    
    try:
        await client.connect()
        
        tools = await client.list_tools()
        
        print(f"\n✅ Discovered {len(tools)} tools:")
        for i, tool in enumerate(tools, 1):
            print(f"\n   {i}. {tool.name}")
            print(f"      Description: {tool.description}")
            print(f"      Parameters: {len(tool.inputSchema.get('properties', {}))} parameters")
        
    finally:
        await client.disconnect()


# ============================================================================
# Main Entry Point
# ============================================================================

async def main():
    """Run all examples."""
    print("\n" + "=" * 60)
    print("🚀 Fraud Detection MCP Client - Demo Suite")
    print("=" * 60)
    print("📊 Demonstrates: Agent-based fraud detection (NO database)")
    print("🔧 Tools: 6 MCP tools available via Model Context Protocol")
    print("=" * 60)
    
    if not MCP_AVAILABLE:
        print("\n❌ MCP client library not available.")
        print("   Install with: pip install mcp")
        return
    
    # Run examples with clear separators
    print("\n\n" + "█" * 60)
    print("STEP 1: Tool Discovery - Available MCP Tools")
    print("█" * 60)
    await example_tool_discovery()
    
    print("\n\n" + "█" * 60)
    print("STEP 2: Fraud Detection Example - Last-Mile Payment Risk")
    print("█" * 60)
    await example_comprehensive_fraud_check()
    
    print("\n\n" + "█" * 60)
    print("STEP 3: Employee Control Check - Separation of Duties")
    print("█" * 60)
    await example_employee_risk_only()
    
    print("\n\n" + "█" * 60)
    print("STEP 4: System Health Check - Agent Availability")
    print("█" * 60)
    await example_health_check()
    
    print("\n\n" + "=" * 60)
    print("✅ All 4 Examples Completed Successfully!")
    print("=" * 60)
    print("\n💡 Key Takeaways:")
    print("   • 6 MCP tools discovered (orchestrator + 3 agents + health + reset)")
    print("   • 4 demo examples executed")
    print("   • No database required (ephemeral testing)")
    print("   • No LangSmith traces (MCP protocol only)")
    print("\n📚 For full learning loop with database + LangSmith:")
    print("   → Use REST API: python -m uvicorn app.main:app --reload")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
