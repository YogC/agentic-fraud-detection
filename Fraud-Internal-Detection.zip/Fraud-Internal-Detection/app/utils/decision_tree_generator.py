"""
Decision Tree Generator for Fraud Detection
Generates structured, explainable decision trees showing:
1. What each agent detected
2. Why agents scored the way they did
3. What LLM reasoning added
4. Why final decision was made
"""

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class DecisionTreeGenerator:
    """Generates structured decision trees for fraud detection explainability."""
    
    def __init__(self):
        """Initialize decision tree generator."""
        self.risk_score_map = {'LOW': 0, 'MED': 1, 'HIGH': 2}
    
    def generate(
        self,
        agent_results: Dict[str, Any],
        llm_result: Optional[Dict[str, Any]],
        final_decision: str,
        rule_based_decision: str,
        total_score: int,
        metadata: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Generate comprehensive decision tree.
        
        Args:
            agent_results: Results from all rule-based agents
            llm_result: Result from LLM reasoning agent (if enabled)
            final_decision: Final decision (ALLOW/WARN/BLOCK)
            rule_based_decision: Decision based on rules alone
            total_score: Total risk score from agents
            metadata: Additional context (transaction_id, amount, etc.)
        
        Returns:
            Structured decision tree with full explainability
        """
        try:
            metadata = metadata or {}
            
            # Build agent analysis section
            agents_analysis = self._analyze_agents(agent_results)
            
            # Build LLM reasoning section
            llm_analysis = self._analyze_llm(llm_result) if llm_result else None
            
            # Determine if LLM overrode agents
            llm_override = False
            override_reason = None
            
            if llm_result and llm_result.get('recommendation'):
                llm_decision = llm_result['recommendation']
                if llm_decision != rule_based_decision:
                    llm_override = True
                    override_reason = self._explain_override(
                        rule_based_decision,
                        llm_decision,
                        llm_result
                    )
            
            # Build decision path
            decision_path = self._build_decision_path(
                agents_analysis,
                llm_analysis,
                rule_based_decision,
                final_decision,
                total_score,
                llm_override
            )
            
            # Build comprehensive decision tree
            decision_tree = {
                "metadata": {
                    "transaction_id": metadata.get("transaction_id", "unknown"),
                    "timestamp": datetime.utcnow().isoformat(),
                    "event_type": metadata.get("event_type", "PAYMENT_FRAUD"),
                    "amount": metadata.get("payment_amount", 0),
                    "vendor_name": metadata.get("vendor_name", "N/A")
                },
                
                "agents_analysis": agents_analysis,
                
                "llm_reasoning": llm_analysis,
                
                "decision_logic": {
                    "total_agent_score": total_score,
                    "rule_based_decision": rule_based_decision,
                    "llm_decision": llm_result.get('recommendation') if llm_result else None,
                    "final_decision": final_decision,
                    "llm_override": llm_override,
                    "override_reason": override_reason
                },
                
                "decision_path": decision_path,
                
                "explainability": self._generate_summary(
                    agents_analysis,
                    llm_analysis,
                    final_decision,
                    llm_override
                )
            }
            
            logger.info(f"Decision tree generated: {final_decision} | override={llm_override}")
            return decision_tree
            
        except Exception as e:
            logger.error(f"Error generating decision tree: {e}")
            return self._create_fallback_tree(final_decision, str(e))
    
    def _analyze_agents(self, agent_results: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze results from all rule-based agents."""
        agents = {}
        
        for agent_name, result in agent_results.items():
            if isinstance(result, dict):
                risk = result.get('risk', 'LOW')
                score = self.risk_score_map.get(risk, 0)
                
                agents[agent_name] = {
                    "score": score,
                    "risk_level": risk,
                    "reasoning": result.get('reason', 'No reason provided'),
                    "flags_detected": result.get('flags', []),
                    "confidence": result.get('confidence', 0.0),
                    "details": result.get('details', {})
                }
        
        # Calculate consensus
        total_agents = len(agents)
        high_risk_count = sum(1 for a in agents.values() if a['risk_level'] == 'HIGH')
        med_risk_count = sum(1 for a in agents.values() if a['risk_level'] == 'MED')
        
        agents["_summary"] = {
            "total_agents": total_agents,
            "high_risk_count": high_risk_count,
            "medium_risk_count": med_risk_count,
            "low_risk_count": total_agents - high_risk_count - med_risk_count,
            "consensus": "HIGH" if high_risk_count >= 2 else "MEDIUM" if med_risk_count >= 2 else "LOW"
        }
        
        return agents
    
    def _analyze_llm(self, llm_result: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze LLM reasoning and contribution."""
        return {
            "enabled": True,
            "recommendation": llm_result.get('recommendation', 'N/A'),
            "risk_level": llm_result.get('risk_level', 'N/A'),
            "confidence": llm_result.get('confidence', 0.0),
            "reasoning": llm_result.get('reasoning', 'No reasoning provided'),
            "key_factors": llm_result.get('key_factors', []),
            "world_knowledge_applied": self._detect_world_knowledge(llm_result),
            "patterns_recognized": self._extract_patterns(llm_result),
            "token_usage": llm_result.get('token_usage', {}),
            "processing_metadata": {
                "fallback": llm_result.get('fallback', False),
                "error": llm_result.get('error', None)
            }
        }
    
    def _detect_world_knowledge(self, llm_result: Dict[str, Any]) -> bool:
        """Detect if LLM applied world knowledge beyond rules."""
        reasoning = str(llm_result.get('reasoning', '')).lower()
        key_factors = str(llm_result.get('key_factors', [])).lower()
        
        # Keywords indicating world knowledge
        world_knowledge_keywords = [
            'crypto', 'scam', 'phishing', 'social engineering',
            'business email compromise', 'bec', 'common tactic',
            'typical pattern', 'known fraud', 'suspicious narrative',
            'urgency pressure', 'vague description', 'recovery service'
        ]
        
        combined_text = f"{reasoning} {key_factors}"
        return any(keyword in combined_text for keyword in world_knowledge_keywords)
    
    def _extract_patterns(self, llm_result: Dict[str, Any]) -> List[str]:
        """Extract fraud patterns recognized by LLM."""
        patterns = []
        reasoning = str(llm_result.get('reasoning', '')).lower()
        
        pattern_map = {
            'crypto': 'crypto_scam',
            'phishing': 'phishing_attempt',
            'social engineering': 'social_engineering',
            'business email compromise': 'bec_attack',
            'urgency': 'urgency_pressure',
            'vague': 'vague_description',
            'recovery': 'recovery_scam',
            'ceo': 'ceo_fraud',
            'executive': 'executive_impersonation'
        }
        
        for keyword, pattern in pattern_map.items():
            if keyword in reasoning:
                patterns.append(pattern)
        
        return patterns
    
    def _explain_override(
        self,
        rule_decision: str,
        llm_decision: str,
        llm_result: Dict[str, Any]
    ) -> str:
        """Explain why LLM overrode agent decision."""
        confidence = llm_result.get('confidence', 0.0)
        reasoning = llm_result.get('reasoning', 'No reasoning provided')
        
        if llm_decision == 'BLOCK' and rule_decision != 'BLOCK':
            return (
                f"LLM escalated to BLOCK (confidence: {confidence:.2f}) based on: {reasoning[:200]}"
            )
        elif llm_decision == 'ALLOW' and rule_decision == 'BLOCK':
            return (
                f"LLM downgraded to ALLOW (confidence: {confidence:.2f}) based on: {reasoning[:200]}"
            )
        else:
            return f"LLM changed decision from {rule_decision} to {llm_decision}: {reasoning[:200]}"
    
    def _build_decision_path(
        self,
        agents: Dict[str, Any],
        llm: Optional[Dict[str, Any]],
        rule_decision: str,
        final_decision: str,
        total_score: int,
        llm_override: bool
    ) -> List[Dict[str, str]]:
        """Build step-by-step decision path."""
        path = []
        
        # Step 1: Agent evaluation
        agent_count = agents.get('_summary', {}).get('total_agents', 0)
        high_count = agents.get('_summary', {}).get('high_risk_count', 0)
        
        path.append({
            "step": "1",
            "phase": "Agent Evaluation",
            "description": f"Evaluated {agent_count} rule-based agents",
            "result": f"Total score: {total_score}/6 | HIGH risk: {high_count} agents",
            "decision": rule_decision
        })
        
        # Step 2: LLM reasoning
        if llm:
            llm_confidence = llm.get('confidence', 0.0)
            llm_decision = llm.get('recommendation', 'N/A')
            
            path.append({
                "step": "2",
                "phase": "LLM Reasoning",
                "description": "Applied AI reasoning and world knowledge",
                "result": f"Confidence: {llm_confidence:.2f} | Decision: {llm_decision}",
                "decision": llm_decision
            })
        else:
            path.append({
                "step": "2",
                "phase": "LLM Reasoning",
                "description": "LLM reasoning not available",
                "result": "Falling back to rule-based decision",
                "decision": rule_decision
            })
        
        # Step 3: Final decision
        if llm_override:
            path.append({
                "step": "3",
                "phase": "Final Decision",
                "description": f"LLM overrode agents: {rule_decision} → {final_decision}",
                "result": f"Decision changed based on LLM reasoning",
                "decision": final_decision
            })
        else:
            path.append({
                "step": "3",
                "phase": "Final Decision",
                "description": "Agents and LLM agree",
                "result": f"Consensus decision: {final_decision}",
                "decision": final_decision
            })
        
        return path
    
    def _generate_summary(
        self,
        agents: Dict[str, Any],
        llm: Optional[Dict[str, Any]],
        final_decision: str,
        llm_override: bool
    ) -> Dict[str, Any]:
        """Generate human-readable summary."""
        summary = agents.get('_summary', {})
        
        # Primary reason
        if llm_override and llm:
            primary_reason = "LLM world knowledge override"
            key_insight = llm.get('reasoning', 'N/A')[:200]
        else:
            if summary.get('high_risk_count', 0) >= 2:
                primary_reason = "Multiple agents detected high risk"
            elif summary.get('medium_risk_count', 0) >= 2:
                primary_reason = "Multiple agents detected medium risk"
            else:
                primary_reason = "Low risk detected by agents"
            key_insight = "Agent consensus"
        
        return {
            "final_decision": final_decision,
            "primary_reason": primary_reason,
            "key_insight": key_insight,
            "agent_consensus": summary.get('consensus', 'UNKNOWN'),
            "llm_override": llm_override,
            "confidence": llm.get('confidence', 0.0) if llm else summary.get('high_risk_count', 0) / 3.0,
            "recommendation": (
                f"{'BLOCK' if final_decision == 'BLOCK' else 'APPROVE' if final_decision == 'ALLOW' else 'REVIEW'} "
                f"this transaction based on {primary_reason.lower()}"
            )
        }
    
    def _create_fallback_tree(self, decision: str, error: str) -> Dict[str, Any]:
        """Create minimal decision tree on error."""
        return {
            "error": error,
            "final_decision": decision,
            "explainability": {
                "final_decision": decision,
                "primary_reason": "Error generating decision tree",
                "key_insight": f"Error: {error}",
                "recommendation": "Manual review recommended due to system error"
            }
        }
