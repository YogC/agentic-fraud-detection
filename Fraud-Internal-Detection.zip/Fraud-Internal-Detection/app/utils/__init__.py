"""
Utility modules for the Medical Report Analyzer
"""
