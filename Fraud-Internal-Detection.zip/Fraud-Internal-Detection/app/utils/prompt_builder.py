"""
Prompt Builder - Constructs dynamic prompts with few-shot examples.
Manages prompt templates and example selection for LLM reasoning.
"""

import yaml
import logging
from typing import Dict, Any, List
from pathlib import Path
from feedback.feedback_store import FeedbackStore

logger = logging.getLogger(__name__)


class PromptBuilder:
    """
    Builds dynamic prompts for LLM reasoning.
    
    Features:
    - Load templates from YAML
    - Inject few-shot examples from feedback store
    - Format case data for LLM
    - Track which examples are used
    """
    
    def __init__(
        self,
        config_path: str = "app/config/llm_config_fixed.yaml",
        feedback_store: FeedbackStore = None
    ):
        """
        Initialize prompt builder.
        
        Args:
            config_path: Path to LLM configuration YAML
            feedback_store: Feedback store instance
        """
        
        self.config_path = Path(config_path)
        self.feedback_store = feedback_store or FeedbackStore()
        
        # Load configuration
        self.config = self._load_config()
        self.templates = self.config.get('prompts', {})
        self.example_selection = self.config.get('feedback', {}).get('example_selection', {})
        
        logger.info(f"Prompt builder initialized with config: {config_path}")
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from YAML."""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.error(f"Failed to load config from {self.config_path}: {e}")
            return {}
    
    def build_prompt(
        self,
        current_case: Dict[str, Any],
        agent_results: Dict[str, Any],
        rule_score: int
    ) -> str:
        """
        Build complete prompt with few-shot examples.
        
        Args:
            current_case: Payment data and evidence
            agent_results: Results from rule-based agents
            rule_score: Total rule-based score (0-6)
        
        Returns:
            Complete formatted prompt
        """
        
        # Step 1: Get few-shot examples from feedback store
        examples = self._get_few_shot_examples()
        
        # Step 2: Format examples
        formatted_examples = self._format_examples(examples)
        
        # Step 3: Format current case
        case_details = self._format_current_case(current_case, agent_results, rule_score)
        
        # Step 4: Build final prompt from template
        template = self.templates.get('analysis_template', '')
        
        prompt = template.format(
            few_shot_examples=formatted_examples,
            **case_details
        )
        
        # Step 5: Update example usage
        for example in examples:
            self.feedback_store.update_example_usage(example['id'])
        
        logger.info(f"Built prompt with {len(examples)} examples ({len(prompt)} chars)")
        
        return prompt
    
    def _get_few_shot_examples(self) -> List[Dict[str, Any]]:
        """Get best examples from feedback store."""
        
        max_examples = self.example_selection.get('max_examples', 5)
        min_reward = self.example_selection.get('min_reward_threshold', 50)
        include_failures = self.example_selection.get('include_failure_examples', 1)
        
        examples = self.feedback_store.get_best_examples(
            max_examples=max_examples,
            min_reward=min_reward,
            include_failures=include_failures
        )
        
        return examples
    
    def _format_examples(self, examples: List[Dict[str, Any]]) -> str:
        """Format examples using template."""
        
        if not examples:
            return "(No historical cases available yet - system is learning)"
        
        example_template = self.templates.get('example_template', '')
        formatted = []
        
        for idx, example in enumerate(examples, 1):
            # Determine outcome label
            if example.get('reward_score', 0) > 0:
                outcome = "Confirmed Fraud ✅"
            else:
                outcome = "False Positive ❌"
            
            # Format example
            example_text = example_template.format(
                example_number=idx,
                outcome=outcome,
                reward=example.get('reward_score', 0),
                pattern_type=example.get('pattern_type', 'Unknown'),
                case_summary=example.get('case_summary', ''),
                rule_score=example.get('rule_score', 'N/A'),
                rule_decision=example.get('rule_decision', 'N/A'),
                llm_risk=example.get('llm_risk', 'N/A'),
                llm_confidence=example.get('llm_confidence', 0.0),
                final_decision=example.get('final_decision', 'N/A'),
                actual_outcome=example.get('actual_outcome', 'N/A'),
                lesson_learned=example.get('lesson_learned', ''),
                investigator_notes=example.get('investigator_notes', 'No notes available')
            )
            
            formatted.append(example_text)
        
        return "\n\n".join(formatted)
    
    def _format_current_case(
        self,
        current_case: Dict[str, Any],
        agent_results: Dict[str, Any],
        rule_score: int
    ) -> Dict[str, str]:
        """
        Format current case data for prompt using COMPLIANCE-SAFE fields.
        
        NO PII/SENSITIVE DATA is included:
        - No claim_id, payment_id, employee_id, bank_account_hash, or amount
        - Only derived metrics and aggregated patterns
        """
        
        # Extract agent results
        employee_result = agent_results.get('employee_control', {})
        lastmile_result = agent_results.get('lastmile_payment', {})
        graph_result = agent_results.get('graph_entity', {})
        
        # Determine rule-based decision
        if rule_score <= 1:
            rule_decision = "ALLOW"
        elif rule_score <= 3:
            rule_decision = "WARN"
        else:
            rule_decision = "BLOCK"
        
        # Get compliance-safe derived metrics from current_case
        # These must be provided by the caller (see API updates)
        transaction_reference = current_case.get('transaction_reference', 'REF-001')
        employee_pattern = current_case.get('employee_pattern', 'SINGLE_EMPLOYEE')
        account_pattern = current_case.get('account_pattern', 'FIRST_USE')
        amount_category = current_case.get('amount_category', 'MEDIUM')
        workflow_separation = current_case.get('workflow_separation', 'PROPER')
        
        # Count and timing (aggregated, not specific timestamps)
        actions_count = len(current_case.get('session_actions', []))
        time_window_mins = current_case.get('time_window_mins', 0)
        
        return {
            # COMPLIANCE-SAFE: Reference only (no real IDs)
            'transaction_reference': transaction_reference,
            
            # COMPLIANCE-SAFE: Derived pattern indicators
            'employee_pattern': employee_pattern,  # e.g., "SINGLE_EMPLOYEE", "PROPER_SEPARATION", "CONCENTRATION"
            'account_pattern': account_pattern,    # e.g., "FIRST_USE", "ESTABLISHED", "REUSED_ACROSS_CLAIMS"
            'amount_category': amount_category,    # e.g., "SMALL", "MEDIUM", "LARGE", "STRUCTURING_THRESHOLD"
            'workflow_separation': workflow_separation,  # e.g., "PROPER", "SAME_EMPLOYEE_ALL_STEPS", "PARTIAL"
            
            # COMPLIANCE-SAFE: Aggregated counts and timing
            'actions_count': actions_count,
            'time_window_mins': time_window_mins,
            
            # Employee Control Agent
            'employee_risk': employee_result.get('control_risk', 'LOW'),
            'employee_score': self._get_score(employee_result.get('control_risk', 'LOW')),
            'employee_reasons': ', '.join(employee_result.get('reasons', ['None'])),
            
            # Last-Mile Payment Agent
            'lastmile_risk': lastmile_result.get('last_mile_risk', 'LOW'),
            'lastmile_score': self._get_score(lastmile_result.get('last_mile_risk', 'LOW')),
            'lastmile_reasons': ', '.join(lastmile_result.get('reasons', ['None'])),
            
            # Graph Entity Agent
            'graph_risk': graph_result.get('entity_risk', 'LOW'),
            'graph_score': self._get_score(graph_result.get('entity_risk', 'LOW')),
            'graph_reasons': ', '.join(graph_result.get('reasons', ['None'])),
            
            # Totals
            'total_rule_score': rule_score,
            'rule_decision': rule_decision,
            
            # Additional context (compliance-safe)
            'additional_context': self._format_additional_context(current_case)
        }
    
    def _get_score(self, risk_level: str) -> int:
        """Map risk level to score."""
        return {'LOW': 0, 'MED': 1, 'HIGH': 2}.get(risk_level, 0)
    
    def _format_additional_context(self, current_case: Dict[str, Any]) -> str:
        """
        Format additional context information using COMPLIANCE-SAFE fields only.
        No PII or sensitive identifiers included.
        """
        
        context_items = []
        
        # Payment method (non-sensitive)
        payment_method = current_case.get('payment_method')
        if payment_method:
            context_items.append(f"- Payment Method: {payment_method}")
        
        # Account status (pattern, not specific account)
        account_pattern = current_case.get('account_pattern', '')
        if 'FIRST_USE' in account_pattern or 'NEW' in account_pattern:
            context_items.append("- Bank Account Pattern: NEW (no transaction history)")
        elif 'REUSED' in account_pattern:
            context_items.append("- Bank Account Pattern: REUSED across multiple claims")
        elif 'ESTABLISHED' in account_pattern:
            context_items.append("- Bank Account Pattern: ESTABLISHED with history")
        
        # Payee changes (behavioral indicator)
        payee_changed = current_case.get('payee_changed_after_approval', False)
        if payee_changed:
            context_items.append("- Payee changed AFTER claim approval")
        
        # Verification status (compliance indicator)
        verification_flag = current_case.get('verification_flag', False)
        if verification_flag:
            context_items.append("- Customer verification: COMPLETED")
        
        # Claim status (workflow state, non-sensitive)
        claim_status = current_case.get('claim_status')
        if claim_status:
            context_items.append(f"- Claim Status: {claim_status}")
        
        return "\n".join(context_items) if context_items else "No additional context available"
