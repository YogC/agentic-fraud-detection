"""
Performance and Cost Monitoring Module
Tracks API performance, decision metrics, and system costs for PEP.
Provides Prometheus-compatible metrics for observability.
"""

import os
from datetime import datetime, timezone
from typing import Dict, Any, Optional
from pathlib import Path
from prometheus_client import Counter, Histogram, Gauge, Info
import time
import json


def get_project_root() -> Path:
    """Get the project root directory (Fraud-Internal-Detection/)."""
    # This file is in: Fraud-Internal-Detection/app/utils/monitoring.py
    # So go up 2 levels to get to project root
    current_file = Path(__file__).resolve()
    project_root = current_file.parent.parent.parent
    return project_root


# ============================================================================
# Prometheus Metrics
# ============================================================================

# API Request Metrics
api_requests_total = Counter(
    'pep_api_requests_total',
    'Total number of API requests',
    ['endpoint', 'method', 'status']
)

api_request_duration_seconds = Histogram(
    'pep_api_request_duration_seconds',
    'API request duration in seconds',
    ['endpoint', 'method']
)

# PEP Decision Metrics
pep_decisions_total = Counter(
    'pep_decisions_total',
    'Total number of PEP decisions',
    ['decision']  # ALLOW, WARN, BLOCK
)

pep_decision_score_histogram = Histogram(
    'pep_decision_score',
    'Distribution of PEP decision scores',
    buckets=[0, 1, 2, 3, 4, 5, 6]
)

pep_decision_duration_seconds = Histogram(
    'pep_decision_duration_seconds',
    'Time taken for PEP decision',
    ['decision']
)

# Agent Performance Metrics
agent_execution_duration_seconds = Histogram(
    'pep_agent_execution_duration_seconds',
    'Agent execution time in seconds',
    ['agent_name']
)

agent_risk_level_total = Counter(
    'pep_agent_risk_level_total',
    'Agent risk level counts',
    ['agent_name', 'risk_level']  # LOW, MED, HIGH
)

# System Health Metrics
active_requests = Gauge(
    'pep_active_requests',
    'Number of requests currently being processed'
)

system_errors_total = Counter(
    'pep_system_errors_total',
    'Total number of system errors',
    ['error_type']
)

# Fraud Detection Metrics
fraud_patterns_detected_total = Counter(
    'pep_fraud_patterns_detected_total',
    'Number of fraud patterns detected',
    ['pattern_type']
)

# System Info
system_info = Info(
    'pep_system',
    'PEP system information'
)

# Initialize system info
system_info.info({
    'version': '2.0.0',
    'architecture': 'Policy Enforcement Point (PEP)',
    'agents': 'employee_control,lastmile_payment,graph_entity'
})


# ============================================================================
# Monitoring Classes
# ============================================================================

class PerformanceMonitor:
    """Monitor and track performance metrics."""
    
    def __init__(self, metrics_dir: str = "./logs/metrics"):
        self.request_times: Dict[str, float] = {}
        self.agent_times: Dict[str, list] = {}
        self.decision_counts: Dict[str, int] = {"ALLOW": 0, "WARN": 0, "BLOCK": 0}
        self.fraud_pattern_counts: Dict[str, int] = {}
        self.total_decisions = 0
        
        # Use absolute path based on project root
        project_root = get_project_root()
        if metrics_dir.startswith("./"):
            metrics_dir = metrics_dir[2:]  # Remove "./" prefix
        self.metrics_dir = project_root / metrics_dir
        self.metrics_dir.mkdir(parents=True, exist_ok=True)
        
        print(f"[PerformanceMonitor] Initialized with metrics directory: {self.metrics_dir}")
    
    def start_request(self, request_id: str) -> None:
        """Start timing a request."""
        self.request_times[request_id] = time.time()
        active_requests.inc()
    
    def end_request(
        self,
        request_id: str,
        endpoint: str,
        method: str,
        status_code: int
    ) -> float:
        """
        End timing a request and record metrics.
        
        Returns:
            float: Request duration in seconds
        """
        if request_id not in self.request_times:
            return 0.0
        
        duration = time.time() - self.request_times[request_id]
        del self.request_times[request_id]
        
        # Record metrics
        api_requests_total.labels(
            endpoint=endpoint,
            method=method,
            status=str(status_code)
        ).inc()
        
        api_request_duration_seconds.labels(
            endpoint=endpoint,
            method=method
        ).observe(duration)
        
        active_requests.dec()
        
        return duration
    
    def record_pep_decision(
        self,
        decision: str,
        score: int,
        duration_seconds: float
    ) -> None:
        """
        Record PEP decision metrics.
        
        Args:
            decision: ALLOW, WARN, or BLOCK
            score: Total risk score (0-6)
            duration_seconds: Time taken for decision
        """
        # Increment decision counter
        pep_decisions_total.labels(decision=decision).inc()
        self.decision_counts[decision] += 1
        self.total_decisions += 1
        
        # Record score distribution
        pep_decision_score_histogram.observe(score)
        
        # Record decision duration
        pep_decision_duration_seconds.labels(decision=decision).observe(duration_seconds)
        
        # TESTING MODE: Write metrics after EVERY decision (no threshold)
        # For production, change to: if self.total_decisions % 10 == 0
        self.write_metrics_summary()
    
    def record_agent_execution(
        self,
        agent_name: str,
        risk_level: str,
        duration_seconds: float
    ) -> None:
        """
        Record agent execution metrics.
        
        Args:
            agent_name: Name of agent
            risk_level: LOW, MED, or HIGH
            duration_seconds: Execution time
        """
        # Record execution time
        agent_execution_duration_seconds.labels(agent_name=agent_name).observe(duration_seconds)
        
        # Record risk level
        agent_risk_level_total.labels(
            agent_name=agent_name,
            risk_level=risk_level
        ).inc()
        
        # Track agent times for stats
        if agent_name not in self.agent_times:
            self.agent_times[agent_name] = []
        self.agent_times[agent_name].append(duration_seconds)
    
    def record_fraud_pattern(self, pattern_type: str) -> None:
        """
        Record detected fraud pattern.
        
        Args:
            pattern_type: Type of fraud pattern detected
        """
        fraud_patterns_detected_total.labels(pattern_type=pattern_type).inc()
        
        # Track for metrics summary
        if pattern_type not in self.fraud_pattern_counts:
            self.fraud_pattern_counts[pattern_type] = 0
        self.fraud_pattern_counts[pattern_type] += 1
    
    def record_error(self, error_type: str) -> None:
        """
        Record system error.
        
        Args:
            error_type: Type of error
        """
        system_errors_total.labels(error_type=error_type).inc()
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get current performance statistics.
        
        Returns:
            Dictionary of performance stats
        """
        stats = {
            "decision_counts": self.decision_counts.copy(),
            "agent_performance": {},
            "active_requests": len(self.request_times),
            "fraud_patterns": self.fraud_pattern_counts.copy(),
            "total_decisions": self.total_decisions
        }
        
        # Calculate agent stats
        for agent_name, times in self.agent_times.items():
            if times:
                stats["agent_performance"][agent_name] = {
                    "avg_time_ms": sum(times) / len(times) * 1000,
                    "min_time_ms": min(times) * 1000,
                    "max_time_ms": max(times) * 1000,
                    "total_executions": len(times)
                }
        
        return stats
    
    def write_metrics_summary(self) -> None:
        """
        Write metrics summary to file.
        Creates human-readable text format only.
        """
        import logging
        logger = logging.getLogger(__name__)
        
        timestamp = datetime.now(timezone.utc)
        date_str = timestamp.strftime("%Y-%m-%d")
        
        # Get current stats
        stats = self.get_stats()
        
        # Write human-readable format only
        txt_file = self.metrics_dir / f"metrics_{date_str}.txt"
        logger.info(f"📊 Writing metrics summary to: {txt_file} (Total decisions: {stats['total_decisions']})")
        with open(txt_file, "a", encoding="utf-8") as f:
            f.write("=" * 80 + "\n")
            f.write(f"📊 PERFORMANCE METRICS SUMMARY - {timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}\n")
            f.write("=" * 80 + "\n")
            f.write(f"Total Decisions: {stats['total_decisions']}\n")
            f.write(f"Active Requests: {stats['active_requests']}\n")
            f.write("\n--- DECISION DISTRIBUTION ---\n")
            for decision, count in stats['decision_counts'].items():
                percentage = (count / stats['total_decisions'] * 100) if stats['total_decisions'] > 0 else 0
                f.write(f"  {decision:6s}: {count:4d} ({percentage:5.1f}%)\n")
            f.write("\n--- AGENT PERFORMANCE ---\n")
            for agent, perf in stats['agent_performance'].items():
                f.write(f"  {agent}:\n")
                f.write(f"    Avg Time: {perf['avg_time_ms']:.2f} ms\n")
                f.write(f"    Min Time: {perf['min_time_ms']:.2f} ms\n")
                f.write(f"    Max Time: {perf['max_time_ms']:.2f} ms\n")
                f.write(f"    Executions: {perf['total_executions']}\n")
            if stats['fraud_patterns']:
                f.write("\n--- FRAUD PATTERNS DETECTED ---\n")
                for pattern, count in stats['fraud_patterns'].items():
                    f.write(f"  {pattern}: {count}\n")
            
            # Include JSON representation of stats for reference
            f.write("\n--- DETAILED METRICS (JSON) ---\n")
            stats_with_timestamp = {
                "timestamp": timestamp.isoformat(),
                "event_type": "metrics_summary",
                **stats
            }
            f.write(json.dumps(stats_with_timestamp, indent=2, default=str) + "\n")
            f.write("=" * 80 + "\n\n")


class CostMonitor:
    """
    Monitor and track operational costs.
    Note: This system uses deterministic logic (no LLM calls), so costs are minimal.
    Tracks compute time and potential cloud resource usage.
    """
    
    def __init__(self):
        self.total_requests = 0
        self.total_compute_time_seconds = 0.0
        self.estimated_cost_usd = 0.0
        
        # Cost assumptions (conservative estimates)
        self.cost_per_request = 0.0001  # $0.0001 per request (API Gateway + Lambda/Fargate)
        self.cost_per_compute_hour = 0.05  # $0.05 per hour of compute
    
    def record_request(self, compute_time_seconds: float) -> None:
        """
        Record request cost.
        
        Args:
            compute_time_seconds: Time spent processing request
        """
        self.total_requests += 1
        self.total_compute_time_seconds += compute_time_seconds
        
        # Calculate estimated cost
        request_cost = self.cost_per_request
        compute_cost = (compute_time_seconds / 3600) * self.cost_per_compute_hour
        self.estimated_cost_usd += request_cost + compute_cost
    
    def get_cost_summary(self) -> Dict[str, Any]:
        """
        Get cost summary.
        
        Returns:
            Dictionary of cost metrics
        """
        return {
            "total_requests": self.total_requests,
            "total_compute_time_seconds": round(self.total_compute_time_seconds, 2),
            "total_compute_time_hours": round(self.total_compute_time_seconds / 3600, 4),
            "estimated_cost_usd": round(self.estimated_cost_usd, 4),
            "avg_cost_per_request_usd": round(
                self.estimated_cost_usd / self.total_requests if self.total_requests > 0 else 0,
                6
            ),
            "note": "Costs are estimates based on compute time only. No LLM API costs."
        }


# ============================================================================
# Global Instances
# ============================================================================

_performance_monitor = None
_cost_monitor = None


def get_performance_monitor() -> PerformanceMonitor:
    """Get global performance monitor instance."""
    global _performance_monitor
    if _performance_monitor is None:
        _performance_monitor = PerformanceMonitor()
    return _performance_monitor


def get_cost_monitor() -> CostMonitor:
    """Get global cost monitor instance."""
    global _cost_monitor
    if _cost_monitor is None:
        _cost_monitor = CostMonitor()
    return _cost_monitor
