"""
Audit Trail Logging Module
Provides comprehensive audit logging for PEP (Policy Enforcement Point) decisions.
Ensures compliance and traceability for banking/insurance fraud detection.
"""

import json
import os
import structlog
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional
from enum import Enum


def get_project_root() -> Path:
    """Get the project root directory (Fraud-Internal-Detection/)."""
    # This file is in: Fraud-Internal-Detection/app/utils/audit_logger.py
    # So go up 2 levels to get to project root
    current_file = Path(__file__).resolve()
    project_root = current_file.parent.parent.parent
    return project_root


class AuditEventType(Enum):
    """Types of audit events."""
    PEP_DECISION = "pep_decision"
    AGENT_ANALYSIS = "agent_analysis"
    POLICY_ENFORCEMENT = "policy_enforcement"
    SYSTEM_ERROR = "system_error"
    API_REQUEST = "api_request"
    API_RESPONSE = "api_response"


class AuditLogger:
    """
    Audit logger for PEP system.
    Logs all policy enforcement decisions with full traceability.
    """
    
    def __init__(self, log_dir: str = "./logs/audit"):
        """
        Initialize audit logger.
        
        Args:
            log_dir: Directory for audit log files (relative to project root)
        """
        # Use absolute path based on project root
        project_root = get_project_root()
        if log_dir.startswith("./"):
            log_dir = log_dir[2:]  # Remove "./" prefix
        self.log_dir = project_root / log_dir
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        print(f"[AuditLogger] Initialized with log directory: {self.log_dir}")
        
        # We'll write human-readable TXT logs directly
        # No need for structlog JSON output
    
    def _get_audit_file(self):
        """Get current audit log file path."""
        date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        audit_file = self.log_dir / f"audit_{date_str}.txt"
        return audit_file
    
    def _write_audit_entry(self, content: str) -> None:
        """Write audit entry to file."""
        audit_file = self._get_audit_file()
        with open(audit_file, "a", encoding="utf-8") as f:
            f.write(content)
    
    def log_pep_decision(
        self,
        claim_id: str,
        payment_id: str,
        decision: str,
        total_score: int,
        agent_results: Dict[str, Any],
        actor_id: str,
        actor_role: str,
        reasons: list,
        evidence: Dict[str, Any],
        request_data: Optional[Dict[str, Any]] = None,
        decision_tree: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Log PEP policy enforcement decision.
        
        Args:
            claim_id: Claim identifier
            payment_id: Payment identifier
            decision: ALLOW, WARN, or BLOCK
            total_score: Total risk score
            agent_results: Results from all agents
            actor_id: ID of user/system making request
            actor_role: Role of actor
            reasons: List of reasons for decision
            evidence: Supporting evidence
            request_data: Full request payload (optional)
            decision_tree: Structured decision tree for explainability (optional)
        """
        timestamp = datetime.now(timezone.utc).isoformat()
        
        content = "=" * 80 + "\n"
        content += f"🔍 PEP POLICY DECISION - {timestamp}\n"
        content += "=" * 80 + "\n"
        content += f"Event Type: PEP Decision\n"
        content += f"Claim ID: {claim_id}\n"
        content += f"Payment ID: {payment_id}\n"
        content += f"Decision: {decision}\n"
        content += f"Total Score: {total_score}\n"
        content += f"Actor ID: {actor_id}\n"
        content += f"Actor Role: {actor_role}\n"
        content += "\n--- REASONS ---\n"
        for reason in reasons:
            content += f"  • {reason}\n"
        content += "\n--- AGENT RESULTS ---\n"
        content += json.dumps(agent_results, indent=2, default=str) + "\n"
        content += "\n--- EVIDENCE ---\n"
        content += json.dumps(evidence, indent=2, default=str) + "\n"
        if decision_tree:
            content += "\n--- DECISION TREE (EXPLAINABILITY) ---\n"
            # Include key parts of decision tree for audit trail
            if 'decision_logic' in decision_tree:
                content += "Decision Logic:\n"
                content += json.dumps(decision_tree['decision_logic'], indent=2, default=str) + "\n"
            if 'explainability' in decision_tree:
                content += "\nExplainability Summary:\n"
                content += json.dumps(decision_tree['explainability'], indent=2, default=str) + "\n"
        if request_data:
            content += "\n--- REQUEST DATA ---\n"
            content += json.dumps(request_data, indent=2, default=str) + "\n"
        content += "=" * 80 + "\n\n"
        
        self._write_audit_entry(content)
    
    def log_agent_analysis(
        self,
        agent_name: str,
        claim_id: str,
        risk_level: str,
        score: int,
        reasons: list,
        evidence: Dict[str, Any],
        execution_time_ms: float
    ) -> None:
        """
        Log individual agent analysis.
        
        Args:
            agent_name: Name of agent
            claim_id: Claim identifier
            risk_level: LOW, MED, or HIGH
            score: Risk score (0-2)
            reasons: List of reasons
            evidence: Supporting evidence
            execution_time_ms: Time taken for analysis
        """
        timestamp = datetime.now(timezone.utc).isoformat()
        
        content = "=" * 80 + "\n"
        content += f"🤖 AGENT ANALYSIS - {timestamp}\n"
        content += "=" * 80 + "\n"
        content += f"Event Type: Agent Analysis\n"
        content += f"Agent: {agent_name}\n"
        content += f"Claim ID: {claim_id}\n"
        content += f"Risk Level: {risk_level}\n"
        content += f"Score: {score}\n"
        content += f"Execution Time: {execution_time_ms:.2f} ms\n"
        content += "\n--- REASONS ---\n"
        for reason in reasons:
            content += f"  • {reason}\n"
        content += "\n--- EVIDENCE ---\n"
        content += json.dumps(evidence, indent=2, default=str) + "\n"
        content += "=" * 80 + "\n\n"
        
        self._write_audit_entry(content)
    
    def log_api_request(
        self,
        endpoint: str,
        method: str,
        claim_id: Optional[str] = None,
        source_ip: Optional[str] = None,
        user_agent: Optional[str] = None
    ) -> None:
        """
        Log API request.
        
        Args:
            endpoint: API endpoint
            method: HTTP method
            claim_id: Claim ID if available
            source_ip: Source IP address
            user_agent: User agent string
        """
        timestamp = datetime.now(timezone.utc).isoformat()
        
        content = "=" * 80 + "\n"
        content += f"📥 API REQUEST - {timestamp}\n"
        content += "=" * 80 + "\n"
        content += f"Event Type: API Request\n"
        content += f"Endpoint: {endpoint}\n"
        content += f"Method: {method}\n"
        if claim_id:
            content += f"Claim ID: {claim_id}\n"
        if source_ip:
            content += f"Source IP: {source_ip}\n"
        if user_agent:
            content += f"User Agent: {user_agent}\n"
        content += "=" * 80 + "\n\n"
        
        self._write_audit_entry(content)
    
    def log_api_response(
        self,
        endpoint: str,
        status_code: int,
        claim_id: Optional[str] = None,
        execution_time_ms: float = 0,
        decision: Optional[str] = None
    ) -> None:
        """
        Log API response.
        
        Args:
            endpoint: API endpoint
            status_code: HTTP status code
            claim_id: Claim ID if available
            execution_time_ms: Total execution time
            decision: PEP decision if applicable
        """
        timestamp = datetime.now(timezone.utc).isoformat()
        
        content = "=" * 80 + "\n"
        content += f"📤 API RESPONSE - {timestamp}\n"
        content += "=" * 80 + "\n"
        content += f"Event Type: API Response\n"
        content += f"Endpoint: {endpoint}\n"
        content += f"Status Code: {status_code}\n"
        if claim_id:
            content += f"Claim ID: {claim_id}\n"
        content += f"Execution Time: {execution_time_ms:.2f} ms\n"
        if decision:
            content += f"Decision: {decision}\n"
        content += "=" * 80 + "\n\n"
        
        self._write_audit_entry(content)
    
    def log_error(
        self,
        error_type: str,
        error_message: str,
        claim_id: Optional[str] = None,
        stack_trace: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Log system error.
        
        Args:
            error_type: Type of error
            error_message: Error message
            claim_id: Claim ID if available
            stack_trace: Stack trace
            context: Additional context
        """
        timestamp = datetime.now(timezone.utc).isoformat()
        
        content = "=" * 80 + "\n"
        content += f"❌ SYSTEM ERROR - {timestamp}\n"
        content += "=" * 80 + "\n"
        content += f"Event Type: System Error\n"
        content += f"Error Type: {error_type}\n"
        content += f"Error Message: {error_message}\n"
        if claim_id:
            content += f"Claim ID: {claim_id}\n"
        if stack_trace:
            content += "\n--- STACK TRACE ---\n"
            content += stack_trace + "\n"
        if context:
            content += "\n--- CONTEXT ---\n"
            content += json.dumps(context, indent=2, default=str) + "\n"
        content += "=" * 80 + "\n\n"
        
        self._write_audit_entry(content)
    
    def log_policy_enforcement(
        self,
        claim_id: str,
        payment_id: str,
        decision: str,
        enforced_action: str,
        actor_id: str
    ) -> None:
        """
        Log policy enforcement action taken.
        
        Args:
            claim_id: Claim identifier
            payment_id: Payment identifier
            decision: ALLOW, WARN, or BLOCK
            enforced_action: Actual action taken (e.g., "payment_released", "payment_held", "payment_blocked")
            actor_id: ID of actor
        """
        timestamp = datetime.now(timezone.utc).isoformat()
        
        content = "=" * 80 + "\n"
        content += f"⚖️ POLICY ENFORCEMENT - {timestamp}\n"
        content += "=" * 80 + "\n"
        content += f"Event Type: Policy Enforcement\n"
        content += f"Claim ID: {claim_id}\n"
        content += f"Payment ID: {payment_id}\n"
        content += f"Decision: {decision}\n"
        content += f"Enforced Action: {enforced_action}\n"
        content += f"Actor ID: {actor_id}\n"
        content += "=" * 80 + "\n\n"
        
        self._write_audit_entry(content)
    
    def log_sanitization_audit(
        self,
        claim_id: str,
        payment_id: str,
        fields_excluded: list,
        fields_included: list,
        pii_pci_excluded: bool,
        sanitized_data: Dict[str, Any]
    ) -> None:
        """
        Log data sanitization for compliance audit trail.
        
        This log proves that PII/PCI data was NOT sent to LLM/external systems.
        Critical for regulatory compliance (PCI-DSS, GDPR, etc.)
        
        Args:
            claim_id: Claim identifier
            payment_id: Payment identifier
            fields_excluded: List of sensitive fields excluded (PII/PCI)
            fields_included: List of safe fields included
            pii_pci_excluded: Whether PII/PCI data was successfully excluded
            sanitized_data: The actual sanitized data sent to LLM
        """
        # Log to sanitization-specific file
        date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        sanitization_file = self.log_dir.parent / "sanitization" / f"sanitization_{date_str}.txt"
        sanitization_file.parent.mkdir(parents=True, exist_ok=True)
        
        timestamp = datetime.now(timezone.utc).isoformat()
        
        # Write human-readable format only
        with open(sanitization_file, "a", encoding="utf-8") as f:
            f.write("=" * 80 + "\n")
            f.write(f"🔒 DATA SANITIZATION AUDIT - {timestamp}\n")
            f.write("=" * 80 + "\n")
            f.write(f"Claim ID: {claim_id}\n")
            f.write(f"Payment ID: {payment_id}\n")
            f.write(f"PII/PCI Excluded: {'✅ YES' if pii_pci_excluded else '❌ NO (VIOLATION!)'}\n")
            f.write(f"\n--- EXCLUDED FIELDS (PII/PCI Protected) ---\n")
            for field in fields_excluded:
                f.write(f"  ❌ {field}\n")
            f.write(f"\n--- INCLUDED FIELDS (Fraud Detection Context) ---\n")
            for field in fields_included:
                f.write(f"  ✅ {field}\n")
            f.write(f"\n--- SANITIZED DATA SENT TO LLM ---\n")
            f.write(json.dumps(sanitized_data, indent=2, default=str) + "\n")
            f.write("=" * 80 + "\n\n")


# Global audit logger instance
_audit_logger = None


def get_audit_logger() -> AuditLogger:
    """Get global audit logger instance."""
    global _audit_logger
    if _audit_logger is None:
        _audit_logger = AuditLogger()
    return _audit_logger
