"""
Reward System for LLM Context Learning
Processes investigator feedback and updates prompt examples based on outcomes.
"""

import json
import logging
from typing import Dict, Any, Optional
from datetime import datetime
from pathlib import Path
import yaml

logger = logging.getLogger(__name__)


def calculate_reward_score(llm_decision: str, actual_outcome: str) -> int:
    """
    Standalone function to calculate reward score based on LLM decision vs actual outcome.
    
    This is a simplified version for quick calculations without instantiating RewardSystem.
    
    Args:
        llm_decision: LLM's decision (BLOCK, WARN, ALLOW, INVESTIGATE)
        actual_outcome: Actual outcome (CONFIRMED_FRAUD, CONFIRMED_LEGITIMATE, FALSE_POSITIVE, etc.)
    
    Returns:
        Reward score:
            +100: LLM correctly identified fraud (BLOCK → CONFIRMED_FRAUD)
            +50:  LLM correctly identified legitimate (ALLOW → CONFIRMED_LEGITIMATE)
            -100: LLM missed fraud (ALLOW → CONFIRMED_FRAUD) - FALSE NEGATIVE
            -50:  LLM false positive (BLOCK → CONFIRMED_LEGITIMATE)
            0:    Uncertain/escalated cases
    """
    # Normalize inputs
    decision = llm_decision.upper().strip()
    outcome = actual_outcome.upper().strip()
    
    # Perfect fraud detection
    if decision in ['BLOCK'] and outcome in ['CONFIRMED_FRAUD', 'FRAUD']:
        return 100  # Best case: caught real fraud
    
    # Perfect legitimate detection
    if decision in ['ALLOW'] and outcome in ['CONFIRMED_LEGITIMATE', 'LEGITIMATE']:
        return 50   # Good: correctly allowed legitimate
    
    # False negative (most critical error)
    if decision in ['ALLOW'] and outcome in ['CONFIRMED_FRAUD', 'FRAUD']:
        return -100  # Worst case: missed fraud
    
    # False positive (costly but less critical)
    if decision in ['BLOCK'] and outcome in ['CONFIRMED_LEGITIMATE', 'LEGITIMATE', 'FALSE_POSITIVE']:
        return -50   # Bad: blocked legitimate transaction
    
    # WARN/INVESTIGATE cases
    if decision in ['WARN', 'INVESTIGATE']:
        if outcome in ['CONFIRMED_FRAUD', 'FRAUD']:
            return 40   # Good: warned about real fraud
        elif outcome in ['CONFIRMED_LEGITIMATE', 'LEGITIMATE']:
            return -30  # Overly cautious but not critical
    
    # Unknown/escalated cases
    return 0


class RewardSystem:
    """
    Processes feedback from investigators and calculates rewards.
    Updates prompt examples based on fraud detection outcomes.
    
    This enables "prompt-based learning" - the system improves by adding
    successful (and failed) cases as few-shot examples in future prompts.
    """
    
    def __init__(self, config_path: str = "config/llm_config_fixed.yaml"):
        """
        Initialize reward system.
        
        Args:
            config_path: Path to LLM configuration file
        """
        self.config = self._load_config(config_path)
        self.reward_matrix = self._build_reward_matrix()
        
        logger.info("Reward system initialized")
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration from YAML file."""
        try:
            config_file = Path(__file__).parent.parent / config_path
            if not config_file.exists():
                logger.warning(f"Config file not found: {config_file}. Using defaults.")
                return self._default_config()
                
            with open(config_file, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
                if config is None:
                    logger.warning(f"Config file is empty: {config_file}. Using defaults.")
                    return self._default_config()
                return config
        except Exception as e:
            logger.warning(f"Could not load config from {config_path}: {e}. Using defaults.")
            return self._default_config()
    
    def _default_config(self) -> Dict[str, Any]:
        """Default configuration if YAML not available."""
        return {
            'reward': {
                'matrix': {
                    'BLOCK_CONFIRMED_FRAUD': 100,
                    'BLOCK_FALSE_POSITIVE': -50,
                    'WARN_CONFIRMED_FRAUD': -100,
                    'WARN_CONFIRMED_LEGITIMATE': 10,
                    'ALLOW_CONFIRMED_FRAUD': -200,
                    'ALLOW_CONFIRMED_LEGITIMATE': 10
                },
                'auto_add_to_prompts_threshold': 50
            }
        }
    
    def _build_reward_matrix(self) -> Dict[tuple, int]:
        """Build reward lookup matrix from config."""
        # Ensure config is not None
        if self.config is None:
            logger.warning("Config is None, using default config")
            self.config = self._default_config()
            
        config_matrix = self.config.get('reward', {}).get('matrix', {})
        
        # Build reward matrix
        # Note: INVESTIGATE is treated as an alias for WARN (both flag for review)
        matrix = {
            # BLOCK decisions (high confidence fraud)
            ('BLOCK', 'CONFIRMED_FRAUD'): config_matrix.get('BLOCK_CONFIRMED_FRAUD', 100),
            ('BLOCK', 'FALSE_POSITIVE'): config_matrix.get('BLOCK_FALSE_POSITIVE', -50),
            
            # WARN decisions (flagged for review)
            ('WARN', 'CONFIRMED_FRAUD'): config_matrix.get('WARN_CONFIRMED_FRAUD', 40),  # Good catch - warned about real fraud
            ('WARN', 'FALSE_POSITIVE'): config_matrix.get('WARN_FALSE_POSITIVE', -30),  # Warned unnecessarily
            ('WARN', 'LEGITIMATE'): config_matrix.get('WARN_LEGITIMATE', -30),  # Overly cautious - learn from this
            ('WARN', 'CONFIRMED_LEGITIMATE'): config_matrix.get('WARN_CONFIRMED_LEGITIMATE', -30),  # Same as above
            
            # ALLOW decisions (low risk, approved)
            ('ALLOW', 'CONFIRMED_FRAUD'): config_matrix.get('ALLOW_CONFIRMED_FRAUD', -200),
            ('ALLOW', 'CONFIRMED_LEGITIMATE'): config_matrix.get('ALLOW_CONFIRMED_LEGITIMATE', 10),
        }
        
        # Add INVESTIGATE as alias for WARN (same reward structure)
        for outcome in ['CONFIRMED_FRAUD', 'FALSE_POSITIVE', 'LEGITIMATE', 'CONFIRMED_LEGITIMATE']:
            if ('WARN', outcome) in matrix:
                matrix[('INVESTIGATE', outcome)] = matrix[('WARN', outcome)]
        
        return matrix
    
    def calculate_reward(
        self,
        decision: str,
        actual_outcome: str
    ) -> int:
        """
        Calculate reward based on decision vs actual outcome.
        
        Args:
            decision: Original decision (ALLOW/WARN/BLOCK/INVESTIGATE)
            actual_outcome: Actual fraud outcome (CONFIRMED_FRAUD, FALSE_POSITIVE, etc.)
        
        Returns:
            Reward score (positive = good, negative = bad)
        """
        # Normalize inputs
        decision = decision.upper()
        actual_outcome = actual_outcome.upper()
        
        logger.info(f"💰 [REWARD] Calculating reward: decision={decision}, outcome={actual_outcome}")
        
        # Map outcomes to simplified categories
        if actual_outcome in ['CONFIRMED_FRAUD', 'FRAUD']:
            outcome_category = 'CONFIRMED_FRAUD'
        elif actual_outcome in ['FALSE_POSITIVE']:
            outcome_category = 'FALSE_POSITIVE'
        elif actual_outcome in ['LEGITIMATE', 'CONFIRMED_LEGITIMATE']:
            # For LEGITIMATE outcomes, map based on decision type
            if decision in ['BLOCK']:
                outcome_category = 'FALSE_POSITIVE'  # BLOCK on legitimate = false positive
            elif decision in ['WARN', 'INVESTIGATE']:
                outcome_category = 'LEGITIMATE'  # WARN/INVESTIGATE on legitimate = overly cautious (learn from this)
            else:
                outcome_category = 'CONFIRMED_LEGITIMATE'  # ALLOW on legitimate = correct
        else:
            logger.warning(f"💰 [REWARD] Unknown outcome: {actual_outcome}. Using neutral reward.")
            return 0
        
        # Look up reward
        key = (decision, outcome_category)
        reward = self.reward_matrix.get(key, 0)
        
        logger.info(f"💰 [REWARD] Reward calculated: {reward} for key {key}")
        
        logger.info(f"Reward calculated: {decision} + {actual_outcome} = {reward}")
        
        return reward
    
    def should_add_to_prompts(self, reward: int) -> bool:
        """
        Determine if case should be added to prompt examples.
        
        Args:
            reward: Calculated reward score
        
        Returns:
            True if case should be included in prompts
        """
        threshold = self.config.get('reward', {}).get('auto_add_to_prompts_threshold', 50)
        
        # Add high-reward cases (good detections)
        if reward >= threshold:
            return True
        
        # Also add significant failures to learn from (lowered from -40 to -30 to capture WARN/INVESTIGATE false positives)
        if reward <= -30:
            return True
        
        return False
    
    def process_feedback(
        self,
        payment_id: str,
        decision: str,
        actual_outcome: str,
        investigator_notes: str,
        fraud_pattern: Optional[str] = None,
        additional_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Process investigator feedback and calculate reward.
        
        Args:
            payment_id: Payment identifier
            decision: Original decision (ALLOW/WARN/BLOCK)
            actual_outcome: Actual outcome (CONFIRMED_FRAUD, FALSE_POSITIVE, etc.)
            investigator_notes: Investigator's notes
            fraud_pattern: Type of fraud pattern (if confirmed)
            additional_data: Any additional context
        
        Returns:
            Feedback result with reward and metadata
        """
        try:
            # Calculate reward
            reward = self.calculate_reward(decision, actual_outcome)
            
            # Determine if should add to prompts
            add_to_prompts = self.should_add_to_prompts(reward)
            
            # Determine outcome category
            is_fraud = actual_outcome.upper() in ['CONFIRMED_FRAUD', 'FRAUD']
            is_correct_decision = (
                (decision == 'BLOCK' and is_fraud) or
                (decision == 'ALLOW' and not is_fraud) or
                (decision == 'WARN' and is_fraud)
            )
            
            # Build feedback result
            feedback_result = {
                'payment_id': payment_id,
                'decision': decision,
                'actual_outcome': actual_outcome,
                'reward': reward,
                'add_to_prompts': add_to_prompts,
                'fraud_pattern': fraud_pattern,
                'investigator_notes': investigator_notes,
                'is_fraud': is_fraud,
                'is_correct_decision': is_correct_decision,
                'processed_at': datetime.utcnow().isoformat() + 'Z',
                'additional_data': additional_data or {}
            }
            
            logger.info(
                f"Feedback processed for {payment_id}: reward={reward}, "
                f"add_to_prompts={add_to_prompts}, pattern={fraud_pattern}"
            )
            
            return feedback_result
            
        except Exception as e:
            logger.error(f"Error processing feedback for {payment_id}: {e}")
            raise
    
    def format_as_prompt_example(
        self,
        feedback_case: Dict[str, Any],
        example_number: int = 1
    ) -> str:
        """
        Format a feedback case as a few-shot example for prompts.
        
        Args:
            feedback_case: Feedback case data
            example_number: Example number in the prompt
        
        Returns:
            Formatted example text
        """
        reward = feedback_case.get('reward', 0)
        outcome_label = "Confirmed Fraud ✅" if feedback_case.get('is_fraud') else "False Positive / Legitimate ⚠️"
        result_label = "Correct" if feedback_case.get('is_correct_decision') else "Incorrect"
        
        # Extract data safely
        case_data = feedback_case.get('case_data', {})
        employee_id = case_data.get('employee_id', 'N/A')
        amount = case_data.get('amount', 0)
        account_hash = case_data.get('bank_account_hash', 'N/A')
        rule_score = case_data.get('rule_score', 0)
        llm_risk = case_data.get('llm_risk_level', 'N/A')
        llm_confidence = case_data.get('llm_confidence', 0)
        
        # Build processing details
        processing_details = case_data.get('processing_details', 'N/A')
        
        example_text = f"""--- EXAMPLE {example_number}: {outcome_label} (Reward: {reward:+d}) ---

Pattern Type: {feedback_case.get('fraud_pattern', 'unknown')}
Case Summary: {feedback_case.get('case_summary', 'N/A')}

Payment Details:
- Employee: {employee_id}
- Amount: ${amount}
- Account: {account_hash[:30]}...
- Processing: {processing_details}

Analysis:
- Rule-based Score: {rule_score}/6
- LLM Assessment: {llm_risk} risk (confidence: {llm_confidence})

Actual Outcome: {feedback_case.get('actual_outcome')}
Decision Made: {feedback_case.get('decision')} → {result_label}

KEY LESSON: {feedback_case.get('lesson_learned', 'N/A')}

Investigator Notes: "{feedback_case.get('investigator_notes', 'N/A')}"

---"""
        
        return example_text
    
    def generate_lesson_learned(
        self,
        feedback_case: Dict[str, Any]
    ) -> str:
        """
        Generate a lesson learned from the feedback case.
        
        Args:
            feedback_case: Feedback case data
        
        Returns:
            Lesson learned text
        """
        reward = feedback_case.get('reward', 0)
        decision = feedback_case.get('decision')
        actual_outcome = feedback_case.get('actual_outcome')
        fraud_pattern = feedback_case.get('fraud_pattern', 'this pattern')
        is_fraud = feedback_case.get('is_fraud', False)
        investigator_notes = feedback_case.get('investigator_notes', '')
        
        if reward > 0:
            # Successful detection
            if is_fraud:
                return f"The {fraud_pattern} pattern is high risk and requires blocking. {investigator_notes[:100]}"
            else:
                return f"This transaction was correctly identified as legitimate despite some risk signals. {investigator_notes[:100]}"
        else:
            # Failure case - learn from it
            if decision == 'ALLOW' and is_fraud:
                return f"CRITICAL: The {fraud_pattern} pattern was missed. This combination of signals should trigger blocking. {investigator_notes[:100]}"
            elif decision == 'BLOCK' and not is_fraud:
                return f"NOT all {fraud_pattern} patterns are fraud. Context matters: {investigator_notes[:100]}"
            elif decision == 'WARN' and is_fraud:
                return f"The {fraud_pattern} pattern should have been escalated to BLOCK, not just WARN. {investigator_notes[:100]}"
            else:
                return f"Review needed for {fraud_pattern} pattern classification. {investigator_notes[:100]}"
