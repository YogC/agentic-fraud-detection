"""
Feedback Store - File-based storage for feedback cases and prompt examples.
Manages the learning database using JSON files.
"""

import json
import os
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
from pathlib import Path
import shutil

logger = logging.getLogger(__name__)


class FeedbackStore:
    """
    File-based storage for feedback cases and prompt examples.
    
    Manages:
    - Feedback cases (investigator reports)
    - Prompt examples (formatted for LLM)
    - Pattern statistics
    - Backups
    """
    
    def __init__(
        self,
        feedback_cases_path: str = "app/data/feedback_cases.json",
        prompt_examples_path: str = "app/data/prompt_examples.json",
        statistics_path: str = "app/data/prompt_statistics.json",
        backup_enabled: bool = True
    ):
        """
        Initialize feedback store.
        
        Args:
            feedback_cases_path: Path to feedback cases JSON
            prompt_examples_path: Path to prompt examples JSON
            statistics_path: Path to statistics JSON
            backup_enabled: Enable automatic backups
        """
        
        self.feedback_cases_path = Path(feedback_cases_path)
        self.prompt_examples_path = Path(prompt_examples_path)
        self.statistics_path = Path(statistics_path)
        self.backup_enabled = backup_enabled
        
        # Ensure directories exist
        self.feedback_cases_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Initialize files if they don't exist
        self._initialize_storage()
        
        logger.info(f"Feedback store initialized at {self.feedback_cases_path.parent}")
    
    def _initialize_storage(self):
        """Initialize storage files with empty structures."""
        
        # Initialize feedback cases
        if not self.feedback_cases_path.exists():
            self._save_json(self.feedback_cases_path, {
                'success_examples': [],
                'failure_examples': [],
                'total_cases': 0,
                'last_updated': datetime.utcnow().isoformat() + 'Z'
            })
            logger.info("Initialized feedback_cases.json")
        
        # Initialize prompt examples
        if not self.prompt_examples_path.exists():
            self._save_json(self.prompt_examples_path, {
                'examples': [],
                'total_examples': 0,
                'last_updated': datetime.utcnow().isoformat() + 'Z'
            })
            logger.info("Initialized prompt_examples.json")
        
        # Initialize statistics
        if not self.statistics_path.exists():
            self._save_json(self.statistics_path, {
                'total_feedback': 0,
                'confirmed_fraud': 0,
                'false_positives': 0,
                'confirmed_legitimate': 0,
                'patterns': {},
                'accuracy_rate': 0.0,
                'last_updated': datetime.utcnow().isoformat() + 'Z'
            })
            logger.info("Initialized prompt_statistics.json")
    
    def add_feedback_case(self, case: Dict[str, Any]) -> str:
        """
        Add new feedback case.
        
        Args:
            case: Feedback case dict with keys:
                - payment_id
                - decision
                - actual_outcome
                - reward_score
                - fraud_pattern
                - investigator_notes
                - etc.
        
        Returns:
            Case ID
        """
        
        # Backup before modification
        if self.backup_enabled:
            self._backup_file(self.feedback_cases_path)
        
        # Load existing cases
        data = self._load_json(self.feedback_cases_path)
        
        # Generate case ID
        case_id = f"FEEDBACK-{data['total_cases'] + 1:04d}"
        case['id'] = case_id
        case['created_at'] = datetime.utcnow().isoformat() + 'Z'
        
        # Add to appropriate list
        if case['reward_score'] > 0:
            data['success_examples'].append(case)
        else:
            data['failure_examples'].append(case)
        
        data['total_cases'] += 1
        data['last_updated'] = datetime.utcnow().isoformat() + 'Z'
        
        # Save
        self._save_json(self.feedback_cases_path, data)
        
        logger.info(f"Added feedback case: {case_id} (reward: {case['reward_score']})")
        
        return case_id
    
    def add_prompt_example(self, example: Dict[str, Any]) -> str:
        """
        Add formatted prompt example.
        
        Args:
            example: Prompt example dict with keys:
                - feedback_case_id
                - example_text (formatted for prompts)
                - pattern_type
                - lesson_learned
                - reward_score
                - priority_score
        
        Returns:
            Example ID
        """
        
        if self.backup_enabled:
            self._backup_file(self.prompt_examples_path)
        
        data = self._load_json(self.prompt_examples_path)
        
        # Generate example ID
        example_id = f"EXAMPLE-{data['total_examples'] + 1:04d}"
        example['id'] = example_id
        example['created_at'] = datetime.utcnow().isoformat() + 'Z'
        example['usage_count'] = 0
        example['last_used_at'] = None
        example['is_active'] = True
        
        data['examples'].append(example)
        data['total_examples'] += 1
        data['last_updated'] = datetime.utcnow().isoformat() + 'Z'
        
        self._save_json(self.prompt_examples_path, data)
        
        logger.info(f"Added prompt example: {example_id} (pattern: {example.get('pattern_type')})")
        
        return example_id
    
    def get_best_examples(
        self,
        max_examples: int = 5,
        min_reward: int = 50,
        include_failures: int = 1
    ) -> List[Dict[str, Any]]:
        """
        Get best examples for prompts.
        
        Args:
            max_examples: Maximum number of examples
            min_reward: Minimum reward threshold
            include_failures: Number of failure examples to include
        
        Returns:
            List of best examples
        """
        
        data = self._load_json(self.prompt_examples_path)
        examples = data.get('examples', [])
        
        # Filter active examples
        active_examples = [ex for ex in examples if ex.get('is_active', True)]
        
        # Split into successes and failures
        successes = [
            ex for ex in active_examples 
            if ex.get('reward_score', 0) >= min_reward
        ]
        failures = [
            ex for ex in active_examples 
            if ex.get('reward_score', 0) < 0
        ]
        
        # Sort successes by priority
        successes.sort(
            key=lambda x: (
                x.get('priority_score', 0),
                -x.get('usage_count', 0)  # Prefer less-used examples
            ),
            reverse=True
        )
        
        # Sort failures by reward (worst first, to learn from)
        failures.sort(key=lambda x: x.get('reward_score', 0))
        
        # Select examples
        selected = []
        
        # Add top successes
        num_successes = max_examples - include_failures
        selected.extend(successes[:num_successes])
        
        # Add failure examples (learn from mistakes)
        selected.extend(failures[:include_failures])
        
        logger.info(
            f"Selected {len(selected)} examples: "
            f"{len(selected) - include_failures} successes, {include_failures} failures"
        )
        
        return selected
    
    def update_example_usage(self, example_id: str):
        """Update usage count for example."""
        
        data = self._load_json(self.prompt_examples_path)
        
        for example in data['examples']:
            if example['id'] == example_id:
                example['usage_count'] = example.get('usage_count', 0) + 1
                example['last_used_at'] = datetime.utcnow().isoformat() + 'Z'
                break
        
        self._save_json(self.prompt_examples_path, data)
    
    def update_statistics(
        self,
        decision: str,
        actual_outcome: str,
        fraud_pattern: Optional[str] = None
    ):
        """
        Update pattern statistics.
        
        Args:
            decision: ALLOW/WARN/BLOCK
            actual_outcome: CONFIRMED_FRAUD, FALSE_POSITIVE, etc.
            fraud_pattern: Pattern type (optional)
        """
        
        if self.backup_enabled:
            self._backup_file(self.statistics_path)
        
        stats = self._load_json(self.statistics_path)
        
        # Update totals
        stats['total_feedback'] += 1
        
        if actual_outcome == 'CONFIRMED_FRAUD':
            stats['confirmed_fraud'] += 1
        elif actual_outcome == 'FALSE_POSITIVE':
            stats['false_positives'] += 1
        elif actual_outcome == 'CONFIRMED_LEGITIMATE':
            stats['confirmed_legitimate'] += 1
        
        # Update pattern stats
        if fraud_pattern:
            if fraud_pattern not in stats['patterns']:
                stats['patterns'][fraud_pattern] = {
                    'total': 0,
                    'confirmed': 0,
                    'false_positives': 0,
                    'detection_rate': 0.0
                }
            
            stats['patterns'][fraud_pattern]['total'] += 1
            
            if actual_outcome == 'CONFIRMED_FRAUD':
                stats['patterns'][fraud_pattern]['confirmed'] += 1
            elif actual_outcome == 'FALSE_POSITIVE':
                stats['patterns'][fraud_pattern]['false_positives'] += 1
            
            # Calculate detection rate
            pattern_stats = stats['patterns'][fraud_pattern]
            if pattern_stats['total'] > 0:
                pattern_stats['detection_rate'] = (
                    pattern_stats['confirmed'] / pattern_stats['total']
                )
        
        # Calculate overall accuracy
        total_decisions = stats['confirmed_fraud'] + stats['confirmed_legitimate'] + stats['false_positives']
        if total_decisions > 0:
            correct = stats['confirmed_fraud'] + stats['confirmed_legitimate']
            stats['accuracy_rate'] = correct / total_decisions
        
        stats['last_updated'] = datetime.utcnow().isoformat() + 'Z'
        
        self._save_json(self.statistics_path, stats)
        
        logger.info(f"Updated statistics: {fraud_pattern or 'general'}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get current statistics."""
        return self._load_json(self.statistics_path)
    
    def _load_json(self, path: Path) -> Dict[str, Any]:
        """Load JSON file."""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load {path}: {e}")
            return {}
    
    def _save_json(self, path: Path, data: Dict[str, Any]):
        """Save JSON file."""
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Failed to save {path}: {e}")
            raise
    
    def _backup_file(self, path: Path):
        """Create backup of file."""
        try:
            if path.exists():
                backup_dir = path.parent / 'backups'
                backup_dir.mkdir(exist_ok=True)
                
                timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
                backup_path = backup_dir / f"{path.stem}_{timestamp}.json"
                
                shutil.copy2(path, backup_path)
                
                # Keep only last 10 backups
                backups = sorted(backup_dir.glob(f"{path.stem}_*.json"))
                if len(backups) > 10:
                    for old_backup in backups[:-10]:
                        old_backup.unlink()
        
        except Exception as e:
            logger.warning(f"Failed to backup {path}: {e}")
