"""
Repository for Prompt Management data access

Handles all DynamoDB operations for:
- FraudDetectionPrompts table
- PromptLearningQueue table
- PromptPerformanceMetrics table
"""

import boto3
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError
from typing import List, Dict, Optional, Any
from decimal import Decimal
import time
import uuid
from datetime import datetime

from config.dynamodb_config import DYNAMODB_CONFIG
from models.prompt_models import (
    PromptVersion, LearningQueueItem, DailyMetrics,
    PromptStatus, QueueStatus
)


class PromptRepository:
    """Repository for managing prompts in DynamoDB"""
    
    def __init__(self):
        self.region = DYNAMODB_CONFIG['region_name']
        self.dynamodb = boto3.resource('dynamodb', region_name=self.region)
        self.table_prefix = ""  # No prefix by default
        self.prompts_table = self.dynamodb.Table(f"{self.table_prefix}FraudDetectionPrompts")
        self.queue_table = self.dynamodb.Table(f"{self.table_prefix}PromptLearningQueue")
        self.metrics_table = self.dynamodb.Table(f"{self.table_prefix}PromptPerformanceMetrics")
    
    # ========================================================================
    # Prompt CRUD Operations
    # ========================================================================
    
    async def get_active_prompt(self, event_type: str) -> Optional[Dict]:
        """
        Get the currently active prompt for an event type.
        Queries by event_type (partition key) and filters for active prompts.
        Handles both 'TRUE' and 'true' for backward compatibility.
        """
        try:
            # Query by event_type (partition key) and filter for is_active
            response = self.prompts_table.query(
                KeyConditionExpression=Key('event_type').eq(event_type),
                FilterExpression=Attr('is_active').is_in(['TRUE', 'true']),  # Support both cases
                ScanIndexForward=False,  # Get newest first
                Limit=1
            )
            
            if response['Items']:
                return self._convert_decimals(response['Items'][0])
            return None
            
        except ClientError as e:
            print(f"Error getting active prompt: {e}")
            return None
    
    async def get_prompt_by_id(self, prompt_id: str, version_id: str = None) -> Optional[Dict]:
        """
        Get a specific prompt version by ID.
        Always uses scan to locate prompt by prompt_id.
        version_id parameter is kept for backwards compatibility but not used.
        """
        try:
            print(f"🔍 DEBUG: Searching for prompt_id: '{prompt_id}'")
            
            # Always search by prompt_id using scan
            response = self.prompts_table.scan(
                FilterExpression=Attr('prompt_id').eq(prompt_id),
                Limit=10  # Temporarily increased to see all results
            )
            
            print(f"🔍 DEBUG: Scan returned {len(response.get('Items', []))} items")
            
            # Debug: Print all prompt_ids found
            for item in response.get('Items', []):
                print(f"  Found: prompt_id='{item.get('prompt_id')}', event_type='{item.get('event_type')}', version_id='{item.get('version_id')}'")
            
            if response['Items']:
                return self._convert_decimals(response['Items'][0])
            
            print(f"⚠️  DEBUG: No items found for prompt_id: '{prompt_id}'")
            return None
                
        except ClientError as e:
            print(f"Error getting prompt by ID: {e}")
            return None
    
    async def get_prompt_history(
        self,
        event_type: str,
        limit: int = 10,
        include_archived: bool = False
    ) -> List[Dict]:
        """Get version history for an event type"""
        try:
            response = self.prompts_table.query(
                KeyConditionExpression=Key('event_type').eq(event_type),
                ScanIndexForward=False,  # Sort by version_id descending
                Limit=limit
            )
            
            items = response['Items']
            
            if not include_archived:
                items = [item for item in items if item.get('status') != 'ARCHIVED']
            
            return [self._convert_decimals(item) for item in items]
            
        except ClientError as e:
            print(f"Error getting prompt history: {e}")
            return []
    
    async def create_prompt_version(self, prompt_data: Dict) -> Dict:
        """Create a new prompt version"""
        try:
            # Generate IDs if not provided
            if 'prompt_id' not in prompt_data:
                prompt_data['prompt_id'] = f"prompt-{prompt_data['event_type'].lower()}-{int(time.time())}"
            
            if 'version_id' not in prompt_data:
                prompt_data['version_id'] = f"{prompt_data['prompt_version']}#{int(time.time())}"
            
            if 'created_at' not in prompt_data:
                prompt_data['created_at'] = int(time.time())
            
            # Convert floats to Decimals for DynamoDB
            prompt_data = self._convert_floats_to_decimals(prompt_data)
            
            self.prompts_table.put_item(Item=prompt_data)
            
            return self._convert_decimals(prompt_data)
            
        except ClientError as e:
            print(f"Error creating prompt version: {e}")
            raise
    
    async def activate_prompt(
        self,
        event_type: str,
        version_id: str,
        approver_id: str,
        approval_notes: str
    ) -> Dict:
        """
        Activate a prompt version.
        Deactivates ALL currently active versions first (handles edge case of multiple active prompts).
        """
        try:
            current_time = int(time.time())
            
            # Step 1: Deactivate ALL currently active prompts (not just one)
            # This fixes the issue where get_active_prompt only returns 1 prompt
            # but multiple prompts might have is_active=TRUE
            response = self.prompts_table.query(
                KeyConditionExpression=Key('event_type').eq(event_type),
                FilterExpression=Attr('is_active').is_in(['TRUE', 'true'])
            )
            
            # Deactivate each active prompt found
            for active_prompt in response.get('Items', []):
                # Skip if this is the one we're about to activate
                if active_prompt['version_id'] == version_id:
                    continue
                    
                print(f"🔄 Deactivating old version: {active_prompt.get('version', 'N/A')} (version_id: {active_prompt['version_id']})")
                self.prompts_table.update_item(
                    Key={
                        'event_type': event_type,
                        'version_id': active_prompt['version_id']
                    },
                    UpdateExpression='SET is_active = :false, #status = :archived',
                    ExpressionAttributeValues={
                        ':false': 'FALSE',
                        ':archived': 'ARCHIVED'
                    },
                    ExpressionAttributeNames={
                        '#status': 'status'
                    }
                )
            
            # Step 2: Activate new version
            response = self.prompts_table.update_item(
                Key={
                    'event_type': event_type,
                    'version_id': version_id
                },
                UpdateExpression='''
                    SET is_active = :true,
                        #status = :active,
                        activated_at = :time,
                        activated_by = :approver,
                        approval_notes = :notes
                ''',
                ExpressionAttributeValues={
                    ':true': 'TRUE',  # Use uppercase for consistency with DB
                    ':active': 'ACTIVE',
                    ':time': current_time,
                    ':approver': approver_id,
                    ':notes': approval_notes
                },
                ExpressionAttributeNames={
                    '#status': 'status'
                },
                ReturnValues='ALL_NEW'
            )
            
            return self._convert_decimals(response['Attributes'])
            
        except ClientError as e:
            print(f"Error activating prompt: {e}")
            raise
    
    async def archive_prompt(self, event_type: str, version_id: str) -> bool:
        """Archive a prompt version"""
        try:
            self.prompts_table.update_item(
                Key={
                    'event_type': event_type,
                    'version_id': version_id
                },
                UpdateExpression='SET #status = :archived, is_active = :false',
                ExpressionAttributeValues={
                    ':archived': 'ARCHIVED',
                    ':false': 'FALSE'  # Use uppercase for consistency with DB
                },
                ExpressionAttributeNames={
                    '#status': 'status'
                }
            )
            return True
            
        except ClientError as e:
            print(f"Error archiving prompt: {e}")
            return False
    
    async def update_prompt_fields(
        self,
        event_type: str,
        version_id: str,
        updates: Dict[str, Any]
    ) -> Dict:
        """
        Update specific fields in a prompt version.
        Used for in-place updates of DRAFT versions.
        
        Args:
            event_type: Event type (partition key)
            version_id: Version ID (sort key)
            updates: Dictionary of fields to update
        
        Returns:
            Updated prompt
        """
        try:
            # Convert floats to Decimals for DynamoDB
            updates = self._convert_floats_to_decimals(updates)
            
            # Build update expression dynamically
            update_expr_parts = []
            expr_attr_names = {}
            expr_attr_values = {}
            
            for key, value in updates.items():
                # Handle reserved keywords
                attr_name = f"#{key}"
                attr_value = f":{key}"
                
                update_expr_parts.append(f"{attr_name} = {attr_value}")
                expr_attr_names[attr_name] = key
                expr_attr_values[attr_value] = value
            
            # Add updated_at timestamp
            update_expr_parts.append("#updated_at = :updated_at")
            expr_attr_names["#updated_at"] = "updated_at"
            expr_attr_values[":updated_at"] = int(time.time())
            
            update_expression = "SET " + ", ".join(update_expr_parts)
            
            response = self.prompts_table.update_item(
                Key={
                    'event_type': event_type,
                    'version_id': version_id
                },
                UpdateExpression=update_expression,
                ExpressionAttributeNames=expr_attr_names,
                ExpressionAttributeValues=expr_attr_values,
                ReturnValues='ALL_NEW'
            )
            
            return self._convert_decimals(response['Attributes'])
            
        except ClientError as e:
            print(f"Error updating prompt fields: {e}")
            raise
    
    # ========================================================================
    # Learning Queue Operations
    # ========================================================================
    
    async def add_to_learning_queue(self, queue_item: Dict) -> Dict:
        """Add a case to the learning queue"""
        try:
            if 'queue_id' not in queue_item:
                queue_item['queue_id'] = str(uuid.uuid4())
            
            if 'created_at' not in queue_item:
                queue_item['created_at'] = int(time.time())
            
            queue_item = self._convert_floats_to_decimals(queue_item)
            
            self.queue_table.put_item(Item=queue_item)
            
            return self._convert_decimals(queue_item)
            
        except ClientError as e:
            print(f"Error adding to learning queue: {e}")
            raise
    
    async def get_learning_queue(
        self,
        event_type: Optional[str] = None,
        status: str = "PENDING_REVIEW",
        limit: int = 50
    ) -> List[Dict]:
        """Get items from learning queue"""
        try:
            if event_type:
                # Query by status and event_type
                response = self.queue_table.query(
                    IndexName='QueueStatusIndex',
                    KeyConditionExpression=Key('status').eq(status) & Key('event_type').eq(event_type),
                    Limit=limit
                )
            else:
                # Query by status only
                response = self.queue_table.query(
                    IndexName='QueueStatusIndex',
                    KeyConditionExpression=Key('status').eq(status),
                    Limit=limit
                )
            
            return [self._convert_decimals(item) for item in response['Items']]
            
        except ClientError as e:
            print(f"Error getting learning queue: {e}")
            return []
    
    async def update_queue_status(
        self,
        queue_id: str,
        created_at: int,
        action: str,
        reviewer_id: str,
        review_notes: str
    ) -> Dict:
        """Update learning queue item status"""
        try:
            new_status = 'APPROVED' if action == 'APPROVE' else 'REJECTED'
            current_time = int(time.time())
            
            response = self.queue_table.update_item(
                Key={
                    'queue_id': queue_id,
                    'created_at': created_at
                },
                UpdateExpression='''
                    SET #status = :status,
                        reviewed_by = :reviewer,
                        reviewed_at = :time,
                        review_notes = :notes
                ''',
                ExpressionAttributeValues={
                    ':status': new_status,
                    ':reviewer': reviewer_id,
                    ':time': current_time,
                    ':notes': review_notes
                },
                ExpressionAttributeNames={
                    '#status': 'status'
                },
                ReturnValues='ALL_NEW'
            )
            
            return self._convert_decimals(response['Attributes'])
            
        except ClientError as e:
            print(f"Error updating queue status: {e}")
            raise
    
    async def mark_queue_items_as_added(
        self,
        queue_ids: List[str],
        prompt_version: str
    ) -> int:
        """Mark multiple queue items as added to prompt"""
        success_count = 0
        current_time = int(time.time())
        
        for queue_id in queue_ids:
            try:
                # Get the item first to get created_at
                response = self.queue_table.query(
                    KeyConditionExpression=Key('queue_id').eq(queue_id),
                    Limit=1
                )
                
                if response['Items']:
                    item = response['Items'][0]
                    
                    self.queue_table.update_item(
                        Key={
                            'queue_id': queue_id,
                            'created_at': item['created_at']
                        },
                        UpdateExpression='''
                            SET #status = :status,
                                target_prompt_version = :version,
                                added_to_prompt_at = :time
                        ''',
                        ExpressionAttributeValues={
                            ':status': 'ADDED_TO_PROMPT',
                            ':version': prompt_version,
                            ':time': current_time
                        },
                        ExpressionAttributeNames={
                            '#status': 'status'
                        }
                    )
                    success_count += 1
                    
            except ClientError as e:
                print(f"Error marking queue item {queue_id} as added: {e}")
                continue
        
        return success_count
    
    # ========================================================================
    # Performance Metrics Operations
    # ========================================================================
    
    async def save_daily_metrics(self, metrics: Dict) -> bool:
        """Save daily performance metrics"""
        try:
            metrics = self._convert_floats_to_decimals(metrics)
            self.metrics_table.put_item(Item=metrics)
            return True
            
        except ClientError as e:
            print(f"Error saving metrics: {e}")
            return False
    
    async def get_metrics_by_date_range(
        self,
        prompt_id: str,
        start_date: str,
        end_date: str
    ) -> List[Dict]:
        """Get metrics for a prompt within a date range"""
        try:
            response = self.metrics_table.query(
                KeyConditionExpression=Key('prompt_id').eq(prompt_id) & Key('date').between(start_date, end_date)
            )
            
            return [self._convert_decimals(item) for item in response['Items']]
            
        except ClientError as e:
            print(f"Error getting metrics: {e}")
            return []
    
    async def get_metrics_by_event_type(
        self,
        event_type: str,
        start_date: str,
        end_date: str
    ) -> List[Dict]:
        """Get metrics for all prompts of an event type"""
        try:
            response = self.metrics_table.query(
                IndexName='EventTypeDateIndex',
                KeyConditionExpression=Key('event_type').eq(event_type) & Key('date').between(start_date, end_date)
            )
            
            return [self._convert_decimals(item) for item in response['Items']]
            
        except ClientError as e:
            print(f"Error getting metrics by event type: {e}")
            return []
    
    # ========================================================================
    # Helper Methods
    # ========================================================================
    
    def _convert_decimals(self, obj: Any) -> Any:
        """Convert Decimal objects to float for JSON serialization"""
        if isinstance(obj, list):
            return [self._convert_decimals(item) for item in obj]
        elif isinstance(obj, dict):
            return {key: self._convert_decimals(value) for key, value in obj.items()}
        elif isinstance(obj, Decimal):
            return float(obj)
        else:
            return obj
    
    def _convert_floats_to_decimals(self, obj: Any) -> Any:
        """Convert float objects to Decimal for DynamoDB"""
        if isinstance(obj, list):
            return [self._convert_floats_to_decimals(item) for item in obj]
        elif isinstance(obj, dict):
            return {key: self._convert_floats_to_decimals(value) for key, value in obj.items()}
        elif isinstance(obj, float):
            return Decimal(str(obj))
        else:
            return obj
    
    async def list_prompts(
        self,
        event_type: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict]:
        """List all prompts with optional filtering"""
        try:
            if event_type:
                # Query by event_type
                response = self.prompts_table.query(
                    KeyConditionExpression=Key('event_type').eq(event_type),
                    ScanIndexForward=False,
                    Limit=limit
                )
            else:
                # Scan all (less efficient but necessary without event_type)
                response = self.prompts_table.scan(Limit=limit)
            
            items = response['Items']
            
            # Filter by status if provided
            if status:
                items = [item for item in items if item.get('status') == status]
            
            return [self._convert_decimals(item) for item in items]
            
        except ClientError as e:
            print(f"Error listing prompts: {e}")
            return []
    
    async def get_prompt_statistics(self) -> Dict:
        """Get overall prompt statistics"""
        try:
            # Scan to get counts (in production, use aggregation table)
            response = self.prompts_table.scan()
            items = response['Items']
            
            total_prompts = len(items)
            # Support both 'TRUE' and 'true' for backward compatibility
            active_prompts = sum(1 for item in items if item.get('is_active') in ['TRUE', 'true'])
            
            by_event_type = {}
            by_status = {}
            
            for item in items:
                event_type = item.get('event_type', 'UNKNOWN')
                status = item.get('status', 'UNKNOWN')
                
                by_event_type[event_type] = by_event_type.get(event_type, 0) + 1
                by_status[status] = by_status.get(status, 0) + 1
            
            return {
                'total_prompts': total_prompts,
                'active_prompts': active_prompts,
                'by_event_type': by_event_type,
                'by_status': by_status,
                'last_updated': datetime.utcnow().isoformat()
            }
            
        except ClientError as e:
            print(f"Error getting prompt statistics: {e}")
            return {
                'total_prompts': 0,
                'active_prompts': 0,
                'by_event_type': {},
                'by_status': {},
                'error': str(e)
            }
    
    async def get_learning_insights(self) -> Dict:
        """Get learning queue insights and statistics"""
        try:
            # Get all queue items
            response = self.queue_table.scan()
            items = response['Items']
            
            total_items = len(items)
            pending = sum(1 for item in items if item.get('status') == 'PENDING_REVIEW')
            approved = sum(1 for item in items if item.get('status') == 'APPROVED')
            rejected = sum(1 for item in items if item.get('status') == 'REJECTED')
            added_to_prompt = sum(1 for item in items if item.get('status') == 'ADDED_TO_PROMPT')
            
            # Calculate reward statistics
            rewards = [float(item.get('reward_score', 0)) for item in items if 'reward_score' in item]
            total_reward = sum(rewards)
            avg_reward = total_reward / len(rewards) if rewards else 0
            
            # High-value cases (|reward| >= 50)
            high_value_cases = [item for item in items if abs(float(item.get('reward_score', 0))) >= 50]
            
            by_event_type = {}
            for item in items:
                event_type = item.get('event_type', 'UNKNOWN')
                by_event_type[event_type] = by_event_type.get(event_type, 0) + 1
            
            return {
                'total_items': total_items,
                'pending_review': pending,
                'approved': approved,
                'rejected': rejected,
                'added_to_prompt': added_to_prompt,
                'total_reward_score': total_reward,
                'average_reward': avg_reward,
                'high_value_cases': len(high_value_cases),
                'by_event_type': by_event_type,
                'last_updated': datetime.utcnow().isoformat()
            }
            
        except ClientError as e:
            print(f"Error getting learning insights: {e}")
            return {
                'total_items': 0,
                'pending_review': 0,
                'approved': 0,
                'rejected': 0,
                'added_to_prompt': 0,
                'total_reward_score': 0,
                'average_reward': 0,
                'high_value_cases': 0,
                'by_event_type': {},
                'error': str(e)
            }
