"""
DynamoDB Client
Handles all DynamoDB operations for fraud detection decisions
"""
import boto3
from boto3.dynamodb.conditions import Key, Attr
from decimal import Decimal
from datetime import datetime
from typing import Dict, List, Optional
import json
import logging
import sys
from pathlib import Path

# Add parent directory to path to allow imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.dynamodb_config import DYNAMODB_CONFIG, DecisionStatus, EventType, EntityType, RiskCategory

logger = logging.getLogger(__name__)


class DynamoDBClient:
    """
    DynamoDB client for fraud detection events (all fraud types)
    Supports: Payment fraud, PII access, data modifications, regulatory violations, etc.
    """
    
    def __init__(self):
        """Initialize DynamoDB connection"""
        self.dynamodb = boto3.resource(
            'dynamodb',
            region_name=DYNAMODB_CONFIG['region_name']
        )
        self.table = self.dynamodb.Table(DYNAMODB_CONFIG['table_name'])
        logger.info(f"DynamoDB client initialized for table: {DYNAMODB_CONFIG['table_name']}")
    
    def _convert_floats_to_decimal(self, data):
        """Convert float values to Decimal for DynamoDB"""
        if isinstance(data, dict):
            return {k: self._convert_floats_to_decimal(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [self._convert_floats_to_decimal(item) for item in data]
        elif isinstance(data, float):
            return Decimal(str(data))
        return data
    
    def _convert_decimal_to_float(self, data):
        """Convert Decimal values to float for JSON serialization"""
        if isinstance(data, dict):
            return {k: self._convert_decimal_to_float(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [self._convert_decimal_to_float(item) for item in data]
        elif isinstance(data, Decimal):
            return float(data)
        return data
    
    def _normalize_decision_format(self, item: Dict) -> Dict:
        """
        Normalize decision format - flatten nested llm_decision if present
        This handles backward compatibility with old data formats.
        
        Converts:
            {'llm_decision': {'decision': 'BLOCK', 'confidence': 0.9, 'reasoning': '...'}}
        To:
            {'llm_decision': 'BLOCK', 'llm_confidence': 0.9, 'llm_reasoning': '...'}
        """
        if isinstance(item.get('llm_decision'), dict):
            # Nested format - flatten it
            nested = item['llm_decision']
            item['llm_decision'] = nested.get('decision', nested.get('llm_decision', 'UNKNOWN'))
            item['llm_confidence'] = nested.get('confidence', nested.get('llm_confidence', 0.0))
            item['llm_reasoning'] = nested.get('reasoning', nested.get('llm_reasoning', ''))
        
        # Ensure ALL required fields exist for FastAPI response validation
        if 'llm_decision' not in item or not item['llm_decision']:
            item['llm_decision'] = 'UNKNOWN'
        if 'llm_confidence' not in item:
            item['llm_confidence'] = 0.0
        if 'llm_reasoning' not in item:
            item['llm_reasoning'] = ''
        if 'final_decision' not in item or not item['final_decision']:
            item['final_decision'] = item.get('llm_decision', 'UNKNOWN')
        if 'created_at' not in item:
            # Try to derive from timestamp if available
            if 'timestamp' in item:
                try:
                    item['created_at'] = datetime.fromtimestamp(int(item['timestamp'])).isoformat()
                except:
                    item['created_at'] = datetime.utcnow().isoformat()
            else:
                item['created_at'] = datetime.utcnow().isoformat()
        
        # Ensure timestamp is always an integer
        if 'timestamp' in item:
            item['timestamp'] = int(item['timestamp'])
        
        return item
    
    def save_decision(self, decision_data: Dict) -> Dict:
        """
        Save a fraud detection event to DynamoDB
        
        Args:
            decision_data: Dictionary containing decision information
                Required fields:
                - event_id: Unique event identifier (payment_id, access_id, etc.)
                - event_type: Type of fraud event (PAYMENT_FRAUD, PII_ACCESS, etc.)
                - llm_decision: Decision (BLOCK/WARN/ALLOW)
                Optional fields:
                - entity_type: Type of entity (PAYMENT, USER_ACCESS, etc.)
                - risk_category: Risk category (FINANCIAL, DATA_PRIVACY, etc.)
                - transaction_data/event_data: Event-specific data
                - rule_agents_results: Agent detection results
                
        Returns:
            Saved item with timestamp
        """
        try:
            timestamp = int(datetime.utcnow().timestamp())
            
            # Prepare item with generic fields
            item = {
                'event_id': decision_data['event_id'],  # Generic ID (payment_id, access_id, etc.)
                'timestamp': timestamp,
                'event_type': decision_data.get('event_type', EventType.PAYMENT_FRAUD),
                'entity_id': decision_data.get('entity_id', decision_data['event_id']),
                'entity_type': decision_data.get('entity_type', EntityType.PAYMENT),
                'risk_category': decision_data.get('risk_category', RiskCategory.FINANCIAL),
                'event_data': decision_data.get('event_data', decision_data.get('transaction_data', {})),
                'detection_results': decision_data.get('detection_results', decision_data.get('rule_agents_results', {})),
                'llm_decision': decision_data['llm_decision'],
                'llm_confidence': decision_data.get('llm_confidence', 0.0),
                'llm_reasoning': decision_data.get('llm_reasoning', ''),
                'final_decision': decision_data.get('final_decision', decision_data['llm_decision']),
                'status': decision_data.get('status', DecisionStatus.PENDING_REVIEW),
                'created_at': datetime.utcnow().isoformat(),
                # Include display_metadata and total_score for UI normalization
                'display_metadata': decision_data.get('display_metadata', {}),
                'total_score': decision_data.get('total_score', 0)
            }
            
            # Convert floats to Decimal for DynamoDB
            item = self._convert_floats_to_decimal(item)
            
            # Save to DynamoDB
            self.table.put_item(Item=item)
            
            logger.info(f"Saved {item['event_type']} event: {item['event_id']}")
            return self._convert_decimal_to_float(item)
            
        except Exception as e:
            logger.error(f"Error saving decision to DynamoDB: {str(e)}")
            raise
    
    def store_decision(self, decision_data: Dict) -> Dict:
        """
        Alias for save_decision - stores a fraud detection event to DynamoDB
        Used by internal API endpoints
        
        Args:
            decision_data: Dictionary containing decision information
                
        Returns:
            Saved item with timestamp
        """
        return self.save_decision(decision_data)
    
    def delete_decision(self, event_id: str, timestamp) -> bool:
        """
        Delete a decision from DynamoDB (for testing/cleanup)
        
        Args:
            event_id: Event identifier (primary key)
            timestamp: Decision timestamp (sort key) - can be int, float, or Decimal
            
        Returns:
            True if deleted successfully
        """
        try:
            # Ensure timestamp is an integer (DynamoDB requirement)
            timestamp_int = int(timestamp)
            
            self.table.delete_item(
                Key={
                    'event_id': event_id,
                    'timestamp': timestamp_int
                }
            )
            logger.info(f"Deleted decision: {event_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error deleting decision {event_id}: {str(e)}")
            raise
    
    def get_decision_by_event_id(self, event_id: str) -> Optional[Dict]:
        """
        Get a decision by event_id (payment_id, access_id, etc.)
        
        Args:
            event_id: Event identifier
            
        Returns:
            Decision data or None if not found
        """
        try:
            # Query by event_id
            response = self.table.query(
                KeyConditionExpression=Key('event_id').eq(event_id),
                ScanIndexForward=False,  # Get latest first
                Limit=1
            )
            
            items = response.get('Items', [])
            if items:
                item = self._convert_decimal_to_float(items[0])
                return self._normalize_decision_format(item)
            return None
            
        except Exception as e:
            logger.error(f"Error getting decision for event_id {event_id}: {str(e)}")
            raise
    
    # Backward compatibility alias
    def get_decision_by_payment_id(self, payment_id: str) -> Optional[Dict]:
        """Backward compatibility: Get decision by payment_id"""
        return self.get_decision_by_event_id(payment_id)
    
    def get_pending_reviews(self, limit: int = 50) -> List[Dict]:
        """
        Get all pending SIU reviews
        
        Args:
            limit: Maximum number of items to return
            
        Returns:
            List of pending decisions
        """
        try:
            response = self.table.query(
                IndexName=DYNAMODB_CONFIG['status_index'],
                KeyConditionExpression=Key('status').eq(DecisionStatus.PENDING_REVIEW),
                ScanIndexForward=False,  # Newest first
                Limit=limit
            )
            
            items = response.get('Items', [])
            logger.info(f"Retrieved {len(items)} pending reviews")
            return [self._normalize_decision_format(self._convert_decimal_to_float(item)) for item in items]
            
        except Exception as e:
            logger.error(f"Error getting pending reviews: {str(e)}")
            raise
    
    def get_decisions_by_event_type(self, event_type: str, limit: int = 100) -> List[Dict]:
        """
        Get decisions by event type (fraud category)
        
        Args:
            event_type: Event type (PAYMENT_FRAUD, PII_ACCESS, DATA_MODIFICATION, etc.)
            limit: Maximum number of items to return
            
        Returns:
            List of decisions
        """
        try:
            response = self.table.query(
                IndexName=DYNAMODB_CONFIG['event_type_index'],
                KeyConditionExpression=Key('event_type').eq(event_type),
                ScanIndexForward=False,  # Newest first
                Limit=limit
            )
            
            items = response.get('Items', [])
            return [self._normalize_decision_format(self._convert_decimal_to_float(item)) for item in items]
            
        except Exception as e:
            logger.error(f"Error getting decisions by event_type {event_type}: {str(e)}")
            raise
    
    def get_decisions_by_status(self, status: str, limit: int = 100) -> List[Dict]:
        """
        Get decisions by status
        
        Args:
            status: Decision status (PENDING_REVIEW, APPROVED, DENIED, etc.)
            limit: Maximum number of items to return
            
        Returns:
            List of decisions
        """
        try:
            response = self.table.query(
                IndexName=DYNAMODB_CONFIG['status_index'],
                KeyConditionExpression=Key('status').eq(status),
                ScanIndexForward=False,  # Newest first
                Limit=limit
            )
            
            items = response.get('Items', [])
            return [self._normalize_decision_format(self._convert_decimal_to_float(item)) for item in items]
            
        except Exception as e:
            logger.error(f"Error getting decisions by status {status}: {str(e)}")
            raise
    
    def update_decision_review(
        self,
        event_id: str,
        timestamp: int,
        review_data: Dict
    ) -> Dict:
        """
        Update a decision with reviewer information
        
        Args:
            event_id: Event identifier
            timestamp: Decision timestamp
            review_data: Review information (reviewer_id, reviewer_action, reviewer_notes, etc.)
            
        Returns:
            Updated item
        """
        try:
            update_expression = "SET "
            expression_values = {}
            expression_names = {}
            
            # Build update expression dynamically
            updates = []
            if 'reviewer_id' in review_data or 'siu_reviewer_id' in review_data:
                updates.append("#reviewer = :reviewer")
                expression_names['#reviewer'] = 'reviewer_id'
                expression_values[':reviewer'] = review_data.get('reviewer_id', review_data.get('siu_reviewer_id'))
            
            if 'reviewer_action' in review_data or 'siu_action' in review_data:
                updates.append("reviewer_action = :action")
                expression_values[':action'] = review_data.get('reviewer_action', review_data.get('siu_action'))
            
            if 'reviewer_notes' in review_data or 'siu_notes' in review_data:
                updates.append("reviewer_notes = :notes")
                expression_values[':notes'] = review_data.get('reviewer_notes', review_data.get('siu_notes'))
            
            if 'actual_outcome' in review_data:
                updates.append("actual_outcome = :outcome")
                expression_values[':outcome'] = review_data['actual_outcome']
            
            if 'reward_score' in review_data:
                updates.append("reward_score = :reward")
                expression_values[':reward'] = review_data['reward_score']
            
            if 'status' in review_data:
                updates.append("#status = :status")
                expression_names['#status'] = 'status'
                expression_values[':status'] = review_data['status']
            
            # Add reviewed timestamp
            updates.append("reviewed_at = :reviewed_at")
            expression_values[':reviewed_at'] = datetime.utcnow().isoformat()
            
            update_expression += ", ".join(updates)
            
            # Convert floats to Decimal
            expression_values = self._convert_floats_to_decimal(expression_values)
            
            # Update item
            response = self.table.update_item(
                Key={
                    'event_id': event_id,
                    'timestamp': timestamp
                },
                UpdateExpression=update_expression,
                ExpressionAttributeValues=expression_values,
                ExpressionAttributeNames=expression_names if expression_names else None,
                ReturnValues="ALL_NEW"
            )
            
            logger.info(f"Updated decision review for event_id: {event_id}")
            item = self._convert_decimal_to_float(response['Attributes'])
            # Normalize the format to ensure all required fields are present
            return self._normalize_decision_format(item)
            
        except Exception as e:
            logger.error(f"Error updating decision review: {str(e)}")
            raise
    
    def get_decisions_by_reviewer(
        self,
        reviewer_id: str,
        limit: int = 50
    ) -> List[Dict]:
        """
        Get decisions reviewed by a specific reviewer
        
        Args:
            reviewer_id: Reviewer identifier (SIU reviewer, data steward, etc.)
            limit: Maximum number of items to return
            
        Returns:
            List of decisions
        """
        try:
            response = self.table.query(
                IndexName=DYNAMODB_CONFIG['reviewer_index'],
                KeyConditionExpression=Key('reviewer_id').eq(reviewer_id),
                ScanIndexForward=False,  # Newest first
                Limit=limit
            )
            
            items = response.get('Items', [])
            return [self._normalize_decision_format(self._convert_decimal_to_float(item)) for item in items]
            
        except Exception as e:
            logger.error(f"Error getting decisions for reviewer {reviewer_id}: {str(e)}")
            raise
    
    def get_all_decisions(self, limit: int = 100) -> List[Dict]:
        """
        Get all decisions (paginated)
        
        Args:
            limit: Maximum number of items to return
            
        Returns:
            List of decisions
        """
        try:
            response = self.table.scan(Limit=limit)
            
            items = response.get('Items', [])
            return [self._normalize_decision_format(self._convert_decimal_to_float(item)) for item in items]
            
        except Exception as e:
            logger.error(f"Error getting all decisions: {str(e)}")
            raise
    
    def get_statistics(self) -> Dict:
        """
        Get statistics about decisions
        
        Returns:
            Dictionary with counts by status, decision, etc.
        """
        try:
            # This is a simplified version - for production, use DynamoDB Streams + Lambda
            # or maintain a separate analytics table
            
            stats = {
                'total_decisions': 0,
                'pending_reviews': 0,
                'approved': 0,
                'denied': 0,
                'by_decision': {
                    'BLOCK': 0,
                    'WARN': 0,
                    'ALLOW': 0
                }
            }
            
            # Get counts by status
            for status in [DecisionStatus.PENDING_REVIEW, DecisionStatus.APPROVED, DecisionStatus.DENIED]:
                items = self.get_decisions_by_status(status, limit=1000)
                if status == DecisionStatus.PENDING_REVIEW:
                    stats['pending_reviews'] = len(items)
                elif status == DecisionStatus.APPROVED:
                    stats['approved'] = len(items)
                elif status == DecisionStatus.DENIED:
                    stats['denied'] = len(items)
                
                stats['total_decisions'] += len(items)
                
                # Count by decision type
                for item in items:
                    decision = item.get('llm_decision', 'UNKNOWN')
                    if decision in stats['by_decision']:
                        stats['by_decision'][decision] += 1
            
            return stats
            
        except Exception as e:
            logger.error(f"Error getting statistics: {str(e)}")
            raise


# Singleton instance
_dynamodb_client = None

def get_dynamodb_client() -> DynamoDBClient:
    """Get or create DynamoDB client singleton"""
    global _dynamodb_client
    if _dynamodb_client is None:
        _dynamodb_client = DynamoDBClient()
    return _dynamodb_client
