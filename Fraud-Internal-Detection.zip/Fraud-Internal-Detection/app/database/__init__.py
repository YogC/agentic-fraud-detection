"""
Database package initialization
"""
from database.dynamodb_client import get_dynamodb_client, DynamoDBClient

__all__ = ['get_dynamodb_client', 'DynamoDBClient']
