"""
Medical Report AI Analyzer
Main package initialization
"""

__version__ = "1.0.0"
__author__ = "Medical Report AI Analyzer Team"
__description__ = "Agentic AI system for analyzing auto insurance medical reports using AWS services"
