"""
CLEAN SLATE - Simple Database Setup Script

Purpose: Clean database and create fresh prompts with correct few-shot examples
"""

import boto3
import time
import sys
from decimal import Decimal

def main():
    print("\n" + "=" * 80)
    print("CLEAN SLATE - Database Reset & Setup")
    print("=" * 80)

    # Initialize DynamoDB
    print("\n1. Connecting to DynamoDB...")
    try:
        dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        prompts_table = dynamodb.Table('FraudDetectionPrompts')
        events_table = dynamodb.Table('fraud-detection-events')
        learning_queue_table = dynamodb.Table('PromptLearningQueue')
        print("   ✅ Connected to FraudDetectionPrompts")
        print("   ✅ Connected to fraud-detection-events")
        print("   ✅ Connected to PromptLearningQueue")
    except Exception as e:
        print(f"   ❌ Error connecting: {e}")
        input("\nPress Enter to exit...")
        sys.exit(1)

    # Step 1: Clear old fraud detection events
    print("\n2. Clearing old fraud detection events...")
    try:
        response = events_table.scan()
        items = response.get('Items', [])
        deleted_count = 0
        
        for item in items:
            events_table.delete_item(
                Key={
                    'event_id': item['event_id'],
                    'timestamp': item['timestamp']
                }
            )
            deleted_count += 1
        
        # Handle pagination if there are many items
        while 'LastEvaluatedKey' in response:
            response = events_table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            items = response.get('Items', [])
            for item in items:
                events_table.delete_item(
                    Key={
                        'event_id': item['event_id'],
                        'timestamp': item['timestamp']
                    }
                )
                deleted_count += 1
        
        print(f"   ✅ Deleted {deleted_count} old fraud detection events")
    except Exception as e:
        print(f"   ⚠️  Warning: {e}")
        print("   (This is OK if table was empty)")

    # Step 2: Clear old prompts
    print("\n3. Clearing old prompts...")
    try:
        response = prompts_table.scan()
        items = response.get('Items', [])
        deleted_count = 0
        
        for item in items:
            prompts_table.delete_item(
                Key={
                    'event_type': item['event_type'],
                    'version_id': item['version_id']
                }
            )
            deleted_count += 1
        
        print(f"   ✅ Deleted {deleted_count} old prompts")
    except Exception as e:
        print(f"   ⚠️  Warning: {e}")
        print("   (This is OK if table was empty)")

    # Step 3: Clear learning queue
    print("\n4. Clearing learning queue...")
    try:
        response = learning_queue_table.scan()
        items = response.get('Items', [])
        deleted_count = 0
        
        for item in items:
            # PromptLearningQueue has composite key: queue_id (partition) + created_at (sort)
            learning_queue_table.delete_item(
                Key={
                    'queue_id': item['queue_id'],
                    'created_at': item['created_at']
                }
            )
            deleted_count += 1
        
        # Handle pagination if there are many items
        while 'LastEvaluatedKey' in response:
            response = learning_queue_table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            items = response.get('Items', [])
            for item in items:
                learning_queue_table.delete_item(
                    Key={
                        'queue_id': item['queue_id'],
                        'created_at': item['created_at']
                    }
                )
                deleted_count += 1
        
        print(f"   ✅ Deleted {deleted_count} old learning queue items")
    except Exception as e:
        print(f"   ⚠️  Warning: {e}")
        print("   (This is OK if table was empty)")

    # Step 4: Create fresh PAYMENT_FRAUD prompt
    print("\n5. Creating fresh PAYMENT_FRAUD prompt...")

    system_prompt = """You are an expert fraud detection agent for insurance claims and payments.

Your role is to analyze payment transactions and identify fraud patterns, particularly:
- Insider fraud (employee manipulation)
- Last-mile fraud (payee changes before payment)
- Separation of duties violations
- Suspicious timing patterns

For each transaction, provide:
1. A decision: ALLOW, WARN, or BLOCK
2. Clear reasoning for your decision
3. Specific fraud indicators you identified (if any)

Be thorough but concise. Focus on facts and patterns, not speculation."""

    few_shot_examples = [
        {
            "correct_decision": "BLOCK",
            "scenario": "Employee EMP-001 approved claim CLM-001 at 10:00 AM, changed the payee bank account at 10:05 AM (5 minutes later), and released payment at 10:10 AM. All three control actions performed by the same employee within 10 minutes.",
            "reasoning": "Critical separation of duties violation. Same employee performed all three control actions (approve, modify payee, release payment) within a short timeframe. This pattern indicates insider fraud risk with high confidence.",
            "fraud_type": "INSIDER_FRAUD"
        },
        {
            "correct_decision": "ALLOW",
            "scenario": "Employee EMP-001 approved claim CLM-002 at 9:00 AM on Monday. Different employee EMP-002 released the payment at 2:00 PM on Tuesday (29 hours later). No payee changes detected. Standard ACH payment method. Customer identity verification completed successfully.",
            "reasoning": "Proper separation of duties maintained. Different employees handled approval and release. Sufficient time gap between actions. No suspicious modifications. Verification completed. This represents a normal legitimate transaction flow.",
            "fraud_type": "CLEAN_TRANSACTION"
        },
        {
            "correct_decision": "WARN",
            "scenario": "Employee EMP-003 approved claim CLM-003 at 2:00 PM. Same employee attempted to modify payee details at 2:15 PM but the system blocked the change due to insufficient permissions. Different employee EMP-004 released payment at 3:00 PM with original payee intact.",
            "reasoning": "Attempted payee modification by approving employee is a red flag, but the control system worked correctly by blocking it. Final payment went to correct payee with proper separation of duties. Warrants investigation into why EMP-003 attempted the modification, but not high enough risk to block payment.",
            "fraud_type": "ATTEMPTED_FRAUD"
        }
    ]

    # Create the prompt with correct version_id format and ALL required fields
    created_at = int(time.time())
    prompt_version = '1'
    version_id = f"{prompt_version}#{created_at}"  # Format: prompt_version#timestamp

    # Model configuration (required by UI and API) - Use Decimal for DynamoDB
    model_config = {
        'temperature': Decimal('0.7'),
        'max_tokens': 1000,
        'top_p': Decimal('0.9')
    }

    prompt_item = {
        # Primary keys
        'event_type': 'PAYMENT_FRAUD',
        'version_id': version_id,
        
        # Identification
        'prompt_id': f"prompt-payment_fraud-{created_at}",
        'prompt_version': prompt_version,
        'version': prompt_version,  # Duplicate for compatibility
        
        # Status
        'status': 'ACTIVE',
        'is_active': 'TRUE',  # Use uppercase to match DB format
        
        # Content
        'system_prompt': system_prompt,
        'template': system_prompt,  # Duplicate for UI compatibility
        'few_shot_examples': few_shot_examples,
        
        # Configuration
        'model_config': model_config,
        'llm_model_config': model_config,  # Duplicate for API compatibility
        
        # Metadata
        'examples_count': len(few_shot_examples),
        'usage_count': 0,
        'created_at': created_at,
        'created_by': 'CLEAN_SLATE_SCRIPT',
        'updated_at': created_at,
        'activated_at': created_at,
        'activated_by': 'system',
        'description': 'Fresh prompt with correct schema - created by CLEAN_SLATE.py'
    }

    try:
        prompts_table.put_item(Item=prompt_item)
        print(f"   ✅ Created PAYMENT_FRAUD prompt v1")
        print(f"   ✅ Added 3 few-shot examples")
        print(f"      - BLOCK: Insider fraud example")
        print(f"      - ALLOW: Clean transaction example")  
        print(f"      - WARN: Attempted fraud example")
        print(f"   ✅ Added model configuration (temperature=0.7, max_tokens=1000)")
        print(f"   ✅ Added all UI compatibility fields")
    except Exception as e:
        print(f"   ❌ Error: {e}")
        input("\nPress Enter to exit...")
        sys.exit(1)

    # Step 5: Verify
    print("\n6. Verifying...")
    try:
        response = prompts_table.get_item(
            Key={
                'event_type': 'PAYMENT_FRAUD',
                'version_id': version_id
            }
        )
        
        if 'Item' in response:
            item = response['Item']
            examples = item.get('few_shot_examples', [])
            
            print(f"   ✅ Prompt verified")
            print(f"   ✅ Examples: {len(examples)}")
            
            # Check schema
            if examples:
                first_ex = examples[0]
                has_correct_decision = 'correct_decision' in first_ex
                has_old_decision = 'decision' in first_ex
                has_confidence = 'confidence' in first_ex
                
                print(f"\n   Schema Check:")
                print(f"      correct_decision: {'✅ YES' if has_correct_decision else '❌ NO'}")
                print(f"      decision (old):   {'❌ FOUND (BAD)' if has_old_decision else '✅ NOT FOUND (GOOD)'}")
                print(f"      confidence:       {'❌ FOUND (BAD)' if has_confidence else '✅ NOT FOUND (GOOD)'}")
                
                # Check values
                decision_value = first_ex.get('correct_decision', 'UNKNOWN')
                print(f"\n   Decision Value: {decision_value}")
                if decision_value in ['ALLOW', 'WARN', 'BLOCK']:
                    print(f"      ✅ Correct (ALLOW/WARN/BLOCK)")
                else:
                    print(f"      ❌ Wrong value: {decision_value}")
        else:
            print(f"   ❌ Could not verify prompt")
            input("\nPress Enter to exit...")
            sys.exit(1)
            
    except Exception as e:
        print(f"   ❌ Verification error: {e}")
        input("\nPress Enter to exit...")
        sys.exit(1)

    # Done!
    print("\n" + "=" * 80)
    print("✅ CLEAN SLATE COMPLETE!")
    print("=" * 80)
    print("\nDatabase is now clean with fresh prompts")
    print("\nNext steps:")
    print("  1. Restart backend:  .\\START_SERVER.ps1")
    print("  2. Test Prompt Management UI (should see 3 examples)")
    print("  3. Test Learning Queue UI (preview should show correct schema)")
    print("\n" + "=" * 80)
    
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n❌ FATAL ERROR: {e}")
        import traceback
        traceback.print_exc()
        input("\nPress Enter to exit...")
        sys.exit(1)
