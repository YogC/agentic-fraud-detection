# 🛡️ Fraud Detection System - Setup Guide

> **AI-Powered Fraud Detection with Human-in-the-Loop Learning**

---

## 📋 Table of Contents

- [System Overview](#-system-overview)
- [Prerequisites](#-prerequisites)
- [First-Time Setup](#-first-time-setup)
- [Running the System](#-running-the-system)
- [Testing the System](#-testing-the-system)
- [Architecture Overview](#-architecture-overview)
- [Security & Compliance](#-security--compliance)
- [Troubleshooting](#-troubleshooting)
- [Documentation](#-documentation)

---

## 🏗️ System Overview

This is a **hybrid fraud detection platform** combining:
- **Rule-Based Agents** (5ms) - Detect pattern violations
- **LLM Reasoning** (600ms) - Interpret findings, detect sophisticated fraud, learn from feedback

### Key Features
- ✅ Real-time fraud detection (ALLOW/WARN/BLOCK decisions)
- ✅ Human-in-the-loop learning (SIU feedback → LLM prompt updates)
- ✅ Full audit trail (LangSmith tracing)
- ✅ Dashboard for SIU investigators
- ✅ MCP server for quick testing without database

---

## 🔧 Prerequisites

### Required Software

| Software | Version | Download Link |
|----------|---------|---------------|
| **Python** | 3.10+ | https://www.python.org/downloads/ |
| **AWS CLI** | 2.x | https://aws.amazon.com/cli/ |
| **Git** | Latest | https://git-scm.com/downloads |
| **Postman** (optional) | Latest | https://www.postman.com/downloads/ |

### Required Accounts & Credentials

1. **AWS Account** (for DynamoDB)
   - IAM user with DynamoDB permissions
   - Access Key ID and Secret Access Key

2. **LangSmith Account** (for LLM tracing)
   - Sign up at https://smith.langchain.com/
   - API Key from account settings

3. **Anthropic/OpenAI API Key** (for LLM)
   - Anthropic (Claude): https://console.anthropic.com/
   - OR OpenAI (GPT): https://platform.openai.com/

---

## 🚀 First-Time Setup

### Step 1: Clone Repository

```powershell
# Navigate to your workspace
cd "c:\YourWorkspace"

# Clone the repository (replace with your repo URL)
git clone <repository-url> "Fraud Detection"
cd "Fraud Detection\Fraud-Internal-Detection"
```

### Step 2: Create Virtual Environment

```powershell
# Create virtual environment
python -m venv venv

# Activate virtual environment
.\venv\Scripts\Activate.ps1

# If you get execution policy error, run:
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### Step 3: Install Dependencies

```powershell
# Install Python packages
pip install -r requirements.txt

# Verify installation
pip list | Select-String "fastapi|anthropic|boto3|streamlit"
```

### Step 4: Configure Environment Variables

```powershell
# Create .env file from template
Copy-Item .env.example .env

# Edit .env file with your credentials
notepad .env
```

**Required `.env` Variables:**

```bash
# AWS Configuration (DynamoDB)
AWS_ACCESS_KEY_ID=your_access_key_here
AWS_SECRET_ACCESS_KEY=your_secret_key_here
AWS_DEFAULT_REGION=us-east-1

# LangSmith Configuration (LLM Tracing)
LANGCHAIN_TRACING_V2=true
LANGCHAIN_API_KEY=your_langsmith_api_key_here
LANGCHAIN_PROJECT=fraud-detection-demo
LANGCHAIN_ENDPOINT=https://api.smith.langchain.com

# LLM Configuration (Choose ONE)
# Option 1: Anthropic Claude
ANTHROPIC_API_KEY=your_anthropic_key_here
LLM_PROVIDER=anthropic
LLM_MODEL=claude-3-sonnet-20240229

# Option 2: OpenAI GPT (alternative)
# OPENAI_API_KEY=your_openai_key_here
# LLM_PROVIDER=openai
# LLM_MODEL=gpt-4

# Application Settings
ENVIRONMENT=development
LOG_LEVEL=INFO
```

### Step 5: Initialize Database

```powershell
# Create DynamoDB tables and seed with baseline data
python CLEAN_SLATE.py

# Expected output:
# ✅ Tables created/reset
# ✅ 3 baseline prompt examples added
# ✅ System ready for testing
```

---

## 🎯 Running the System

### Option 1: Quick Testing (No Database - MCP Mode)

**Best for:** Quick validation, LLM testing, demos without AWS setup

```powershell
# Start MCP server in HTTP mode
python app\mcp\fraud_detection_server.py --http --port 8001

# Expected output:
# 🌐 HTTP/SSE Mode ENABLED
# 📡 Server URL: http://localhost:8001/sse
```

**What you get:**
- ✅ LLM fraud detection
- ✅ All 3 agents running
- ✅ LangSmith traces
- ❌ No database persistence
- ❌ No learning loop
- ❌ No dashboard

### Option 2: Full System (With Database & Learning Loop)

**Best for:** Full demos, SIU feedback testing, production-like testing

**Terminal 1: Start Backend API**
```powershell
cd "c:\Yogesh\GenAI\Fraud Detection\Fraud-Internal-Detection"
.\venv\Scripts\Activate.ps1
python -m uvicorn app.main:app --reload

# Or use the batch file:
.\start_backend.bat

# Expected output:
# INFO:     Uvicorn running on http://127.0.0.1:8000
# INFO:     Application startup complete
```

**Terminal 2: Start Dashboard**
```powershell
cd "c:\Yogesh\GenAI\Fraud Detection\SIU-Fraud-Dashboard"
.\venv\Scripts\Activate.ps1
streamlit run app.py

# Expected output:
# Local URL: http://localhost:8501
# Network URL: http://192.168.x.x:8501
```

**Verify System is Running:**
- Backend API: http://localhost:8000/docs
- Dashboard: http://localhost:8501
- Health Check: http://localhost:8000/health

---

## 🧪 Testing the System

### Quick Test (5 minutes)

**Using MCP Client:**
```powershell
# Run built-in test suite
python app\mcp\fraud_mcp_client.py

# Expected output:
# ✅ 6 tools discovered
# ✅ 4 demo examples executed
# ✅ BLOCK decision for last-mile fraud
```

### Full Test with Postman (15 minutes)

1. **Import Collection:**
   - Open Postman
   - Click **Import**
   - Select: `test-collections/Fraud_Detection_API_Tests.insomnia_collection.json`

2. **Run Test Scenarios:**
   - Navigate to: **🎬 DEMO Scenarios (Learning Loop)**
   - Run: **SETUP-001A** (seed historical data)
   - Run: **SETUP-001B** (seed more historical data)
   - Run: **DEMO-001** (bank account reuse fraud)
   - Expected Result: `WARN` (before learning)

3. **Complete Learning Loop:**
   - Open Dashboard: http://localhost:8501
   - Submit SIU feedback
   - Generate training data
   - Activate new prompt
   - Re-run DEMO-001
   - Expected Result: `BLOCK` (after learning) ✅

### Test with cURL

```powershell
# Test clean transaction (should ALLOW)
curl.exe -X POST http://localhost:8000/api/v1/payout/decision `
  -H "Content-Type: application/json" `
  -d '{
    "employee_id": "EMP-123",
    "amount": 1000.00,
    "bank_account_hash": "ba_clean_test_12345",
    "description": "Legitimate payment to vendor"
  }'

# Expected response:
# {
#   "decision": "ALLOW",
#   "confidence": 0.95,
#   "total_score": 0
# }
```

---

## 🏛️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    REQUEST FLOW                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  1. Transaction Request                                      │
│          ↓                                                   │
│  2. FastAPI Backend (Port 8000)                             │
│          ↓                                                   │
│  3. Payout Orchestrator                                     │
│          ↓                                                   │
│  4. Run 3 Agents in Parallel (5ms)                          │
│     ├── Employee Control Agent                              │
│     ├── LastMile Payment Agent                              │
│     └── Graph Entity Agent                                  │
│          ↓                                                   │
│  5. LLM Reasoning Agent (600ms)                             │
│     - Interprets agent findings                             │
│     - Makes final decision (ALLOW/WARN/BLOCK)               │
│     - Generates explanation                                 │
│          ↓                                                   │
│  6. Save to DynamoDB (if enabled)                           │
│          ↓                                                   │
│  7. Return Decision + Reasoning                             │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Components

| Component | Purpose | Technology |
|-----------|---------|------------|
| **Backend API** | HTTP endpoints for fraud detection | FastAPI (Python) |
| **Agent Layer** | Rule-based pattern detection | Python |
| **LLM Layer** | Semantic fraud detection, learning | Claude/GPT + LangChain |
| **Database** | Transaction storage, prompt versioning | DynamoDB (AWS) |
| **Dashboard** | SIU review interface, learning queue | Streamlit (Python) |
| **MCP Server** | Quick testing without database | MCP Protocol |
| **Tracing** | LLM observability, debugging | LangSmith |

---

## 🔍 Troubleshooting

### Common Issues

#### 1. **Import Error: Module not found**

```powershell
# Problem: Package not installed
# Fix:
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

#### 2. **AWS Credentials Error**

```
Error: NoCredentialsError: Unable to locate credentials
```

**Fix:**
```powershell
# Check .env file has correct AWS credentials
cat .env | Select-String "AWS_"

# Test AWS connection
aws dynamodb list-tables --region us-east-1
```

#### 3. **LangSmith Not Showing Traces**

**Fix:**
```powershell
# Check .env configuration
cat .env | Select-String "LANGCHAIN_"

# Ensure these are set:
# LANGCHAIN_TRACING_V2=true
# LANGCHAIN_API_KEY=<your-key>
```

#### 4. **Port Already in Use**

```
Error: [Errno 10048] Address already in use
```

**Fix:**
```powershell
# Find process using port 8000
netstat -ano | findstr :8000

# Kill process (replace PID with actual number)
taskkill /PID <PID> /F

# Or use different port
python -m uvicorn app.main:app --port 8001
```

#### 5. **DEMO-001 Returns ALLOW Instead of WARN**

**Problem:** Historical data not seeded

**Fix:**
```powershell
# Run setup transactions first
# In Postman: 
# - Run SETUP-001A
# - Run SETUP-001B
# - Then run DEMO-001
```

#### 6. **Dashboard Shows "No Data"**

**Problem:** Transactions not saved to database

**Fix:**
```powershell
# Option 1: Check backend is running
curl http://localhost:8000/health

# Option 2: Enable DB persistence in request
# Add to JSON payload: "save_to_db": true

# Option 3: Re-run CLEAN_SLATE.py
python CLEAN_SLATE.py
```

---

## 📚 Documentation

### For Engineers

| Document | Purpose | Location |
|----------|---------|----------|
| **This README** | Setup & getting started | `README.md` |
| **Demo Walkthrough** | Full demo script with talking points | `DEMO_WALKTHROUGH.md` |
| **API Documentation** | FastAPI auto-generated docs | http://localhost:8000/docs |
| **Postman Guide** | Postman collection usage | `test-collections/POSTMAN_COLLECTION_GUIDE.md` |
| **MCP Payloads** | MCP testing reference | `MCP_POSTMAN_PAYLOADS.md` |
| **Logging Guide** | System logging details | `docs/LOGGING_SYSTEM_GUIDE.md` |

### For Business/Demos

| Document | Purpose | Location |
|----------|---------|----------|
| **Quick Fix Guide** | Common issues during demos | `TECHNICAL_DOCUMENTATION/QUICK_FIX_GUIDE.md` |
| **Production Readiness** | Gap analysis for production | `PRODUCTION_READINESS_GAP_ANALYSIS.md` |
| **End-to-End Testing** | Testing strategy | `END_TO_END_TESTING_ANALYSIS.md` |

### Architecture Diagrams

- **System Architecture:** `Arch Digram.jpeg`
- **Original Response Flow:** `Agentic_Fraud_OriginalResponse.pdf`

---

## 🧪 Pre-Trained LLM Knowledge

### ⚠️ IMPORTANT: LLM Already Has Fraud Detection Training

The LLM (Claude/GPT) we use is **already pre-trained** on massive datasets including:

✅ **Social Engineering Patterns:**
- Phishing tactics (urgency, authority impersonation)
- Business Email Compromise (BEC) patterns
- Suspicious language ("URGENT," "bypass approval," "CEO request")

✅ **Financial Fraud Concepts:**
- Money laundering indicators
- Shell company patterns
- Invoice fraud schemes
- Payment redirection fraud

✅ **General Fraud Knowledge:**
- Common fraud types across industries
- Red flag indicators
- Risk assessment frameworks

### What This Means for Our System

**Our system leverages this pre-trained knowledge by:**

1. **Agent Detection (Rule-Based)** → Finds structural violations
   - Example: Employee Control Agent detects same person approving + releasing

2. **LLM Interpretation (Semantic)** → Applies pre-trained fraud knowledge
   - Example: LLM sees "URGENT CEO REQUEST - BYPASS APPROVAL" and flags as social engineering

3. **Human Feedback (Fine-Tuning)** → Teaches organization-specific patterns
   - Example: SIU teaches "3 employees → same account → fraud ring" pattern

### Demo Talking Point

> **SAY:** "The LLM brings built-in fraud expertise from training on millions of fraud cases. Our rule-based agents catch the structural violations, and the LLM applies its semantic understanding to interpret context, tone, and language patterns that rules can't detect. Then through our learning loop, we teach it YOUR organization's specific fraud patterns and policies."

### Example: Social Engineering Detection

**Without Our Agents (LLM Only):**
```json
{
  "description": "URGENT! CEO needs immediate payment to new vendor. Skip approval process.",
  "amount": 50000
}
```
→ LLM flags: "Social engineering - urgency + authority bypass" (pre-trained knowledge)

**With Our Agents + LLM:**
```json
{
  "employee_id": "EMP-123",
  "description": "Payment to ABC Services",
  "amount": 8500,
  "bank_account_hash": "ba_fraud_ring_account"
}
```
→ Graph Agent detects: "3rd employee to this account" (rule-based)  
→ LLM interprets: "Collusion fraud ring" (pre-trained) + "Learned pattern from SIU" (our training)  
→ Decision: **BLOCK with high confidence**

---

## 🚀 Quick Start Checklist

Use this checklist for your first setup:

```
□ Python 3.10+ installed
□ Virtual environment created and activated
□ Dependencies installed (pip install -r requirements.txt)
□ .env file configured with all keys
□ AWS credentials tested
□ DynamoDB tables created (python CLEAN_SLATE.py)
□ Backend running (http://localhost:8000/docs)
□ Dashboard running (http://localhost:8501)
□ LangSmith showing traces
□ Postman collection imported
□ DEMO-001 test successful (WARN → BLOCK)
```

---

## 🤝 Contributing

### Making Code Changes

1. Create feature branch: `git checkout -b feature/your-feature`
2. Make changes
3. Test locally (run all demo scenarios)
4. Commit: `git commit -m "feat: your feature description"`
5. Push: `git push origin feature/your-feature`
6. Create Pull Request

### Testing Before Commit

```powershell
# Run quick validation
python app\mcp\fraud_mcp_client.py

# Run full test suite (if exists)
pytest tests/

# Check linting
flake8 app/
```

---

## � Security & Compliance

**IMPORTANT:** This system handles sensitive financial and personal data. Security is paramount.

### 🛡️ Implemented Security Features

| Feature | Status | Details |
|---------|--------|---------|
| **PII Sanitization** | ✅ Active | SSN, account numbers redacted before external transmission |
| **Encryption** | ✅ Active | TLS 1.3 in transit, AES-256 at rest (AWS managed) |
| **Audit Logging** | ✅ Active | Every decision logged in `logs/audit/` |
| **Explainable AI** | ✅ Active | Natural language reasoning for all decisions |
| **Prompt Versioning** | ✅ Active | Full audit trail of LLM changes |

### 📄 Security Documentation

> **COMPLETE SECURITY GUIDE:** See [`SECURITY_AND_COMPLIANCE_SUMMARY.md`](./SECURITY_AND_COMPLIANCE_SUMMARY.md)

This guide covers:
- Encryption and data protection
- PII sanitization implementation (with code references)
- Complete audit trail system
- Regulatory compliance (SOX, GDPR, PCI-DSS, HIPAA)
- Role-based access control
- Incident response procedures
- Production security recommendations

### 🚨 Security Best Practices

**For Development:**
- ✅ Never commit `.env` files to Git
- ✅ Use read-only AWS credentials for testing
- ✅ Review audit logs regularly (`logs/audit/`)
- ✅ Validate PII sanitization before external tracing

**For Production:**
- ⚠️ Add authentication (AWS Cognito/OAuth2)
- ⚠️ Enable API rate limiting (AWS API Gateway)
- ⚠️ Use AWS Secrets Manager (not .env files)
- ⚠️ Enable CloudWatch log aggregation
- ⚠️ Conduct security audit (SOC2 Type II)

**Compliance Contacts:**
- Security questions → System administrator
- Audit requests → Review `logs/audit/` directory
- Incident response → Escalate to security team

---

## �📞 Support & Resources

### Getting Help

1. **Check Documentation:** Start with `DEMO_WALKTHROUGH.md` and `QUICK_FIX_GUIDE.md`
2. **Review Logs:** Check `logs/` directory for error details
3. **LangSmith Traces:** Debug LLM behavior at https://smith.langchain.com/
4. **Team Contact:** [Your team contact info]

### External Resources

- **FastAPI Docs:** https://fastapi.tiangolo.com/
- **LangChain Docs:** https://python.langchain.com/
- **Claude API:** https://docs.anthropic.com/
- **MCP Protocol:** https://modelcontextprotocol.io/

---

## 📝 Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-02-01 | Initial system with 3 agents + LLM |
| 1.1 | 2026-02-10 | Added MCP server for quick testing |
| 1.2 | 2026-02-11 | Added Postman collection |
| 1.3 | 2026-02-12 | Added comprehensive README |

---

## 🎓 Next Steps

After successful setup:

1. **Run Demo Scenarios:** Follow `DEMO_WALKTHROUGH.md` for full walkthrough
2. **Complete Learning Loop:** Submit feedback, update prompts, verify improvement
3. **Explore Customization:** Add new agents, modify prompt templates
4. **Production Planning:** Review `PRODUCTION_READINESS_GAP_ANALYSIS.md`

---

**Welcome to the team! 🎉**

**Last Updated:** February 12, 2026  
**Maintainer:** [Your Name/Team]
