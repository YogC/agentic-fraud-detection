@echo off
echo ========================================
echo Starting Fraud Detection Backend API
echo ========================================
echo.

REM Activate virtual environment
echo Activating virtual environment...
call venv\Scripts\activate.bat
if errorlevel 1 (
    echo ERROR: Failed to activate virtual environment
    echo Please ensure venv exists by running: python -m venv venv
    pause
    exit /b 1
)

echo.
echo Environment: Virtual environment activated
echo Server: http://localhost:8000
echo API Docs: http://localhost:8000/docs
echo Metrics: http://localhost:8000/metrics
echo.
echo LangSmith tracing is enabled (check .env file for configuration)
echo.

REM Start the server from the app directory
cd app
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
