# LLM Integration & Observability Guide 🔧

## Table of Contents
1. [Overview](#overview)
2. [LLM Integration Architecture](#llm-integration-architecture)
3. [AWS Bedrock Configuration](#aws-bedrock-configuration)
4. [LangSmith Tracing & Observability](#langsmith-tracing--observability)
5. [Logging Patterns & Best Practices](#logging-patterns--best-practices)
6. [Prompt Management System](#prompt-management-system)
7. [Token Usage & Cost Tracking](#token-usage--cost-tracking)
8. [Security & Compliance](#security--compliance)
9. [Troubleshooting & Debugging](#troubleshooting--debugging)

---

## Overview

The Fraud Detection System uses **AWS Bedrock** (Claude 3.5 Sonnet) for advanced contextual fraud analysis, complemented by **LangSmith** for observability and comprehensive logging patterns for audit compliance.

### System Components

```
┌──────────────────────────────────────────────────────────────┐
│  FRAUD DETECTION LLM PIPELINE                                 │
└──────────────────────────────────────────────────────────────┘
                         ↓
┌──────────────────────────────────────────────────────────────┐
│  1. RULE-BASED AGENTS (Fast Execution)                        │
│  ├─ Employee Control Agent                                   │
│  ├─ Graph Entity Agent                                       │
│  └─ Last Mile Payment Agent                                  │
│                                                                │
│  Result: Initial risk assessment (LOW/MED/HIGH)              │
└──────────────────────────────────────────────────────────────┘
                         ↓
┌──────────────────────────────────────────────────────────────┐
│  2. LLM REASONING AGENT (Contextual Analysis)                │
│                                                                │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ A. Prompt Service (DynamoDB)                           │ │
│  │    ├─ Load active prompt template                      │ │
│  │    ├─ Version control                                  │ │
│  │    └─ A/B testing support                              │ │
│  └────────────────────────────────────────────────────────┘ │
│                         ↓                                      │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ B. Data Sanitization (Compliance)                      │ │
│  │    ├─ Redact PII (SSN, account numbers)               │ │
│  │    ├─ Mask sensitive IDs                               │ │
│  │    └─ Preserve context for analysis                    │ │
│  └────────────────────────────────────────────────────────┘ │
│                         ↓                                      │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ C. AWS Bedrock API Call (Claude 3.5 Sonnet)           │ │
│  │    ├─ Formatted prompt with transaction context       │ │
│  │    ├─ LangSmith tracing enabled                        │ │
│  │    └─ Token usage tracking                             │ │
│  └────────────────────────────────────────────────────────┘ │
│                         ↓                                      │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ D. Response Parsing & Validation                       │ │
│  │    ├─ Extract structured JSON                          │ │
│  │    ├─ Validate required fields                         │ │
│  │    └─ Normalize risk levels                            │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                                │
│  Result: LLM risk assessment + reasoning + confidence         │
└──────────────────────────────────────────────────────────────┘
                         ↓
┌──────────────────────────────────────────────────────────────┐
│  3. RISK AGGREGATION & DECISION                              │
│  ├─ Combine agent + LLM signals                              │
│  ├─ LLM high-confidence override logic                       │
│  └─ Generate final decision (ALLOW/WARN/BLOCK)               │
└──────────────────────────────────────────────────────────────┘
                         ↓
┌──────────────────────────────────────────────────────────────┐
│  4. OBSERVABILITY & AUDIT LOGGING                            │
│  ├─ LangSmith trace (visual debugging)                       │
│  ├─ Structured logs (audit trail)                            │
│  ├─ Prometheus metrics (performance)                         │
│  └─ DynamoDB storage (compliance)                            │
└──────────────────────────────────────────────────────────────┘
```

---

## LLM Integration Architecture

### Core Components

#### 1. LLM Reasoning Agent (Facade)
**File**: `app/agents/llm_reasoning_agent.py`

```python
class LLMReasoningAgent:
    """
    Facade for LLM-based fraud detection.
    Delegates to BedrockLLMAgent for actual API calls.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize with AWS Bedrock backend.
        Falls back gracefully if Bedrock unavailable.
        """
        self.name = "llm_reasoning_agent"
        self.using_mock = False
        self.enabled = False
        
        try:
            self.bedrock_agent = BedrockLLMAgent(config)
            self.enabled = True
            logger.info("✅ LLM BACKEND ACTIVE: AWS Bedrock (Claude 3.5 Sonnet)")
        except Exception as e:
            logger.error(f"❌ Bedrock initialization failed: {e}")
            self.bedrock_agent = None
            self.enabled = False
            logger.warning("⚠️ LLM AGENT DISABLED - Continuing with rule-based agents only")
    
    async def analyze(
        self,
        agent_results: Dict[str, Any],
        rule_score: int,
        rule_decision: str,
        reasons: list,
        evidence: Dict[str, Any],
        transaction_data: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """
        Analyze transaction using LLM.
        Returns None if LLM unavailable (orchestrator handles gracefully).
        """
        if not self.bedrock_agent:
            logger.warning("LLM agent not available - skipping LLM analysis")
            return None
        
        llm_input = {
            'agent_results': agent_results or {},
            'rule_score': rule_score,
            'rule_decision': rule_decision,
            'reasons': reasons or [],
            'evidence': evidence or {},
            'context': transaction_data or {}
        }
        
        return await self.bedrock_agent.analyze(llm_input)
```

**Key Design Decisions**:
- ✅ **Graceful Degradation**: System works without LLM (rule-based fallback)
- ✅ **Clear Logging**: Explicit messages about LLM status
- ✅ **Facade Pattern**: Separates interface from implementation

---

#### 2. Bedrock LLM Agent (Implementation)
**File**: `app/agents/bedrock_llm_agent.py`

```python
class BedrockLLMAgent:
    """AWS Bedrock integration for Claude 3.5 Sonnet fraud detection."""
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize Bedrock client with configuration."""
        self.model_id = config.get('model_id', 
            'anthropic.claude-3-5-sonnet-20240620-v1:0')
        self.region = config.get('region', 'us-east-1')
        self.max_tokens = config.get('max_tokens', 2048)
        self.temperature = config.get('temperature', 0.3)
        
        # Token tracking for cost management
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.total_requests = 0
        
        # Initialize prompt service (DynamoDB-backed)
        self.prompt_service = PromptService()
        
        # Configure LangSmith tracing
        self._configure_langsmith()
        
        # Initialize Bedrock client
        self.bedrock_client = boto3.client(
            service_name='bedrock-runtime',
            region_name=self.region
        )
        
        logger.info(f"Bedrock LLM initialized: {self.model_id} | region={self.region}")
        if LANGSMITH_AVAILABLE:
            logger.info("✅ LangSmith tracing enabled")
```

**Key Features**:
- ✅ **Model Configuration**: Flexible model selection (Claude 3.5 Sonnet default)
- ✅ **Token Tracking**: Built-in cost monitoring
- ✅ **Prompt Service Integration**: Centralized prompt management
- ✅ **LangSmith Support**: Automatic tracing when available

---

### Integration Flow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│  Transaction Arrives at API Endpoint                         │
└─────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────┐
│  PayoutOrchestrator.analyze_transaction()                   │
│  ├─ Run rule-based agents (parallel)                        │
│  ├─ Aggregate initial risk assessment                       │
│  └─ Prepare LLM context                                     │
└─────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────┐
│  LLMReasoningAgent.analyze()                                │
│  ├─ Check if LLM enabled                                    │
│  ├─ Build comprehensive input payload                       │
│  └─ Delegate to BedrockLLMAgent                             │
└─────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────┐
│  BedrockLLMAgent.analyze()                                  │
│  ├─ Sanitize data (remove PII)                              │
│  ├─ Load prompt template (DynamoDB)                         │
│  ├─ Format prompt with context                              │
│  ├─ Call AWS Bedrock API (with LangSmith tracing)           │
│  ├─ Parse response (extract JSON)                           │
│  ├─ Validate and normalize output                           │
│  └─ Track token usage & cost                                │
└─────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────┐
│  Return to PayoutOrchestrator                               │
│  ├─ Combine LLM result with agent results                   │
│  ├─ Apply risk aggregation logic                            │
│  └─ Generate final decision                                 │
└─────────────────────────────────────────────────────────────┘
```

---

## AWS Bedrock Configuration

### Environment Setup

#### Required Environment Variables

```bash
# AWS Credentials (use IAM role in production)
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=secret...
AWS_DEFAULT_REGION=us-east-1

# Bedrock Configuration
BEDROCK_MODEL_ID=anthropic.claude-3-5-sonnet-20240620-v1:0
BEDROCK_MAX_TOKENS=2048
BEDROCK_TEMPERATURE=0.3

# Optional: LangSmith Tracing
LANGCHAIN_TRACING_V2=true
LANGCHAIN_API_KEY=ls__...
LANGCHAIN_PROJECT=fraud-detection-prod
```

---

### Bedrock API Request Format

```python
# Request structure sent to Bedrock
request_body = {
    "anthropic_version": "bedrock-2023-05-31",
    "max_tokens": 2048,
    "temperature": 0.3,
    "messages": [
        {
            "role": "user",
            "content": formatted_prompt
        }
    ]
}

# Invoke Bedrock model
response = bedrock_client.invoke_model(
    modelId='anthropic.claude-3-5-sonnet-20240620-v1:0',
    contentType='application/json',
    accept='application/json',
    body=json.dumps(request_body)
)
```

---

### Response Parsing

```python
# Claude response format
{
    "id": "msg_01ABC123...",
    "type": "message",
    "role": "assistant",
    "content": [
        {
            "type": "text",
            "text": "```json\n{\"risk_level\": \"HIGH\", ...}\n```"
        }
    ],
    "model": "claude-3-5-sonnet-20240620",
    "stop_reason": "end_turn",
    "usage": {
        "input_tokens": 1245,
        "output_tokens": 187
    }
}

# Parsed into structured format
{
    "risk_level": "HIGH",
    "confidence": 0.92,
    "recommendation": "BLOCK",
    "reasoning": "Detected phishing script pattern...",
    "fraud_indicators": ["Phishing", "Urgency manipulation"],
    "token_usage": {
        "input_tokens": 1245,
        "output_tokens": 187,
        "total_tokens": 1432,
        "cost_usd": 0.0429  # Calculated based on Bedrock pricing
    }
}
```

---

### Cost Calculation

```python
def _calculate_cost(self, input_tokens: int, output_tokens: int) -> float:
    """
    Calculate cost for Claude 3.5 Sonnet on Bedrock.
    
    Pricing (as of Feb 2026):
    - Input:  $0.003 per 1K tokens
    - Output: $0.015 per 1K tokens
    """
    input_cost = (input_tokens / 1000.0) * 0.003
    output_cost = (output_tokens / 1000.0) * 0.015
    return input_cost + output_cost

# Example: 1,245 input + 187 output tokens
# Cost = (1245/1000 * $0.003) + (187/1000 * $0.015)
# Cost = $0.003735 + $0.002805 = $0.00654
```

---

## LangSmith Tracing & Observability

### What is LangSmith?

**LangSmith** is a platform for debugging, testing, and monitoring LLM applications. It provides:
- 📊 **Visual trace trees** (see execution flow)
- ⏱️ **Latency tracking** (identify bottlenecks)
- 💰 **Token/cost monitoring** (control spending)
- 🔍 **Prompt/response inspection** (debug issues)
- 📈 **A/B test comparison** (optimize prompts)

---

### Installation & Setup

```bash
# Install LangSmith client
pip install langsmith>=0.1.0

# Set environment variables
export LANGCHAIN_TRACING_V2=true
export LANGCHAIN_API_KEY=ls__your-api-key-here
export LANGCHAIN_PROJECT=fraud-detection-prod
```

---

### Code Implementation

#### 1. Import LangSmith Decorators

```python
# app/agents/bedrock_llm_agent.py
try:
    from langsmith import traceable
    from langsmith.run_helpers import get_current_run_tree
    LANGSMITH_AVAILABLE = True
except ImportError:
    LANGSMITH_AVAILABLE = False
    logger.warning("LangSmith not available. Install with: pip install langsmith")
```

---

#### 2. Apply @traceable Decorator

```python
@traceable(
    name="fraud_detection_llm_analysis",
    run_type="llm",
    tags=["fraud-detection", "bedrock", "claude-3.5-sonnet"]
)
async def _analyze_with_tracing(self, llm_input: Dict[str, Any]) -> Dict[str, Any]:
    """
    Main analysis method with LangSmith tracing.
    Creates a trace tree with metadata, inputs, and outputs.
    """
    try:
        # Get current run tree for adding metadata
        run_tree = get_current_run_tree()
        
        # Extract context (sanitized)
        context = llm_input.get('context', {})
        event_type = context.get('event_type', 'PAYMENT_FRAUD')
        transaction_id = context.get('transaction_id', 'unknown')
        amount = context.get('payment_amount', 0)
        
        # Add metadata to trace (NO PII)
        if run_tree:
            masked_txn_id = f"{transaction_id[:3]}...{transaction_id[-3:]}"
            
            run_tree.add_metadata({
                "event_id": masked_txn_id,  # Masked transaction ID
                "event_type": event_type,
                "amount": amount,
                "vendor_name": context.get('vendor_name', 'N/A'),
                "model_id": self.model_id,
                "temperature": self.temperature,
                "data_sanitized": True  # Flag for compliance
            })
        
        # Perform Bedrock API call
        result = await self._perform_analysis(llm_input, event_type)
        
        # Add outputs to trace
        if run_tree:
            run_tree.add_outputs({
                "decision": result.get('recommendation', 'N/A'),
                "confidence": result.get('confidence', 0.0),
                "risk_level": result.get('risk_level', 'N/A'),
                "reasoning": result.get('reasoning', 'N/A')[:500],  # Truncate
                "token_usage": result.get('token_usage', {}),
                "cost_usd": result.get('token_usage', {}).get('cost_usd', 0.0)
            })
        
        return result
        
    except Exception as e:
        logger.error(f"Error in traced analysis: {e}")
        return self._create_fallback_response(str(e))
```

---

#### 3. Data Sanitization for Tracing

```python
def _sanitize_for_tracing(self, data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Remove PII/PCI data before sending to LangSmith.
    Critical for GDPR/CCPA compliance.
    """
    # Fields to completely redact
    pii_fields = {
        'bank_account_hash', 'routing_hash', 'bank_account_number',
        'routing_number', 'ssn', 'employee_id', 'claimant_id',
        'account_number', 'card_number', 'cvv'
    }
    
    # Fields to mask (show first/last few chars)
    mask_fields = {
        'transaction_id', 'payment_id', 'claim_id'
    }
    
    sanitized = {}
    for key, value in data.items():
        if key in pii_fields:
            sanitized[key] = "[REDACTED]"
        elif key in mask_fields and isinstance(value, str) and len(value) > 8:
            sanitized[key] = f"{value[:3]}...{value[-3:]}"
        elif isinstance(value, dict):
            sanitized[key] = self._sanitize_for_tracing(value)
        elif isinstance(value, list):
            sanitized[key] = [
                self._sanitize_for_tracing(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            sanitized[key] = value
    
    return sanitized
```

**Why Sanitization Matters**:
- ❌ **Without sanitization**: PII sent to LangSmith (compliance violation)
- ✅ **With sanitization**: Only metadata sent (compliance-safe)
- 🔍 **Result**: Full observability without privacy risk

---

### LangSmith Trace Example

When you run the system with LangSmith enabled, you'll see traces like this:

```
fraud_detection_llm_analysis (1.2s)
├─ Metadata:
│  ├─ event_id: TXN...789 (masked)
│  ├─ event_type: PAYMENT_FRAUD
│  ├─ amount: 45000
│  ├─ model_id: claude-3.5-sonnet
│  └─ data_sanitized: true
│
├─ Inputs:
│  ├─ agent_results: {employee_control: MED, graph_entity: HIGH, ...}
│  ├─ rule_score: 7.5
│  └─ context: {vendor_name: "Acme Corp", ...}
│
├─ AWS Bedrock API Call (1.1s)
│  ├─ prompt_tokens: 1245
│  ├─ completion_tokens: 187
│  └─ cost: $0.00654
│
└─ Outputs:
   ├─ decision: BLOCK
   ├─ confidence: 0.92
   ├─ risk_level: HIGH
   ├─ reasoning: "Detected CEO impersonation (BEC attack)..."
   └─ token_usage: {total: 1432, cost_usd: 0.00654}
```

**Benefits**:
- 🐛 **Debug failures**: See exact prompt/response
- ⏱️ **Identify slow calls**: Find API latency issues
- 💰 **Control costs**: Track token usage per transaction
- 📊 **Compare prompts**: A/B test different templates

---

## Logging Patterns & Best Practices

### Logging Architecture

The system uses **Python's standard logging** module with structured patterns for different purposes:

```
┌─────────────────────────────────────────────────────────────┐
│  LOGGING LAYERS                                              │
└─────────────────────────────────────────────────────────────┘

Layer 1: APPLICATION LOGS (stdout/stderr)
├─ Purpose: Real-time debugging & monitoring
├─ Format: Timestamp | Logger | Level | Message
├─ Destination: Console, log files
└─ Retention: 7 days (rotated)

Layer 2: AUDIT LOGS (DynamoDB)
├─ Purpose: Compliance & regulatory audit trail
├─ Format: Structured JSON with immutable timestamps
├─ Destination: DynamoDB table (fraud_detection_audit)
└─ Retention: 7 years (SOX/GDPR compliance)

Layer 3: PERFORMANCE METRICS (Prometheus)
├─ Purpose: System health & SLA monitoring
├─ Format: Time-series metrics (counters, histograms)
├─ Destination: Prometheus → Grafana dashboards
└─ Retention: 90 days

Layer 4: TRACE LOGS (LangSmith)
├─ Purpose: LLM debugging & optimization
├─ Format: Hierarchical trace trees with metadata
├─ Destination: LangSmith platform
└─ Retention: 30 days
```

---

### Application Logging Patterns

#### 1. Startup Logging

```python
# app/main.py
def startup():
    logger.info("=" * 60)
    logger.info("=== Payout Fraud Detection API (PEP) Starting ===")
    logger.info("=" * 60)
    logger.info("Architecture: Policy Enforcement Point (PEP)")
    logger.info("Agents: Employee Control, Last-Mile Payment, Graph Entity")
    logger.info("Features: Audit Logging, Performance Monitoring, Cost Tracking")
    logger.info("Observability: Prometheus metrics at /metrics")
    logger.info("=" * 60)
```

**Output**:
```
2026-02-07 10:30:00 - __main__ - INFO - ============================================================
2026-02-07 10:30:00 - __main__ - INFO - === Payout Fraud Detection API (PEP) Starting ===
2026-02-07 10:30:00 - __main__ - INFO - ============================================================
2026-02-07 10:30:00 - __main__ - INFO - Architecture: Policy Enforcement Point (PEP)
2026-02-07 10:30:00 - __main__ - INFO - Agents: Employee Control, Last-Mile Payment, Graph Entity
2026-02-07 10:30:00 - __main__ - INFO - Features: Audit Logging, Performance Monitoring, Cost Tracking
2026-02-07 10:30:00 - __main__ - INFO - Observability: Prometheus metrics at /metrics
2026-02-07 10:30:00 - __main__ - INFO - ============================================================
```

---

#### 2. LLM Status Logging

```python
# app/agents/llm_reasoning_agent.py
logger.info("="*70)
logger.info(">>> LLM BACKEND ACTIVE: AWS Bedrock (Claude 3.5 Sonnet) <<<")
logger.info(">>> NOT using Mock agent <<<")
logger.info("="*70)
```

**Output**:
```
2026-02-07 10:30:01 - llm_reasoning_agent - INFO - ======================================================================
2026-02-07 10:30:01 - llm_reasoning_agent - INFO - >>> LLM BACKEND ACTIVE: AWS Bedrock (Claude 3.5 Sonnet) <<<
2026-02-07 10:30:01 - llm_reasoning_agent - INFO - >>> NOT using Mock agent <<<
2026-02-07 10:30:01 - llm_reasoning_agent - INFO - ======================================================================
```

---

#### 3. Transaction Processing Logging

```python
# app/main.py
logger.info(
    f"[PEP] Payment decision request intercepted - "
    f"Claim: {claim_id}, Payment: {payment_id}, Actor: {actor_id}"
)
```

**Output**:
```
2026-02-07 10:35:42 - main - INFO - [PEP] Payment decision request intercepted - Claim: CLM-2024-5001, Payment: PAY-2024-1234, Actor: EMP-789
```

---

#### 4. Agent Execution Logging

```python
# app/agents/employee_control_agent.py
logger.info(f"{self.name}: Analyzing control concentration")
logger.info(
    f"{self.name}: Detected {control_count} control actions "
    f"(Risk: {risk_level}, Score: {score:.2f})"
)
```

**Output**:
```
2026-02-07 10:35:43 - employee_control_agent - INFO - employee_control_agent: Analyzing control concentration
2026-02-07 10:35:43 - employee_control_agent - INFO - employee_control_agent: Detected 2 control actions (Risk: MED, Score: 5.50)
```

---

#### 5. LLM API Call Logging

```python
# app/agents/bedrock_llm_agent.py
logger.info(
    f"LLM call: {event_type} | "
    f"prompt_v{prompt_version} | "
    f"tokens: {input_tokens}+{output_tokens} | "
    f"cost: ${cost:.4f}"
)
```

**Output**:
```
2026-02-07 10:35:44 - bedrock_llm_agent - INFO - LLM call: PAYMENT_FRAUD | prompt_v2.1 | tokens: 1245+187 | cost: $0.0065
```

---

#### 6. Error Logging

```python
# app/agents/bedrock_llm_agent.py
logger.error(f"❌ Failed to initialize Bedrock agent: {e}")
logger.warning("⚠️ LLM AGENT DISABLED - Continuing with rule-based agents only")
```

**Output**:
```
2026-02-07 10:30:01 - bedrock_llm_agent - ERROR - ❌ Failed to initialize Bedrock agent: InvalidAccessKeyId
2026-02-07 10:30:01 - bedrock_llm_agent - WARNING - ⚠️ LLM AGENT DISABLED - Continuing with rule-based agents only
```

---

### Structured Logging Best Practices

#### ✅ DO: Use Consistent Prefixes

```python
# Good: Clear agent identification
logger.info(f"[PEP] Payment decision request intercepted - Claim: {claim_id}")
logger.info(f"{self.name}: Analyzing control concentration")

# Bad: No context
logger.info(f"Processing claim {claim_id}")
```

---

#### ✅ DO: Include Key Identifiers

```python
# Good: Transaction ID + key metrics
logger.info(
    f"Transaction {txn_id} | Decision: {decision} | "
    f"Risk: {risk_level} | Confidence: {confidence:.2f}"
)

# Bad: Generic message
logger.info("Transaction processed successfully")
```

---

#### ✅ DO: Log Performance Metrics

```python
# Good: Track execution time
start_time = time.time()
result = await agent.execute(data)
elapsed = time.time() - start_time
logger.info(f"Agent execution: {agent_name} | time: {elapsed:.3f}s")

# Bad: No timing info
result = await agent.execute(data)
logger.info("Agent completed")
```

---

#### ✅ DO: Use Appropriate Log Levels

```python
# INFO: Normal operations
logger.info("LLM analysis complete")

# WARNING: Non-critical issues
logger.warning("LLM unavailable, using rule-based fallback")

# ERROR: Critical failures
logger.error("Failed to save audit log to DynamoDB")

# DEBUG: Detailed diagnostic info
logger.debug(f"Prompt sent to LLM: {prompt[:100]}...")
```

---

#### ❌ DON'T: Log Sensitive Data

```python
# BAD: Exposes PII
logger.info(f"Processing SSN: {ssn}")
logger.info(f"Bank account: {account_number}")

# GOOD: Mask sensitive data
masked_ssn = f"XXX-XX-{ssn[-4:]}"
logger.info(f"Processing SSN: {masked_ssn}")
```

---

### Log Rotation Configuration

```python
# app/utils/logging_config.py
import logging
from logging.handlers import RotatingFileHandler

def setup_logging():
    """Configure rotating file handler for application logs."""
    
    # Create logs directory
    os.makedirs('./logs', exist_ok=True)
    
    # Configure rotating file handler
    handler = RotatingFileHandler(
        filename='./logs/fraud_detection.log',
        maxBytes=10 * 1024 * 1024,  # 10 MB per file
        backupCount=5,  # Keep 5 backup files
        encoding='utf-8'
    )
    
    # Set format
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    handler.setFormatter(formatter)
    
    # Add to root logger
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.addHandler(handler)
```

**Result**:
- `fraud_detection.log` (current log)
- `fraud_detection.log.1` (previous)
- `fraud_detection.log.2` (older)
- ... up to `fraud_detection.log.5`

---

## Prompt Management System

### DynamoDB-Backed Prompt Service

The system uses a **centralized prompt management system** stored in DynamoDB for:
- ✅ **Version control**: Track prompt changes over time
- ✅ **A/B testing**: Deploy multiple prompt versions
- ✅ **Hot reload**: Update prompts without code deployment
- ✅ **Audit trail**: See who changed what, when

---

### Prompt Service Architecture

```python
# app/services/prompt_service.py
class PromptService:
    """
    Centralized prompt management with DynamoDB backend.
    Handles loading, versioning, and formatting of LLM prompts.
    """
    
    def __init__(self):
        self.repository = PromptRepository()
    
    async def format_prompt_for_llm(
        self, 
        event_type: str, 
        transaction_data: Dict[str, Any]
    ) -> Dict[str, str]:
        """
        Load active prompt template for event type and format with data.
        
        Args:
            event_type: Type of fraud event (PAYMENT_FRAUD, BEC_ATTACK, etc.)
            transaction_data: Transaction context to inject into prompt
        
        Returns:
            {
                'system': 'System prompt with instructions',
                'prompt_version': '2.1',
                'prompt_id': 'PAYMENT_FRAUD_v2.1'
            }
        """
        # Load active prompt from DynamoDB
        prompt_data = await self.repository.get_active_prompt(event_type)
        
        if not prompt_data:
            logger.warning(f"No active prompt for {event_type}, using default")
            return self._get_default_prompt(event_type)
        
        # Extract template
        system_prompt = prompt_data.get('system_prompt', '')
        prompt_version = prompt_data.get('version', 'unknown')
        
        logger.info(
            f"[PROMPT_SERVICE] Loaded prompt: {event_type} v{prompt_version}"
        )
        
        return {
            'system': system_prompt,
            'prompt_version': prompt_version,
            'prompt_id': f"{event_type}_v{prompt_version}"
        }
```

---

### DynamoDB Prompt Schema

```python
# Table: fraud_detection_prompts
{
    "PK": "PAYMENT_FRAUD",  # Event type
    "SK": "v2.1",  # Version
    "system_prompt": "You are an expert fraud investigator...",
    "is_active": True,  # Active version flag
    "created_at": "2026-02-07T10:00:00Z",
    "created_by": "admin@company.com",
    "test_cases": [
        {"input": "...", "expected_output": "..."}
    ],
    "performance_metrics": {
        "precision": 0.94,
        "recall": 0.89,
        "avg_tokens": 1250
    }
}
```

---

### Prompt Versioning Example

```python
# Load active prompt (returns v2.1)
prompt_v2_1 = await prompt_service.get_active_prompt("PAYMENT_FRAUD")

# A/B test: Load specific version
prompt_v2_0 = await prompt_service.get_prompt_by_version("PAYMENT_FRAUD", "v2.0")

# Activate new version (hot swap, no code deployment needed)
await prompt_service.activate_prompt("PAYMENT_FRAUD", "v2.2")
```

**Benefits**:
- ✅ **No code deployment** for prompt changes
- ✅ **Instant rollback** if new prompt performs poorly
- ✅ **A/B testing** to optimize prompt performance
- ✅ **Audit trail** of all prompt changes

---

## Token Usage & Cost Tracking

### Real-Time Token Tracking

```python
# app/agents/bedrock_llm_agent.py
class BedrockLLMAgent:
    def __init__(self, config):
        # Initialize token counters
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.total_requests = 0
    
    def _calculate_cost(self, input_tokens: int, output_tokens: int) -> float:
        """Calculate cost based on Claude 3.5 Sonnet pricing."""
        # Bedrock Claude 3.5 Sonnet pricing (Feb 2026)
        INPUT_COST_PER_1K = 0.003  # $0.003 per 1K input tokens
        OUTPUT_COST_PER_1K = 0.015  # $0.015 per 1K output tokens
        
        input_cost = (input_tokens / 1000.0) * INPUT_COST_PER_1K
        output_cost = (output_tokens / 1000.0) * OUTPUT_COST_PER_1K
        
        return input_cost + output_cost
    
    async def _perform_analysis(self, llm_input, event_type):
        """Perform LLM analysis and track token usage."""
        # ... API call ...
        
        # Extract token usage from response
        usage = response_body.get('usage', {})
        input_tokens = usage.get('input_tokens', 0)
        output_tokens = usage.get('output_tokens', 0)
        
        # Calculate cost
        cost = self._calculate_cost(input_tokens, output_tokens)
        
        # Update running totals
        self.total_input_tokens += input_tokens
        self.total_output_tokens += output_tokens
        self.total_requests += 1
        
        # Log token usage
        logger.info(
            f"LLM tokens: {input_tokens} in + {output_tokens} out | "
            f"cost: ${cost:.4f} | "
            f"total_requests: {self.total_requests}"
        )
        
        # Include in response
        result['token_usage'] = {
            'input_tokens': input_tokens,
            'output_tokens': output_tokens,
            'total_tokens': input_tokens + output_tokens,
            'cost_usd': round(cost, 6)
        }
        
        return result
```

---

### Cost Monitoring Dashboard

```python
# app/utils/monitoring.py
class CostMonitor:
    """Track LLM costs and generate reports."""
    
    def get_cost_summary(self) -> Dict[str, Any]:
        """Generate cost summary for current session."""
        return {
            'total_requests': self.total_requests,
            'total_input_tokens': self.total_input_tokens,
            'total_output_tokens': self.total_output_tokens,
            'total_tokens': self.total_input_tokens + self.total_output_tokens,
            'total_cost_usd': self.calculate_total_cost(),
            'avg_cost_per_request': self.calculate_total_cost() / max(self.total_requests, 1),
            'avg_tokens_per_request': (self.total_input_tokens + self.total_output_tokens) / max(self.total_requests, 1)
        }
```

**Output**:
```json
{
    "total_requests": 1247,
    "total_input_tokens": 1552350,
    "total_output_tokens": 233128,
    "total_tokens": 1785478,
    "total_cost_usd": 8.15,
    "avg_cost_per_request": 0.0065,
    "avg_tokens_per_request": 1432
}
```

---

## Security & Compliance

### Data Sanitization

```python
def _sanitize_for_tracing(self, data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Remove PII before sending to external services (LangSmith).
    Compliance: GDPR, CCPA, PCI DSS.
    """
    # Fields to redact completely
    pii_fields = {
        'ssn', 'bank_account_number', 'routing_number',
        'card_number', 'cvv', 'employee_id', 'claimant_id'
    }
    
    # Fields to mask (show partial)
    mask_fields = {
        'transaction_id', 'payment_id', 'claim_id'
    }
    
    sanitized = {}
    for key, value in data.items():
        if key in pii_fields:
            sanitized[key] = "[REDACTED]"
        elif key in mask_fields and len(value) > 8:
            sanitized[key] = f"{value[:3]}...{value[-3:]}"
        elif isinstance(value, dict):
            sanitized[key] = self._sanitize_for_tracing(value)
        else:
            sanitized[key] = value
    
    return sanitized
```

---

### Audit Logging

```python
# app/utils/audit_logger.py
async def log_decision(decision_data: Dict[str, Any]):
    """
    Save fraud detection decision to DynamoDB for audit trail.
    Retention: 7 years (regulatory requirement).
    """
    audit_record = {
        'PK': f"TXN#{decision_data['transaction_id']}",
        'SK': f"DECISION#{datetime.utcnow().isoformat()}",
        'timestamp': datetime.utcnow().isoformat(),
        'decision': decision_data['final_decision'],
        'risk_level': decision_data['final_risk'],
        'agent_results': decision_data['agent_results'],
        'llm_result': decision_data.get('llm_result'),
        'actor_id': decision_data['actor_id'],
        'ttl': int((datetime.utcnow() + timedelta(days=2555)).timestamp())  # 7 years
    }
    
    dynamodb.put_item(TableName='fraud_detection_audit', Item=audit_record)
    logger.info(f"Audit log saved: {decision_data['transaction_id']}")
```

---

## Troubleshooting & Debugging

### Common Issues & Solutions

#### Issue 1: LLM Agent Disabled

**Symptoms**:
```
WARNING - ⚠️ LLM AGENT DISABLED - Continuing with rule-based agents only
```

**Causes**:
- AWS credentials not configured
- Bedrock service not available in region
- IAM role lacks Bedrock permissions

**Solution**:
```bash
# Check AWS credentials
aws sts get-caller-identity

# Verify Bedrock access
aws bedrock list-foundation-models --region us-east-1

# Add Bedrock permissions to IAM role
{
    "Effect": "Allow",
    "Action": [
        "bedrock:InvokeModel",
        "bedrock:ListFoundationModels"
    ],
    "Resource": "*"
}
```

---

#### Issue 2: LangSmith Traces Not Appearing

**Symptoms**:
- No traces in LangSmith dashboard
- Warning: "LangSmith not available"

**Solution**:
```bash
# Install LangSmith
pip install langsmith>=0.1.0

# Set environment variables
export LANGCHAIN_TRACING_V2=true
export LANGCHAIN_API_KEY=ls__your-api-key
export LANGCHAIN_PROJECT=fraud-detection-prod

# Verify configuration
python -c "import os; print(os.getenv('LANGCHAIN_TRACING_V2'))"
```

---

#### Issue 3: High Token Costs

**Symptoms**:
- LLM costs exceeding budget
- Avg tokens per request > 2000

**Solutions**:
1. **Optimize prompts**: Remove unnecessary context
2. **Implement caching**: Cache LLM responses for identical inputs
3. **Filter transactions**: Only run LLM on MED/HIGH risk transactions
4. **Use cheaper models**: Consider Claude 3 Haiku for simple cases

```python
# Implement tiered LLM usage
if initial_risk == "HIGH":
    llm_result = await llm_agent.analyze(data)  # Use LLM
elif initial_risk == "MED":
    llm_result = await llm_agent.analyze(data)  # Use LLM
else:  # LOW risk
    llm_result = None  # Skip LLM, save cost
```

---

#### Issue 4: JSON Parsing Failures

**Symptoms**:
```
ERROR - Failed to parse JSON from LLM response
```

**Causes**:
- LLM response not in expected JSON format
- Extra text before/after JSON block

**Solution**:
```python
def _parse_response(self, text: str) -> Dict[str, Any]:
    """Robust JSON extraction from LLM response."""
    try:
        # Try parsing entire response as JSON
        return json.loads(text)
    except json.JSONDecodeError:
        # Extract JSON from markdown code block
        if '```json' in text:
            start = text.find('```json') + 7
            end = text.find('```', start)
            json_str = text[start:end].strip()
            return json.loads(json_str)
        
        # Extract JSON by finding braces
        if '{' in text and '}' in text:
            start = text.find('{')
            end = text.rfind('}') + 1
            json_str = text[start:end]
            return json.loads(json_str)
        
        # Fallback: Return default response
        return self._create_fallback_response("No JSON found")
```

---

## Summary

### Key Takeaways

✅ **LLM Integration**: AWS Bedrock (Claude 3.5 Sonnet) for contextual fraud detection  
✅ **Observability**: LangSmith tracing with PII sanitization for compliance  
✅ **Logging**: Multi-layered logging (app logs, audit logs, metrics, traces)  
✅ **Prompt Management**: DynamoDB-backed prompt service with versioning  
✅ **Cost Tracking**: Real-time token usage and cost monitoring  
✅ **Security**: Data sanitization before external API calls  
✅ **Graceful Degradation**: System works without LLM (rule-based fallback)  

---

**Document Version**: 1.0  
**Last Updated**: February 7, 2026  
**Status**: ✅ Production Ready  
**Next Review**: March 1, 2026
