# Graph Entity Agent - Rule-Based Logic Detailed Explanation 🎯

## Overview

The Graph Entity Agent uses a **point-based scoring system** to evaluate entity relationship risks. This document explains exactly how each rule works, when it triggers, and how scores combine to produce final risk levels.

---

## Scoring Framework

### Risk Points System

The agent accumulates **risk points** by evaluating 4 independent rules:

| Rule | Focus Area | Max Points | Trigger Condition |
|------|------------|------------|-------------------|
| **Rule 1** | Multiple Claimants | 2 | distinct_claimants ≥ 2 |
| **Rule 2** | Multiple Claims | 1 | distinct_claims ≥ 2 |
| **Rule 3** | Employee Pattern | 2 | same_employee + claims ≥ 2 |
| **Rule 4** | New Account Risk | 1 | FIRST_USE + post_approval_change |
| **Maximum** | **Total** | **6** | All rules triggered |

### Final Risk Determination

```
Total Risk Points → Risk Level → Recommendation

0 points        →  LOW        →  ALLOW
1-2 points      →  MED        →  WARN / REVIEW  
3+ points       →  HIGH       →  BLOCK
```

---

## Rule 1: Multiple Claimants Detection 🚨

### **Objective**
Detect **fraud rings** where multiple different individuals attempt to receive payments to the same bank account.

### **Logic**
```python
if distinct_claimants >= high_reuse_threshold:  # threshold = 2
    risk_points += 2
    reasons.append(
        f"🚨 Bank account reused across {distinct_claimants} different claimants "
        f"(possible money mule or fraud ring)"
    )
```

### **Scoring Table**

| Distinct Claimants | Risk Points | Risk Level (if only this rule) | Explanation |
|-------------------|-------------|-------------------------------|-------------|
| 1 | 0 | LOW | Normal - one claimant per account |
| 2 | +2 | MED | **ALERT**: Two people using same account |
| 3+ | +2 | MED | **CRITICAL**: Fraud ring likely |

### **Fraud Pattern Example**

**Scenario: Money Mule Scheme**

```
Bank Account: ****5678

Claimant A (CLM-001) → $5,000 → Account ****5678
Claimant B (CLM-002) → $3,000 → Account ****5678  ← Rule 1 TRIGGERS (+2 points)
Claimant C (CLM-003) → $7,000 → Account ****5678  ← Still +2 points (not cumulative)
```

**Registry State:**
```python
{
  'account_****5678': {
    'claims': {'CLM-001', 'CLM-002', 'CLM-003'},
    'claimants': {'CLMT-A', 'CLMT-B', 'CLMT-C'},  # ← 3 distinct claimants
    'employees': {'EMP-123', 'EMP-456'}
  }
}
```

**Result:**
- `distinct_claimants = 3`
- `risk_points = 2`
- **Reason**: "🚨 Bank account reused across 3 different claimants (possible money mule or fraud ring)"

---

## Rule 2: Multiple Claims Detection ⚠️

### **Objective**
Identify accounts with **unusual reuse patterns** across multiple claims, even if from the same claimant.

### **Logic**
```python
if distinct_claims >= high_reuse_threshold:  # threshold = 2
    risk_points += 1
    reasons.append(
        f"⚠️ Bank account used in {distinct_claims} distinct claims "
        f"(possible pattern of reuse)"
    )
```

### **Scoring Table**

| Distinct Claims | Risk Points | Risk Level (if only this rule) | Explanation |
|----------------|-------------|-------------------------------|-------------|
| 1 | 0 | LOW | Normal - first time or single use |
| 2 | +1 | MED | Reused account, requires review |
| 3+ | +1 | MED | Pattern of reuse established |

### **Use Case Example**

**Scenario: Repeat Offender**

```
Bank Account: ****9012

Claim CLM-001 (2025-01-15) → $2,000 → Account ****9012
Claim CLM-002 (2025-06-20) → $4,000 → Account ****9012  ← Rule 2 TRIGGERS (+1 point)
Claim CLM-003 (2026-02-07) → $6,000 → Account ****9012  ← Still +1 point
```

**Registry State:**
```python
{
  'account_****9012': {
    'claims': {'CLM-001', 'CLM-002', 'CLM-003'},  # ← 3 distinct claims
    'claimants': {'CLMT-X'},  # ← Same claimant (Rule 1 not triggered)
    'employees': {'EMP-789'}
  }
}
```

**Result:**
- `distinct_claims = 3`
- `risk_points = 1`
- **Reason**: "⚠️ Bank account used in 3 distinct claims (possible pattern of reuse)"

---

## Rule 3: Employee Pattern Detection 🚨

### **Objective**
Detect **employee collusion** where the same employee repeatedly directs payments to the same bank account.

### **Logic**
```python
if distinct_employees == 1 and distinct_claims >= 2:
    risk_points += 2
    reasons.append(
        f"🚨 Same employee ({employee_id}) repeatedly directed payments "
        f"to this account ({distinct_claims} times)"
    )
```

### **Scoring Table**

| Distinct Employees | Distinct Claims | Risk Points | Explanation |
|-------------------|----------------|-------------|-------------|
| 1 | 1 | 0 | Normal - first transaction |
| 1 | 2+ | +2 | **ALERT**: Same employee, multiple times |
| 2+ | Any | 0 | Normal - different employees |

### **Fraud Pattern Example**

**Scenario: Employee Kickback Scheme**

```
Bank Account: ****3456

Employee EMP-5678:
  Claim CLM-100 → $8,000 → Account ****3456
  Claim CLM-101 → $5,000 → Account ****3456  ← Rule 3 TRIGGERS (+2 points)
  Claim CLM-102 → $9,000 → Account ****3456  ← Still +2 points
```

**Registry State:**
```python
{
  'account_****3456': {
    'claims': {'CLM-100', 'CLM-101', 'CLM-102'},
    'claimants': {'CLMT-A', 'CLMT-B', 'CLMT-C'},
    'employees': {'EMP-5678'}  # ← Only 1 distinct employee
  }
}
```

**Result:**
- `distinct_employees = 1`
- `distinct_claims = 3`
- `risk_points = 2`
- **Reason**: "🚨 Same employee (EMP-5678) repeatedly directed payments to this account (3 times)"

**Why This Matters:**
- Employee may have a financial relationship with account holder
- Potential kickback arrangement
- Insider threat indicator

---

## Rule 4: New Account + Post-Approval Change ⚠️

### **Objective**
Flag **account hijacking** attempts where a new bank account appears immediately after payee information is changed post-approval.

### **Logic**
```python
if is_new_account and payee_changed_post:  # account_pattern == 'FIRST_USE'
    risk_points += 1
    reasons.append(
        "⚠️ New bank account with post-approval payee change "
        "(elevated risk for first-time account)"
    )
```

### **Scoring Table**

| Account Pattern | Post-Approval Change | Risk Points | Explanation |
|----------------|---------------------|-------------|-------------|
| FIRST_USE | False | 0 | Normal new account |
| FIRST_USE | True | +1 | **ALERT**: Suspicious timing |
| ESTABLISHED | True | 0 | Acceptable (known account) |
| REUSED_ACROSS_CLAIMS | Any | 0 | Not applicable (not new) |

### **Fraud Pattern Example**

**Scenario: Account Hijacking Attack**

```
Timeline:
Day 1: Claim CLM-500 approved → Original Payee: John Smith, Account ****1111
Day 2: Payee changed → New Payee: John Smith, Account ****9999 (FIRST_USE)
       Payment released to NEW account ****9999
       
       ⚠️ Rule 4 TRIGGERS (+1 point)
```

**Input Data:**
```json
{
  "bank_account_hash": "hash_of_****9999",
  "account_pattern": "FIRST_USE",
  "payee_changed_post_approval": true
}
```

**Result:**
- `is_new_account = True`
- `payee_changed_post = True`
- `risk_points = 1`
- **Reason**: "⚠️ New bank account with post-approval payee change (elevated risk for first-time account)"

**Why This Matters:**
- Classic account hijacking pattern
- Attacker changes payee details after claim approved
- New account never seen before in system
- High probability of social engineering attack

---

## Combined Rule Examples

### **Scenario 1: Perfect Storm (HIGH Risk)**

**Situation**: All red flags present

```
Bank Account: ****7890

Employee EMP-5678:
  Claim CLM-200 (Claimant A) → $4,000 → Account ****7890 (FIRST_USE, payee changed)
  Claim CLM-201 (Claimant B) → $3,000 → Account ****7890
  Claim CLM-202 (Claimant C) → $5,000 → Account ****7890
```

**Rule Evaluation:**

| Rule | Triggered? | Points | Reason |
|------|-----------|--------|--------|
| Rule 1 | ✅ YES | +2 | 3 distinct claimants |
| Rule 2 | ✅ YES | +1 | 3 distinct claims |
| Rule 3 | ✅ YES | +2 | Same employee, 3 claims |
| Rule 4 | ✅ YES | +1 | FIRST_USE + post-approval change |
| **Total** | | **6** | **BLOCK IMMEDIATELY** |

**Output:**
```json
{
  "entity_risk": "HIGH",
  "reasons": [
    "🚨 Bank account reused across 3 different claimants (possible money mule or fraud ring)",
    "⚠️ Bank account used in 3 distinct claims (possible pattern of reuse)",
    "🚨 Same employee (EMP-5678) repeatedly directed payments to this account (3 times)",
    "⚠️ New bank account with post-approval payee change (elevated risk for first-time account)"
  ],
  "link_metrics": {
    "distinct_claims_count": 3,
    "distinct_claimants_count": 3,
    "distinct_employees_count": 1,
    "risk_points": 6
  }
}
```

---

### **Scenario 2: Moderate Risk (MED Risk)**

**Situation**: Multiple claims, same claimant, different employees

```
Bank Account: ****4321

Employee EMP-111:
  Claim CLM-300 (Claimant X) → $2,000 → Account ****4321

Employee EMP-222:
  Claim CLM-301 (Claimant X) → $3,000 → Account ****4321
```

**Rule Evaluation:**

| Rule | Triggered? | Points | Reason |
|------|-----------|--------|--------|
| Rule 1 | ❌ NO | 0 | Only 1 claimant |
| Rule 2 | ✅ YES | +1 | 2 distinct claims |
| Rule 3 | ❌ NO | 0 | 2 different employees |
| Rule 4 | ❌ NO | 0 | Established account, no change |
| **Total** | | **1** | **WARN / REVIEW** |

**Output:**
```json
{
  "entity_risk": "MED",
  "reasons": [
    "⚠️ Bank account used in 2 distinct claims (possible pattern of reuse)"
  ],
  "link_metrics": {
    "distinct_claims_count": 2,
    "distinct_claimants_count": 1,
    "distinct_employees_count": 2,
    "risk_points": 1
  }
}
```

---

### **Scenario 3: Clean Transaction (LOW Risk)**

**Situation**: First-time use, no red flags

```
Bank Account: ****6543

Employee EMP-999:
  Claim CLM-400 (Claimant Y) → $1,500 → Account ****6543 (FIRST_USE, no change)
```

**Rule Evaluation:**

| Rule | Triggered? | Points | Reason |
|------|-----------|--------|--------|
| Rule 1 | ❌ NO | 0 | Only 1 claimant |
| Rule 2 | ❌ NO | 0 | Only 1 claim |
| Rule 3 | ❌ NO | 0 | First time for this employee |
| Rule 4 | ❌ NO | 0 | FIRST_USE but no post-approval change |
| **Total** | | **0** | **ALLOW** |

**Output:**
```json
{
  "entity_risk": "LOW",
  "reasons": [
    "No significant entity linkage risks detected"
  ],
  "link_metrics": {
    "distinct_claims_count": 1,
    "distinct_claimants_count": 1,
    "distinct_employees_count": 1,
    "risk_points": 0
  }
}
```

---

## Configuration & Tuning

### Adjustable Parameters

```python
class GraphEntityLinkAgent:
    def __init__(self):
        self.high_reuse_threshold = 2  # ← Adjustable
```

**Tuning Options:**

| Use Case | Threshold | Impact |
|----------|-----------|--------|
| **Strict Security** | 2 (default) | More alerts, fewer false negatives |
| **High Volume** | 3 | Fewer alerts, focus on severe cases |
| **Pilot Testing** | 1 | Maximum sensitivity, may produce false positives |

---

## Decision Tree Visualization

```
START
  ↓
Check Registry: Does account exist?
  ↓
  ├─ NO → Create new entry
  └─ YES → Load existing data
  ↓
Update Registry (add claim, claimant, employee)
  ↓
Evaluate Rules in Sequence:
  ↓
  ├─ Rule 1: distinct_claimants >= 2? → YES → +2 points
  ├─ Rule 2: distinct_claims >= 2? → YES → +1 point
  ├─ Rule 3: (distinct_employees == 1) AND (claims >= 2)? → YES → +2 points
  └─ Rule 4: (FIRST_USE) AND (post_approval_change)? → YES → +1 point
  ↓
Sum Total Points
  ↓
  ├─ 0 points → LOW risk → ALLOW
  ├─ 1-2 points → MED risk → WARN / REVIEW
  └─ 3+ points → HIGH risk → BLOCK
  ↓
Return Result with Reasons
```

---

## Performance Considerations

### Time Complexity

| Operation | Complexity | Notes |
|-----------|-----------|-------|
| Registry lookup | O(1) | Hash-based dictionary |
| Set insertion | O(1) | Add claim/claimant/employee |
| Set size calculation | O(1) | len() on set |
| Rule evaluation | O(1) | 4 conditional checks |
| **Total** | **O(1)** | Constant time per transaction |

### Space Complexity

| Component | Complexity | Notes |
|-----------|-----------|-------|
| Registry storage | O(n) | n = unique bank accounts |
| Per-account data | O(m) | m = avg claims per account |
| **Total** | **O(n × m)** | Linear with accounts and claims |

---

## Testing Recommendations

### Critical Test Cases

1. **Rule 1 Test**: Send 2+ transactions with different claimants, same account
2. **Rule 2 Test**: Send 2+ claims with same claimant, same account
3. **Rule 3 Test**: Send 2+ claims with same employee, same account
4. **Rule 4 Test**: Send FIRST_USE account with `payee_changed_post_approval=true`
5. **Combined Test**: Trigger all 4 rules simultaneously (6 points → HIGH)

### Expected Outcomes

| Test | Expected Risk | Expected Points |
|------|--------------|----------------|
| All rules triggered | HIGH | 6 |
| Rules 1+2 triggered | MED/HIGH | 3 |
| Rule 1 only | MED | 2 |
| Rule 2 only | MED | 1 |
| No rules triggered | LOW | 0 |

---

## Summary

The Graph Entity Agent uses a **transparent, rule-based scoring system** that:

✅ **Accumulates risk points** across 4 independent fraud detection rules  
✅ **Focuses on relationships** between accounts, claims, claimants, and employees  
✅ **Provides explainable decisions** with specific reasons for each risk point  
✅ **Scales efficiently** with O(1) lookup and update operations  
✅ **Balances sensitivity** with configurable thresholds to reduce false positives  

**Key Design Philosophy**: Every point is earned through a specific, explainable rule trigger. No "black box" ML models—just transparent logic that auditors and regulators can verify.

---

**Last Updated**: February 7, 2026  
**Document Version**: 1.0  
**Author**: Fraud Detection Team
