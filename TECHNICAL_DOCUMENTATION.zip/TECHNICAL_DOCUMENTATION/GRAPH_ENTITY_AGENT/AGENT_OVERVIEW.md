# Graph Entity Agent - Technical Overview 🕸️

## **Logic File Description**

**File Location:** `c:\Yogesh\GenAI\Fraud Detection\Fraud-Internal-Detection\app\agents\graph_entity_agent.py`

**Class Name:** `GraphEntityLinkAgent`

---

### **Purpose**

The Graph Entity Agent is a specialized fraud detection component that analyzes **relationship patterns** and **entity linkages** across the payment ecosystem. It identifies suspicious connections by tracking how bank accounts, claimants, employees, and claims are interconnected over time.

This agent is particularly effective at detecting:
- **Fraud rings**: Multiple claimants using the same bank account
- **Money mules**: Bank accounts receiving payments from numerous sources
- **Employee collusion**: Same employee repeatedly directing payments to specific accounts
- **Account hijacking**: New accounts appearing immediately after payee changes

---

### **Core Functionality**

| Feature | Description |
|---------|-------------|
| **Entity Relationship Tracking** | Maintains a graph of connections between bank accounts, claims, claimants, and employees |
| **Pattern Recognition** | Detects suspicious reuse patterns across multiple dimensions |
| **Real-Time Registry** | Uses in-memory data structure (replaceable with Redis/Database) |
| **Privacy-Compliant** | Works with hashed identifiers (no PII exposure) |
| **Stateful Analysis** | Builds knowledge over time to detect emerging patterns |

---

### **Key Design Principles**

✅ **Graph-Based Logic**: Models fraud detection as a network analysis problem  
✅ **Multi-Dimensional Analysis**: Examines claims × claimants × employees × accounts  
✅ **Incremental Learning**: Registry grows with each transaction analyzed  
✅ **Zero-Configuration**: Works out-of-the-box with sensible defaults  
✅ **Production-Ready**: Can scale to Redis/DynamoDB for distributed systems  

---

## **Execution Overview**

### **How the Logic Executes**

#### **Phase 1: Input Reception & Validation**

```
INPUT RECEIVED
    ↓
Extract Key Identifiers:
  - bank_account_hash (primary key)
  - claim_id
  - claimant_id
  - employee_id
  - account_pattern (FIRST_USE | ESTABLISHED | REUSED_ACROSS_CLAIMS)
  - payee_changed_post_approval (boolean)
```

#### **Phase 2: Registry Lookup/Creation**

```
CHECK: Does bank_account_hash exist in registry?
    ↓
┌─────────────────────────────────────────────┐
│ IF NOT EXISTS:                              │
│   Create new registry entry:                │
│   {                                         │
│     'claims': set(),                        │
│     'claimants': set(),                     │
│     'employees': set()                      │
│   }                                         │
└─────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────┐
│ IF EXISTS:                                  │
│   Retrieve existing record for analysis     │
└─────────────────────────────────────────────┘
```

#### **Phase 3: Registry Update**

```
UPDATE REGISTRY with current transaction:
    ↓
account_record['claims'].add(claim_id)
account_record['claimants'].add(claimant_id)
account_record['employees'].add(employee_id)
    ↓
Calculate Metrics:
  - distinct_claims_count
  - distinct_claimants_count
  - distinct_employees_count
  - same_employee_reuse_count
```

#### **Phase 4: Risk Rule Evaluation**

The agent applies **4 risk rules** in sequence, accumulating risk points:

```
RULE 1: Multiple Claimants → Same Account
┌─────────────────────────────────────────────┐
│ IF distinct_claimants >= 2:                 │
│   risk_points += 2                          │
│   reason: "Account reused across X          │
│            different claimants"             │
│   📊 Fraud Ring Detection                   │
└─────────────────────────────────────────────┘
    ↓
RULE 2: Multiple Claims → Same Account
┌─────────────────────────────────────────────┐
│ IF distinct_claims >= 2:                    │
│   risk_points += 1                          │
│   reason: "Account used in X distinct       │
│            claims"                          │
│   📊 Pattern of Reuse                       │
└─────────────────────────────────────────────┘
    ↓
RULE 3: Same Employee → Same Account (Repeated)
┌─────────────────────────────────────────────┐
│ IF distinct_employees == 1 AND              │
│    distinct_claims >= 2:                    │
│   risk_points += 2                          │
│   reason: "Same employee repeatedly         │
│            directed payments to account"    │
│   📊 Employee Collusion                     │
└─────────────────────────────────────────────┘
    ↓
RULE 4: New Account + Post-Approval Change
┌─────────────────────────────────────────────┐
│ IF account_pattern == 'FIRST_USE' AND       │
│    payee_changed_post_approval == True:     │
│   risk_points += 1                          │
│   reason: "New account with post-approval   │
│            payee change"                    │
│   📊 Account Hijacking                      │
└─────────────────────────────────────────────┘
```

#### **Phase 5: Risk Level Determination**

```
CALCULATE FINAL RISK:
    ↓
┌─────────────────────────────────────────────┐
│ IF risk_points >= 3:                        │
│   entity_risk = 'HIGH'                      │
│   Action: BLOCK transaction                 │
└─────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────┐
│ ELIF risk_points >= 1:                      │
│   entity_risk = 'MED'                       │
│   Action: WARN / Manual Review              │
└─────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────┐
│ ELSE:                                       │
│   entity_risk = 'LOW'                       │
│   Action: ALLOW transaction                 │
└─────────────────────────────────────────────┘
```

#### **Phase 6: Output Generation**

```json
{
  "entity_risk": "HIGH",
  "reasons": [
    "🚨 Bank account reused across 3 different claimants",
    "⚠️ Bank account used in 5 distinct claims"
  ],
  "link_metrics": {
    "distinct_claims_count": 5,
    "distinct_claimants_count": 3,
    "distinct_employees_count": 2,
    "same_employee_reuse_count": 3,
    "account_pattern": "REUSED_ACROSS_CLAIMS",
    "is_new_account": false,
    "risk_points": 3
  }
}
```

---

## **Risk Scoring Matrix**

| Risk Rule | Condition | Points | Severity | Detection Target |
|-----------|-----------|--------|----------|------------------|
| **Rule 1** | distinct_claimants ≥ 2 | +2 | 🔴 Critical | Fraud rings, money mules |
| **Rule 2** | distinct_claims ≥ 2 | +1 | 🟡 Moderate | Suspicious patterns |
| **Rule 3** | same employee + multiple claims | +2 | 🔴 Critical | Employee collusion |
| **Rule 4** | new account + post-approval change | +1 | 🟡 Moderate | Account hijacking |

**Thresholds:**
- **0 points** → LOW risk (Normal transaction)
- **1-2 points** → MED risk (Review recommended)
- **3+ points** → HIGH risk (Block transaction)

---

## **Mandatory Input Fields**

### **Complete Input Structure**

```python
input_data = {
    'bank_account_hash': str,           # ← MANDATORY
    'claim_id': str,                    # ← MANDATORY
    'claimant_id': str,                 # ← MANDATORY
    'employee_id': str,                 # ← OPTIONAL (defaults to 'unknown')
    'account_pattern': str,             # ← MANDATORY
    'payee_changed_post_approval': bool, # ← OPTIONAL (defaults to False)
    'routing_hash': str,                # ← OPTIONAL
    'payee_address_hash': str,          # ← OPTIONAL
    'payee_phone_hash': str             # ← OPTIONAL
}
```

---

### **Field Specifications**

#### **1. `bank_account_hash` (MANDATORY)**

| Property | Value |
|----------|-------|
| **Type** | string |
| **Required** | ✅ YES |
| **Format** | SHA-256 hash (64 hex characters) |
| **Purpose** | Primary key for entity relationship tracking |
| **Privacy** | Uses hashed value to protect PII |

**Description:**  
A cryptographic hash of the bank account number. This is the **primary identifier** used to track account reuse across claims, claimants, and employees.

**Example:**
```json
"bank_account_hash": "a3c5e7f9b2d4e6f8a1c3e5f7b9d1e3f5a7c9e1f3b5d7e9f1a3c5e7f9b2d4e6f8"
```

**Validation:**
- Must be non-empty
- Recommended: 64-character hexadecimal string (SHA-256)
- Case-insensitive (internally normalized)

---

#### **2. `claim_id` (MANDATORY)**

| Property | Value |
|----------|-------|
| **Type** | string |
| **Required** | ✅ YES |
| **Format** | Alphanumeric identifier |
| **Purpose** | Track how many distinct claims use this account |

**Description:**  
Unique identifier for the insurance claim. Used to detect if the same bank account is being used across multiple claims.

**Example:**
```json
"claim_id": "CLM-2026-123456"
```

**Validation:**
- Must be non-empty
- Unique per claim
- Consistent format recommended (e.g., `CLM-YYYY-NNNNNN`)

---

#### **3. `claimant_id` (MANDATORY)**

| Property | Value |
|----------|-------|
| **Type** | string |
| **Required** | ✅ YES |
| **Format** | Alphanumeric identifier (can be hashed) |
| **Purpose** | Detect fraud rings (multiple claimants → same account) |

**Description:**  
Unique identifier for the person submitting the claim. **Critical for detecting fraud rings** where multiple individuals funnel payments to a single bank account (money mule schemes).

**Example:**
```json
"claimant_id": "CLMT-789012"
```

**Validation:**
- Must be non-empty
- Can be hashed for privacy: `sha256(SSN or unique_id)`
- Consistency across transactions is critical

---

#### **4. `employee_id` (OPTIONAL)**

| Property | Value |
|----------|-------|
| **Type** | string |
| **Required** | ⚠️ OPTIONAL |
| **Default** | `'unknown'` |
| **Format** | Alphanumeric identifier |
| **Purpose** | Detect employee collusion patterns |

**Description:**  
Identifier for the employee who processed/approved the payment. Used to detect if the same employee repeatedly directs payments to the same bank account (potential kickback scheme).

**Example:**
```json
"employee_id": "EMP-5678"
```

**Validation:**
- If not provided, defaults to `'unknown'`
- Recommended: Always provide for full fraud detection coverage

---

#### **5. `account_pattern` (MANDATORY)**

| Property | Value |
|----------|-------|
| **Type** | string |
| **Required** | ✅ YES |
| **Format** | Enum: `'FIRST_USE'` \| `'ESTABLISHED'` \| `'REUSED_ACROSS_CLAIMS'` |
| **Purpose** | Indicate account usage history |

**Description:**  
Categorizes the account's usage pattern in the system. This field provides context for risk assessment.

**Values:**

| Value | Meaning | Risk Implication |
|-------|---------|------------------|
| `FIRST_USE` | Account never seen before | Higher risk if combined with payee changes |
| `ESTABLISHED` | Account has clean history | Lower baseline risk |
| `REUSED_ACROSS_CLAIMS` | Account used in multiple claims | Elevated risk, triggers deeper analysis |

**Example:**
```json
"account_pattern": "FIRST_USE"
```

**Validation:**
- Must be one of the three enum values
- Case-sensitive (UPPERCASE)

---

#### **6. `payee_changed_post_approval` (OPTIONAL)**

| Property | Value |
|----------|-------|
| **Type** | boolean |
| **Required** | ⚠️ OPTIONAL |
| **Default** | `False` |
| **Purpose** | Flag suspicious timing of payee changes |

**Description:**  
Indicates whether the payee information (bank account, address, etc.) was modified **after** the claim was approved. This is a red flag for account hijacking attacks.

**Example:**
```json
"payee_changed_post_approval": true
```

**Risk Context:**
- `True` + `FIRST_USE` account → **HIGH RISK** (Rule 4 triggered)
- `False` → Normal workflow, no additional risk

---

#### **7-9. Optional Hash Fields**

| Field | Type | Required | Purpose |
|-------|------|----------|---------|
| **`routing_hash`** | string | ⚠️ OPTIONAL | Bank routing number hash (future use) |
| **`payee_address_hash`** | string | ⚠️ OPTIONAL | Mailing address hash (future use) |
| **`payee_phone_hash`** | string | ⚠️ OPTIONAL | Phone number hash (future use) |

**Description:**  
Reserved for future multi-dimensional entity linking. Currently not used in risk scoring but captured for analytics.

**Example:**
```json
"routing_hash": "b4d6f8a2c4e6f8b1d3e5f7b9d1e3f5a7c9e1f3b5d7e9f1a3c5e7f9b2d4e6f8a2",
"payee_address_hash": "c5e7f9b1d3e5f7a9c1e3f5b7d9e1f3a5c7e9f1b3d5e7f9a1c3e5f7b9d1e3f5a7",
"payee_phone_hash": "d6f8a2c4e6f8b1d3e5f7b9d1e3f5a7c9e1f3b5d7e9f1a3c5e7f9b2d4e6f8a2c4"
```

---

## **Complete Input Example**

### **Example 1: HIGH Risk Scenario (Fraud Ring)**

```json
{
  "bank_account_hash": "a3c5e7f9b2d4e6f8a1c3e5f7b9d1e3f5a7c9e1f3b5d7e9f1a3c5e7f9b2d4e6f8",
  "claim_id": "CLM-2026-123456",
  "claimant_id": "CLMT-999999",
  "employee_id": "EMP-5678",
  "account_pattern": "REUSED_ACROSS_CLAIMS",
  "payee_changed_post_approval": false,
  "routing_hash": "b4d6f8a2c4e6f8b1d3e5f7b9d1e3f5a7c9e1f3b5d7e9f1a3c5e7f9b2d4e6f8a2"
}
```

**Expected Output:**
```json
{
  "entity_risk": "HIGH",
  "reasons": [
    "🚨 Bank account reused across 3 different claimants (possible money mule or fraud ring)",
    "⚠️ Bank account used in 5 distinct claims (possible pattern of reuse)"
  ],
  "link_metrics": {
    "distinct_claims_count": 5,
    "distinct_claimants_count": 3,
    "distinct_employees_count": 2,
    "same_employee_reuse_count": 2,
    "account_pattern": "REUSED_ACROSS_CLAIMS",
    "is_new_account": false,
    "risk_points": 3
  }
}
```

---

### **Example 2: MED Risk Scenario (Employee Collusion)**

```json
{
  "bank_account_hash": "e7f9b1d3e5f7a9c1e3f5b7d9e1f3a5c7e9f1b3d5e7f9a1c3e5f7b9d1e3f5a7c9",
  "claim_id": "CLM-2026-789012",
  "claimant_id": "CLMT-111111",
  "employee_id": "EMP-5678",
  "account_pattern": "ESTABLISHED",
  "payee_changed_post_approval": false
}
```

**Expected Output:**
```json
{
  "entity_risk": "MED",
  "reasons": [
    "⚠️ Bank account used in 2 distinct claims (possible pattern of reuse)"
  ],
  "link_metrics": {
    "distinct_claims_count": 2,
    "distinct_claimants_count": 1,
    "distinct_employees_count": 1,
    "same_employee_reuse_count": 2,
    "account_pattern": "ESTABLISHED",
    "is_new_account": false,
    "risk_points": 1
  }
}
```

---

### **Example 3: LOW Risk Scenario (Normal Transaction)**

```json
{
  "bank_account_hash": "f1a3c5e7f9b2d4e6f8a1c3e5f7b9d1e3f5a7c9e1f3b5d7e9f1a3c5e7f9b2d4e6",
  "claim_id": "CLM-2026-345678",
  "claimant_id": "CLMT-222222",
  "employee_id": "EMP-9999",
  "account_pattern": "FIRST_USE",
  "payee_changed_post_approval": false
}
```

**Expected Output:**
```json
{
  "entity_risk": "LOW",
  "reasons": [
    "No significant entity linkage risks detected"
  ],
  "link_metrics": {
    "distinct_claims_count": 1,
    "distinct_claimants_count": 1,
    "distinct_employees_count": 1,
    "same_employee_reuse_count": 1,
    "account_pattern": "FIRST_USE",
    "is_new_account": true,
    "risk_points": 0
  }
}
```

---

## **Registry Data Structure**

The agent maintains an in-memory registry:

```python
_account_registry = {
    'account_hash_1': {
        'claims': {'CLM-001', 'CLM-002', 'CLM-003'},
        'claimants': {'CLMT-A', 'CLMT-B', 'CLMT-C'},
        'employees': {'EMP-123', 'EMP-456'}
    },
    'account_hash_2': {
        'claims': {'CLM-004'},
        'claimants': {'CLMT-D'},
        'employees': {'EMP-789'}
    }
}
```

**Production Considerations:**
- **In-Memory**: Fast but not persistent (data lost on restart)
- **Redis**: Recommended for production (distributed, persistent)
- **DynamoDB**: Alternative for AWS-native deployments
- **Clear Method**: `reset_registry()` for testing

---

## **Performance Characteristics**

| Metric | Value |
|--------|-------|
| **Execution Time** | < 10ms (typical) |
| **Memory Usage** | O(n) where n = unique bank accounts |
| **Lookup Complexity** | O(1) hash-based lookup |
| **Update Complexity** | O(1) set insertion |
| **Scalability** | Linear with number of unique accounts |

---

## **Error Handling**

```python
try:
    # Execute graph analysis logic
except Exception as e:
    logger.error(f"Error in entity link analysis: {e}")
    return {
        'entity_risk': 'LOW',  # Fail-safe: default to LOW risk
        'reasons': [f"Error in analysis: {str(e)}"],
        'link_metrics': {}
    }
```

**Fail-Safe Behavior:**
- If agent fails, defaults to `LOW` risk (fail-open)
- Error logged to audit trail
- Transaction proceeds to other agents
- System remains operational

---

## **Integration with Orchestrator**

The Graph Entity Agent is called by the Payout Orchestrator:

```python
# In payout_orchestrator.py
graph_entity_input = {
    'bank_account_hash': input_data.get('bank_account_hash'),
    'routing_hash': input_data.get('routing_hash'),
    'payee_address_hash': input_data.get('payee_address_hash'),
    'payee_phone_hash': input_data.get('payee_phone_hash'),
    'claim_id': input_data.get('current_action', {}).get('claim_id'),
    'claimant_id': input_data.get('claimant_id'),
    'employee_id': input_data.get('current_action', {}).get('employee_id'),
    'account_pattern': input_data.get('account_pattern', ''),
    'payee_changed_post_approval': input_data.get('payee_changed_after_approval', False)
}

graph_result = await self.graph_entity_agent.execute(graph_entity_input)
```

---

## **Key Takeaways**

✅ **Graph-based fraud detection**: Models relationships as a network  
✅ **Multi-dimensional analysis**: Tracks claims × claimants × employees × accounts  
✅ **Privacy-compliant**: Uses hashed identifiers, no PII exposure  
✅ **Stateful learning**: Builds knowledge over time to detect patterns  
✅ **Production-ready**: Can scale to Redis/DynamoDB for distributed systems  

**Critical Use Cases:**
1. **Fraud Ring Detection**: Multiple claimants → same account
2. **Money Mule Schemes**: Account receiving from many sources
3. **Employee Collusion**: Same employee → same account repeatedly
4. **Account Hijacking**: New account + post-approval changes

---

**Next Steps:**
- See `RULE_BASED_LOGIC.md` for detailed scoring rules
- See `../TEST_CASES/GRAPH_ENTITY_AGENT/` for test scenarios
- See orchestrator documentation for integration examples

---

**Last Updated**: February 7, 2026  
**Agent Version**: 1.0  
**Author**: Fraud Detection Team
