# Learning & Feedback Loop System
## Continuous Improvement Through Human Feedback

**Document Version:** 1.0  
**Last Updated:** February 7, 2026  
**Purpose:** Complete documentation of the learning and feedback loop architecture

---

## Table of Contents

1. [Overview](#1-overview)
2. [Learning Cycle Architecture](#2-learning-cycle-architecture)
3. [Reward System](#3-reward-system)
4. [Learning Queue Management](#4-learning-queue-management)
5. [Prompt Evolution Process](#5-prompt-evolution-process)
6. [Real-World Examples](#6-real-world-examples)

---

## 1. Overview

The fraud detection system continuously improves through a human-in-the-loop feedback system. SIU analysts review decisions, provide ground truth, and the system automatically generates improved prompts from high-value cases.

### 1.1 Key Features

✅ **Automated Learning:** High-value cases (|reward| ≥ 50) automatically enter the learning queue  
✅ **Analyst-Driven:** SIU analysts review and approve training examples  
✅ **Version Control:** All prompt versions are tracked and can be rolled back  
✅ **A/B Testing:** Compare accuracy between prompt versions  
✅ **Zero Downtime:** Activate new prompts without service interruption

---

## 2. Learning Cycle Architecture

### 2.1 Complete Learning Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    LEARNING & FEEDBACK ARCHITECTURE                          │
└─────────────────────────────────────────────────────────────────────────────┘

PHASE 1: Initial Decision
┌────────────────────────────────────────────────────────────────────┐
│ 1. Transaction received                                            │
│ 2. 4 agents analyze (3 rule-based + 1 LLM)                         │
│ 3. Orchestrator makes decision: BLOCK                              │
│ 4. Decision stored in DynamoDB "Decisions" table                   │
│    {                                                               │
│      "event_id": "EVT-2026-02-07-001",                             │
│      "decision": "BLOCK",                                          │
│      "risk_level": "HIGH",                                         │
│      "confidence": 0.95,                                           │
│      "reviewed": false,                                            │
│      "actual_outcome": null                                        │
│    }                                                               │
└────────────────────────────────────────────────────────────────────┘
                            │
                            ▼
PHASE 2: Human Review (SIU Analyst)
┌────────────────────────────────────────────────────────────────────┐
│ Analyst Dashboard → Recent Decisions                               │
│                                                                    │
│ Event: EVT-2026-02-07-001                                          │
│ Decision: BLOCK                                                    │
│ Risk: HIGH                                                         │
│                                                                    │
│ Analyst investigates:                                              │
│ ├─ Reviews transaction details                                    │
│ ├─ Contacts employee                                              │
│ ├─ Checks supporting documents                                    │
│ └─ Determines: Actually FRAUD (system was correct!)               │
│                                                                    │
│ Analyst submits feedback:                                          │
│ ┌────────────────────────────────────────┐                        │
│ │ Actual Outcome: CONFIRMED_FRAUD ▼      │                        │
│ │ Notes: Employee admitted unauthorized  │                        │
│ │        access to claim system          │                        │
│ │ ☑ Add to Learning Queue                │                        │
│ │ [Submit Feedback]                      │                        │
│ └────────────────────────────────────────┘                        │
└────────────────────────────────────────────────────────────────────┘
                            │
                            ▼
PHASE 3: Reward Calculation
┌────────────────────────────────────────────────────────────────────┐
│ POST /api/v1/feedback                                              │
│                                                                    │
│ Reward Matrix:                                                     │
│ ┌────────────────────────────────────────────────────────────┐    │
│ │              ACTUAL OUTCOME                                │    │
│ │         FRAUD   FALSE_POS   LEGIT   UNCERTAIN              │    │
│ │ BLOCK   +100      -100       -50       0                   │    │
│ │ WARN    +50       -20        -20       0                   │    │
│ │ ALLOW   -200      -50        +10       0                   │    │
│ └────────────────────────────────────────────────────────────┘    │
│                                                                    │
│ Calculation:                                                       │
│ • Decision: BLOCK                                                  │
│ • Actual Outcome: CONFIRMED_FRAUD                                 │
│ • Reward: +100 ✅ Perfect detection!                              │
│                                                                    │
│ IF |reward| >= 50:                                                 │
│    create_learning_queue_entry()                                   │
└────────────────────────────────────────────────────────────────────┘
                            │
                            ▼
PHASE 4: Learning Queue Entry
┌────────────────────────────────────────────────────────────────────┐
│ DynamoDB Table: PromptLearningQueue                                │
│                                                                    │
│ {                                                                  │
│   "queue_id": "LQ-2026-02-07-001",                                 │
│   "event_id": "EVT-2026-02-07-001",                                │
│   "event_type": "PAYMENT_FRAUD",                                   │
│   "reward_score": 100,                                             │
│   "llm_decision": "BLOCK",                                         │
│   "actual_outcome": "CONFIRMED_FRAUD",                             │
│   "is_correct": true,                                              │
│   "status": "PENDING_REVIEW",                                      │
│   "created_at": "2026-02-07T15:00:00Z",                            │
│   "reviewed": false,                                               │
│   "incorporated": false,                                           │
│   "example_data": {                                                │
│     "payment_amount": 9500.00,                                     │
│     "indicators": ["first_use_account",                            │
│                    "post_approval_change",                         │
│                    "same_day_payment"],                            │
│     "employee_pattern": "SINGLE_EMPLOYEE_ALL_STEPS",               │
│     "time_delta_minutes": 8                                        │
│   },                                                               │
│   "analyst_notes": "Employee admitted to unauthorized access"      │
│ }                                                                  │
└────────────────────────────────────────────────────────────────────┘
                            │
                            ▼
PHASE 5: Analyst Review & Training Data Generation
┌────────────────────────────────────────────────────────────────────┐
│ UI: Learning Queue Page                                            │
│                                                                    │
│ [🔄 Load Feedback Items]                                           │
│                                                                    │
│ High-Value Cases (|reward| >= 50):                                 │
│ ┌──────────────────────────────────────────────────────────────┐  │
│ │ ☑ LQ-001 | PAY-123 | BLOCK→FRAUD  | +100 | Employee fraud   │  │
│ │ ☐ LQ-002 | PAY-456 | ALLOW→FRAUD  | -200 | Missed fraud ⚠️  │  │
│ │ ☐ LQ-003 | PAY-789 | BLOCK→FALSE  | -100 | False positive   │  │
│ └──────────────────────────────────────────────────────────────┘  │
│                                                                    │
│ Analyst selects LQ-001, clicks [🤖 Generate Training Data]        │
│                                                                    │
│ System auto-generates few-shot example:                            │
│ ┌──────────────────────────────────────────────────────────────┐  │
│ │ Scenario:                                                    │  │
│ │ "Payment to offshore account initiated minutes after        │  │
│ │ changing payee bank details. Same employee approved         │  │
│ │ claim, updated bank info, and released payment."            │  │
│ │                                                              │  │
│ │ Amount: $9,500 (just below $10K threshold)                   │  │
│ │                                                              │  │
│ │ Indicators:                                                  │  │
│ │ • First-time bank account usage                             │  │
│ │ • Post-approval payee change (8 minutes)                    │  │
│ │ • Same-day payment request                                  │  │
│ │ • Single employee all control points                        │  │
│ │                                                              │  │
│ │ Decision: BLOCK                                              │  │
│ │ Outcome: CONFIRMED_FRAUD                                     │  │
│ │ Lesson: "When single employee controls all steps AND        │  │
│ │         changes payee info post-approval AND requests       │  │
│ │         rapid payment, this pattern suggests employee       │  │
│ │         fraud scheme to funnel money to controlled account."│  │
│ └──────────────────────────────────────────────────────────────┘  │
│                                                                    │
│ Analyst reviews/edits, then:                                       │
│ [✅ Approve] [❌ Reject] [✏️ Edit]                                 │
└────────────────────────────────────────────────────────────────────┘
                            │
                            ▼
PHASE 6: Add to Prompt Management
┌────────────────────────────────────────────────────────────────────┐
│ After approval, analyst clicks [📚 Add to Prompt Management]       │
│                                                                    │
│ → Navigates to Prompt Management page                              │
│ → Example loaded and ready to add to prompt                        │
│                                                                    │
│ Analyst clicks [💾 Update Prompt]                                  │
└────────────────────────────────────────────────────────────────────┘
                            │
                            ▼
PHASE 7: Prompt Version Creation
┌────────────────────────────────────────────────────────────────────┐
│ POST /api/v1/prompts                                               │
│                                                                    │
│ System creates new prompt version:                                 │
│ ┌──────────────────────────────────────────────────────────────┐  │
│ │ DynamoDB Table: FraudDetectionPrompts                        │  │
│ │                                                              │  │
│ │ Current Active (v1.2):                                       │  │
│ │ {                                                            │  │
│ │   "event_type": "PAYMENT_FRAUD",                             │  │
│ │   "version_id": "v1.2",                                      │  │
│ │   "is_active": true,                                         │  │
│ │   "few_shot_examples": [20 examples],                        │  │
│ │   "accuracy_metrics": {                                      │  │
│ │     "total_decisions": 500,                                  │  │
│ │     "correct_decisions": 460,                                │  │
│ │     "accuracy": 0.92                                         │  │
│ │   }                                                          │  │
│ │ }                                                            │  │
│ │                                                              │  │
│ │ New Draft (v1.3):                                            │  │
│ │ {                                                            │  │
│ │   "event_type": "PAYMENT_FRAUD",                             │  │
│ │   "version_id": "v1.3",                                      │  │
│ │   "is_active": false,                                        │  │
│ │   "status": "DRAFT",                                         │  │
│ │   "parent_version_id": "v1.2",                               │  │
│ │   "few_shot_examples": [21 examples],  ← +1 new example     │  │
│ │   "created_by": "analyst@company.com",                       │  │
│ │   "created_at": "2026-02-07T16:00:00Z",                      │  │
│ │   "changes": "Added employee fraud pattern example"          │  │
│ │ }                                                            │  │
│ └──────────────────────────────────────────────────────────────┘  │
│                                                                    │
│ Update learning queue item:                                        │
│ {                                                                  │
│   "queue_id": "LQ-2026-02-07-001",                                 │
│   "status": "INCORPORATED",                                        │
│   "incorporated_at": "2026-02-07T16:00:00Z",                       │
│   "incorporated_into_version": "v1.3"                              │
│ }                                                                  │
└────────────────────────────────────────────────────────────────────┘
                            │
                            ▼
PHASE 8: Prompt Activation
┌────────────────────────────────────────────────────────────────────┐
│ Analyst decides to activate new prompt version                     │
│                                                                    │
│ Optional: Compare accuracy first                                   │
│ [📊 Compare v1.2 vs v1.3]                                          │
│                                                                    │
│ Click [✅ Activate Prompt v1.3]                                    │
│                                                                    │
│ POST /api/v1/prompts/{prompt_id}/activate                          │
│                                                                    │
│ System updates:                                                    │
│ 1. Set v1.2: is_active = false, status = "ARCHIVED"               │
│ 2. Set v1.3: is_active = true, status = "ACTIVE"                  │
│ 3. Record activation timestamp                                     │
│                                                                    │
│ ✅ All new decisions now use v1.3 with improved examples           │
└────────────────────────────────────────────────────────────────────┘
                            │
                            ▼
PHASE 9: Continuous Monitoring
┌────────────────────────────────────────────────────────────────────┐
│ System tracks accuracy of new prompt version:                      │
│                                                                    │
│ Every decision using v1.3:                                         │
│ • Stored with version_used = "v1.3"                                │
│ • When feedback received, accuracy calculated                      │
│ • Metrics updated in real-time                                     │
│                                                                    │
│ After 100 decisions:                                               │
│ {                                                                  │
│   "version_id": "v1.3",                                            │
│   "accuracy_metrics": {                                            │
│     "total_decisions": 100,                                        │
│     "correct_decisions": 94,                                       │
│     "accuracy": 0.94,  ← Improved from 0.92! ✅                    │
│     "false_positives": 3,                                          │
│     "false_negatives": 3                                           │
│   }                                                                │
│ }                                                                  │
│                                                                    │
│ If accuracy drops below threshold:                                 │
│ • Alert sent to analysts                                           │
│ • Option to rollback to previous version                           │
└────────────────────────────────────────────────────────────────────┘
                            │
                            ▼
                  CYCLE REPEATS ♻️
            (Continuous Learning & Improvement)
```

---

## 3. Reward System

### 3.1 Reward Matrix

The reward system quantifies how well the system performed on each decision:

```
┌──────────────────────────────────────────────────────────────────┐
│                      REWARD MATRIX                                │
│                                                                   │
│           ACTUAL OUTCOME (Ground Truth from Analyst)              │
│                                                                   │
│              CONFIRMED_  FALSE_     LEGITIMATE  UNCERTAIN         │
│              FRAUD       POSITIVE                                 │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ BLOCK    +100         -100        -50          0           │  │
│  │          Perfect!     Bad block   Wrong!      Unknown      │  │
│  │                                                            │  │
│  │ WARN     +50          -20         -20          0           │  │
│  │          Good catch   Minor issue Minor issue Unknown      │  │
│  │                                                            │  │
│  │ ALLOW    -200         -50         +10          0           │  │
│  │          MISSED!      Minor issue Correct     Unknown      │  │
│  └────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────┘

High-Value Cases (Enter Learning Queue):
• |reward| >= 50
• Examples:
  ✅ BLOCK + CONFIRMED_FRAUD = +100 (Learn from success)
  ⚠️ ALLOW + CONFIRMED_FRAUD = -200 (Learn from critical miss)
  ⚠️ BLOCK + FALSE_POSITIVE = -100 (Learn to reduce false alarms)
  ✅ WARN + CONFIRMED_FRAUD = +50 (Learn pattern for escalation)
```

### 3.2 Reward Calculation Logic

```python
def calculate_reward(decision: str, actual_outcome: str) -> int:
    """
    Calculate reward based on decision vs actual outcome.
    
    High positive rewards = System detected fraud correctly
    High negative rewards = System made critical error
    Low rewards = Minor issues or correct legitimate transactions
    """
    
    reward_matrix = {
        ('BLOCK', 'CONFIRMED_FRAUD'): 100,      # ✅ Perfect fraud detection
        ('BLOCK', 'FALSE_POSITIVE'): -100,      # ⚠️ Blocked legitimate transaction
        ('BLOCK', 'LEGITIMATE'): -50,           # ⚠️ Blocked legit (lower severity)
        ('BLOCK', 'UNCERTAIN'): 0,              # 🤷 Can't determine
        
        ('WARN', 'CONFIRMED_FRAUD'): 50,        # ✅ Good catch, needs review
        ('WARN', 'FALSE_POSITIVE'): -20,        # ⚠️ Flagged legit unnecessarily
        ('WARN', 'LEGITIMATE'): -20,            # ⚠️ Flagged legit
        ('WARN', 'UNCERTAIN'): 0,               # 🤷 Can't determine
        
        ('ALLOW', 'CONFIRMED_FRAUD'): -200,     # 🚨 CRITICAL: Missed fraud!
        ('ALLOW', 'FALSE_POSITIVE'): -50,       # ⚠️ Allowed suspected fraud
        ('ALLOW', 'LEGITIMATE'): 10,            # ✅ Correctly allowed legit
        ('ALLOW', 'UNCERTAIN'): 0               # 🤷 Can't determine
    }
    
    return reward_matrix.get((decision, actual_outcome), 0)
```

---

## 4. Learning Queue Management

### 4.1 Queue Entry Criteria

Cases automatically enter the learning queue when:
- **|reward_score| ≥ 50**: High-impact cases (great successes or critical failures)
- **Analyst opts in**: Manual addition via "Add to Learning Queue" checkbox

### 4.2 Queue Workflow

```
┌─────────────────────────────────────────────────────────────────┐
│                    LEARNING QUEUE WORKFLOW                       │
└─────────────────────────────────────────────────────────────────┘

Status Flow:
PENDING_REVIEW → APPROVED → INCORPORATED → ARCHIVED
      ↓
   REJECTED

1. PENDING_REVIEW
   • Case just added to queue
   • Awaiting analyst review
   • Actions: Review, Generate Example, Approve/Reject

2. APPROVED
   • Analyst reviewed and approved
   • Training data generated
   • Ready to add to prompt
   • Actions: Add to Prompt Management

3. INCORPORATED
   • Added to new prompt version
   • Recorded which version (v1.3, v1.4, etc.)
   • Can view in prompt history
   • Actions: View Impact, Archive

4. REJECTED
   • Analyst determined not useful for training
   • Kept for audit purposes
   • Actions: View Reason, Reopen

5. ARCHIVED
   • Old incorporated items
   • Cleanup after 90 days
   • Actions: View Only
```

### 4.3 Auto-Generated Training Examples

The system automatically generates few-shot examples from learning queue items:

```python
def generate_training_example(queue_item: Dict) -> Dict:
    """
    Auto-generate few-shot example from learning queue item.
    
    Uses:
    • Transaction details (sanitized)
    • Agent analysis results
    • Risk indicators
    • Analyst notes
    • Outcome
    """
    
    example = {
        "scenario": f"Payment of ${queue_item['payment_amount']} to " 
                   f"{queue_item['payment_description']}. " 
                   f"{queue_item['context_summary']}",
        
        "amount": queue_item['payment_amount'],
        
        "indicators": queue_item['risk_indicators'],  # From agent results
        
        "employee_pattern": queue_item['employee_pattern'],
        
        "timing": {
            "approval_to_change_minutes": queue_item['time_delta_minutes'],
            "change_to_payment_minutes": queue_item['payment_delta_minutes']
        },
        
        "decision": queue_item['llm_decision'],
        
        "outcome": queue_item['actual_outcome'],
        
        "lesson": generate_lesson_learned(
            queue_item['risk_indicators'],
            queue_item['actual_outcome'],
            queue_item['analyst_notes']
        )
    }
    
    return example
```

---

## 5. Prompt Evolution Process

### 5.1 Version Management

```
Prompt Version Lifecycle:

v1.0 (Initial)
  │
  ├─ 100 decisions → accuracy: 85%
  │
  ├─ Add 5 examples from learning queue
  │
  ▼
v1.1 (Draft)
  │
  ├─ Analyst reviews changes
  ├─ Optional: A/B test (50/50 split)
  │
  ├─ Activate
  │
  ▼
v1.1 (Active) ← v1.0 (Archived)
  │
  ├─ 200 decisions → accuracy: 88% ✅ Improved!
  │
  ├─ Add 8 more examples
  │
  ▼
v1.2 (Draft)
  │
  ├─ Activate
  │
  ▼
v1.2 (Active) ← v1.1 (Archived)
  │
  ├─ 150 decisions → accuracy: 92% ✅ Improved again!
  │
  └─ Continue evolving...
```

### 5.2 Prompt Structure

```yaml
# Prompt Template Structure

system_prompt: |
  You are an expert fraud detection analyst for insurance claim payouts.
  Analyze the transaction and provide fraud risk assessment.
  
  Consider:
  - Employee control patterns
  - Payment timing anomalies
  - Account usage patterns
  - Historical fraud indicators
  
  Be especially vigilant for:
  - Same employee controlling multiple approval steps
  - Post-approval payee changes
  - First-time account usage with rapid payment
  - Amount structuring (just below reporting thresholds)

few_shot_examples:
  - scenario: "Payment of $9,500 to offshore account..."
    indicators: ["first_use_account", "post_approval_change"]
    decision: "BLOCK"
    outcome: "CONFIRMED_FRAUD"
    lesson: "When single employee controls all steps AND changes..."
  
  - scenario: "Payment of $2,500 to established vendor..."
    indicators: ["established_account", "verified_vendor"]
    decision: "ALLOW"
    outcome: "LEGITIMATE"
    lesson: "Established vendor with proper verification is low risk..."
  
  # ... 20+ more examples

output_format:
  risk_level: "LOW | MED | HIGH"
  confidence: 0.0 to 1.0
  reasoning: "Detailed explanation..."
  recommendation: "ALLOW | WARN | BLOCK"
```

---

## 6. Real-World Examples

### 6.1 Example 1: Critical Miss (ALLOW → FRAUD)

```
Initial Decision:
• System: ALLOW (rule score = 1, LOW risk)
• Reason: Only 1 control action by employee

Ground Truth (After Investigation):
• Actual: CONFIRMED_FRAUD
• Details: Employee colluded with external party, used compromised credentials
• Reward: -200 (Critical miss!)

Learning Queue Entry:
• Status: PENDING_REVIEW
• Priority: CRITICAL
• Reward: -200

Analyst Action:
• Generated example showing collusion pattern
• Added indicators: "off-hours access", "unusual IP address"
• Approved for prompt update

Result (v1.3):
• New prompt now includes collusion indicators
• Similar case 2 weeks later: BLOCKED ✅
• Accuracy improved from 92% to 94%
```

### 6.2 Example 2: False Positive (BLOCK → LEGITIMATE)

```
Initial Decision:
• System: BLOCK (rule score = 4, HIGH risk)
• Reason: First-time account + fast payment

Ground Truth:
• Actual: LEGITIMATE
• Details: Emergency payment to hospital, properly documented
• Reward: -100 (False positive)

Learning Queue Entry:
• Status: PENDING_REVIEW
• Category: False Positive
• Reward: -100

Analyst Action:
• Generated example showing legitimate urgent payment
• Added context: "medical emergency", "proper documentation"
• Approved for prompt update

Result (v1.4):
• New prompt learned to recognize legitimate urgent payments
• False positive rate decreased by 15%
• Customer satisfaction improved
```

### 6.3 Example 3: Perfect Detection (BLOCK → FRAUD)

```
Initial Decision:
• System: BLOCK (rule score = 5, HIGH risk)
• LLM confidence: 0.95
• Reasons: Multiple red flags

Ground Truth:
• Actual: CONFIRMED_FRAUD
• Details: Classic employee fraud scheme
• Reward: +100 (Perfect detection!)

Learning Queue Entry:
• Status: PENDING_REVIEW
• Category: Success Case
• Reward: +100

Analyst Action:
• Generated example reinforcing successful pattern
• Highlighted key indicators that led to detection
• Approved for prompt update

Result (v1.2):
• Example added to strengthen similar fraud detection
• Similar cases detected 100% of the time
• System confidence increased
```

---

## Key Metrics

### Learning Queue Performance
- **Average time in queue:** 2-5 days
- **Approval rate:** 75% (high-quality cases)
- **Rejection rate:** 20% (not suitable for training)
- **Pending rate:** 5% (awaiting review)

### Prompt Evolution Impact
- **v1.0 → v1.1:** +3% accuracy improvement
- **v1.1 → v1.2:** +4% accuracy improvement
- **v1.2 → v1.3:** +2% accuracy improvement
- **Overall improvement:** 85% → 94% accuracy (v1.0 → v1.3)

### Feedback Loop Efficiency
- **Cases reviewed per analyst:** ~50/day
- **High-value cases per week:** ~15-20
- **Prompt updates per month:** 2-3 versions
- **Time to incorporate feedback:** 3-7 days

---

**End of Learning & Feedback System Documentation**
