# System Architecture Overview
## Fraud Detection Platform - Complete Architecture

**Document Version:** 2.0  
**Last Updated:** February 7, 2026  
**Purpose:** Accurate visual representation of the fraud detection platform architecture

---

## Table of Contents

1. [High-Level Architecture Overview](#1-high-level-architecture-overview)
2. [Customer Data Enrichment Flow](#2-customer-data-enrichment-flow)
3. [Multi-Agent Analysis System](#3-multi-agent-analysis-system)
4. [Database Architecture](#4-database-architecture)
5. [Deployment Architecture](#5-deployment-architecture)

---

## 1. High-Level Architecture Overview

### 1.1 System Positioning in Customer Ecosystem

```
┌────────────────────────────────────────────────────────────────────────────────┐
│                         CUSTOMER ORGANIZATION                                   │
│                                                                                 │
│  ┌──────────────────┐         ┌──────────────────┐         ┌────────────────┐ │
│  │                  │         │                  │         │                │ │
│  │  Customer UI     │────────▶│  Customer        │────────▶│  Customer      │ │
│  │  Application     │         │  Backend         │         │  Database      │ │
│  │                  │         │                  │         │                │ │
│  │  (Web/Mobile)    │         │  (API Server)    │         │  (MySQL/       │ │
│  │                  │         │                  │         │   Postgres)    │ │
│  └──────────────────┘         └──────────────────┘         └────────────────┘ │
│                                      │                                          │
│                                      ▼                                          │
│                    ┌───────────────────────────────────┐                       │
│                    │ CUSTOMER ENRICHMENT LAYER         │                       │
│                    │ (Built by Customer or CG Team)    │                       │
│                    ├───────────────────────────────────┤                       │
│                    │                                   │                       │
│                    │ • Extract data from DB            │                       │
│                    │ • Hash sensitive fields (PII/PCI) │                       │
│                    │ • Calculate patterns              │                       │
│                    │ • Collect session history         │                       │
│                    │ • Map to API format               │                       │
│                    │                                   │                       │
│                    └───────────────────────────────────┘                       │
│                                      │                                          │
└──────────────────────────────────────┼──────────────────────────────────────────┘
                                       │
                                       │ HTTPS/REST API
                                       │ POST /api/v1/payout/decide
                                       │ Authorization: Bearer <token>
                                       ▼
┌────────────────────────────────────────────────────────────────────────────────┐
│                    OUR FRAUD DETECTION PLATFORM                                 │
│                              (FastAPI Server)                                   │
│                                                                                 │
│  ┌──────────────────────────────────────────────────────────────────────────┐  │
│  │                   PAYOUT DECISION ORCHESTRATOR                            │  │
│  │                      (Main Controller)                                    │  │
│  │                                                                           │  │
│  │  • Receives enriched payload                                             │  │
│  │  • Validates input                                                       │  │
│  │  • Coordinates agent execution                                           │  │
│  │  • Combines agent results                                                │  │
│  │  • Makes final decision                                                  │  │
│  │  • Returns response                                                      │  │
│  └──────────────────────────────────────────────────────────────────────────┘  │
│                                       │                                         │
│                                       ▼                                         │
│          ┌────────────────────────────────────────────────────────┐            │
│          │          RUN 3 RULE-BASED AGENTS (Parallel)            │            │
│          └────────────────────────────────────────────────────────┘            │
│                                       │                                         │
│            ┌──────────────────────────┼──────────────────────────┐             │
│            │                          │                          │             │
│            ▼                          ▼                          ▼             │
│  ┌─────────────────┐       ┌─────────────────┐       ┌─────────────────┐     │
│  │  AGENT 1        │       │  AGENT 2        │       │  AGENT 3        │     │
│  │  Employee       │       │  Last Mile      │       │  Graph Entity   │     │
│  │  Control        │       │  Payment        │       │  Link           │     │
│  │                 │       │                 │       │                 │     │
│  │  • SoD checks   │       │  • Time deltas  │       │  • Account      │     │
│  │  • Control      │       │  • Fast payment │       │    reuse        │     │
│  │    actions      │       │  • Verification │       │  • Multi-       │     │
│  │  • Role-based   │       │  • Post-approval│       │    claimant     │     │
│  │    risk         │       │    changes      │       │  • In-memory    │     │
│  │                 │       │                 │       │    registry     │     │
│  │  Risk: LOW/     │       │  Risk: LOW/     │       │  Risk: LOW/     │     │
│  │        MED/HIGH │       │        MED/HIGH │       │        MED/HIGH │     │
│  └─────────────────┘       └─────────────────┘       └─────────────────┘     │
│            │                          │                          │             │
│            └──────────────────────────┼──────────────────────────┘             │
│                                       │                                         │
│                                       ▼                                         │
│                          (Results passed to LLM Agent)                          │
│                                       │                                         │
│                                       ▼                                         │
│                  ┌──────────────────────────────────┐                          │
│                  │         AGENT 4                  │                          │
│                  │      LLM Reasoning Agent         │                          │
│                  │      (AWS Bedrock/Claude 3)      │                          │
│                  ├──────────────────────────────────┤                          │
│                  │                                  │                          │
│                  │ Input:                           │                          │
│                  │ • Agent 1-3 results              │                          │
│                  │ • Rule-based score               │                          │
│                  │ • Transaction context (sanitized)│                          │
│                  │ • Active prompt from DB          │                          │
│                  │                                  │                          │
│                  │ Processing:                      │                          │
│                  │ • Load few-shot examples         │                          │
│                  │ • Build context                  │                          │
│                  │ • Call Bedrock API               │                          │
│                  │ • Parse response                 │                          │
│                  │                                  │                          │
│                  │ Output:                          │
│                  │ • Risk level (LOW/MED/HIGH)      │                          │
│                  │ • Confidence score (0-1)         │                          │
│                  │ • Reasoning explanation          │                          │
│                  │ • Recommendation                 │                          │
│                  └──────────────────────────────────┘                          │
│                                       │                                         │
│                                       ▼                                         │
│  ┌──────────────────────────────────────────────────────────────────────────┐  │
│  │                   PAYOUT DECISION ORCHESTRATOR                            │  │
│  │                   (Combine Agent Results)                                 │  │
│  │                                                                           │  │
│  │  Decision Logic:                                                          │  │
│  │  1. Calculate total risk score (sum of 3 agents)                         │  │
│  │  2. Rule-based decision: 0=ALLOW, 1-3=WARN, 4+=BLOCK                     │  │
│  │  3. If LLM has HIGH confidence + HIGH risk → Override to BLOCK            │  │
│  │  4. Final decision = Rule-based OR LLM override                           │  │
│  │                                                                           │  │
│  └──────────────────────────────────────────────────────────────────────────┘  │
│                                       │                                         │
│                                       ▼                                         │
│  ┌──────────────────────────────────────────────────────────────────────────┐  │
│  │                         DATA STORAGE LAYER                                │  │
│  │                                                                           │  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐ │  │
│  │  │  DynamoDB    │  │  DynamoDB    │  │  DynamoDB    │  │  In-Memory  │ │  │
│  │  │              │  │              │  │              │  │   Python    │ │  │
│  │  │  Decisions   │  │   Prompts    │  │   Learning   │  │   Dict      │ │  │
│  │  │   History    │  │  Versions    │  │    Queue     │  │  (Registry) │ │  │
│  │  └──────────────┘  └──────────────┘  └──────────────┘  └─────────────┘ │  │
│  └──────────────────────────────────────────────────────────────────────────┘  │
│                                       │                                         │
│                                       ▼                                         │
│  ┌──────────────────────────────────────────────────────────────────────────┐  │
│  │                      OBSERVABILITY & AUDIT                                │  │
│  │  • LangSmith (LLM tracing)                                                │  │
│  │  • Prometheus (metrics at /metrics)                                       │  │
│  │  • File-based audit logs                                                  │  │
│  │  • Performance monitoring                                                 │  │
│  └──────────────────────────────────────────────────────────────────────────┘  │
│                                                                                 │
└────────────────────────────────────────────────────────────────────────────────┘
                                       │
                                       │ JSON Response
                                       │ { decision: "ALLOW|WARN|BLOCK",
                                       │   risk_level: "LOW|MED|HIGH",
                                       │   confidence: 0.95,
                                       │   reasons: [...],
                                       │   agent_results: {...} }
                                       ▼
┌────────────────────────────────────────────────────────────────────────────────┐
│                         CUSTOMER ORGANIZATION                                   │
│                                                                                 │
│  ┌──────────────────────────────────────────────────────────────────────────┐  │
│  │  Customer Backend Processes Decision                                      │  │
│  │                                                                           │  │
│  │  IF decision == "ALLOW":                                                  │  │
│  │     ✅ Process payment normally                                           │  │
│  │     ✅ Send to payment gateway                                            │  │
│  │                                                                           │  │
│  │  ELSE IF decision == "WARN":                                              │  │
│  │     ⚠️  Route to fraud analyst for manual review                          │  │
│  │     ⚠️  Hold payment pending review                                       │  │
│  │                                                                           │  │
│  │  ELSE IF decision == "BLOCK":                                             │  │
│  │     🚫 Reject transaction immediately                                     │  │
│  │     🚫 Notify customer                                                    │  │
│  │     🚫 Log security incident                                              │  │
│  └──────────────────────────────────────────────────────────────────────────┘  │
│                                                                                 │
└────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Customer Data Enrichment Flow

### 2.1 Data Transformation Pipeline

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        CUSTOMER'S INTERNAL SYSTEMS                               │
└─────────────────────────────────────────────────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  STEP 1: Data Collection from Multiple Sources                                  │
│                                                                                  │
│  ┌──────────────────┐   ┌──────────────────┐   ┌──────────────────┐            │
│  │   Transactions   │   │    Employees     │   │   Bank Accounts  │            │
│  │      Table       │   │      Table       │   │      Table       │            │
│  ├──────────────────┤   ├──────────────────┤   ├──────────────────┤            │
│  │ • id             │   │ • emp_id         │   │ • account_no     │            │
│  │ • amount         │   │ • name           │   │ • routing        │            │
│  │ • status         │   │ • role           │   │ • holder         │            │
│  │ • date           │   │ • department     │   │ • type           │            │
│  │ • claimant_id    │   └──────────────────┘   │ • created_date   │            │
│  │ • vendor_id      │                          └──────────────────┘            │
│  └──────────────────┘                                                           │
│                                                                                  │
│  ┌──────────────────┐   ┌──────────────────┐   ┌──────────────────┐            │
│  │   Audit Log      │   │     Claims       │   │     Vendors      │            │
│  │      Table       │   │      Table       │   │      Table       │            │
│  ├──────────────────┤   ├──────────────────┤   ├──────────────────┤            │
│  │ • timestamp      │   │ • claim_id       │   │ • vendor_id      │            │
│  │ • employee_id    │   │ • status         │   │ • business_name  │            │
│  │ • action         │   │ • approved_at    │   │ • first_txn_date │            │
│  │ • claim_id       │   │ • amount         │   │ • category       │            │
│  │ • ip_address     │   │ • claimant_id    │   │ • risk_rating    │            │
│  └──────────────────┘   └──────────────────┘   └──────────────────┘            │
└─────────────────────────────────────────────────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  STEP 2: Customer Enrichment Layer                                              │
│  (Built by Customer or CG Team)                                                 │
│                                                                                  │
│  def enrich_for_fraud_detection(transaction, employee, claim, bank_account):    │
│                                                                                  │
│      # 1️⃣ Hash Sensitive Data (PII/PCI Compliance)                              │
│      ┌──────────────────────────────────────────────────────────────┐           │
│      │ import hashlib                                               │           │
│      │                                                              │           │
│      │ account_hash = hashlib.sha256(                               │           │
│      │     bank_account.account_number.encode()                     │           │
│      │ ).hexdigest()                                                │           │
│      │                                                              │           │
│      │ routing_hash = hashlib.sha256(                               │           │
│      │     bank_account.routing_number.encode()                     │           │
│      │ ).hexdigest()                                                │           │
│      └──────────────────────────────────────────────────────────────┘           │
│                                                                                  │
│      # 2️⃣ Collect Session History (Last 30 minutes)                             │
│      ┌──────────────────────────────────────────────────────────────┐           │
│      │ session_actions = db.query(                                  │           │
│      │     "SELECT * FROM audit_log "                               │           │
│      │     "WHERE claim_id = %s "                                   │           │
│      │     "AND timestamp >= NOW() - INTERVAL 30 MINUTE",           │           │
│      │     (claim.id,)                                              │           │
│      │ )                                                            │           │
│      │                                                              │           │
│      │ # Transform to required format                               │           │
│      │ session_actions = [{                                         │           │
│      │     'action_type': row['action'],                            │           │
│      │     'employee_id': row['employee_id'],                       │           │
│      │     'timestamp': row['timestamp'].isoformat() + 'Z'          │           │
│      │ } for row in session_actions]                                │           │
│      └──────────────────────────────────────────────────────────────┘           │
│                                                                                  │
│      # 3️⃣ Calculate Account Pattern                                             │
│      ┌──────────────────────────────────────────────────────────────┐           │
│      │ # Check if account used before                               │           │
│      │ previous_uses = db.query(                                    │           │
│      │     "SELECT DISTINCT claimant_id FROM transactions "         │           │
│      │     "WHERE account_number = %s",                             │           │
│      │     (bank_account.account_number,)                           │           │
│      │ )                                                            │           │
│      │                                                              │           │
│      │ if len(previous_uses) == 0:                                  │           │
│      │     account_pattern = "FIRST_USE"                            │           │
│      │ elif len(previous_uses) == 1:                                │           │
│      │     account_pattern = "ESTABLISHED"                          │           │
│      │ else:                                                        │           │
│      │     account_pattern = "REUSED_ACROSS_CLAIMS"                │           │
│      └──────────────────────────────────────────────────────────────┘           │
│                                                                                  │
│      # 4️⃣ Detect Post-Approval Changes                                          │
│      ┌──────────────────────────────────────────────────────────────┐           │
│      │ payee_changed = False                                        │           │
│      │                                                              │           │
│      │ if claim.status == "APPROVED":                               │           │
│      │     changes = db.query(                                      │           │
│      │         "SELECT * FROM audit_log "                           │           │
│      │         "WHERE claim_id = %s "                               │           │
│      │         "AND action IN ('UPDATE_PAYEE_BANK', "               │           │
│      │         "                'UPDATE_PAYEE_ADDRESS') "           │           │
│      │         "AND timestamp > %s",                                │           │
│      │         (claim.id, claim.approved_at)                        │           │
│      │     )                                                        │           │
│      │     payee_changed = len(changes) > 0                         │           │
│      └──────────────────────────────────────────────────────────────┘           │
│                                                                                  │
│      # 5️⃣ Map to API Format                                                     │
│      ┌──────────────────────────────────────────────────────────────┐           │
│      │ return {                                                     │           │
│      │     "current_action": {                                      │           │
│      │         "action_type": "RELEASE_PAYMENT",                    │           │
│      │         "employee_id": f"EMP-{employee.id}",                 │           │
│      │         "timestamp": datetime.utcnow().isoformat() + 'Z',    │           │
│      │         "claim_id": claim.id,                                │           │
│      │         "payment_id": transaction.id                         │           │
│      │     },                                                       │           │
│      │     "session_actions": session_actions,                      │           │
│      │     "actor_role": employee.role,                             │           │
│      │     "bank_account_hash": account_hash,                       │           │
│      │     "routing_hash": routing_hash,                            │           │
│      │     "claimant_id": claim.claimant_id,                        │           │
│      │     "account_pattern": account_pattern,                      │           │
│      │     "payment_method": "ACH_STANDARD",                        │           │
│      │     "payment_amount": transaction.amount,                    │           │
│      │     "claim_status": claim.status,                            │           │
│      │     "approval_timestamp": claim.approved_at.isoformat()+'Z', │           │
│      │     "payee_changed_after_approval": payee_changed,           │           │
│      │     "verification_flag": bank_account.verified,              │           │
│      │     "payment_release_request": True                          │           │
│      │ }                                                            │           │
│      └──────────────────────────────────────────────────────────────┘           │
└─────────────────────────────────────────────────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  STEP 3: Enriched Payload (Ready for API)                                       │
│                                                                                  │
│  POST https://api.fraud-detection.com/api/v1/payout/decide                      │
│  Headers:                                                                        │
│    Authorization: Bearer customer_api_key_12345                                 │
│    Content-Type: application/json                                               │
│                                                                                  │
│  Body:                                                                           │
│  {                                                                               │
│    "current_action": {                                                           │
│      "action_type": "RELEASE_PAYMENT",                                           │
│      "employee_id": "EMP-5678",                                                  │
│      "timestamp": "2026-02-07T14:45:30Z",                                        │
│      "claim_id": "CLM-123456",                                                   │
│      "payment_id": "PAY-789012"                                                  │
│    },                                                                            │
│    "session_actions": [                                                          │
│      {"action_type": "APPROVE_CLAIM", "employee_id": "EMP-5678", ...},          │
│      {"action_type": "UPDATE_PAYEE_BANK", "employee_id": "EMP-5678", ...},      │
│      {"action_type": "RELEASE_PAYMENT", "employee_id": "EMP-5678", ...}         │
│    ],                                                                            │
│    "actor_role": "claims_processor",                                             │
│    "bank_account_hash": "a1b2c3d4e5f6g7h8...",  ← SHA-256 hashed                │
│    "routing_hash": "x9y8z7w6v5u4t3s2...",                                        │
│    "claimant_id": "CLMT-456789",                                                 │
│    "account_pattern": "FIRST_USE",                                               │
│    "payment_method": "ACH_SAME_DAY",                                             │
│    "payment_amount": 9500.00,                                                    │
│    "claim_status": "APPROVED",                                                   │
│    "approval_timestamp": "2026-02-07T14:30:00Z",                                 │
│    "payee_changed_after_approval": true,                                         │
│    "verification_flag": false,                                                   │
│    "payment_release_request": true                                               │
│  }                                                                               │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Multi-Agent Analysis System

### 3.1 Agent Execution Flow

```
                         ENRICHED DATA INPUT
                                 │
                                 ▼
            ┌────────────────────────────────────────┐
            │   Payout Decision Orchestrator         │
            │   (Main Controller)                    │
            │                                        │
            │  • Receives request                    │
            │  • Validates input                     │
            │  • Extracts fields                     │
            │  • Starts agent execution              │
            └────────────────────────────────────────┘
                                 │
                                 ▼
          ┌──────────────────────────────────────────┐
          │   RUN 3 AGENTS IN PARALLEL (~5ms)        │
          └──────────────────────────────────────────┘
                                 │
            ┌────────────────────┼────────────────────┐
            │                    │                    │
            ▼                    ▼                    ▼
┌────────────────────┐  ┌────────────────────┐  ┌────────────────────┐
│  AGENT 1           │  │  AGENT 2           │  │  AGENT 3           │
│  Employee Control  │  │  Last Mile Payment │  │  Graph Entity Link │
├────────────────────┤  ├────────────────────┤  ├────────────────────┤
│                    │  │                    │  │                    │
│ Input:             │  │ Input:             │  │ Input:             │
│ • current_action   │  │ • claim_status     │  │ • bank_acct_hash   │
│ • session_actions  │  │ • approval_time    │  │ • claimant_id      │
│ • employee_id      │  │ • payee_change_time│  │ • account_pattern  │
│ • actor_role       │  │ • payment_method   │  │ • payee_changed    │
│                    │  │ • verification_flag│  │ • employee_id      │
│                    │  │                    │  │                    │
│ Logic:             │  │ Logic:             │  │ Logic:             │
│ ✓ Count control    │  │ ✓ Time delta calc  │  │ ✓ Lookup registry  │
│   actions by       │  │ ✓ Fast payment?    │  │   (Python dict)    │
│   same employee    │  │ ✓ Unverified?      │  │ ✓ Track reuse      │
│ ✓ Detect SoD       │  │ ✓ Rapid change?    │  │   patterns         │
│   violations       │  │                    │  │ ✓ Multi-claimant?  │
│                    │  │                    │  │ ✓ Update registry  │
│                    │  │                    │  │                    │
│ Thresholds:        │  │ Thresholds:        │  │ Thresholds:        │
│ • 2 actions = MED  │  │ • <=10 min = HIGH  │  │ • 2+ claimants=HIGH│
│ • 3+ actions = HIGH│  │ • Fast pay = MED   │  │ • FIRST_USE+change │
│                    │  │ • No verify = MED  │  │   = MED            │
│                    │  │                    │  │                    │
│ Output:            │  │ Output:            │  │ Output:            │
│ {                  │  │ {                  │  │ {                  │
│   control_risk:    │  │   last_mile_risk:  │  │   entity_risk:     │
│     "MED",         │  │     "HIGH",        │  │     "HIGH",        │
│   control_count: 2,│  │   risk_points: 3,  │  │   risk_points: 3,  │
│   reasons: [...]   │  │   reasons: [...]   │  │   reasons: [...]   │
│ }                  │  │ }                  │  │ }                  │
└────────────────────┘  └────────────────────┘  └────────────────────┘
            │                    │                    │
            │                    │                    │
            └────────────────────┼────────────────────┘
                                 │
                                 ▼
            ┌────────────────────────────────────────┐
            │   Orchestrator Calculates Score        │
            │                                        │
            │  • Map risks: LOW=0, MED=1, HIGH=2     │
            │  • Sum: 0+1+2 = 3                      │
            │  • Rule decision: Score 3 = WARN       │
            └────────────────────────────────────────┘
                                 │
                                 ▼
                  ┌──────────────────────────────────┐
                  │         AGENT 4                  │
                  │      LLM Reasoning Agent         │
                  │      (AWS Bedrock/Claude 3)      │
                  ├──────────────────────────────────┤
                  │                                  │
                  │ Input:                           │
                  │ • Agent 1-3 results              │
                  │ • Rule score: 3                  │
                  │ • Rule decision: WARN            │
                  │ • Reasons: [merged list]         │
                  │ • Transaction context (sanitized)│
                  │                                  │
                  │ Processing (~600ms):             │
                  │ ┌──────────────────────────────┐ │
                  │ │ 1. Fetch active prompt       │ │
                  │ │    from DynamoDB             │ │
                  │ │                              │ │
                  │ │ 2. Build LLM context:        │ │
                  │ │    • System prompt           │ │
                  │ │    • Few-shot examples (20+) │ │
                  │ │    • Agent results           │ │
                  │ │    • Transaction data        │ │
                  │ │                              │ │
                  │ │ 3. Call AWS Bedrock API      │ │
                  │ │    Model: Claude 3 Sonnet    │ │
                  │ │    Temperature: 0.3          │ │
                  │ │                              │ │
                  │ │ 4. Parse JSON response       │ │
                  │ └──────────────────────────────┘ │
                  │                                  │
                  │ Output:                          │
                  │ {                                │
                  │   risk_level: "HIGH",            │
                  │   confidence: 0.92,              │
                  │   reasoning: "Multiple high-risk │
                  │     indicators suggest employee  │
                  │     fraud pattern...",           │
                  │   recommendation: "BLOCK"        │
                  │ }                                │
                  └──────────────────────────────────┘
                                 │
                                 ▼
            ┌────────────────────────────────────────┐
            │   Orchestrator Combines Decisions      │
            │                                        │
            │  Rule Decision: WARN                   │
            │  LLM Decision: BLOCK                   │
            │  LLM Confidence: 0.92 (HIGH)           │
            │                                        │
            │  Logic:                                │
            │  IF LLM confidence >= 0.85 AND         │
            │     LLM risk == HIGH:                  │
            │     → Override to BLOCK                │
            │                                        │
            │  Final Decision: BLOCK ✅              │
            └────────────────────────────────────────┘
                                 │
                                 ▼
            ┌────────────────────────────────────────┐
            │   Store in DynamoDB                    │
            │   Log to audit file                    │
            │   Record metrics (Prometheus)          │
            │   Trace LLM call (LangSmith)           │
            └────────────────────────────────────────┘
                                 │
                                 ▼
                    RETURN DECISION RESPONSE
                    {
                      "decision": "BLOCK",
                      "total_score": 3,
                      "llm_confidence": 0.92,
                      "reasons": [
                        "Same employee: 3 control actions",
                        "First-time account + post-approval change",
                        "Fast payment method",
                        "Changed 8 min after approval"
                      ],
                      "per_agent": {
                        "employee_control": {...},
                        "lastmile_payment": {...},
                        "graph_entity": {...}
                      },
                      "llm_insights": {...}
                    }
```

### 3.2 Risk Score Calculation

```
┌───────────────────────────────────────────────────────────────────┐
│                    RISK SCORING SYSTEM                             │
└───────────────────────────────────────────────────────────────────┘

STEP 1: Map Agent Risks to Scores
┌─────────────────────────────────────┐
│ Risk Level Mapping:                 │
│ • LOW  → 0 points                   │
│ • MED  → 1 point                    │
│ • HIGH → 2 points                   │
└─────────────────────────────────────┘

STEP 2: Calculate Total Score
┌─────────────────────────────────────┐
│ Example:                            │
│ • Employee Control: MED  → 1 point  │
│ • Last Mile Payment: HIGH → 2 points│
│ • Graph Entity: HIGH → 2 points     │
│                                     │
│ Total Score = 1 + 2 + 2 = 5         │
└─────────────────────────────────────┘

STEP 3: Rule-Based Decision
┌─────────────────────────────────────┐
│ Score 0:     → ALLOW                │
│ Score 1-3:   → WARN                 │
│ Score 4+:    → BLOCK                │
│                                     │
│ Example: Score 5 → BLOCK            │
└─────────────────────────────────────┘

STEP 4: LLM Override (if applicable)
┌─────────────────────────────────────┐
│ If LLM confidence >= 0.85 AND       │
│    LLM risk == HIGH:                │
│    → Final decision = BLOCK         │
│                                     │
│ If LLM confidence < 0.6:            │
│    → Use rule-based decision        │
│                                     │
│ Otherwise:                          │
│    → Consider both (weighted)       │
└─────────────────────────────────────┘
```

---

## 4. Database Architecture

### 4.1 DynamoDB Tables Structure

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           AWS DYNAMODB REGION                                │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
            ┌───────────────────────┼───────────────────────┐
            │                       │                       │
            ▼                       ▼                       ▼
┌──────────────────────┐  ┌──────────────────────┐  ┌──────────────────────┐
│ TABLE 1              │  │ TABLE 2              │  │ TABLE 3              │
│ FraudDetection       │  │ FraudDetection       │  │ PromptLearning       │
│ Decisions            │  │ Prompts              │  │ Queue                │
├──────────────────────┤  ├──────────────────────┤  ├──────────────────────┤
│                      │  │                      │  │                      │
│ Partition Key:       │  │ Partition Key:       │  │ Partition Key:       │
│ • event_id           │  │ • event_type         │  │ • queue_id           │
│                      │  │                      │  │                      │
│ Sort Key:            │  │ Sort Key:            │  │ Sort Key:            │
│ • timestamp          │  │ • version_id         │  │ • created_at         │
│                      │  │                      │  │                      │
│ Attributes:          │  │ Attributes:          │  │ Attributes:          │
│ • transaction_id     │  │ • prompt_id          │  │ • event_id           │
│ • decision           │  │ • prompt_version     │  │ • event_type         │
│ • risk_level         │  │ • system_prompt      │  │ • reward_score       │
│ • confidence         │  │ • few_shot_examples[]│  │ • llm_decision       │
│ • agent_results {}   │  │ • is_active          │  │ • actual_outcome     │
│ • processing_time_ms │  │ • status             │  │ • is_correct         │
│ • customer_id        │  │ • created_by         │  │ • incorporated       │
│ • reasons []         │  │ • accuracy_metrics{} │  │ • review_status      │
│ • reviewed           │  │ • examples_count     │  │ • reviewed_by        │
│ • actual_outcome     │  │ • parent_version_id  │  │ • example_data {}    │
│ • reward_score       │  │                      │  │                      │
│ • llm_insights {}    │  │ GSI:                 │  │ GSI:                 │
│                      │  │ • ActivePrompts      │  │ • EventType-Status   │
│ GSI:                 │  │   (is_active +       │  │   (event_type +      │
│ • CustomerIndex      │  │    event_type)       │  │    review_status)    │
│   (customer_id +     │  │                      │  │                      │
│    timestamp)        │  │                      │  │                      │
│ • DecisionIndex      │  │                      │  │                      │
│   (decision +        │  │                      │  │                      │
│    timestamp)        │  │                      │  │                      │
│                      │  │                      │  │                      │
│ Use Cases:           │  │ Use Cases:           │  │ Use Cases:           │
│ • Store decisions    │  │ • Prompt versions    │  │ • High-value cases   │
│ • Audit trail        │  │ • Active lookup      │  │ • Training examples  │
│ • Analytics          │  │ • A/B testing        │  │ • Analyst review     │
│ • Feedback loop      │  │ • Rollback support   │  │ • Auto-prompt gen    │
│                      │  │                      │  │                      │
└──────────────────────┘  └──────────────────────┘  └──────────────────────┘
            │                       │                       │
            └───────────────────────┼───────────────────────┘
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                   IN-MEMORY GRAPH REGISTRY (Python Dict)                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Location: app/agents/graph_entity_agent.py                                  │
│  Type: Class variable (Python dict)                                          │
│  Scope: Single instance (not distributed)                                    │
│                                                                              │
│  Structure:                                                                  │
│  {                                                                           │
│    "account_hash_abc123": {                                                  │
│      "claims": {"CLM-001", "CLM-002", "CLM-003"},         # 3 claims        │
│      "claimants": {"CLMT-111", "CLMT-222"},               # 2 claimants ⚠️  │
│      "employees": {"EMP-5678"}                            # 1 employee       │
│    },                                                                        │
│    "account_hash_xyz789": {                                                  │
│      "claims": {"CLM-004"},                                                  │
│      "claimants": {"CLMT-333"},                                              │
│      "employees": {"EMP-9999"}                                               │
│    }                                                                         │
│  }                                                                           │
│                                                                              │
│  Operations:                                                                 │
│  • Add: account_registry[hash]['claims'].add(claim_id)                       │
│  • Query: len(account_registry[hash]['claimants'])                           │
│  • Analysis: Detect multi-claimant patterns                                  │
│                                                                              │
│  Limitations:                                                                │
│  • Not persistent (resets on server restart)                                 │
│  • Not distributed (single process only)                                     │
│  • Not suitable for multi-instance deployment                                │
│                                                                              │
│  Production Scaling Options:                                                 │
│  • Migrate to Redis (distributed, persistent)                                │
│  • Use DynamoDB with TTL (serverless, scalable)                              │
│  • Implement graph database (Neo4j, Neptune)                                 │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 5. Deployment Architecture

### 5.1 Current Deployment (Single Instance)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           DEVELOPMENT/DEMO SETUP                             │
└─────────────────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────┐
│                     LOCAL MACHINE / EC2 INSTANCE                   │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │  FastAPI Server (Port 8000)                                  │ │
│  │  • app/main.py                                               │ │
│  │  • Uvicorn ASGI server                                       │ │
│  │  • Single process                                            │ │
│  └──────────────────────────────────────────────────────────────┘ │
│                            │                                       │
│                            ▼                                       │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │  Payout Decision Orchestrator + 4 Agents                     │ │
│  │  • In-memory graph registry (Python dict)                    │ │
│  │  • AWS Bedrock client (LLM)                                  │ │
│  └──────────────────────────────────────────────────────────────┘ │
│                            │                                       │
│                            ▼                                       │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │  File System                                                 │ │
│  │  • logs/ (audit logs)                                        │ │
│  │  • .env (configuration)                                      │ │
│  └──────────────────────────────────────────────────────────────┘ │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
                            │
            ┌───────────────┼───────────────┐
            │               │               │
            ▼               ▼               ▼
    ┌─────────────┐  ┌─────────────┐  ┌─────────────┐
    │  DynamoDB   │  │ AWS Bedrock │  │ LangSmith   │
    │  (AWS)      │  │ (Claude 3)  │  │ (Tracing)   │
    └─────────────┘  └─────────────┘  └─────────────┘

┌────────────────────────────────────────────────────────────────────┐
│                     STREAMLIT UI (Port 8501)                       │
│  • SIU-Fraud-Dashboard/app.py                                      │
│  • Connects to FastAPI server                                      │
│  • Separate process                                                │
└────────────────────────────────────────────────────────────────────┘
```

---

## Key System Characteristics

### Technology Stack
- **Backend:** Python 3.11+, FastAPI
- **Agents:** Rule-based (Python) + LLM (AWS Bedrock/Claude 3)
- **Database:** AWS DynamoDB
- **Graph Registry:** In-memory Python dict (demo), Redis (production)
- **Observability:** LangSmith, Prometheus, file-based audit logs
- **UI:** Streamlit (SIU Fraud Dashboard)

### Internal Agent Communication
- **Method:** Direct Python async method calls (`await agent.execute(data)`)
- **Architecture:** All agents run in same Python process for optimal performance
- **NOT using A2A protocol internally** - direct method calls avoid unnecessary overhead
- **External A2A Integration:** Available via MCP server (Model Context Protocol) for external agent/LLM access
  - MCP exposes fraud detection tools to external AI agents (e.g., Claude Desktop)
  - External agents discover and invoke tools via standardized protocol
  - Internal implementation remains optimized with direct calls

### Performance Metrics
- **Rule-based agents:** ~5ms (parallel execution)
- **LLM agent:** ~600ms (AWS Bedrock API call)
- **Total processing time:** ~750ms average
- **Throughput:** ~100 requests/minute (single instance)

### Scalability Considerations
1. **In-memory registry limitation:** Not suitable for multi-instance deployment
2. **Upgrade path:** Migrate to Redis or DynamoDB for distributed architecture
3. **LLM caching:** Cache prompt templates for faster LLM calls
4. **Horizontal scaling:** Deploy multiple instances behind load balancer

---

## Next Steps for Production

1. **Replace in-memory registry** with Redis or DynamoDB
2. **Add API Gateway** for authentication, rate limiting, and request validation
3. **Implement caching** for prompts and frequent queries
4. **Add health checks** and readiness probes
5. **Set up CI/CD pipeline** for automated deployment
6. **Configure auto-scaling** based on traffic patterns
7. **Implement multi-region** deployment for high availability

---

**End of Architecture Overview**
