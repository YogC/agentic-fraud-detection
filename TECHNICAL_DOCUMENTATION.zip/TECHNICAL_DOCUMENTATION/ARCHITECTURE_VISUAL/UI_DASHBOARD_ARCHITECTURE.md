# UI Dashboard Architecture
## SIU Fraud Detection Dashboard - Complete Guide

**Document Version:** 1.0  
**Last Updated:** February 7, 2026  
**Purpose:** Complete documentation of the Streamlit UI dashboard architecture

---

## Table of Contents

1. [Dashboard Overview](#1-dashboard-overview)
2. [Dashboard Architecture](#2-dashboard-architecture)
3. [Page 1: Main Dashboard](#3-page-1-main-dashboard)
4. [Page 2: Prompt Management](#4-page-2-prompt-management)
5. [Page 3: Learning Queue](#5-page-3-learning-queue)
6. [User Workflows](#6-user-workflows)
7. [API Integration](#7-api-integration)

---

## 1. Dashboard Overview

The SIU Fraud Detection Dashboard is a Streamlit-based web application that provides fraud analysts with tools to:
- Review fraud detection decisions
- Test transactions in real-time
- Manage LLM prompts and versions
- Review and approve learning queue items
- Monitor system accuracy and performance

### 1.1 Key Features

✅ **Real-Time Testing:** Test transactions and see fraud detection results instantly  
✅ **Feedback Loop:** Provide ground truth and improve the system  
✅ **Prompt Management:** Edit, version, and activate LLM prompts  
✅ **Learning Queue:** Review high-value cases and generate training data  
✅ **Analytics:** Monitor accuracy, decision distribution, and agent performance

---

## 2. Dashboard Architecture

### 2.1 Overall Structure

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    SIU FRAUD DASHBOARD (Streamlit)                           │
│                    URL: http://localhost:8501                                │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ Streamlit Multi-Page App
                                    │
            ┌───────────────────────┼───────────────────────┐
            │                       │                       │
            ▼                       ▼                       ▼
┌──────────────────────┐  ┌──────────────────────┐  ┌──────────────────────┐
│ PAGE 1               │  │ PAGE 2               │  │ PAGE 3               │
│ 🏠 Dashboard         │  │ 📚 Prompt            │  │ 🎓 Learning          │
│ 1_🏠_Dashboard.py    │  │    Management        │  │    Queue             │
│                      │  │ 2_📚_Prompt_*.py     │  │ 3_🎓_Learning_*.py   │
│                      │  │                      │  │                      │
│ • Metrics overview   │  │ • Event type select  │  │ • Load items         │
│ • Recent decisions   │  │ • Prompt versions    │  │ • Review cases       │
│ • Transaction test   │  │ • Edit system prompt │  │ • Generate examples  │
│ • Feedback form      │  │ • Few-shot examples  │  │ • Approve/reject     │
│ • Analytics charts   │  │ • Activate prompts   │  │ • Add to prompts     │
│                      │  │ • Compare versions   │  │                      │
└──────────────────────┘  └──────────────────────┘  └──────────────────────┘
            │                       │                       │
            └───────────────────────┴───────────────────────┘
                                    │
                                    ▼
                         API CLIENT (Python)
                         api_client.py
                                    │
                ┌───────────────────┼───────────────────┬───────────────────┐
                │                   │                   │                   │
                ▼                   ▼                   ▼                   ▼
    ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
    │ POST /payout/    │  │ POST /feedback   │  │ GET /prompts     │  │ GET /learning/   │
    │      decide      │  │                  │  │ POST /prompts    │  │      queue       │
    └──────────────────┘  └──────────────────┘  └──────────────────┘  └──────────────────┘
                │                   │                   │                   │
                └───────────────────┴───────────────────┴───────────────────┘
                                    │
                                    ▼
                    FRAUD DETECTION API (FastAPI)
                    http://localhost:8000
```

### 2.2 Technology Stack

- **Frontend:** Streamlit 1.28+
- **API Client:** Python requests library
- **Charting:** Plotly (interactive charts)
- **Data Display:** Pandas DataFrames
- **Styling:** Custom CSS via st.markdown()

---

## 3. Page 1: Main Dashboard

### 3.1 Dashboard Layout

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        🏠 SIU FRAUD DETECTION DASHBOARD                      │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 1: METRICS OVERVIEW (Top Cards)                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │ Total        │  │ Blocked      │  │ Warned       │  │ Allowed      │   │
│  │ Decisions    │  │              │  │              │  │              │   │
│  │              │  │              │  │              │  │              │   │
│  │    1,250     │  │     125      │  │     380      │  │     745      │   │
│  │              │  │    (10%)     │  │    (30%)     │  │    (60%)     │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
│                                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │ System       │  │ Avg Conf.    │  │ High Risk    │  │ Processing   │   │
│  │ Accuracy     │  │              │  │ Cases        │  │ Time         │   │
│  │              │  │              │  │              │  │              │   │
│  │    94.2%     │  │    0.89      │  │     45       │  │   750ms      │   │
│  │     🎯       │  │     📊       │  │     🚨       │  │     ⚡       │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 2: RECENT DECISIONS (Filterable Table)                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Filters: [All Decisions ▼] [Last 24 Hours ▼] [All Risk Levels ▼]          │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ Event ID      │ Time       │ Decision │ Risk  │ Conf. │ Employee      │ │
│  ├────────────────────────────────────────────────────────────────────────┤ │
│  │ EVT-2026-001  │ 14:45:30   │ 🚫 BLOCK │ HIGH  │ 0.95  │ EMP-5678      │ │
│  │ EVT-2026-002  │ 14:42:15   │ ⚠️  WARN  │ MED   │ 0.78  │ EMP-9012      │ │
│  │ EVT-2026-003  │ 14:38:22   │ ✅ ALLOW │ LOW   │ 0.65  │ EMP-3456      │ │
│  │ EVT-2026-004  │ 14:35:10   │ 🚫 BLOCK │ HIGH  │ 0.92  │ EMP-7890      │ │
│  │ ...           │ ...        │ ...      │ ...   │ ...   │ ...           │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  Click on any row to see full details ↓                                     │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 3: DECISION DETAILS (Expandable)                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Selected: EVT-2026-001                                                      │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ 🚫 DECISION: BLOCK                                                     │ │
│  │ 🎯 Risk Level: HIGH                                                    │ │
│  │ 📊 Confidence: 0.95                                                    │ │
│  │ ⏱️  Processing Time: 750ms                                             │ │
│  ├────────────────────────────────────────────────────────────────────────┤ │
│  │                                                                        │ │
│  │ Reasons:                                                               │ │
│  │ • 🚨 Same employee performed 3 control actions (SoD violation)        │ │
│  │ • 🚨 First-time account with post-approval change (8 minutes)         │ │
│  │ • ⚠️ Fast payment method requested (ACH same-day)                      │ │
│  │                                                                        │ │
│  ├────────────────────────────────────────────────────────────────────────┤ │
│  │ Agent Results:                                                         │ │
│  │                                                                        │ │
│  │ Employee Control Agent: 🟡 MED (Score: 1)                             │ │
│  │   • Control count: 2 actions by same employee                         │ │
│  │   • Separation of duties concern                                      │ │
│  │                                                                        │ │
│  │ Graph Entity Agent: 🔴 HIGH (Score: 2)                                │ │
│  │   • First-time account usage                                          │ │
│  │   • Post-approval payee change detected                               │ │
│  │                                                                        │ │
│  │ Last Mile Payment Agent: 🔴 HIGH (Score: 2)                           │ │
│  │   • Time delta: 8 minutes (approval to change)                        │ │
│  │   • Fast payment method: ACH same-day                                 │ │
│  │                                                                        │ │
│  │ LLM Reasoning Agent: 🔴 HIGH (Confidence: 0.92)                       │ │
│  │   • "Multiple high-risk indicators suggest coordinated employee       │ │
│  │      fraud scheme. Pattern matches known fraud cases."                │ │
│  │                                                                        │ │
│  ├────────────────────────────────────────────────────────────────────────┤ │
│  │ Transaction Details:                                                   │ │
│  │ • Claim ID: CLM-123456                                                 │ │
│  │ • Payment ID: PAY-789012                                               │ │
│  │ • Amount: $9,500.00                                                    │ │
│  │ • Employee: EMP-5678 (claims_processor)                                │ │
│  │ • Bank Account: ***6789 (hashed)                                       │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  [📝 Provide Feedback]  [🔄 Reanalyze]  [📊 View in Learning Queue]         │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 4: TEST NEW TRANSACTION                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Test a new transaction for fraud:                                          │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ Transaction Details:                                                   │ │
│  │                                                                        │ │
│  │ Employee ID:      [EMP-5678        ]                                   │ │
│  │ Actor Role:       [claims_processor ▼]                                 │ │
│  │ Claim ID:         [CLM-123456      ]                                   │ │
│  │ Payment Amount:   [$9,500.00       ]                                   │ │
│  │ Payment Method:   [ACH Same Day ▼] │                                   │
│  │                                                                        │ │
│  │ Session Actions (JSON):                                                │ │
│  │ ┌────────────────────────────────────────────────────────────────────┐ │ │
│  │ │[                                                                   │ │ │
│  │ │  {                                                                 │ │ │
│  │ │    "action_type": "APPROVE_CLAIM",                                 │ │ │
│  │ │    "employee_id": "EMP-5678",                                      │ │ │
│  │ │    "timestamp": "2026-02-07T14:30:00Z"                             │ │ │
│  │ │  },                                                                │ │ │
│  │ │  {                                                                 │ │ │
│  │ │    "action_type": "UPDATE_PAYEE_BANK",                             │ │ │
│  │ │    "employee_id": "EMP-5678",                                      │ │ │
│  │ │    "timestamp": "2026-02-07T14:38:00Z"                             │ │ │
│  │ │  },                                                                │ │ │
│  │ │  {                                                                 │ │ │
│  │ │    "action_type": "RELEASE_PAYMENT",                               │ │ │
│  │ │    "employee_id": "EMP-5678",                                      │ │ │
│  │ │    "timestamp": "2026-02-07T14:45:30Z"                             │ │ │
│  │ │  }                                                                 │ │ │
│  │ │]                                                                   │ │ │
│  │ └────────────────────────────────────────────────────────────────────┘ │ │
│  │                                                                        │ │
│  │ Account Pattern:  [FIRST_USE ▼]                                        │ │
│  │ Payee Changed:    ☑ Yes  ☐ No                                         │ │
│  │ Verified:         ☐ Yes  ☑ No                                         │ │
│  │                                                                        │ │
│  │ [🔍 Check for Fraud]                                                   │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  Result will appear here ↓                                                  │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ ⚠️  DECISION: WARN                                                     │ │
│  │ 🎯 Risk Level: MEDIUM                                                  │ │
│  │ 📊 Confidence: 0.87                                                    │ │
│  │                                                                        │ │
│  │ Reasons:                                                               │ │
│  │ • Same employee performed 3 control actions                           │ │
│  │ • Separation of duties violation                                      │ │
│  │                                                                        │ │
│  │ Recommendation: Send to fraud analyst for manual review               │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 5: FEEDBACK FORM                                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Provide feedback on a decision:                                            │
│                                                                              │
│  Event ID: [EVT-2026-001]  [Load Decision]                                  │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ System Decision: BLOCK                                                 │ │
│  │                                                                        │ │
│  │ What was the actual outcome?                                           │ │
│  │ [CONFIRMED_FRAUD ▼]                                                    │ │
│  │   • CONFIRMED_FRAUD                                                    │ │
│  │   • FALSE_POSITIVE                                                     │ │
│  │   • LEGITIMATE                                                         │ │
│  │   • UNCERTAIN                                                          │ │
│  │                                                                        │ │
│  │ Notes:                                                                 │ │
│  │ ┌────────────────────────────────────────────────────────────────────┐ │ │
│  │ │ Employee admitted to unauthorized access to claim system.          │ │ │
│  │ │ Used compromised credentials to approve own claims and             │ │ │
│  │ │ change payee details. Total fraud amount: $47,500 across           │ │ │
│  │ │ 5 claims. Law enforcement notified.                                │ │ │
│  │ └────────────────────────────────────────────────────────────────────┘ │ │
│  │                                                                        │ │
│  │ ☑ Add to Learning Queue (high-value case)                             │ │
│  │                                                                        │ │
│  │ [Submit Feedback]                                                      │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  ✅ Feedback submitted successfully!                                        │
│  Reward: +100 (Perfect fraud detection)                                     │
│  Added to Learning Queue: LQ-2026-02-07-001                                 │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 6: ANALYTICS CHARTS                                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌────────────────────────────────────┬─────────────────────────────────┐   │
│  │ Decision Distribution (Pie Chart)  │ Risk Level Over Time (Line)     │   │
│  │                                    │                                 │   │
│  │       Blocked: 10%                 │  ┌──────────────────────────┐  │   │
│  │       Warned: 30%                  │  │ HIGH ────────────         │  │   │
│  │       Allowed: 60%                 │  │ MED  ──────────           │  │   │
│  │                                    │  │ LOW  ────────             │  │   │
│  └────────────────────────────────────┴─────────────────────────────────┘   │
│                                                                              │
│  ┌────────────────────────────────────┬─────────────────────────────────┐   │
│  │ Agent Accuracy (Bar Chart)         │ Processing Time Distribution    │   │
│  │                                    │                                 │   │
│  │ Employee: 96% ████████████████     │  ┌──────────────────────────┐  │   │
│  │ Last Mile: 94% ███████████████     │  │ <500ms:  15%             │  │   │
│  │ Graph:     92% ██████████████      │  │ 500-1s:  70%             │  │   │
│  │ LLM:       95% ████████████████    │  │ >1s:     15%             │  │   │
│  └────────────────────────────────────┴─────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Page 2: Prompt Management

### 4.1 Prompt Management Layout

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        📚 PROMPT MANAGEMENT                                  │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 1: EVENT TYPE SELECTOR                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Select Event Type: [PAYMENT_FRAUD ▼]                                       │
│    • PAYMENT_FRAUD                                                           │
│    • VENDOR_FRAUD                                                            │
│    • EMPLOYEE_COLLUSION                                                      │
│    • CLAIM_MANIPULATION                                                      │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 2: PROMPT VERSION LIST                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Available Versions:                                                         │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ ☐ v1.0 - Initial Version                                              │ │
│  │   Created: 2026-01-15 | Status: ARCHIVED | Accuracy: 85%              │ │
│  │   Examples: 15 | Decisions: 500                                        │ │
│  │   [View] [Compare] [Reactivate]                                        │ │
│  ├────────────────────────────────────────────────────────────────────────┤ │
│  │ ☐ v1.1 - Added collusion patterns                                     │ │
│  │   Created: 2026-01-22 | Status: ARCHIVED | Accuracy: 88%              │ │
│  │   Examples: 18 | Decisions: 350                                        │ │
│  │   [View] [Compare] [Reactivate]                                        │ │
│  ├────────────────────────────────────────────────────────────────────────┤ │
│  │ ☑ v1.2 - Current Active ✅                                            │ │
│  │   Created: 2026-02-01 | Status: ACTIVE | Accuracy: 92%                │ │
│  │   Examples: 20 | Decisions: 200                                        │ │
│  │   [View] [Edit] [Create New Version]                                   │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 3: EDIT PROMPT (v1.2)                                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  System Prompt:                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ You are an expert fraud detection analyst for insurance claim payouts.│ │
│  │                                                                        │ │
│  │ Analyze the transaction and provide fraud risk assessment based on:   │ │
│  │ • Employee control patterns (Separation of Duties violations)         │ │
│  │ • Payment timing anomalies (rapid changes post-approval)              │ │
│  │ • Account usage patterns (first-time, reused, established)            │ │
│  │ • Historical fraud indicators from past cases                         │ │
│  │                                                                        │ │
│  │ Be especially vigilant for:                                            │ │
│  │ • Same employee controlling multiple approval steps                   │ │
│  │ • Post-approval payee changes (especially < 15 minutes)               │ │
│  │ • First-time account usage with rapid payment                         │ │
│  │ • Amount structuring (just below $10K reporting threshold)            │ │
│  │ • Offshore accounts with fast payment methods                         │ │
│  │                                                                        │ │
│  │ Provide your analysis in the following JSON format:                   │ │
│  │ {                                                                      │ │
│  │   "risk_level": "LOW | MED | HIGH",                                    │ │
│  │   "confidence": 0.0 to 1.0,                                            │ │
│  │   "reasoning": "Detailed explanation of your assessment",             │ │
│  │   "recommendation": "ALLOW | WARN | BLOCK"                             │ │
│  │ }                                                                      │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  [Save Changes]                                                              │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 4: FEW-SHOT EXAMPLES                                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Training Examples (20):                                                     │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ Example 1: Employee Fraud (BLOCK → CONFIRMED_FRAUD)                   │ │
│  │ ▼ Click to expand                                                      │ │
│  │                                                                        │ │
│  │ Scenario:                                                              │ │
│  │ "Payment of $9,500 to offshore account initiated 8 minutes after      │ │
│  │  changing payee bank details. Same employee approved claim, updated   │ │
│  │  bank info, and released payment."                                     │ │
│  │                                                                        │ │
│  │ Amount: $9,500                                                         │ │
│  │                                                                        │ │
│  │ Indicators:                                                            │ │
│  │ • first_use_account                                                    │ │
│  │ • post_approval_change                                                 │ │
│  │ • same_day_payment                                                     │ │
│  │ • single_employee_all_steps                                            │ │
│  │                                                                        │ │
│  │ Decision: BLOCK                                                        │ │
│  │ Outcome: CONFIRMED_FRAUD                                               │ │
│  │                                                                        │ │
│  │ Lesson:                                                                │ │
│  │ "When single employee controls all steps AND changes payee info       │ │
│  │  post-approval AND requests rapid payment, this pattern strongly      │ │
│  │  suggests employee fraud scheme to funnel money to controlled         │ │
│  │  account. Amount just below $10K threshold suggests structuring."     │ │
│  │                                                                        │ │
│  │ [Edit] [Remove] [Move Up] [Move Down]                                 │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ Example 2: Legitimate Urgent Payment (ALLOW → LEGITIMATE)             │ │
│  │ ▶ Click to expand                                                      │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ Example 3: Vendor Fraud Pattern (BLOCK → CONFIRMED_FRAUD)             │ │
│  │ ▶ Click to expand                                                      │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  ... (17 more examples)                                                      │
│                                                                              │
│  [+ Add New Example]                                                         │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 5: ACTIONS                                                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  [💾 Save Draft] [👀 Preview Changes] [🔄 Compare with v1.1]                │
│                                                                              │
│  Create New Version:                                                         │
│  Version: [v1.3] Description: [Added employee fraud pattern example]        │
│  [Create New Version]                                                        │
│                                                                              │
│  ⚠️  Note: Creating new version will set it to DRAFT status                 │
│  You must activate it to use in production                                   │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 6: ACCURACY METRICS                                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Current Version (v1.2) Performance:                                         │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ Total Decisions: 200                                                   │ │
│  │ Correct Decisions: 184                                                 │ │
│  │ Accuracy: 92.0% 🎯                                                     │ │
│  │                                                                        │ │
│  │ Confusion Matrix:                                                      │ │
│  │              Predicted                                                 │ │
│  │          ALLOW  WARN  BLOCK                                            │ │
│  │ LEGIT     110     8     2                                              │ │
│  │ FRAUD       6    12    62                                              │ │
│  │                                                                        │ │
│  │ False Positives: 10 (5%)                                               │ │
│  │ False Negatives: 6 (3%)                                                │ │
│  │                                                                        │ │
│  │ vs Previous Version (v1.1):                                            │ │
│  │ Accuracy: 88% → 92% (+4% improvement) ✅                               │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 7: ACTIVATE PROMPT                                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ⚠️  PRODUCTION DEPLOYMENT                                                  │
│                                                                              │
│  Activate v1.3 (DRAFT) to production?                                        │
│                                                                              │
│  This will:                                                                  │
│  • Set v1.2 to ARCHIVED                                                      │
│  • Set v1.3 to ACTIVE                                                        │
│  • All new decisions will use v1.3                                           │
│  • You can rollback if needed                                                │
│                                                                              │
│  [✅ Activate v1.3] [Cancel]                                                 │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 5. Page 3: Learning Queue

### 5.1 Learning Queue Layout

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        🎓 LEARNING QUEUE                                     │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 1: LOAD ITEMS                                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  [🔄 Load Feedback Items] [Refresh]                                          │
│                                                                              │
│  Filters: [All Status ▼] [All Event Types ▼] [Reward >= 50]                 │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 2: QUEUE ITEMS TABLE                                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  High-Value Cases (|reward| >= 50):                                          │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ ☑│Queue ID│Event ID│LLM│Act│Rew│Status│Event Type│Created│Reviewed│ │ │
│  ├────────────────────────────────────────────────────────────────────────┤ │
│  │☑│LQ-001  │PAY-123 │BLK│FRD│+100│PENDING│PAY_FRAUD│Feb 7│-       │ │ │
│  │☐│LQ-002  │PAY-456 │ALW│FRD│-200│PENDING│PAY_FRAUD│Feb 7│-       │⚠️│ │
│  │☐│LQ-003  │PAY-789 │BLK│FLS│-100│PENDING│PAY_FRAUD│Feb 6│-       │ │ │
│  │☐│LQ-004  │PAY-101 │BLK│FRD│+100│APPROVED│PAY_FRAUD│Feb 6│analyst│ │ │
│  │☐│LQ-005  │PAY-202 │WRN│FRD│+50 │INCORPOR│PAY_FRAUD│Feb 5│analyst│✅│ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  Legend:                                                                     │
│  • BLK=BLOCK, WRN=WARN, ALW=ALLOW                                            │
│  • FRD=FRAUD, FLS=FALSE_POS, LEG=LEGITIMATE                                  │
│  • ⚠️ = Critical case (high negative reward)                                 │
│  • ✅ = Incorporated into prompt                                             │
│                                                                              │
│  [Select All] [Bulk Approve] [Bulk Reject] [Export CSV]                     │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 3: SELECTED ITEM DETAILS                                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Selected: LQ-001 (PAY-123)                                                  │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ Event: PAY-123                                                         │ │
│  │ Event Type: PAYMENT_FRAUD                                              │ │
│  │ Created: 2026-02-07T15:00:00Z                                          │ │
│  │ Status: PENDING_REVIEW                                                 │ │
│  │                                                                        │ │
│  │ Decision vs Outcome:                                                   │ │
│  │ • LLM Decision: BLOCK                                                  │ │
│  │ • Actual Outcome: CONFIRMED_FRAUD ✅                                   │ │
│  │ • Reward Score: +100 (Perfect detection!)                              │ │
│  │ • Is Correct: Yes                                                      │ │
│  │                                                                        │ │
│  │ Transaction Context:                                                   │ │
│  │ • Payment Amount: $9,500.00                                            │ │
│  │ • Employee Pattern: SINGLE_EMPLOYEE_ALL_STEPS                          │ │
│  │ • Time Delta: 8 minutes (approval to payee change)                     │ │
│  │ • Account Pattern: FIRST_USE                                           │ │
│  │ • Payment Method: ACH Same Day                                         │ │
│  │                                                                        │ │
│  │ Risk Indicators:                                                       │ │
│  │ • first_use_account                                                    │ │
│  │ • post_approval_change                                                 │ │
│  │ • same_day_payment                                                     │ │
│  │ • single_employee_all_steps                                            │ │
│  │                                                                        │ │
│  │ Analyst Notes:                                                         │ │
│  │ "Employee admitted to unauthorized access to claim system. Used       │ │
│  │  compromised credentials to approve own claims and change payee       │ │
│  │  details. Total fraud amount: $47,500 across 5 claims."               │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 4: GENERATE TRAINING DATA                                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  [🤖 Auto-Generate Training Example] [✏️ Manual Entry]                       │
│                                                                              │
│  Generated Example:                                                          │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ Scenario:                                                              │ │
│  │ ┌────────────────────────────────────────────────────────────────────┐ │ │
│  │ │ Payment of $9,500 to offshore account initiated 8 minutes after    │ │ │
│  │ │ changing payee bank details. Same employee approved claim,         │ │ │
│  │ │ updated bank info, and released payment.                           │ │ │
│  │ └────────────────────────────────────────────────────────────────────┘ │ │
│  │                                                                        │ │
│  │ Amount: [$9,500.00]                                                    │ │
│  │                                                                        │ │
│  │ Indicators (one per line):                                             │ │
│  │ ┌────────────────────────────────────────────────────────────────────┐ │ │
│  │ │ first_use_account                                                  │ │ │
│  │ │ post_approval_change                                               │ │ │
│  │ │ same_day_payment                                                   │ │ │
│  │ │ single_employee_all_steps                                          │ │ │
│  │ └────────────────────────────────────────────────────────────────────┘ │ │
│  │                                                                        │ │
│  │ Employee Pattern: [SINGLE_EMPLOYEE_ALL_STEPS ▼]                        │ │
│  │                                                                        │ │
│  │ Decision: [BLOCK ▼]                                                    │ │
│  │ Outcome: [CONFIRMED_FRAUD ▼]                                           │ │
│  │                                                                        │ │
│  │ Lesson Learned:                                                        │ │
│  │ ┌────────────────────────────────────────────────────────────────────┐ │ │
│  │ │ When single employee controls all steps AND changes payee info     │ │ │
│  │ │ post-approval AND requests rapid payment, this pattern strongly    │ │ │
│  │ │ suggests employee fraud scheme to funnel money to controlled       │ │ │
│  │ │ account. Amount just below $10K threshold suggests structuring.    │ │ │
│  │ └────────────────────────────────────────────────────────────────────┘ │ │
│  │                                                                        │ │
│  │ [Save Example] [Reset]                                                 │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 5: REVIEW ACTIONS                                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Review Status: PENDING_REVIEW                                               │
│                                                                              │
│  [✅ Approve] [❌ Reject] [⏭️ Skip]                                          │
│                                                                              │
│  After approval, you can:                                                    │
│  [📚 Add to Prompt Management]                                               │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ SECTION 6: QUEUE STATISTICS                                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │ Total Items  │  │ Pending      │  │ Approved     │  │ Incorporated │   │
│  │              │  │              │  │              │  │              │   │
│  │     127      │  │      45      │  │      58      │  │      24      │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
│                                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │ Avg Reward   │  │ High Value   │  │ Critical     │  │ Success Rate │   │
│  │              │  │ (+100)       │  │ Misses(-200) │  │              │   │
│  │    +72       │  │      38      │  │      12      │  │     75%      │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 6. User Workflows

### 6.1 Workflow 1: Review Flagged Transaction

```
1. Analyst opens Dashboard (Page 1)
   └─ Sees recent decisions table

2. Identifies high-risk case (BLOCK decision)
   └─ Clicks on row to expand details

3. Reviews agent analysis and LLM reasoning
   └─ Sees why system blocked transaction

4. Investigates offline (phone calls, documents, etc.)
   └─ Determines actual outcome: CONFIRMED_FRAUD

5. Scrolls to Feedback Form
   ├─ Enters Event ID
   ├─ Selects "CONFIRMED_FRAUD"
   ├─ Adds notes
   ├─ Checks "Add to Learning Queue"
   └─ Clicks [Submit Feedback]

6. System calculates reward (+100) and adds to queue
   └─ Success message displayed

7. (Optional) Navigate to Learning Queue to review item
```

### 6.2 Workflow 2: Update Prompt with Learning Queue Item

```
1. Analyst opens Learning Queue (Page 3)
   └─ Clicks [🔄 Load Feedback Items]

2. Reviews pending items, selects high-value case
   └─ Clicks on LQ-001

3. Views transaction details and context
   └─ Decides it's valuable for training

4. Clicks [🤖 Auto-Generate Training Example]
   └─ System generates few-shot example

5. Reviews/edits generated example
   ├─ Refines scenario description
   ├─ Adjusts lesson learned
   └─ Clicks [Save Example]

6. Clicks [✅ Approve]
   └─ Status changes to APPROVED

7. Clicks [📚 Add to Prompt Management]
   └─ Navigates to Prompt Management (Page 2)

8. On Prompt Management page:
   ├─ Example is pre-loaded
   ├─ Reviews current prompt (v1.2)
   ├─ Sees new example added
   ├─ Enters new version: v1.3
   ├─ Adds description
   └─ Clicks [Create New Version]

9. Reviews new version v1.3 (DRAFT)
   └─ Optionally compares with v1.2

10. When ready, clicks [✅ Activate v1.3]
    └─ New prompt is now active

11. All new decisions use v1.3 with improved examples
```

### 6.3 Workflow 3: Test New Transaction

```
1. Analyst opens Dashboard (Page 1)
   └─ Scrolls to "Test New Transaction" section

2. Fills in transaction details:
   ├─ Employee ID: EMP-5678
   ├─ Claim ID: CLM-123456
   ├─ Amount: $9,500
   ├─ Payment Method: ACH Same Day
   └─ Session actions (JSON)

3. Sets flags:
   ├─ Account Pattern: FIRST_USE
   ├─ Payee Changed: Yes
   └─ Verified: No

4. Clicks [🔍 Check for Fraud]
   └─ API call sent to backend

5. System displays result:
   ├─ Decision: WARN
   ├─ Risk Level: MEDIUM
   ├─ Confidence: 0.87
   ├─ Reasons listed
   └─ Agent breakdowns shown

6. Analyst reviews results
   └─ Can adjust inputs and retest if needed
```

---

## 7. API Integration

### 7.1 API Client (`api_client.py`)

```python
import requests
import json
from typing import Dict, Any, Optional

class FraudDetectionAPIClient:
    """Client for interacting with Fraud Detection API"""
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.session = requests.Session()
    
    def check_fraud(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Call fraud detection API
        
        POST /api/v1/payout/decide
        """
        url = f"{self.base_url}/api/v1/payout/decide"
        response = self.session.post(url, json=payload)
        response.raise_for_status()
        return response.json()
    
    def submit_feedback(self, event_id: str, actual_outcome: str, 
                        notes: str, add_to_queue: bool = False) -> Dict[str, Any]:
        """
        Submit feedback for a decision
        
        POST /api/v1/feedback
        """
        url = f"{self.base_url}/api/v1/feedback"
        payload = {
            "event_id": event_id,
            "actual_outcome": actual_outcome,
            "notes": notes,
            "add_to_learning_queue": add_to_queue
        }
        response = self.session.post(url, json=payload)
        response.raise_for_status()
        return response.json()
    
    def get_prompts(self, event_type: str) -> Dict[str, Any]:
        """
        Get prompt versions
        
        GET /api/v1/prompts?event_type={event_type}
        """
        url = f"{self.base_url}/api/v1/prompts"
        params = {"event_type": event_type}
        response = self.session.get(url, params=params)
        response.raise_for_status()
        return response.json()
    
    def create_prompt_version(self, prompt_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create new prompt version
        
        POST /api/v1/prompts
        """
        url = f"{self.base_url}/api/v1/prompts"
        response = self.session.post(url, json=prompt_data)
        response.raise_for_status()
        return response.json()
    
    def activate_prompt(self, prompt_id: str) -> Dict[str, Any]:
        """
        Activate prompt version
        
        POST /api/v1/prompts/{prompt_id}/activate
        """
        url = f"{self.base_url}/api/v1/prompts/{prompt_id}/activate"
        response = self.session.post(url)
        response.raise_for_status()
        return response.json()
    
    def get_learning_queue(self, status: Optional[str] = None) -> Dict[str, Any]:
        """
        Get learning queue items
        
        GET /api/v1/learning/queue?status={status}
        """
        url = f"{self.base_url}/api/v1/learning/queue"
        params = {"status": status} if status else {}
        response = self.session.get(url, params=params)
        response.raise_for_status()
        return response.json()
    
    def approve_queue_item(self, queue_id: str, example_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Approve learning queue item
        
        POST /api/v1/learning/queue/{queue_id}/approve
        """
        url = f"{self.base_url}/api/v1/learning/queue/{queue_id}/approve"
        response = self.session.post(url, json=example_data)
        response.raise_for_status()
        return response.json()
```

### 7.2 Usage in Streamlit

```python
import streamlit as st
from api_client import FraudDetectionAPIClient

# Initialize client
@st.cache_resource
def get_api_client():
    return FraudDetectionAPIClient(base_url="http://localhost:8000")

client = get_api_client()

# Example: Check fraud
if st.button("Check for Fraud"):
    payload = {
        "current_action": {
            "action_type": "RELEASE_PAYMENT",
            "employee_id": employee_id,
            "timestamp": timestamp,
            "claim_id": claim_id
        },
        # ... more fields
    }
    
    with st.spinner("Analyzing..."):
        result = client.check_fraud(payload)
    
    # Display result
    st.success(f"Decision: {result['decision']}")
    st.write(f"Risk Level: {result['risk_level']}")
    st.write(f"Confidence: {result['confidence']}")
```

---

## Key Features Summary

### Dashboard Capabilities
- **Real-time fraud testing** with instant results
- **Comprehensive decision review** with agent breakdowns
- **Feedback submission** with automatic reward calculation
- **Visual analytics** with charts and metrics
- **Filterable tables** for easy data exploration

### Prompt Management
- **Version control** with full history
- **Side-by-side comparison** of versions
- **Drag-and-drop** example reordering
- **Accuracy tracking** per version
- **One-click activation** for deployment

### Learning Queue
- **Auto-generation** of training examples
- **Bulk operations** for efficient review
- **Status tracking** (PENDING → APPROVED → INCORPORATED)
- **Priority sorting** by reward score
- **Direct integration** with Prompt Management

---

**End of UI Dashboard Architecture**
