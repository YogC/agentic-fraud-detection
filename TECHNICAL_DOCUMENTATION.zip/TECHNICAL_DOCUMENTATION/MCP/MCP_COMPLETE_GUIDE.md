# MCP Complete Guide - Fraud Detection System

**Document Version:** 1.0  
**Last Updated:** February 8, 2026  
**Purpose:** Complete guide to understanding, testing, and using the MCP fraud detection server

---

## 📋 **Table of Contents**

1. [What is MCP and What Does It Do?](#1-what-is-mcp-and-what-does-it-do)
2. [How to Test MCP Locally](#2-how-to-test-mcp-locally)
3. [How MCP is Implemented in This Project](#3-how-mcp-is-implemented-in-this-project)
4. [How Other Agents/LLMs Can Use MCP](#4-how-other-agentsllms-can-use-mcp)
5. [Database Persistence Strategy](#5-database-persistence-strategy)
6. [Advanced Topics: Entity Registry, Risk Scoring, and Agent Architecture](#6-advanced-topics-entity-registry-risk-scoring-and-agent-architecture)
   - 6.1 [In-Memory Entity Graph Registry](#61-in-memory-entity-graph-registry)
   - 6.2 [Risk Scoring Logic (NOT Reinforcement Learning)](#62-risk-scoring-logic-not-reinforcement-learning-rewards)
   - 6.3 [Orchestrator Pattern (Agent Coordination)](#63-orchestrator-pattern-agent-coordination--broker)
   - 6.4 [LLM Confidence Scoring](#64-llm-confidence-scoring-how-and-why-it-controls-decisions)

---

## 1. What is MCP and What Does It Do?

### **What is MCP?**

**MCP (Model Context Protocol)** is a standardized protocol created by Anthropic that allows AI systems to discover and interact with external tools and data sources. Think of it as a "universal adapter" that lets AI agents call your fraud detection system without needing custom integration code.

### **What Does Our MCP Server Do?**

Our MCP fraud detection server exposes **5 fraud detection tools** that AI agents can discover and use:

```
┌─────────────────────────────────────────────────────────────────┐
│                     MCP Fraud Detection Server                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Tool 1: check_payout_fraud                                    │
│  → Full 3-agent fraud detection with decision (ALLOW/WARN/BLOCK)│
│                                                                 │
│  Tool 2: check_employee_control_risk                           │
│  → Detect same employee doing multiple control actions        │
│                                                                 │
│  Tool 3: check_lastmile_payment_risk                           │
│  → Detect payee changes after approval + fast payment methods  │
│                                                                 │
│  Tool 4: check_entity_link_risk                                │
│  → Detect bank account reuse across multiple claimants        │
│                                                                 │
│  Tool 5: get_fraud_system_health                               │
│  → Check if fraud detection system is ready                    │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### **What Happens When You Call MCP?**

```
Step 1: AI Agent discovers available tools
   ↓
Step 2: AI Agent chooses tool (e.g., check_payout_fraud)
   ↓
Step 3: AI Agent sends fraud check parameters
   ↓
Step 4: MCP Server runs 3 fraud detection agents:
   • Employee Control Agent (checks employee behavior)
   • Last-Mile Payment Agent (checks post-approval changes)
   • Graph Entity Agent (checks bank account linkage)
   ↓
Step 5: MCP Server calculates risk score (0-6)
   ↓
Step 6: MCP Server returns decision + detailed analysis
   ↓
Step 7: AI Agent uses result to make decisions
```

### **Key Point: MCP Does NOT Save to Database**

⚠️ **Important**: The MCP server is designed for **analysis only**. It:
- ✅ Analyzes fraud patterns
- ✅ Returns risk scores and decisions
- ✅ Provides detailed fraud indicators
- ❌ Does NOT save results to database
- ❌ Does NOT appear in SIU Dashboard
- ❌ Does NOT create audit trails

**Why?** Because MCP is designed for:
- AI agent integration (they just need analysis)
- Testing (don't want to pollute production database)
- High-volume queries (fast, stateless)

---

## 2. How to Test MCP Locally

### **Step 1: Prerequisites**

Make sure you have:
```bash
# Virtual environment activated
.\venv\Scripts\Activate.ps1

# Required packages installed
pip install mcp fastmcp
```

### **Step 2: Run the Simple Test**

We've created a comprehensive test script that validates all MCP functionality:

```bash
# Navigate to project root
cd "c:\Yogesh\GenAI\Fraud Detection\Fraud-Internal-Detection"

# Run the test
python test_mcp_simple.py
```

### **What the Test Does**

The test performs 6 validation steps:

#### **Test Step 1: Connection**
```
Connecting to MCP server...
✅ Connected successfully!
```
**What it validates**: MCP server starts and accepts connections

#### **Test Step 2: Tool Discovery**
```
Discovering available tools...
✅ Found 5 tools:
   • check_payout_fraud
   • check_employee_control_risk
   • check_lastmile_payment_risk
   • check_entity_link_risk
   • get_fraud_system_health
```
**What it validates**: All fraud detection tools are registered and discoverable

#### **Test Step 3: LOW Risk Scenario**
```
Testing LOW risk scenario...
Scenario: Normal payment release by different employee

Input:
  - Current action: RELEASE_PAYMENT by EMP-001
  - Session history: APPROVE_CLAIM by EMP-002 (different employee)
  - No payee changes, normal ACH payment

Expected: ALLOW decision, 0/6 risk score
✅ Correctly identified as LOW risk
```
**What it validates**: System correctly allows safe transactions

#### **Test Step 4: HIGH Risk Scenario**
```
Testing HIGH risk scenario...
Scenario: Same employee approved claim AND releasing payment

Input:
  - Current action: RELEASE_PAYMENT by EMP-SAME
  - Session history: 
    • APPROVE_CLAIM by EMP-SAME (same employee!)
    • UPDATE_PAYEE_BANK by EMP-SAME (same employee again!)
  - Payee changed after approval
  - No customer verification

Expected: WARN or BLOCK decision, 2+ risk score
Result: WARN, 2/6 risk score

Fraud Indicators Detected:
  - ⚠️ Payee destination changed AFTER claim was approved
  - ⚠️ No customer verification recorded
✅ Correctly identified as HIGH risk
```
**What it validates**: System catches fraud patterns

#### **Test Step 5: Agent Breakdown**
```
Checking agent breakdown...
   Employee Control Agent:
      Risk: None (different employees used)
      Score: 0
   Last-Mile Payment Agent:
      Risk: MED-HIGH
      Score: 2 (payee changed + no verification)
   Graph Entity Agent:
      Risk: None
      Score: 0
✅ All agents executed successfully
```
**What it validates**: Individual agents are working and contributing scores

#### **Test Step 6: Stateless Verification**
```
Verifying MCP is stateless (no database writes)...
✅ Confirmed: No event_id (not saved to database)
✅ Confirmed: No status field (stateless)
```
**What it validates**: MCP doesn't pollute database

### **Expected Output**

```
======================================================================
✅ ALL TESTS PASSED!
======================================================================

Summary:
  • MCP server is running correctly
  • All 3 agents are working (Employee, Last-Mile, Entity)
  • Risk detection is accurate
  • No database persistence (as expected)

Your MCP fraud detection system is ready to use! 🎉
```

### **Manual Testing (Interactive)**

You can also test manually using Python:

```python
import asyncio
from app.mcp.fraud_mcp_client import FraudDetectionMCPClient

async def manual_test():
    # Connect
    client = FraudDetectionMCPClient("app/mcp/fraud_detection_server.py")
    await client.connect()
    
    # Test a fraud scenario
    result = await client.check_payout_fraud({
        "current_action": {
            "action_type": "RELEASE_PAYMENT",
            "employee_id": "EMP-TEST",
            "timestamp": "2026-02-08T14:00:00Z",
            "claim_id": "CLM-001",
            "payment_id": "PAY-001"
        },
        "session_actions": [],
        "actor_role": "payment_processor",
        "claim_status": "APPROVED",
        "bank_account_hash": "test_hash",
        "claimant_id": "CLMT-001"
    })
    
    print(f"Decision: {result['decision']}")
    print(f"Score: {result['total_score']}/6")
    print(f"Reasons: {result['reasons']}")
    
    # Disconnect
    await client.disconnect()

# Run
asyncio.run(manual_test())
```

---

## 3. How MCP is Implemented in This Project

### **Architecture Overview**

```
┌──────────────────────────────────────────────────────────────────┐
│                         MCP Layer                                │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  fraud_detection_server.py                                      │
│  ├── FastMCP initialization                                     │
│  ├── Tool 1: @mcp.tool() check_payout_fraud                    │
│  ├── Tool 2: @mcp.tool() check_employee_control_risk           │
│  ├── Tool 3: @mcp.tool() check_lastmile_payment_risk           │
│  ├── Tool 4: @mcp.tool() check_entity_link_risk                │
│  └── Tool 5: @mcp.tool() get_fraud_system_health               │
│                                                                  │
├──────────────────────────────────────────────────────────────────┤
│                      Orchestration Layer                         │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  payout_orchestrator.py                                         │
│  └── Coordinates 3 agents, calculates final decision            │
│                                                                  │
├──────────────────────────────────────────────────────────────────┤
│                         Agent Layer                              │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  employee_control_agent.py                                      │
│  ├── Detects same employee doing multiple actions              │
│  └── Returns: LOW/MED/HIGH + score 0-2                          │
│                                                                  │
│  lastmile_payment_agent.py                                      │
│  ├── Detects payee changes after approval                      │
│  ├── Detects fast payment methods                              │
│  └── Returns: LOW/MED/HIGH + score 0-2                          │
│                                                                  │
│  graph_entity_agent.py                                          │
│  ├── Detects bank account reuse across claimants               │
│  ├── Maintains in-memory entity registry                       │
│  └── Returns: LOW/MED/HIGH + score 0-2                          │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

### **File Structure**

```
app/
├── mcp/
│   ├── fraud_detection_server.py     ← MCP server (exposes tools)
│   └── fraud_mcp_client.py           ← Python client (for testing)
│
├── agents/
│   ├── payout_orchestrator.py        ← Coordinates all agents
│   ├── employee_control_agent.py     ← Agent 1: Employee behavior
│   ├── lastmile_payment_agent.py     ← Agent 2: Post-approval changes
│   └── graph_entity_agent.py         ← Agent 3: Account linkage
│
└── [other modules...]
```

### **Implementation Details**

#### **1. MCP Server (fraud_detection_server.py)**

```python
from fastmcp import FastMCP

# Initialize MCP server
mcp = FastMCP("fraud-detection-mcp-server")

# Initialize agents (singleton instances)
orchestrator = PayoutDecisionOrchestrator()
employee_agent = EmployeeControlAgent()
lastmile_agent = LastMilePaymentAgent()
entity_agent = GraphEntityLinkAgent()

# Expose Tool 1: Comprehensive fraud check
@mcp.tool()
async def check_payout_fraud(
    current_action: Dict[str, Any],
    session_actions: List[Dict[str, Any]],
    actor_role: str,
    claim_status: str,
    # ... other parameters
) -> Dict[str, Any]:
    """
    Comprehensive payout fraud detection using all 3 agents.
    Returns ALLOW/WARN/BLOCK decision with detailed analysis.
    """
    # Prepare input
    input_data = {
        'current_action': current_action,
        'session_actions': session_actions,
        # ... other fields
    }
    
    # Execute orchestrator (runs all 3 agents)
    result = await orchestrator.execute(input_data)
    
    # Return result (NO database save)
    return result
```

**Key Points**:
- Uses `@mcp.tool()` decorator to expose functions as MCP tools
- Each tool has type hints and docstrings (for auto-discovery)
- Tools call underlying agents directly
- **No database writes** - just returns analysis

#### **2. Orchestrator (payout_orchestrator.py)**

```python
class PayoutDecisionOrchestrator:
    """Coordinates all 3 fraud detection agents"""
    
    async def execute(self, input_data: Dict) -> Dict:
        # Run all 3 agents in parallel
        employee_result = await self.employee_agent.execute(input_data)
        lastmile_result = await self.lastmile_agent.execute(input_data)
        entity_result = await self.entity_agent.execute(input_data)
        
        # Calculate total score
        total_score = (
            employee_result['score'] +
            lastmile_result['score'] +
            entity_result['score']
        )
        
        # Make decision
        if total_score == 0:
            decision = "ALLOW"
        elif total_score <= 3:
            decision = "WARN"
        else:
            decision = "BLOCK"
        
        # Return combined result
        return {
            'decision': decision,
            'total_score': total_score,
            'per_agent': {
                'employee_control': employee_result,
                'lastmile_payment': lastmile_result,
                'graph_entity': entity_result
            },
            'reasons': [...],  # Combined reasons from all agents
            'timestamp': datetime.utcnow().isoformat() + 'Z'
        }
```

#### **3. Individual Agents**

Each agent follows the same pattern:

```python
class EmployeeControlAgent:
    """Detects same employee doing multiple control actions"""
    
    async def execute(self, input_data: Dict) -> Dict:
        # Extract data
        current_action = input_data['current_action']
        session_actions = input_data['session_actions']
        
        # Count control actions by same employee
        control_count = self._count_control_actions(
            current_action['employee_id'],
            session_actions
        )
        
        # Determine risk level
        if control_count >= 3:
            risk = "HIGH"
            score = 2
        elif control_count == 2:
            risk = "MED"
            score = 1
        else:
            risk = "LOW"
            score = 0
        
        # Return result
        return {
            'control_risk': risk,
            'score': score,
            'reasons': [...],
            'metrics': {...}
        }
```

### **Communication Flow**

```
1. MCP Client sends request to Server
   ↓
2. Server receives tool invocation (e.g., "check_payout_fraud")
   ↓
3. Server calls orchestrator.execute(input_data)
   ↓
4. Orchestrator runs 3 agents in parallel:
   ├─ Employee Control Agent → score 0-2
   ├─ Last-Mile Payment Agent → score 0-2
   └─ Graph Entity Agent → score 0-2
   ↓
5. Orchestrator sums scores (0-6 total)
   ↓
6. Orchestrator makes decision:
   - Score 0: ALLOW
   - Score 1-3: WARN
   - Score 4-6: BLOCK
   ↓
7. Server returns result to MCP Client
   ↓
8. Client receives JSON response with:
   - decision
   - total_score
   - per_agent breakdown
   - reasons
   - evidence
```

---

## 4. How Other Agents/LLMs Can Use MCP

### **Example 1: Claude Desktop Integration**

Claude Desktop can discover and use our fraud detection tools automatically.

#### **Setup (One-time Configuration)**

Edit Claude Desktop's MCP configuration file:

**File Location**:
- Windows: `%APPDATA%\Claude\claude_desktop_config.json`
- Mac: `~/Library/Application Support/Claude/claude_desktop_config.json`

**Configuration**:
```json
{
  "mcpServers": {
    "fraud-detection": {
      "command": "python",
      "args": [
        "c:/Yogesh/GenAI/Fraud Detection/Fraud-Internal-Detection/app/mcp/fraud_detection_server.py"
      ]
    }
  }
}
```

#### **Usage in Claude Desktop**

Once configured, you can ask Claude natural language questions, and it will automatically discover and use our fraud detection tools:

**Example Conversation**:

**You**: 
> "I need to check a payout for fraud. Employee EMP-5678 is releasing payment PAY-12345 for claim CLM-98765. This same employee approved the claim 10 minutes ago. The payee bank account was also changed 5 minutes after approval. Is this fraudulent?"

**Claude** (automatically):
```
I'll use the fraud detection tool to analyze this scenario.

[Claude calls check_payout_fraud with parameters]

Based on the fraud detection analysis:
- Decision: WARN
- Risk Score: 3/6
- Key Issues Detected:
  1. Same employee (EMP-5678) performed both claim approval and payment release
  2. Payee bank account changed shortly after approval (5 minutes)
  3. No customer verification recorded for the payee change

This scenario shows moderate-to-high fraud risk. I recommend:
1. Human review before releasing payment
2. Contact the claimant to verify the bank account change
3. Check if this employee has a pattern of similar behavior
```

**What Happened Behind the Scenes**:
1. Claude discovered the `check_payout_fraud` tool via MCP
2. Claude extracted parameters from your natural language query
3. Claude called the MCP tool with proper parameters
4. Claude received the fraud analysis result
5. Claude explained the result in natural language

### **Example 2: LangChain Agent Integration**

You can build custom AI agents using LangChain that leverage our fraud detection tools.

#### **Code Example**:

```python
from langchain.agents import initialize_agent, AgentType
from langchain.tools import Tool
from langchain_openai import ChatOpenAI
from app.mcp.fraud_mcp_client import FraudDetectionMCPClient
import asyncio

# Initialize MCP client
mcp_client = None

async def get_mcp_client():
    global mcp_client
    if mcp_client is None:
        mcp_client = FraudDetectionMCPClient("app/mcp/fraud_detection_server.py")
        await mcp_client.connect()
    return mcp_client

# Create LangChain tool wrapper
def check_fraud_tool(query: str) -> str:
    """
    Check a payout for fraud.
    
    Input should be a JSON string with keys:
    - current_action (dict): Action being performed
    - session_actions (list): Previous actions
    - actor_role (str): Role of person
    - claim_status (str): Status of claim
    - bank_account_hash (str): Hashed bank account
    - claimant_id (str): Claimant ID
    
    Returns fraud detection analysis with ALLOW/WARN/BLOCK decision.
    """
    import json
    
    # Parse input
    input_data = json.loads(query)
    
    # Call MCP
    async def call_mcp():
        client = await get_mcp_client()
        result = await client.check_payout_fraud(input_data)
        return result
    
    # Run async call
    result = asyncio.run(call_mcp())
    
    # Return formatted result
    return json.dumps({
        'decision': result['decision'],
        'risk_score': result['total_score'],
        'reasons': result['reasons']
    }, indent=2)

# Create LangChain agent
tools = [
    Tool(
        name="FraudDetection",
        func=check_fraud_tool,
        description="Check a payout for fraud. Returns ALLOW/WARN/BLOCK decision with risk score and reasons."
    )
]

llm = ChatOpenAI(model="gpt-4", temperature=0)
agent = initialize_agent(
    tools, 
    llm, 
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True
)

# Use the agent
result = agent.run("""
I need to investigate a suspicious payout:
- Employee EMP-5678 is releasing payment PAY-12345
- Same employee approved the claim 10 minutes ago
- Claim ID: CLM-98765
- Bank account: HASH123
- Claimant: CLMT-456

Should this payment be allowed?
""")

print(result)
```

**Output**:
```
> Entering new AgentExecutor chain...

I need to check this payout for fraud using the fraud detection tool.

Action: FraudDetection
Action Input: {
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-08T14:30:00Z",
    "claim_id": "CLM-98765",
    "payment_id": "PAY-12345"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-08T14:20:00Z",
      "claim_id": "CLM-98765"
    }
  ],
  "actor_role": "claims_processor",
  "claim_status": "APPROVED",
  "bank_account_hash": "HASH123",
  "claimant_id": "CLMT-456"
}

Observation: {
  "decision": "WARN",
  "risk_score": 2,
  "reasons": [
    "Same employee performed APPROVE_CLAIM and RELEASE_PAYMENT"
  ]
}

Thought: The fraud detection system flagged this as WARN with a risk score of 2/6. The main issue is that the same employee (EMP-5678) both approved the claim and is now releasing the payment, which violates separation of duties.

Final Answer: This payment should NOT be automatically allowed. The fraud detection system returned a WARN decision with risk score 2/6 because the same employee (EMP-5678) performed both the claim approval and is now releasing the payment. This violates separation of duties principles and increases fraud risk. I recommend:
1. Route to human review before releasing payment
2. Have a different employee or supervisor verify the payment
3. Document the reason for the same-employee processing
```

### **Example 3: Custom Python Agent**

Build a simple autonomous agent that monitors payments:

```python
import asyncio
from app.mcp.fraud_mcp_client import FraudDetectionMCPClient
from datetime import datetime

class FraudMonitorAgent:
    """Autonomous agent that monitors payments for fraud"""
    
    def __init__(self):
        self.mcp_client = None
        self.blocked_payments = []
        self.warned_payments = []
    
    async def start(self):
        """Start the agent"""
        self.mcp_client = FraudDetectionMCPClient("app/mcp/fraud_detection_server.py")
        await self.mcp_client.connect()
        print("🤖 Fraud Monitor Agent started")
    
    async def check_payment(self, payment_data: dict):
        """Check a payment for fraud"""
        print(f"\n🔍 Checking payment {payment_data['payment_id']}...")
        
        # Call MCP fraud detection
        result = await self.mcp_client.check_payout_fraud(payment_data)
        
        decision = result['decision']
        score = result['total_score']
        
        if decision == "BLOCK":
            self.blocked_payments.append(payment_data['payment_id'])
            print(f"🚫 BLOCKED payment {payment_data['payment_id']} (Score: {score}/6)")
            print(f"   Reasons: {', '.join(result['reasons'])}")
            # Take action: Send alert, block payment
            await self.send_alert(payment_data, result)
            
        elif decision == "WARN":
            self.warned_payments.append(payment_data['payment_id'])
            print(f"⚠️  FLAGGED payment {payment_data['payment_id']} (Score: {score}/6)")
            print(f"   Reasons: {', '.join(result['reasons'])}")
            # Take action: Route to human review
            await self.route_to_review(payment_data, result)
            
        else:  # ALLOW
            print(f"✅ ALLOWED payment {payment_data['payment_id']} (Score: {score}/6)")
            # Take action: Process payment automatically
            await self.process_payment(payment_data)
    
    async def send_alert(self, payment_data, fraud_result):
        """Send alert for blocked payment"""
        print(f"   📧 Sending alert to fraud team...")
        # Integrate with email/Slack/PagerDuty
    
    async def route_to_review(self, payment_data, fraud_result):
        """Route to human review"""
        print(f"   👤 Routing to SIU analyst for review...")
        # Integrate with case management system
    
    async def process_payment(self, payment_data):
        """Process allowed payment"""
        print(f"   💰 Processing payment...")
        # Integrate with payment system
    
    async def monitor_queue(self, payment_queue):
        """Monitor a queue of payments"""
        for payment in payment_queue:
            await self.check_payment(payment)
            await asyncio.sleep(0.5)  # Throttle
    
    async def stop(self):
        """Stop the agent"""
        if self.mcp_client:
            await self.mcp_client.disconnect()
        print(f"\n🤖 Fraud Monitor Agent stopped")
        print(f"   Blocked: {len(self.blocked_payments)} payments")
        print(f"   Flagged: {len(self.warned_payments)} payments")

# Usage
async def main():
    agent = FraudMonitorAgent()
    await agent.start()
    
    # Simulate payment queue
    payment_queue = [
        {
            "payment_id": "PAY-001",
            "current_action": {
                "action_type": "RELEASE_PAYMENT",
                "employee_id": "EMP-001",
                "timestamp": datetime.utcnow().isoformat() + 'Z',
                "claim_id": "CLM-001",
                "payment_id": "PAY-001"
            },
            "session_actions": [],
            "actor_role": "payment_processor",
            "claim_status": "APPROVED",
            "bank_account_hash": "HASH001",
            "claimant_id": "CLMT-001"
        },
        # ... more payments
    ]
    
    await agent.monitor_queue(payment_queue)
    await agent.stop()

asyncio.run(main())
```

---

## 5. Database Persistence Strategy

### **Overview**

The fraud detection system supports **two distinct approaches** for different use cases:

```
┌────────────────────────────────────────────────────────────────┐
│                    Approach Decision Tree                      │
└────────────────────────────────────────────────────────────────┘

Do you need database persistence and audit trails?
│
├─ YES → Use API Server (Approach A)
│   └─ Saves to DynamoDB, visible in SIU Dashboard
│
└─ NO → Use MCP Server (Approach B)
    └─ Analysis only, no database writes
```

### **Approach A: With Database Persistence (API Server)**

#### **When to Use**
- ✅ Production fraud checks that need audit trails
- ✅ Regulatory compliance requirements
- ✅ Human review workflows (SIU analysts)
- ✅ Case management and status tracking
- ✅ Integration with claims processing system
- ✅ Historical reporting and analytics

#### **Who Uses It**
- **Claims System**: Integrated REST API calls during payment processing
- **SIU Analysts**: Review flagged cases in dashboard
- **Compliance Team**: Audit trail queries
- **Fraud Investigators**: Case history analysis
- **Management**: Reporting and metrics

#### **Why Database Persistence**
1. **Regulatory Compliance**: SOX, PCI-DSS require audit trails
2. **Accountability**: Track who made what decision and when
3. **Investigation**: Historical data for fraud patterns
4. **Human Review**: SIU analysts need dashboard visibility
5. **Status Tracking**: Cases go through workflow (pending → approved/rejected)

#### **How It Works**

```
1. REST API receives fraud check request
   ↓
2. API calls fraud detection orchestrator
   ↓
3. Orchestrator runs 3 agents
   ↓
4. API SAVES result to DynamoDB:
   ├─ event_id (unique)
   ├─ decision (ALLOW/WARN/BLOCK)
   ├─ risk_score
   ├─ fraud_indicators
   ├─ timestamp
   ├─ claim_id, payment_id
   ├─ employee_id, claimant_id
   ├─ bank_account_hash
   ├─ status: "pending_review"
   └─ source: "API"
   ↓
5. API returns decision + event_id
   ↓
6. SIU Dashboard queries DynamoDB
   ↓
7. Analyst reviews case, changes status
```

#### **Example API Call**

```bash
POST http://localhost:8000/api/v1/fraud-detection/check-payout
Content-Type: application/json

{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-08T14:30:00Z",
    "claim_id": "CLM-98765",
    "payment_id": "PAY-12345"
  },
  "session_actions": [...],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "bank_account_hash": "HASH123",
  "claimant_id": "CLMT-456"
}
```

#### **Response (With Database Save)**

```json
{
  "decision": "WARN",
  "risk_score": 3,
  "event_id": "EVT-20260208-ABC123",
  "timestamp": "2026-02-08T14:30:05Z",
  "status": "pending_review",
  "source": "API",
  "claim_id": "CLM-98765",
  "payment_id": "PAY-12345",
  "fraud_indicators": [
    "Same employee performed multiple control actions",
    "Payee changed after approval"
  ],
  "agent_breakdown": {...}
}
```

**Key Fields**:
- ✅ `event_id` - Unique ID for database record
- ✅ `status` - Workflow status (pending_review/approved/rejected)
- ✅ `source` - "API" (to distinguish from MCP)

#### **Database Schema**

```python
# DynamoDB Table: FraudDetectionEvents
{
  "event_id": "EVT-20260208-ABC123",  # PK
  "timestamp": "2026-02-08T14:30:05Z",  # SK
  "event_type": "fraud_check",
  "decision": "WARN",
  "risk_score": 3,
  "claim_id": "CLM-98765",
  "payment_id": "PAY-12345",
  "employee_id": "EMP-5678",
  "claimant_id": "CLMT-456",
  "bank_account_hash": "HASH123",
  "fraud_indicators": ["..."],
  "agent_breakdown": {...},
  "status": "pending_review",
  "source": "API",
  "created_at": "2026-02-08T14:30:05Z",
  "reviewed_by": null,
  "reviewed_at": null,
  "review_notes": null
}
```

---

### **Approach B: Without Database Persistence (MCP Server)**

#### **When to Use**
- ✅ AI agent integration (Claude, LangChain, etc.)
- ✅ Testing and development (don't pollute production DB)
- ✅ High-volume batch analysis (performance)
- ✅ Exploratory fraud analysis
- ✅ Third-party integrations that only need results
- ✅ Real-time fraud scoring without workflow

#### **Who Uses It**
- **AI Agents**: Claude Desktop, LangChain agents, custom bots
- **Developers**: Testing fraud detection logic
- **QA Team**: Automated testing without DB pollution
- **External Systems**: Third-party fraud scoring requests
- **Batch Processing**: Analyze historical data without saving

#### **Why NO Database Persistence**
1. **Performance**: 50-70% faster (no DB write overhead)
2. **Stateless**: No side effects, pure analysis
3. **Testing**: Don't create fake records in production DB
4. **AI Agents**: They just need analysis, not persistence
5. **Scalability**: Can handle much higher throughput

#### **How It Works**

```
1. MCP client connects to server
   ↓
2. Client discovers tools
   ↓
3. Client calls check_payout_fraud
   ↓
4. MCP Server runs 3 agents
   ↓
5. MCP Server returns result (NO database save)
   ↓
6. Client receives analysis
   ↓
7. No SIU Dashboard visibility
```

#### **Example MCP Call**

```python
from app.mcp.fraud_mcp_client import FraudDetectionMCPClient

client = FraudDetectionMCPClient("app/mcp/fraud_detection_server.py")
await client.connect()

result = await client.check_payout_fraud({
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-08T14:30:00Z",
    "claim_id": "CLM-98765",
    "payment_id": "PAY-12345"
  },
  "session_actions": [...],
  "actor_role": "payment_processor",
  "claim_status": "APPROVED",
  "bank_account_hash": "HASH123",
  "claimant_id": "CLMT-456"
})

await client.disconnect()
```

#### **Response (NO Database Save)**

```json
{
  "decision": "WARN",
  "total_score": 3,
  "timestamp": "2026-02-08T14:30:05Z",
  "reasons": [
    "Same employee performed multiple control actions",
    "Payee changed after approval"
  ],
  "per_agent": {
    "employee_control": {...},
    "lastmile_payment": {...},
    "graph_entity": {...}
  },
  "evidence": {...}
}
```

**Key Differences**:
- ❌ No `event_id` field (not saved)
- ❌ No `status` field (no workflow)
- ❌ No `source` field (not tracked)

---

### **Comparison Table**

| Feature | API Server (With DB) | MCP Server (No DB) |
|---------|---------------------|-------------------|
| **Saves to Database** | ✅ Yes | ❌ No |
| **Dashboard Visible** | ✅ Yes | ❌ No |
| **Audit Trail** | ✅ Complete | ❌ None |
| **Event ID** | ✅ Yes | ❌ No |
| **Status Tracking** | ✅ Yes | ❌ No |
| **Human Review** | ✅ Yes | ❌ No |
| **Response Time** | 150-300ms | 50-150ms |
| **Use Case** | Production | Testing/AI |
| **Who Uses** | Claims System, SIU | AI Agents, Developers |
| **Compliance** | ✅ Full | ❌ No |

---

### **Future Enhancement: Hybrid Approach**

If needed in the future, we could implement a **hybrid approach** where MCP server optionally saves to database:

```python
# Future enhancement (not implemented yet)
result = await client.check_payout_fraud({
  # ... fraud check parameters ...
  "save_to_database": True  # ← Optional flag
})

# If save_to_database=True:
#   - Creates DynamoDB record
#   - Returns event_id
#   - Visible in SIU Dashboard
# If save_to_database=False (default):
#   - Analysis only
#   - No database write
```

**When This Would Be Useful**:
- AI agent wants to escalate high-risk cases to human review
- Batch processing wants to save only WARN/BLOCK cases
- Testing wants to save specific scenarios for validation

**Implementation Approach**:
1. Add `save_to_database` parameter to MCP tool
2. Import `DynamoDBClient` in MCP server
3. Conditionally save based on flag
4. Return `event_id` if saved

**However**, for now, we keep it simple:
- **API Server** = Always save (production workflow)
- **MCP Server** = Never save (analysis only)

---

## **Quick Reference**

### **When to Use Each Approach**

| Scenario | Use This |
|----------|----------|
| Production claim processing | API Server |
| SIU analyst review | API Server |
| Compliance audit trails | API Server |
| Claude Desktop integration | MCP Server |
| LangChain agent | MCP Server |
| Testing fraud logic | MCP Server |
| High-volume batch analysis | MCP Server |
| Development/debugging | MCP Server |

### **How to Test Each Approach**

**Test API Server**:
```bash
# Start API
python app/main.py

# Test
curl -X POST http://localhost:8000/api/v1/fraud-detection/check-payout \
  -H "Content-Type: application/json" \
  -d '{"current_action": {...}, ...}'

# Verify in dashboard
cd ../SIU-Fraud-Dashboard
streamlit run app.py
```

**Test MCP Server**:
```bash
# Run test
python test_mcp_simple.py

# Or manual test
python -c "
import asyncio
from app.mcp.fraud_mcp_client import FraudDetectionMCPClient

async def test():
    client = FraudDetectionMCPClient('app/mcp/fraud_detection_server.py')
    await client.connect()
    result = await client.check_payout_fraud({...})
    print(result)
    await client.disconnect()

asyncio.run(test())
"
```

---

## 6. Advanced Topics: Entity Registry, Risk Scoring, and Agent Architecture

### **6.1 In-Memory Entity Graph Registry**

#### **What It Is**

The **Entity Graph Registry** is a Python dictionary that tracks bank account linkages across multiple claims and claimants. It's maintained by the `GraphEntityLinkAgent` to detect fraud rings and money mule operations.

```python
# Location: app/agents/graph_entity_agent.py

class GraphEntityLinkAgent:
    def __init__(self):
        # This is the in-memory registry
        self.entity_registry = {}
        
        # Structure:
        # {
        #   "HASH-ABC123": {
        #     "claims": ["CLM-001", "CLM-002", "CLM-003"],
        #     "claimants": ["CLMT-001", "CLMT-002", "CLMT-003"],
        #     "employees": ["EMP-001", "EMP-002"]
        #   },
        #   "HASH-DEF456": {
        #     "claims": ["CLM-004"],
        #     "claimants": ["CLMT-004"],
        #     "employees": ["EMP-003"]
        #   }
        # }
```

#### **Where It's Used**

**File:** `app/agents/graph_entity_agent.py`

**In the fraud detection flow:**
```
1. Payout request comes in
   ↓
2. GraphEntityLinkAgent receives bank_account_hash
   ↓
3. Agent checks entity_registry dictionary
   ↓
4. If account not in registry → First time seen → LOW risk
5. If account in registry → Check linkage patterns:
   - Multiple claimants? → HIGH risk (fraud ring!)
   - Same employee reuse? → MED risk
   - New account + post-approval change? → MED risk
   ↓
6. Agent updates registry with new linkage
   ↓
7. Returns risk score (0-2) and detailed metrics
```

#### **How It Works - Detailed Example**

**Scenario: Detecting a Fraud Ring**

```python
# Payment 1: Normal transaction
Input: {
    "bank_account_hash": "HASH-123",
    "claimant_id": "CLMT-001",
    "claim_id": "CLM-001",
    "employee_id": "EMP-001"
}

Registry State:
{
    "HASH-123": {
        "claims": ["CLM-001"],
        "claimants": ["CLMT-001"],  # 1 claimant
        "employees": ["EMP-001"]
    }
}

Result: entity_risk = "LOW", score = 0
Reason: First use of this account


# Payment 2: Different claimant, SAME bank account (FRAUD!)
Input: {
    "bank_account_hash": "HASH-123",  # Same account!
    "claimant_id": "CLMT-002",         # Different claimant!
    "claim_id": "CLM-002",
    "employee_id": "EMP-002"
}

Registry State:
{
    "HASH-123": {
        "claims": ["CLM-001", "CLM-002"],
        "claimants": ["CLMT-001", "CLMT-002"],  # 2 claimants!
        "employees": ["EMP-001", "EMP-002"]
    }
}

Result: entity_risk = "HIGH", score = 2
Reason: "Bank account linked to 2 different claimants (fraud ring indicator)"


# Payment 3: Third claimant, SAME bank account (MAJOR FRAUD!)
Input: {
    "bank_account_hash": "HASH-123",  # Same account again!
    "claimant_id": "CLMT-003",         # Third claimant!
    "claim_id": "CLM-003",
    "employee_id": "EMP-001"
}

Registry State:
{
    "HASH-123": {
        "claims": ["CLM-001", "CLM-002", "CLM-003"],
        "claimants": ["CLMT-001", "CLMT-002", "CLMT-003"],  # 3 claimants!
        "employees": ["EMP-001", "EMP-002"]
    }
}

Result: entity_risk = "HIGH", score = 2
Reason: "Bank account linked to 3+ different claimants (organized fraud ring)"
```

#### **Why It's Used - Real-World Fraud Patterns**

**Fraud Pattern 1: Money Mule Operation**
```
Scenario:
  - Fraudster controls bank account HASH-123
  - Files fake claims under multiple identities:
    • John Smith (CLMT-001) → $5,000 payout → HASH-123
    • Jane Doe (CLMT-002) → $7,500 payout → HASH-123
    • Bob Johnson (CLMT-003) → $6,000 payout → HASH-123
  - Total fraud: $18,500

Entity Registry Detects:
  - Same account receiving payouts from 3 different claimants
  - Flags as HIGH risk fraud ring
  - Prevents further payouts to this account
```

**Fraud Pattern 2: Employee Collusion**
```
Scenario:
  - Employee EMP-001 processes multiple claims
  - All claims direct payments to same account
  - Employee may be colluding with account owner

Entity Registry Detects:
  - Same employee repeatedly uses same account
  - Multiple claims from one employee to one account
  - Flags as MED risk for investigation
```

**Fraud Pattern 3: New Account + Post-Approval Changes**
```
Scenario:
  - Claim approved with legitimate account
  - Fraudster changes payee to new bank account
  - Fast payment method requested
  - No customer verification

Entity Registry Detects:
  - is_new_account = True
  - payee_changed_post_approval = True
  - Flags as MED risk suspicious activity
```

#### **Code Implementation**

```python
class GraphEntityLinkAgent:
    """Detects bank account reuse across multiple claimants"""
    
    def __init__(self):
        self.entity_registry = {}
        self.lock = asyncio.Lock()  # For thread safety
    
    async def execute(self, input_data: Dict) -> Dict:
        """
        Analyze entity linkage risk via bank account tracking.
        
        Returns risk score based on:
        - Account linked to 2+ claimants: HIGH risk (fraud ring)
        - New account + post-approval change: MED risk
        - Same employee reusing account: MED risk
        """
        # Extract data
        bank_account = input_data.get('bank_account_hash', '')
        claim_id = input_data['current_action']['claim_id']
        claimant_id = input_data.get('claimant_id', '')
        employee_id = input_data['current_action']['employee_id']
        is_new_account = input_data.get('is_new_account', False)
        payee_changed = input_data.get('payee_changed_post_approval', False)
        
        async with self.lock:  # Thread-safe access
            # Check if account exists in registry
            if bank_account not in self.entity_registry:
                # First time seeing this account
                self.entity_registry[bank_account] = {
                    'claims': [claim_id],
                    'claimants': [claimant_id],
                    'employees': [employee_id]
                }
                
                # New account with post-approval change = suspicious
                if is_new_account and payee_changed:
                    return {
                        'entity_risk': 'MED',
                        'score': 1,
                        'reasons': ['New bank account with post-approval payee change'],
                        'link_metrics': {
                            'distinct_claims_count': 1,
                            'distinct_claimants_count': 1,
                            'is_new_account': True,
                            'risk_points': 1
                        }
                    }
                
                # Normal new account
                return {
                    'entity_risk': 'LOW',
                    'score': 0,
                    'reasons': [],
                    'link_metrics': {
                        'distinct_claims_count': 1,
                        'distinct_claimants_count': 1,
                        'is_new_account': is_new_account
                    }
                }
            
            # Account exists - check for fraud patterns
            account_data = self.entity_registry[bank_account]
            
            # Add current claim/claimant/employee if not already tracked
            if claim_id not in account_data['claims']:
                account_data['claims'].append(claim_id)
            if claimant_id not in account_data['claimants']:
                account_data['claimants'].append(claimant_id)
            if employee_id not in account_data['employees']:
                account_data['employees'].append(employee_id)
            
            # Calculate risk metrics
            distinct_claimants = len(account_data['claimants'])
            distinct_claims = len(account_data['claims'])
            distinct_employees = len(account_data['employees'])
            
            # FRAUD RING DETECTION: Multiple claimants using same account
            if distinct_claimants >= 2:
                return {
                    'entity_risk': 'HIGH',
                    'score': 2,
                    'reasons': [
                        f'Bank account linked to {distinct_claimants} different claimants (fraud ring indicator)',
                        f'Account reused across {distinct_claims} claims'
                    ],
                    'link_metrics': {
                        'distinct_claims_count': distinct_claims,
                        'distinct_claimants_count': distinct_claimants,
                        'distinct_employees_count': distinct_employees,
                        'risk_points': 2
                    }
                }
            
            # EMPLOYEE COLLUSION: Same employee repeatedly using account
            employee_reuse_count = account_data['employees'].count(employee_id)
            if employee_reuse_count >= 3:
                return {
                    'entity_risk': 'MED',
                    'score': 1,
                    'reasons': [
                        f'Same employee ({employee_id}) has used this account {employee_reuse_count} times'
                    ],
                    'link_metrics': {
                        'distinct_claims_count': distinct_claims,
                        'same_employee_reuse_count': employee_reuse_count,
                        'risk_points': 1
                    }
                }
            
            # LOW RISK: Established account, single claimant
            return {
                'entity_risk': 'LOW',
                'score': 0,
                'reasons': [],
                'link_metrics': {
                    'distinct_claims_count': distinct_claims,
                    'distinct_claimants_count': 1
                }
            }
```

#### **Pros of In-Memory Registry**

| Advantage | Explanation |
|-----------|-------------|
| ✅ **Fast Performance** | O(1) dictionary lookup - no database queries |
| ✅ **Real-Time Detection** | Immediate fraud pattern recognition |
| ✅ **Simple Architecture** | No external dependencies, easy to understand |
| ✅ **No Latency** | Sub-millisecond lookups |
| ✅ **Easy Debugging** | Can print registry state anytime |
| ✅ **Stateless Option** | Perfect for MCP server (no DB needed) |

#### **Cons of In-Memory Registry**

| Disadvantage | Impact | Mitigation |
|--------------|--------|------------|
| ❌ **Lost on Restart** | Registry resets when server restarts | Use persistent storage (DynamoDB) for production |
| ❌ **Not Shared** | Each server instance has separate registry | Implement distributed cache (Redis) for multi-instance |
| ❌ **Memory Growth** | Registry grows over time | Implement LRU eviction or periodic cleanup |
| ❌ **No Historical Analysis** | Can't analyze patterns from last week | Save to database for long-term tracking |
| ❌ **Single Server Only** | Doesn't work with load balancers | Use Redis/Memcached for shared state |

#### **Production Considerations**

**For MCP Server (Current Implementation):**
```
✅ Use in-memory registry
✅ Fast and simple
✅ Perfect for testing/development
⚠️ Accept that registry resets on restart
⚠️ Not suitable for production with multiple servers
```

**For API Server (Production):**
```
✅ Use DynamoDB or Redis for persistent storage
✅ Share state across multiple server instances
✅ Historical fraud pattern analysis
✅ Survives server restarts
❌ Slower (network latency for database queries)
```

**Hybrid Approach (Recommended for Production):**
```python
class GraphEntityLinkAgent:
    def __init__(self, use_cache=True):
        # In-memory cache for speed
        self.entity_cache = {}
        
        # Persistent storage for durability
        self.db_client = DynamoDBClient() if use_cache else None
    
    async def execute(self, input_data):
        bank_account = input_data['bank_account_hash']
        
        # Check cache first (fast)
        if bank_account in self.entity_cache:
            return self._analyze_cached_account(bank_account, input_data)
        
        # Cache miss - check database (slower but persistent)
        if self.db_client:
            db_data = self.db_client.get_account_linkages(bank_account)
            if db_data:
                self.entity_cache[bank_account] = db_data
                return self._analyze_cached_account(bank_account, input_data)
        
        # First time seeing this account
        return self._analyze_new_account(bank_account, input_data)
```

---

### **6.2 Risk Scoring Logic (NOT Reinforcement Learning Rewards!)**

#### **Important Clarification**

⚠️ **This system uses RULE-BASED SCORING, not REINFORCEMENT LEARNING REWARDS.**

Many people confuse "score" with "reward" because of machine learning terminology. Let's clarify:

#### **What This System HAS: Rule-Based Risk Scores**

```python
# Risk Score Calculation (Deterministic Rules)

# Each agent returns a score based on fixed rules
employee_score = 0, 1, or 2  # Based on control action count
lastmile_score = 0, 1, or 2  # Based on payment timing/method
entity_score = 0, 1, or 2    # Based on account linkage

# Total risk score
total_score = employee_score + lastmile_score + entity_score  # 0-6

# Decision based on thresholds
if total_score == 0:
    decision = "ALLOW"   # No risk detected
elif total_score <= 3:
    decision = "WARN"    # Medium risk
else:
    decision = "BLOCK"   # High risk
```

**Characteristics:**
- ✅ **Deterministic**: Same input → Same output
- ✅ **Rule-Based**: If X then Y logic
- ✅ **Static Thresholds**: Score >= 4 = BLOCK (never changes)
- ✅ **No Learning**: System doesn't improve over time
- ✅ **Transparent**: Easy to explain why score = 3

#### **What This System DOES NOT HAVE: Reinforcement Learning Rewards**

```python
# This does NOT exist in our system:

# RL Reward Calculation (NOT IMPLEMENTED)
if fraud_detected and blocked_correctly:
    reward = +10  # Positive reward
    agent.learn(state, action, reward)  # Update model
elif missed_fraud:
    reward = -10  # Negative penalty
    agent.learn(state, action, reward)  # Update model

# RL Policy Update (NOT IMPLEMENTED)
agent.update_policy()
agent.optimize_thresholds()
```

**Characteristics (that we DON'T have):**
- ❌ **Learning from Feedback**: System doesn't learn
- ❌ **Dynamic Thresholds**: Thresholds don't change
- ❌ **Model Training**: No neural networks
- ❌ **Probabilistic**: No probability distributions
- ❌ **Exploration**: No trying different strategies

#### **Why Call It "Score" Instead of "Reward"?**

| Term | Meaning in Our System | RL Meaning |
|------|----------------------|------------|
| **Score** | Risk level (0-6 scale) | Not used |
| **Reward** | ❌ Not used | +/- feedback for learning |
| **Decision** | ALLOW/WARN/BLOCK | Action taken by agent |
| **Threshold** | Static (score >= 4 = BLOCK) | Dynamic (learned over time) |

#### **Detailed Scoring Logic**

**Employee Control Agent:**
```python
# Rule-Based Scoring
control_action_count = count_control_actions(employee_id, session_actions)

if control_action_count >= 3:
    score = 2  # HIGH risk
    risk = "HIGH"
    reason = "Same employee performed 3+ control actions"
elif control_action_count == 2:
    score = 1  # MED risk
    risk = "MED"
    reason = "Same employee performed 2 control actions"
else:
    score = 0  # LOW risk
    risk = "LOW"
    reason = "Normal separation of duties"

return {'score': score, 'control_risk': risk, 'reasons': [reason]}
```

**Last-Mile Payment Agent:**
```python
# Rule-Based Scoring
risk_points = 0

if payee_changed_after_approval:
    minutes_since_approval = calculate_time_delta(approval_ts, payee_change_ts)
    if minutes_since_approval <= 10:
        risk_points += 2  # HIGH risk: Very fast change
    else:
        risk_points += 1  # MED risk: Changed but not immediately

if payment_method in ['ACH_SAME_DAY', 'WIRE', 'INSTANT', 'RTP']:
    risk_points += 1  # Fast payment method

if not verification_flag:
    risk_points += 1  # No customer verification

# Convert risk points to score
if risk_points >= 2:
    score = 2  # HIGH
elif risk_points == 1:
    score = 1  # MED
else:
    score = 0  # LOW

return {'score': score, 'last_mile_risk': risk, 'risk_points': risk_points}
```

**Graph Entity Agent:**
```python
# Rule-Based Scoring
distinct_claimants = len(entity_registry[bank_account]['claimants'])

if distinct_claimants >= 2:
    score = 2  # HIGH risk: Fraud ring
    risk = "HIGH"
    reason = f"Account linked to {distinct_claimants} claimants"
elif is_new_account and payee_changed_post_approval:
    score = 1  # MED risk: Suspicious new account
    risk = "MED"
    reason = "New account with post-approval change"
else:
    score = 0  # LOW risk: Normal account
    risk = "LOW"
    reason = "No linkage concerns"

return {'score': score, 'entity_risk': risk, 'reasons': [reason]}
```

#### **Total Score Aggregation**

```python
# Orchestrator combines agent scores
class PayoutDecisionOrchestrator:
    async def execute(self, input_data):
        # Run all agents
        emp_result = await self.employee_agent.execute(input_data)
        lm_result = await self.lastmile_agent.execute(input_data)
        entity_result = await self.entity_agent.execute(input_data)
        
        # Sum scores (simple addition)
        total_score = (
            emp_result['score'] +      # 0-2
            lm_result['score'] +       # 0-2
            entity_result['score']     # 0-2
        )  # Total: 0-6
        
        # Apply decision rules (static thresholds)
        if total_score == 0:
            decision = "ALLOW"
        elif total_score <= 3:
            decision = "WARN"
        else:  # score >= 4
            decision = "BLOCK"
        
        return {
            'decision': decision,
            'total_score': total_score,
            'per_agent': {
                'employee_control': emp_result,
                'lastmile_payment': lm_result,
                'graph_entity': entity_result
            }
        }
```

#### **Example Scoring Scenarios**

**Scenario 1: Clean Transaction**
```
Input: Different employees, normal timing, new account
  - Employee Control: 0 points (different employees)
  - Last-Mile: 0 points (no changes)
  - Entity: 0 points (first use)
Total Score: 0
Decision: ALLOW
```

**Scenario 2: Moderate Risk**
```
Input: Same employee, payee changed after approval
  - Employee Control: 1 point (2 actions)
  - Last-Mile: 1 point (payee changed)
  - Entity: 0 points (single claimant)
Total Score: 2
Decision: WARN
```

**Scenario 3: High Risk**
```
Input: Same employee, fast payment, fraud ring
  - Employee Control: 2 points (3+ actions)
  - Last-Mile: 2 points (fast + no verification)
  - Entity: 2 points (multiple claimants)
Total Score: 6
Decision: BLOCK
```

#### **Why NOT Reinforcement Learning?**

**Advantages of Rule-Based Scoring:**
1. ✅ **Explainable**: Can show exactly why score = 3
2. ✅ **Auditable**: Compliance teams can verify logic
3. ✅ **Predictable**: Same input always gives same output
4. ✅ **Fast**: No model inference overhead
5. ✅ **No Training Data**: Works immediately
6. ✅ **No Drift**: Model doesn't degrade over time

**Disadvantages (compared to RL):**
1. ❌ **Doesn't Learn**: Can't adapt to new fraud patterns
2. ❌ **Manual Tuning**: Thresholds must be set by humans
3. ❌ **Static**: Can't optimize over time
4. ❌ **Simple Patterns**: May miss complex fraud schemes

**When to Use RL (Future Enhancement):**
```
IF you have:
  ✅ Large dataset of labeled fraud cases
  ✅ Feedback loop (was decision correct?)
  ✅ Acceptable "black box" for some decisions
  ✅ Resources for model training/maintenance
THEN consider:
  → Hybrid approach (rules + ML model)
  → Use RL to tune thresholds dynamically
  → Learn complex fraud patterns
```

---

### **6.3 Orchestrator Pattern (Agent Coordination / "Broker")**

#### **What Is the Orchestrator?**

The **Orchestrator** is the "conductor" that coordinates all 3 fraud detection agents. It's sometimes called an "Agent Registry Broker" or "Agent Coordinator" in architectural patterns.

**File:** `app/agents/payout_orchestrator.py`

```python
class PayoutDecisionOrchestrator:
    """
    Orchestrator Pattern: Coordinates multiple agents to make a unified decision.
    
    Responsibilities:
    1. Receive fraud check request
    2. Route to all 3 agents in parallel
    3. Collect results from each agent
    4. Aggregate risk scores
    5. Apply decision rules
    6. Return unified fraud decision
    """
    
    def __init__(self):
        # Register all agents
        self.employee_agent = EmployeeControlAgent()
        self.lastmile_agent = LastMilePaymentAgent()
        self.entity_agent = GraphEntityLinkAgent()
    
    async def execute(self, input_data: Dict) -> Dict:
        """Orchestrate fraud detection across all agents"""
        # ... implementation ...
```

#### **Architecture Diagram**

```
┌────────────────────────────────────────────────────────────┐
│                    MCP Server / API                        │
│                         ↓                                   │
│              Receives Fraud Check Request                  │
└────────────────────────────────────────────────────────────┘
                           ↓
┌────────────────────────────────────────────────────────────┐
│             PayoutDecisionOrchestrator                     │
│                    (Broker/Coordinator)                    │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  1. Prepares input data for agents                        │
│  2. Dispatches to all agents in parallel                  │
│  3. Collects results                                      │
│  4. Aggregates scores                                     │
│  5. Makes final decision                                  │
│                                                            │
└────────────────────────────────────────────────────────────┘
           ↓               ↓               ↓
    ┌──────────┐    ┌──────────┐    ┌──────────┐
    │ Employee │    │ Last-Mile│    │  Entity  │
    │ Control  │    │ Payment  │    │  Graph   │
    │  Agent   │    │  Agent   │    │  Agent   │
    └──────────┘    └──────────┘    └──────────┘
         ↓               ↓               ↓
    score: 0-2      score: 0-2      score: 0-2
         ↓               ↓               ↓
    ┌────────────────────────────────────────┐
    │   Orchestrator Aggregates Results      │
    │   total_score = 0 + 1 + 2 = 3         │
    │   decision = "WARN" (score <= 3)      │
    └────────────────────────────────────────┘
                       ↓
              Return to MCP/API
```

#### **How It Works (Step-by-Step)**

```python
async def execute(self, input_data: Dict) -> Dict:
    """Orchestrate fraud detection"""
    
    # STEP 1: Run all agents in parallel (faster)
    results = await asyncio.gather(
        self.employee_agent.execute(input_data),
        self.lastmile_agent.execute(input_data),
        self.entity_agent.execute(input_data)
    )
    
    employee_result = results[0]
    lastmile_result = results[1]
    entity_result = results[2]
    
    # STEP 2: Extract scores from each agent
    employee_score = employee_result.get('score', 0)
    lastmile_score = lastmile_result.get('score', 0)
    entity_score = entity_result.get('score', 0)
    
    # STEP 3: Calculate total risk score
    total_score = employee_score + lastmile_score + entity_score
    
    # STEP 4: Apply decision rules
    if total_score == 0:
        decision = "ALLOW"
    elif total_score <= 3:
        decision = "WARN"
    else:
        decision = "BLOCK"
    
    # STEP 5: Collect all reasons from agents
    all_reasons = []
    all_reasons.extend(employee_result.get('reasons', []))
    all_reasons.extend(lastmile_result.get('reasons', []))
    all_reasons.extend(entity_result.get('reasons', []))
    
    # STEP 6: Build evidence dictionary
    evidence = {
        'employee_metrics': employee_result.get('metrics', {}),
        'lastmile_metrics': lastmile_result.get('computed_deltas', {}),
        'entity_metrics': entity_result.get('link_metrics', {})
    }
    
    # STEP 7: Return unified result
    return {
        'decision': decision,
        'total_score': total_score,
        'per_agent': {
            'employee_control': employee_result,
            'lastmile_payment': lastmile_result,
            'graph_entity': entity_result
        },
        'reasons': all_reasons,
        'evidence': evidence,
        'timestamp': datetime.utcnow().isoformat() + 'Z'
    }
```

#### **Why Use an Orchestrator? (Benefits)**

| Benefit | Explanation |
|---------|-------------|
| ✅ **Separation of Concerns** | Each agent focuses on ONE fraud type |
| ✅ **Parallel Execution** | Agents run concurrently (3x faster) |
| ✅ **Extensibility** | Easy to add new agents without changing others |
| ✅ **Single Entry Point** | One API for all fraud detection |
| ✅ **Centralized Logic** | Decision rules in one place |
| ✅ **Testability** | Can test each agent independently |
| ✅ **Maintainability** | Changes to one agent don't affect others |

#### **Orchestrator vs Individual Agents**

**Without Orchestrator (Bad):**
```python
# Caller has to coordinate everything
employee_result = await employee_agent.execute(data)
lastmile_result = await lastmile_agent.execute(data)
entity_result = await entity_agent.execute(data)

# Caller has to aggregate scores
total_score = employee_result['score'] + lastmile_result['score'] + entity_result['score']

# Caller has to make decision
if total_score >= 4:
    decision = "BLOCK"
# ...

# Repeated in every caller!
```

**With Orchestrator (Good):**
```python
# Orchestrator handles everything
result = await orchestrator.execute(data)

# Get final decision
print(result['decision'])  # WARN
print(result['total_score'])  # 3
```

#### **Pros of Orchestrator Pattern**

| Advantage | Impact |
|-----------|--------|
| ✅ **Clean Architecture** | Clear separation between coordination and execution |
| ✅ **Easy to Test** | Can unit test each agent + integration test orchestrator |
| ✅ **Performance** | Parallel execution reduces latency |
| ✅ **Flexibility** | Can add/remove agents without breaking callers |
| ✅ **Reusability** | Same orchestrator for MCP, API, CLI, tests |
| ✅ **Single Responsibility** | Orchestrator = coordination, Agents = detection |

#### **Cons of Orchestrator Pattern**

| Disadvantage | Mitigation |
|--------------|------------|
| ❌ **Single Point of Failure** | Add error handling, circuit breakers |
| ❌ **All Agents Always Run** | Implement conditional execution (future) |
| ❌ **No Dynamic Routing** | Add agent selection logic (future) |
| ❌ **Complexity** | Worth it for multi-agent systems |

#### **Advanced: Conditional Agent Execution (Future Enhancement)**

```python
class SmartOrchestrator:
    """Orchestrator with conditional agent execution"""
    
    async def execute(self, input_data: Dict) -> Dict:
        # Always run employee agent first (fastest)
        employee_result = await self.employee_agent.execute(input_data)
        
        # If employee score is already HIGH, might skip others
        if employee_result['score'] == 2:
            # Run others in parallel
            lm_result, entity_result = await asyncio.gather(
                self.lastmile_agent.execute(input_data),
                self.entity_agent.execute(input_data)
            )
        else:
            # Run entity check (fast)
            entity_result = await self.entity_agent.execute(input_data)
            
            # Only run expensive lastmile if needed
            if entity_result['score'] >= 1:
                lm_result = await self.lastmile_agent.execute(input_data)
            else:
                lm_result = {'score': 0, 'reasons': []}
        
        # Aggregate as before
        total_score = (
            employee_result['score'] +
            lm_result['score'] +
            entity_result['score']
        )
        # ...
```

---

---

### **6.4 LLM Confidence Scoring: How and Why It Controls Decisions**

#### **What Is the Confidence Field?**

The **confidence field** (also called `llm_confidence` in API responses) is a **probabilistic score between 0.0 and 1.0** that indicates how certain the LLM (Large Language Model) is about its fraud risk assessment.

**Think of it as**: The LLM's "certainty level" about whether fraud is present.

- **0.95 confidence** = "I'm 95% sure this is fraud"
- **0.70 confidence** = "I think it might be fraud, but not certain"
- **0.40 confidence** = "I really can't tell, need more information"

#### **Where Does It Come From?**

The confidence score is **generated by the LLM itself** (AWS Bedrock/Claude 3), not calculated by your code:

```
┌─────────────────────────────────────────────────────────────┐
│         Confidence Score Generation Flow                    │
└─────────────────────────────────────────────────────────────┘

1. Orchestrator sends transaction data to LLM
   ↓
2. LLM analyzes fraud patterns, risks, indicators
   ↓
3. LLM generates JSON response:
   {
     "risk_level": "HIGH",
     "confidence": 0.92,          ← LLM provides this
     "recommendation": "BLOCK",
     "reasoning": "..."
   }
   ↓
4. bedrock_llm_agent.py validates confidence (0.0-1.0 range)
   ↓
5. Orchestrator uses confidence to decide whether to trust LLM
```

**Source Files**:
- **Generated**: `app/agents/bedrock_llm_agent.py` (receives from AWS Bedrock)
- **Used**: `app/agents/payout_orchestrator.py` (decision override logic)
- **Displayed**: `SIU-Fraud-Dashboard/pages/*.py` (UI shows percentages)

#### **How Is Confidence Used? (The Critical Part)**

The confidence score **directly controls whether the LLM can override rule-based decisions**:

```python
# From payout_orchestrator.py - _combine_decisions() method

# PRIORITY 1: High confidence LLM override (≥0.85)
if llm_risk == 'HIGH' and llm_confidence >= 0.85:
    # LLM is VERY SURE fraud is present
    if rule_decision != 'BLOCK':
        logger.info("🚨 LLM HIGH-CONFIDENCE FRAUD → Overriding to BLOCK")
        return 'BLOCK'  # Override rules!

# PRIORITY 2: Medium-high confidence (≥0.70)
if llm_risk == 'HIGH' and llm_confidence >= 0.7:
    # LLM is fairly confident, escalate to at least WARN
    if rule_decision == 'ALLOW':
        return 'WARN'  # Escalate for review

# PRIORITY 3: Low confidence (<0.60)
if llm_confidence < 0.6:
    # LLM is uncertain, don't trust it
    return rule_decision  # Defer to rules
```

**Decision Thresholds Explained**:

| Confidence Range | What It Means | System Behavior |
|-----------------|---------------|-----------------|
| **0.85 - 1.00** | **HIGH**: LLM is very confident about fraud | ✅ Override rules to BLOCK if LLM detects HIGH risk |
| **0.70 - 0.84** | **MEDIUM-HIGH**: LLM fairly confident | ⚠️ Escalate to WARN if rules say ALLOW |
| **0.60 - 0.69** | **MEDIUM**: LLM moderately confident | 🔄 Weighted combination with rule score |
| **0.00 - 0.59** | **LOW**: LLM is uncertain | ❌ Defer to rule-based decision |

#### **Why Is Confidence So Important?**

**Problem 1: Not All LLM Predictions Are Reliable**

LLMs can make mistakes. Without confidence scoring, the system would blindly trust every LLM output:

```
Bad Scenario (No Confidence Check):
  Rule Decision: ALLOW (clean transaction)
  LLM: HIGH risk, confidence=0.45 (uncertain!)
  Without confidence: System blocks legitimate payment ❌
  With confidence: System ignores uncertain LLM, allows payment ✅
```

**Problem 2: Sophisticated Fraud Requires AI Detection**

Rule-based agents miss sophisticated fraud patterns (phishing emails, BEC scams, crypto fraud):

```
Good Scenario (High Confidence Override):
  Rule Decision: ALLOW (no rule violations detected)
  LLM: HIGH risk, confidence=0.92 (very confident!)
  LLM Reasoning: "Email contains exact phishing script from known fraud ring"
  Result: System blocks payment, prevents fraud ✅
```

#### **Real-World Example: Confidence in Action**

**Scenario**: Employee EMP-5678 is releasing a payment. The claim was approved 2 hours earlier by a different employee. However, the payment description contains suspicious language.

**Rule-Based Analysis**:
```
Employee Control Agent: LOW risk (different employees) → score 0
Last-Mile Payment Agent: LOW risk (normal timing) → score 0
Entity Agent: LOW risk (first-time account) → score 0

Total Score: 0
Rule Decision: ALLOW
```

**LLM Analysis**:
```json
{
  "risk_level": "HIGH",
  "confidence": 0.94,
  "recommendation": "BLOCK",
  "reasoning": "Payment description contains exact wording from known crypto recovery scam: 'Recover your Bitcoin investment losses through our verified recovery service'. This matches 15 confirmed fraud cases in our training data.",
  "key_factors": [
    "Crypto recovery scam language",
    "Promise of investment loss recovery",
    "Matches known fraud pattern"
  ]
}
```

**Final Decision** (with confidence check):
```
LLM confidence: 0.94 (≥0.85 threshold)
LLM risk: HIGH
Rule decision: ALLOW

Decision Logic:
  ✅ Confidence is HIGH (0.94 ≥ 0.85)
  ✅ LLM detected HIGH risk
  ✅ Override rule-based ALLOW → BLOCK

Final Decision: BLOCK ✅
Reason: "LLM HIGH-CONFIDENCE FRAUD DETECTED → Overriding ALLOW to BLOCK"
```

**Result**: Payment blocked, fraud prevented. The confidence score of 0.94 gave the system permission to trust the LLM's sophisticated pattern recognition.

#### **Where Does Confidence Appear in the System?**

**1. Orchestrator Logic** (`payout_orchestrator.py`):
```python
decision_bundle = {
    'decision': final_decision,
    'llm_confidence': llm_insights.get('confidence', 0.0),
    'llm_insights': {
        'confidence': 0.92,
        'risk_level': 'HIGH',
        'reasoning': '...'
    }
}
```

**2. API Response Format**:
```json
{
  "decision": "BLOCK",
  "llm_confidence": 0.92,
  "total_score": 0,
  "reasons": [
    "LLM escalated to BLOCK (confidence: 0.92) based on: crypto recovery scam pattern"
  ]
}
```

**3. Dashboard UI** (shows to analysts):
```
Decision: BLOCK (92% confidence) | Status: pending_review
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 Current Recommendation: BLOCK (92% confidence)
```

**4. Audit Logs**:
```
[2026-02-08 14:30:05] FRAUD CHECK
  Decision: BLOCK (LLM override from ALLOW)
  LLM Confidence: 0.92 (HIGH)
  Rule Score: 0/6
  Reason: High-confidence LLM fraud detection
```

#### **How LLM Determines Confidence**

The LLM bases its confidence on:

1. **Pattern Clarity**: How closely the transaction matches known fraud patterns
   - Exact match to training data → confidence 0.90+
   - Similar but not exact → confidence 0.70-0.85
   - Ambiguous pattern → confidence 0.40-0.60

2. **Evidence Strength**: Number and quality of fraud indicators
   - 5+ strong indicators → confidence 0.85+
   - 2-3 moderate indicators → confidence 0.60-0.75
   - 1 weak indicator → confidence 0.30-0.50

3. **Alternative Explanations**: Whether legitimate reasons exist
   - No legitimate explanation → confidence 0.85+
   - Possible legitimate use → confidence 0.50-0.70
   - Likely legitimate → confidence 0.20-0.40

**From DETECTION_METHODOLOGY.md**:
- **High Confidence (0.85-1.0)**: Clear fraud patterns, multiple strong indicators, established fraud type
- **Medium Confidence (0.60-0.84)**: Suspicious but not definitive, fewer strong indicators, novel fraud variation
- **Low Confidence (0.40-0.59)**: Weak signals only, ambiguous scenario, legitimate alternative explanation exists
- **Very Low Confidence (<0.40)**: Insufficient data, contradictory indicators, edge case scenario

#### **Confidence Field Validation**

The system ensures confidence is always valid:

```python
# From bedrock_llm_agent.py - _parse_llm_response()

if 'confidence' in parsed:
    try:
        conf = float(parsed['confidence'])
        # Clamp to 0.0-1.0 range
        parsed['confidence'] = max(0.0, min(1.0, conf))
    except:
        # Default to medium-low confidence on parse error
        parsed['confidence'] = 0.5

# Fallback defaults
defaults = {
    'confidence': 0.5,  # Medium-low (system defers to rules)
}

# Error fallback
error_response = {
    'confidence': 0.3,  # Low (definitely defer to rules)
}
```

**When LLM is disabled**:
```python
decision_bundle = {
    'llm_confidence': 0.0,  # No LLM available
}
```

#### **Why This Design Is Critical**

**Without Confidence Scoring**:
- ❌ All LLM predictions treated equally (high false positive rate)
- ❌ No way to distinguish "very sure" vs "guessing"
- ❌ System either trusts LLM blindly (risky) or ignores it completely (defeats purpose)

**With Confidence Scoring**:
- ✅ High-confidence predictions override conservative rules (catches sophisticated fraud)
- ✅ Low-confidence predictions ignored (prevents false positives)
- ✅ System adapts based on LLM certainty (best of both worlds)
- ✅ Explainable decisions for compliance ("LLM was 94% confident")

#### **Production Considerations**

**Monitoring Confidence Levels**:
```python
# Track: "When LLM confidence was 0.9, how often was it correct?"
# Adjust thresholds based on real-world performance

if confidence >= 0.85:
    accuracy = 95%  # Very reliable, safe to override
elif confidence >= 0.70:
    accuracy = 80%  # Fairly reliable, escalate to review
else:
    accuracy = 60%  # Not reliable enough, defer to rules
```

**Configuration Options** (future enhancement):
```yaml
# llm_config.yaml
confidence_thresholds:
  high_confidence_override: 0.85  # LLM can BLOCK
  medium_high_escalate: 0.70      # LLM can WARN
  low_confidence_defer: 0.60      # Defer to rules
  
  # Could tune based on false positive tolerance:
  # - Higher thresholds (0.90+) = Fewer overrides, more conservative
  # - Lower thresholds (0.75+) = More overrides, catch more fraud
```

#### **Common Questions**

**Q: Why not always trust the LLM?**  
A: LLMs can be uncertain or wrong. A confidence=0.45 prediction is essentially guessing and shouldn't override proven rules.

**Q: Why not use only rule-based detection?**  
A: Rules miss sophisticated fraud (phishing language, social engineering, novel scams). High-confidence LLM catches these.

**Q: Can confidence scoring be removed?**  
A: ❌ NO. It's critical for safe LLM integration. Without it, you must either:
- Never let LLM override (defeats purpose)
- Always let LLM override (too many false positives)

**Q: How were thresholds (0.85, 0.70, 0.60) chosen?**  
A: Based on ML best practices and testing. These can be tuned based on production data:
- 0.85 = "Very confident" (typical for high-quality predictions)
- 0.70 = "Fairly confident" (enough to escalate for review)
- 0.60 = "Not confident enough" (too uncertain to trust)

---

## **Summary: Key Takeaways**

### **In-Memory Entity Registry**
- ✅ Python dictionary tracking bank account linkages
- ✅ Detects fraud rings (multiple claimants → same account)
- ✅ Fast O(1) lookups for real-time detection
- ⚠️ Lost on restart (use persistent storage for production)

### **Risk Scoring (Not Rewards)**
- ✅ Rule-based scoring system (0-6 scale)
- ✅ Deterministic: same input → same output
- ❌ NOT reinforcement learning
- ❌ NOT dynamic/learning system
- ✅ Explainable and auditable

### **Orchestrator Pattern**
- ✅ Coordinates 3 fraud detection agents
- ✅ Runs agents in parallel for speed
- ✅ Aggregates scores and makes unified decision
- ✅ Single entry point for fraud detection
- ✅ Clean architecture with separation of concerns

### **LLM Confidence Scoring**
- ✅ 0.0-1.0 probability score indicating LLM certainty
- ✅ Controls whether LLM can override rule-based decisions
- ✅ High confidence (≥0.85) allows BLOCK overrides
- ✅ Low confidence (<0.60) defers to rule-based logic
- ✅ Critical for safe AI integration and preventing false positives
- ✅ Generated by LLM (AWS Bedrock/Claude 3), validated by system

---

**End of Advanced Topics**
