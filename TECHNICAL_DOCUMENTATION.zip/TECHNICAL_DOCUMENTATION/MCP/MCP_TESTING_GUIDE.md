# MCP Testing Guide
## How to Test MCP Fraud Detection Locally

**Document Version:** 1.0  
**Last Updated:** February 8, 2026  
**Purpose:** Step-by-step guide for testing MCP server locally

---

## Table of Contents

1. [Test Environment Setup](#1-test-environment-setup)
2. [Quick Test with Provided Client](#2-quick-test-with-provided-client)
3. [Testing MCP with Python Client](#3-testing-mcp-with-python-client)
4. [Test Individual Tools](#4-test-individual-tools)
5. [Test Scenarios](#5-test-scenarios)
6. [Performance Testing](#6-performance-testing)
7. [Integration Testing](#7-integration-testing)

---

## 1. Test Environment Setup

### Prerequisites

```bash
# 1. Navigate to project root
cd "c:\Yogesh\GenAI\Fraud Detection\Fraud-Internal-Detection"

# 2. Activate virtual environment
.\venv\Scripts\Activate.ps1

# 3. Install MCP dependencies
pip install mcp fastmcp

# 4. Verify installation
python -c "import mcp; print('MCP client OK')"
python -c "import fastmcp; print('FastMCP server OK')"
```

### Understanding MCP Server Startup

⚠️ **Important:** You do **NOT** need to manually start the MCP server when using the Python client!

**The MCP client automatically starts the server as a subprocess:**
1. When you run `python app/mcp/fraud_mcp_client.py`, the client spawns the server process
2. The server runs in the background (stdio transport captures its logs)
3. When the client disconnects, the server process is terminated

**You won't see server logs in your terminal** because:
- MCP uses **stdio transport** (stdin/stdout communication)
- The server's stdout/stderr are captured by the client for MCP protocol communication
- Server logs are not printed to your terminal

### How the Client Auto-Starts the Server (Under the Hood)

Here's what happens in `fraud_mcp_client.py` when you call `await client.connect()`:

```python
# From fraud_mcp_client.py - connect() method

# Step 1: Configure server parameters
server_params = StdioServerParameters(
    command="python",                           # Python executable
    args=["app/mcp/fraud_detection_server.py"], # Server script to run
    env=None
)

# Step 2: Start server as subprocess
self.stdio_context = stdio_client(server_params)
read, write = await self.stdio_context.__aenter__()  # This spawns the server!

# Step 3: Create MCP session
self.session_context = ClientSession(read, write)
self.session = await self.session_context.__aenter__()

# Step 4: Initialize MCP protocol
await self.session.initialize()
```

**What happens:**
- `stdio_client(server_params)` spawns a subprocess: `python app/mcp/fraud_detection_server.py`
- The client captures the server's stdin/stdout pipes
- All communication happens via these pipes (MCP protocol messages)
- Server prints (like startup logs) are hidden because stdout is used for MCP messages

### Manual Server Startup (Optional - For Debugging Only)

If you want to see server logs for debugging, you can start it manually in a separate terminal:

```bash
# Open a NEW terminal window
cd "c:\Yogesh\GenAI\Fraud Detection\Fraud-Internal-Detection"
.\venv\Scripts\Activate.ps1

# Run server directly (you'll see startup logs)
python app/mcp/fraud_detection_server.py

# Expected output:
# ============================================================
# Starting Fraud Detection MCP Server
# ============================================================
# Tools available:
#   1. check_payout_fraud - Comprehensive fraud detection
#   2. check_employee_control_risk - Employee behavior analysis
#   3. check_lastmile_payment_risk - Payment risk analysis
#   4. check_entity_link_risk - Bank account linkage detection
#   5. get_fraud_system_health - System health check
# ============================================================
# Server is ready and waiting for MCP protocol messages on stdin...
```

**Note:** Manual startup is **only for debugging**. The server will wait for MCP messages on stdin and won't accept regular terminal input. Press `Ctrl+C` to stop it.

### How to Verify Server is Working

Instead of checking server logs, verify the server is working by:

1. **Run the Python client** - it will auto-start the server:
   ```bash
   python app/mcp/fraud_mcp_client.py
   ```

2. **Check the client logs** - you'll see:
   ```
   INFO - Connecting to MCP server: app/mcp/fraud_detection_server.py
   INFO - Connected to MCP server successfully
   INFO - Found 5 tools
   ```

3. **Health check returns "healthy"** - confirms server is running correctly

### Key Takeaway

✅ **For normal testing:** Just run the client. It auto-starts the server.  
✅ **For management demos:** Show the client output - it proves the system works!  
❌ **Don't manually start the server** unless debugging startup issues.

### 🎯 **For Management/Architecture Demos**

**Simple Approach - Show Client Output:**

```powershell
# Run the MCP client tests
python app/mcp/fraud_mcp_client.py
```

**This output is sufficient proof for management:**
- ✅ Shows 5 tools discovered via MCP protocol
- ✅ Shows fraud detection working (WARN/ALLOW/BLOCK decisions)
- ✅ Shows all agents responding correctly
- ✅ Shows system health check passing

**What management sees:**
```
✅ Discovered 5 tools:
   1. check_payout_fraud
   2. check_employee_control_risk
   3. check_lastmile_payment_risk
   4. check_entity_link_risk
   5. get_fraud_system_health

✅ Fraud Detection Result:
   Decision: WARN
   Total Score: 2

✅ System Health:
   Status: healthy
   Agents: All 4 agents available

✅ All examples completed!
```

**Additional proof (if needed):**

While client is running, open another terminal to show 2 Python processes:
```powershell
Get-Process python | Select-Object Id, ProcessName, StartTime
# You'll see: client process + auto-started server process
```

---

## 2. Quick Test with Provided Client

### Using Example Client

The project includes a ready-to-use MCP client example:

```bash
# Location: app/mcp/fraud_mcp_client.py

# Run example client
python app/mcp/fraud_mcp_client.py
```

### Example Client Code

```python
# app/mcp/fraud_mcp_client.py already includes test scenarios

import asyncio
from fraud_mcp_client import FraudDetectionMCPClient

async def quick_test():
    client = FraudDetectionMCPClient(
        server_script_path="app/mcp/fraud_detection_server.py"
    )
    
    await client.connect()
    
    # Test 1: Health check
    health = await client.get_health()
    print(f"✅ Health check: {health['status']}")
    
    # Test 2: List tools
    tools = await client.list_tools()
    print(f"✅ Discovered {len(tools)} tools")
    
    # Test 3: Simple fraud check
    result = await client.check_payout_fraud({
        "current_action": {
            "action_type": "RELEASE_PAYMENT",
            "employee_id": "TEST-EMP-001",
            "timestamp": "2026-02-08T10:00:00Z",
            "claim_id": "TEST-CLM-001",
            "payment_id": "TEST-PAY-001"
        },
        "session_actions": [],
        "actor_role": "claims_processor",
        "claim_status": "APPROVED"
    })
    
    print(f"✅ Fraud check completed: {result['decision']}")
    
    await client.disconnect()

asyncio.run(quick_test())
```

### Expected Output

```
============================================================
Example 4: Tool Discovery
============================================================
2026-02-08 12:00:17,989 - __main__ - INFO - Listing available tools...
2026-02-08 12:00:18,003 - __main__ - INFO - Found 5 tools:

✅ Discovered 5 tools:
   1. check_payout_fraud
   2. check_employee_control_risk
   3. check_lastmile_payment_risk
   4. check_entity_link_risk
   5. get_fraud_system_health

============================================================
Example 1: Comprehensive Payout Fraud Detection
============================================================
✅ Fraud Detection Result:
   Decision: WARN
   Total Score: 2
   Per-Agent Breakdown:
     employee_control: LOW (score: 0)
     lastmile_payment: HIGH (score: 2)
     graph_entity: LOW (score: 0)

============================================================
Example 2: Employee Control Risk Check Only
============================================================
✅ Employee Control Risk Result:
   Risk Level: LOW
   Control Actions: 1

============================================================
Example 3: System Health Check
============================================================
✅ System Health:
   Status: healthy
   Agents: All 4 agents available
   Entity Registry: 0 accounts tracked

============================================================
All examples completed!
============================================================
```

**Note:** You may see a harmless `DeprecationWarning` about `datetime.utcnow()` - this does not affect functionality.

---

## 3. Testing MCP with Python Client

### Understanding MCP Protocol

⚠️ **Important:** MCP (Model Context Protocol) uses **stdio transport** (standard input/output communication), not HTTP/REST.

- MCP servers communicate via stdin/stdout
- Tools like Insomnia/Postman **cannot directly test MCP protocol**
- Use the provided Python MCP client for testing (see Section 2)

### Why Not Insomnia/Postman?

MCP is designed for:
- **AI assistants** (Claude Desktop, Cursor, etc.)
- **LangChain/LangGraph** integrations
- **Custom Python clients** using the MCP SDK

It is **not** a REST API and cannot be tested with traditional HTTP clients.

### Recommended Testing Approach

**Use the Python MCP Client** (covered in Section 2):
```bash
python app/mcp/fraud_mcp_client.py
```

**Or test with LangChain integration** (covered in Section 7):
- LangChain MCP Toolkit example
- Full integration test sequence

**For AI tool integration** (Claude Desktop, etc.):
- See [MCP Integration Guide](./MCP_INTEGRATION_GUIDE.md) for detailed setup

### Alternative: Test REST API Instead

If you need to test with Insomnia/Postman, use the **REST API endpoints** instead:
- REST API runs on port 8000 (separate from MCP)
- Exposes the same fraud detection logic
- See project documentation for REST API testing guide

---

## 4. Test Individual Tools

### Test Tool 1: check_payout_fraud (Orchestrator)

```python
import asyncio
from fraud_mcp_client import FraudDetectionMCPClient

async def test_orchestrator():
    client = FraudDetectionMCPClient("app/mcp/fraud_detection_server.py")
    await client.connect()
    
    # Test LOW risk scenario
    result = await client.check_payout_fraud({
        "current_action": {
            "action_type": "RELEASE_PAYMENT",
            "employee_id": "EMP-001",
            "timestamp": "2026-02-08T10:00:00Z",
            "claim_id": "CLM-001",
            "payment_id": "PAY-001"
        },
        "session_actions": [
            {
                "action_type": "APPROVE_CLAIM",
                "employee_id": "EMP-DIFFERENT",  # Different employee
                "timestamp": "2026-02-08T09:00:00Z",
                "claim_id": "CLM-001"
            }
        ],
        "actor_role": "payment_processor",
        "claim_status": "APPROVED",
        "approval_timestamp": "2026-02-08T09:00:00Z",
        "payment_method": "ACH",  # Standard, not fast
        "payee_changed_after_approval": False,
        "bank_account_hash": "NEW_ACCOUNT_HASH_001",
        "claimant_id": "CLMT-001"
    })
    
    assert result["decision"] == "ALLOW", f"Expected ALLOW, got {result['decision']}"
    assert result["total_score"] == 0, f"Expected score 0, got {result['total_score']}"
    print("✅ LOW risk test passed")
    
    await client.disconnect()

asyncio.run(test_orchestrator())
```

### Test Tool 2: check_employee_control_risk

```python
async def test_employee_risk():
    client = FraudDetectionMCPClient("app/mcp/fraud_detection_server.py")
    await client.connect()
    
    # Test HIGH risk: Same employee, 3 control actions
    result = await client.check_employee_control_risk(
        current_action={
            "action_type": "RELEASE_PAYMENT",
            "employee_id": "EMP-FRAUD",
            "timestamp": "2026-02-08T10:15:00Z",
            "claim_id": "CLM-FRAUD",
            "payment_id": "PAY-FRAUD"
        },
        session_actions=[
            {
                "action_type": "APPROVE_CLAIM",
                "employee_id": "EMP-FRAUD",
                "timestamp": "2026-02-08T10:00:00Z",
                "claim_id": "CLM-FRAUD"
            },
            {
                "action_type": "UPDATE_PAYEE_BANK",
                "employee_id": "EMP-FRAUD",
                "timestamp": "2026-02-08T10:10:00Z",
                "claim_id": "CLM-FRAUD"
            }
        ],
        actor_role="claims_processor"
    )
    
    assert result["control_risk"] == "HIGH", f"Expected HIGH, got {result['control_risk']}"
    assert result["metrics"]["control_action_count"] == 3
    print("✅ Employee risk test passed")
    
    await client.disconnect()

asyncio.run(test_employee_risk())
```

### Test Tool 3: check_lastmile_payment_risk

```python
async def test_lastmile_risk():
    client = FraudDetectionMCPClient("app/mcp/fraud_detection_server.py")
    await client.connect()
    
    # Test HIGH risk: Fast payment + short time delta
    result = await client.check_lastmile_payment_risk(
        claim_status="APPROVED",
        approval_timestamp="2026-02-08T10:00:00Z",
        payee_change_timestamp="2026-02-08T10:05:00Z",  # 5 minutes later
        payment_method="ACH_SAME_DAY",  # Fast method
        verification_flag=False,
        payee_changed_after_approval=True
    )
    
    assert result["last_mile_risk"] == "HIGH"
    assert result["computed_deltas"]["minutes_from_approval_to_payee_change"] <= 10
    print("✅ Last-mile risk test passed")
    
    await client.disconnect()

asyncio.run(test_lastmile_risk())
```

### Test Tool 4: check_entity_link_risk

```python
async def test_entity_risk():
    client = FraudDetectionMCPClient("app/mcp/fraud_detection_server.py")
    await client.connect()
    
    # First transaction - establish baseline
    result1 = await client.check_entity_link_risk(
        bank_account_hash="TEST_ACCOUNT_REUSE_001",
        claim_id="CLM-001",
        claimant_id="CLMT-001",
        employee_id="EMP-001"
    )
    
    # Second transaction - same account, different claimant
    result2 = await client.check_entity_link_risk(
        bank_account_hash="TEST_ACCOUNT_REUSE_001",  # Same account
        claim_id="CLM-002",
        claimant_id="CLMT-DIFFERENT",  # Different claimant (fraud indicator)
        employee_id="EMP-001"
    )
    
    assert result2["entity_risk"] == "HIGH", "Should detect multi-claimant reuse"
    print("✅ Entity risk test passed")
    
    await client.disconnect()

asyncio.run(test_entity_risk())
```

### Test Tool 5: get_fraud_system_health

```python
async def test_health():
    client = FraudDetectionMCPClient("app/mcp/fraud_detection_server.py")
    await client.connect()
    
    health = await client.get_health()
    
    assert health["status"] == "healthy"
    assert health["agents"]["orchestrator"] == "available"
    assert health["agents"]["employee_control"] == "available"
    assert health["agents"]["lastmile_payment"] == "available"
    assert health["agents"]["graph_entity"] == "available"
    print("✅ Health check test passed")
    
    await client.disconnect()

asyncio.run(test_health())
```

---

## 5. Test Scenarios

### Scenario 1: Clean Transaction (ALLOW)

```python
# No red flags
result = await client.check_payout_fraud({
    "current_action": {
        "action_type": "RELEASE_PAYMENT",
        "employee_id": "EMP-PAYMENT-PROCESSOR",
        "timestamp": "2026-02-08T10:00:00Z",
        "claim_id": "CLM-CLEAN",
        "payment_id": "PAY-CLEAN"
    },
    "session_actions": [
        {
            "action_type": "APPROVE_CLAIM",
            "employee_id": "EMP-APPROVER",  # Different employee
            "timestamp": "2026-02-07T15:00:00Z",  # Previous day
            "claim_id": "CLM-CLEAN"
        }
    ],
    "actor_role": "payment_processor",
    "claim_status": "APPROVED",
    "approval_timestamp": "2026-02-07T15:00:00Z",
    "payment_method": "ACH",
    "payee_changed_after_approval": False,
    "verification_flag": True,
    "bank_account_hash": "ESTABLISHED_ACCOUNT_001",
    "claimant_id": "CLMT-CLEAN"
})

# Expected: decision=ALLOW, total_score=0
```

### Scenario 2: Employee Fraud (WARN)

```python
# Same employee: APPROVE + UPDATE_PAYEE + RELEASE
result = await client.check_payout_fraud({
    "current_action": {
        "action_type": "RELEASE_PAYMENT",
        "employee_id": "EMP-INSIDER",
        "timestamp": "2026-02-08T10:15:00Z",
        "claim_id": "CLM-INSIDER",
        "payment_id": "PAY-INSIDER"
    },
    "session_actions": [
        {
            "action_type": "APPROVE_CLAIM",
            "employee_id": "EMP-INSIDER",  # Same employee
            "timestamp": "2026-02-08T10:00:00Z",
            "claim_id": "CLM-INSIDER"
        },
        {
            "action_type": "UPDATE_PAYEE_BANK",
            "employee_id": "EMP-INSIDER",  # Same employee
            "timestamp": "2026-02-08T10:10:00Z",
            "claim_id": "CLM-INSIDER"
        }
    ],
    "actor_role": "claims_processor",
    "claim_status": "APPROVED",
    "approval_timestamp": "2026-02-08T10:00:00Z",
    "payment_method": "ACH",
    "bank_account_hash": "INSIDER_ACCOUNT",
    "claimant_id": "CLMT-VICTIM"
})

# Expected: decision=WARN, total_score=2 (HIGH employee risk)
```

### Scenario 3: Last-Mile Fraud (WARN)

```python
# Payee changed minutes after approval + fast payment
result = await client.check_payout_fraud({
    "current_action": {
        "action_type": "RELEASE_PAYMENT",
        "employee_id": "EMP-PAYMENT",
        "timestamp": "2026-02-08T10:08:00Z",
        "claim_id": "CLM-LASTMILE",
        "payment_id": "PAY-LASTMILE"
    },
    "session_actions": [
        {
            "action_type": "UPDATE_PAYEE_BANK",
            "employee_id": "EMP-DIFFERENT",
            "timestamp": "2026-02-08T10:05:00Z",
            "claim_id": "CLM-LASTMILE"
        }
    ],
    "actor_role": "payment_processor",
    "claim_status": "APPROVED",
    "approval_timestamp": "2026-02-08T10:00:00Z",  # Approved at 10:00
    "payee_change_timestamp": "2026-02-08T10:05:00Z",  # Changed at 10:05 (5 min)
    "payment_method": "ACH_SAME_DAY",  # Fast payment
    "verification_flag": False,  # No verification
    "payee_changed_after_approval": True,
    "bank_account_hash": "NEW_SUSPICIOUS_ACCOUNT",
    "claimant_id": "CLMT-VICTIM"
})

# Expected: decision=WARN, total_score=3 (HIGH last-mile risk)
```

### Scenario 4: Fraud Ring (BLOCK)

```python
# Account reused across multiple claimants + all other red flags
result = await client.check_payout_fraud({
    "current_action": {
        "action_type": "RELEASE_PAYMENT",
        "employee_id": "EMP-FRAUD-RING",
        "timestamp": "2026-02-08T10:08:00Z",
        "claim_id": "CLM-FRAUD-RING-3",
        "payment_id": "PAY-FRAUD-RING-3"
    },
    "session_actions": [
        {
            "action_type": "APPROVE_CLAIM",
            "employee_id": "EMP-FRAUD-RING",
            "timestamp": "2026-02-08T10:00:00Z",
            "claim_id": "CLM-FRAUD-RING-3"
        },
        {
            "action_type": "UPDATE_PAYEE_BANK",
            "employee_id": "EMP-FRAUD-RING",
            "timestamp": "2026-02-08T10:05:00Z",
            "claim_id": "CLM-FRAUD-RING-3"
        }
    ],
    "actor_role": "claims_processor",
    "claim_status": "APPROVED",
    "approval_timestamp": "2026-02-08T10:00:00Z",
    "payee_change_timestamp": "2026-02-08T10:05:00Z",
    "payment_method": "WIRE",  # Fast method
    "verification_flag": False,
    "payee_changed_after_approval": True,
    "bank_account_hash": "MULE_ACCOUNT_REUSED",  # Same account from previous tests
    "claimant_id": "CLMT-FAKE-3"  # Third fake claimant
})

# Expected: decision=BLOCK, total_score=6 (all HIGH risks)
```

---

## 6. Performance Testing

### Response Time Test

```python
import time

async def performance_test():
    client = FraudDetectionMCPClient("app/mcp/fraud_detection_server.py")
    await client.connect()
    
    # Test orchestrator (with LLM - slowest)
    start = time.time()
    await client.check_payout_fraud({...})
    duration = time.time() - start
    print(f"Orchestrator: {duration*1000:.0f}ms")
    
    # Test individual agents (fast)
    start = time.time()
    await client.check_employee_control_risk({...})
    duration = time.time() - start
    print(f"Employee agent: {duration*1000:.0f}ms")
    
    await client.disconnect()

asyncio.run(performance_test())
```

### Expected Results

```
Orchestrator: ~750ms (includes LLM call)
Employee agent: ~5ms (rule-based only)
Last-mile agent: ~5ms
Entity agent: ~5ms
Health check: ~2ms
```

### Concurrent Requests Test

```python
async def concurrent_test():
    client = FraudDetectionMCPClient("app/mcp/fraud_detection_server.py")
    await client.connect()
    
    # Run 10 concurrent fraud checks
    tasks = [
        client.check_employee_control_risk({...})
        for _ in range(10)
    ]
    
    start = time.time()
    results = await asyncio.gather(*tasks)
    duration = time.time() - start
    
    print(f"10 concurrent requests: {duration*1000:.0f}ms")
    print(f"Avg per request: {duration/10*1000:.0f}ms")
    
    await client.disconnect()

asyncio.run(concurrent_test())
```

---

## 7. Integration Testing

### Test with LangChain

```python
from langchain_mcp import MCPToolkit
from langchain.agents import initialize_agent
from langchain_openai import ChatOpenAI

async def test_langchain():
    # Connect to MCP
    toolkit = MCPToolkit(
        server_script_path="app/mcp/fraud_detection_server.py"
    )
    
    # Create agent
    llm = ChatOpenAI(model="gpt-4", temperature=0)
    agent = initialize_agent(
        tools=toolkit.get_tools(),
        llm=llm,
        agent="zero-shot-react-description"
    )
    
    # Test
    result = agent.run(
        "Check if claim CLM-TEST is fraudulent. "
        "Employee EMP-001 did everything alone."
    )
    
    print(f"✅ LangChain integration test passed")
    print(f"Result: {result}")

asyncio.run(test_langchain())
```

### Test All Tools in Sequence

```python
async def integration_test():
    """Full integration test of all 5 tools"""
    client = FraudDetectionMCPClient("app/mcp/fraud_detection_server.py")
    await client.connect()
    
    print("Running full integration test...")
    
    # 1. Health check
    health = await client.get_health()
    assert health["status"] == "healthy"
    print("✅ Health check passed")
    
    # 2. Employee risk
    emp_result = await client.check_employee_control_risk({...})
    assert "control_risk" in emp_result
    print("✅ Employee risk check passed")
    
    # 3. Last-mile risk
    lm_result = await client.check_lastmile_payment_risk({...})
    assert "last_mile_risk" in lm_result
    print("✅ Last-mile risk check passed")
    
    # 4. Entity risk
    entity_result = await client.check_entity_link_risk({...})
    assert "entity_risk" in entity_result
    print("✅ Entity risk check passed")
    
    # 5. Full orchestrator
    full_result = await client.check_payout_fraud({...})
    assert "decision" in full_result
    print("✅ Orchestrator check passed")
    
    await client.disconnect()
    print("\n✅ All integration tests passed!")

asyncio.run(integration_test())
```

---

## Test Checklist

- [ ] MCP server starts without errors
- [ ] Health check returns "healthy"
- [ ] All 5 tools are discoverable
- [ ] Tool #1 (orchestrator) returns ALLOW/WARN/BLOCK
- [ ] Tool #2 (employee risk) detects SoD violations
- [ ] Tool #3 (last-mile risk) detects post-approval changes
- [ ] Tool #4 (entity risk) detects account reuse
- [ ] Tool #5 (health) returns system status
- [ ] Response times are acceptable (<1s for orchestrator)
- [ ] LangChain integration works
- [ ] Error handling works (invalid inputs)
- [ ] Concurrent requests work

---

---

## 8. Testing Hybrid Persistence Modes

### Understanding Database Persistence Options

MCP fraud detection tools support **two modes** via the `save_to_database` parameter:

**Mode 1: With Database Persistence (Default)**
- Results saved to DynamoDB
- Visible in SIU Dashboard
- Full audit trail
- Use for: Internal AI agents, compliance, production

**Mode 2: Analysis-Only (No Persistence)**
- Returns results without DB writes
- Faster performance
- No database costs
- Use for: Testing, external partners, high-volume scenarios

### Test Mode 1: With Database Persistence

```python
async def test_with_database():
    client = FraudDetectionMCPClient("app/mcp/fraud_detection_server.py")
    await client.connect()
    
    # Call with database persistence (explicit)
    result = await client.check_payout_fraud({
        "current_action": {
            "action_type": "RELEASE_PAYMENT",
            "employee_id": "EMP-001",
            "timestamp": "2026-02-08T10:00:00Z",
            "claim_id": "CLM-001",
            "payment_id": "PAY-001"
        },
        "session_actions": [],
        "actor_role": "payment_processor",
        "claim_status": "APPROVED",
        "bank_account_hash": "HASH-001",
        "claimant_id": "CLMT-001",
        "save_to_database": True  # ← Saves to DynamoDB
    })
    
    # Verify database save
    assert result['database_saved'] == True
    assert 'event_id' in result
    
    # Result is now visible in SIU Dashboard
    print(f"✅ Saved to DB with event_id: {result['event_id']}")
    
    await client.disconnect()

asyncio.run(test_with_database())
```

### Test Mode 2: Analysis-Only (No Database)

```python
async def test_without_database():
    client = FraudDetectionMCPClient("app/mcp/fraud_detection_server.py")
    await client.connect()
    
    # Call without database persistence
    result = await client.check_payout_fraud({
        "current_action": {
            "action_type": "RELEASE_PAYMENT",
            "employee_id": "EMP-002",
            "timestamp": "2026-02-08T10:00:00Z",
            "claim_id": "CLM-002",
            "payment_id": "PAY-002"
        },
        "session_actions": [],
        "actor_role": "payment_processor",
        "claim_status": "APPROVED",
        "bank_account_hash": "HASH-002",
        "claimant_id": "CLMT-002",
        "save_to_database": False  # ← No DB write
    })
    
    # Verify no database save
    assert result['database_saved'] == False
    assert 'event_id' not in result
    
    # Result NOT visible in SIU Dashboard (faster, no DB cost)
    print(f"✅ Analysis completed: {result['decision']} (no DB save)")
    
    await client.disconnect()

asyncio.run(test_without_database())
```

### Run Hybrid Tests

```bash
# Run all hybrid persistence tests
pytest tests/mcp/test_mcp_with_database.py -v
pytest tests/mcp/test_mcp_without_database.py -v
pytest tests/mcp/test_mcp_hybrid_scenarios.py -v

# Or run all MCP tests
pytest tests/mcp/ -v
```

### When to Use Each Mode

**Use `save_to_database=True` (Default):**
- ✅ Production fraud detection
- ✅ Internal AI agents
- ✅ Compliance/audit requirements
- ✅ SIU Dashboard integration

**Use `save_to_database=False`:**
- ✅ High-volume testing (don't pollute DB)
- ✅ External/third-party AI agents
- ✅ Performance-critical scenarios
- ✅ Consumer handles their own persistence

---

## Next Steps

- **Database Persistence Strategy**: See [MCP Database Persistence Strategy](./MCP_DATABASE_PERSISTENCE_STRATEGY.md)
- **Hybrid Persistence Tests**: See [MCP Hybrid Persistence Tests](./MCP_HYBRID_PERSISTENCE_TESTS.md)
- **Production Deployment**: See [MCP Production Deployment Changes](./MCP_PRODUCTION_DEPLOYMENT_CHANGES.md)
- **Tool Reference**: See [MCP Tools Reference](./MCP_TOOLS_REFERENCE.md)
- **Integration Examples**: See [MCP Integration Guide](./MCP_INTEGRATION_GUIDE.md)

---

**End of MCP Testing Guide**
