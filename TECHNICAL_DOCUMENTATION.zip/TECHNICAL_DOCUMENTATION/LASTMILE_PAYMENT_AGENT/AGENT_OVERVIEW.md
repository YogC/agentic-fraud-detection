# Last Mile Payment Agent - Technical Overview ⏱️

## **Logic File Description**

**File Location:** `c:\Yogesh\GenAI\Fraud Detection\Fraud-Internal-Detection\app\agents\lastmile_payment_agent.py`

**Class Name:** `LastMilePaymentAgent`

---

### **Purpose**

The Last Mile Payment Agent is a specialized fraud detection component that monitors the **critical final stage** of the payment process—the period immediately after claim approval when fraudsters often strike. It detects suspicious activities that occur in the "last mile" before funds are released, specifically targeting **post-approval manipulation** attacks.

This agent is particularly effective at detecting:
- **Account hijacking**: Payee information changed after claim approval
- **Time-based attacks**: Rapid changes immediately after approval
- **Fast-payment exploitation**: Use of instant payment methods to avoid reversal
- **Unauthorized modifications**: Changes made without customer verification

---

### **Core Functionality**

| Feature | Description |
|---------|-------------|
| **Post-Approval Monitoring** | Tracks changes made AFTER claim approval |
| **Temporal Analysis** | Measures time between approval and payee modification |
| **Payment Method Risk** | Identifies fast/irreversible payment methods |
| **Verification Tracking** | Validates customer authorization for changes |
| **Real-Time Detection** | Operates without historical baseline requirements |

---

### **Key Design Principles**

✅ **Temporal Precision**: Focuses on the critical 10-minute window post-approval  
✅ **Method-Aware**: Understands risks of ACH_SAME_DAY, WIRE, INSTANT, RTP  
✅ **Verification-Centric**: Flags unauthorized changes  
✅ **Session-Based**: No historical data required  
✅ **Fail-Safe**: Defaults to LOW risk on errors (fail-open)

---

### **The "Last Mile" Concept**

```
Fraud Attack Timeline:
┌─────────────────────────────────────────────────────────┐
│  CLAIM LIFECYCLE                                         │
├─────────────────────────────────────────────────────────┤
│                                                           │
│  Day 1-30: Claim Submission → Investigation             │
│           ✅ Normal process, multiple reviews            │
│                                                           │
│  Day 31: CLAIM APPROVED ← Point of No Return            │
│          ════════════════                                │
│                ↓                                          │
│          ⚠️ "LAST MILE" ATTACK WINDOW                    │
│          (Minutes 0-10 after approval)                   │
│                ↓                                          │
│  Attacker changes:                                       │
│    - Bank account                                        │
│    - Address                                             │
│    - Phone number                                        │
│                ↓                                          │
│  Day 31 + 1 hour: Payment Released                      │
│                   💸 Funds stolen                        │
│                                                           │
└─────────────────────────────────────────────────────────┘

❗ THIS AGENT DETECTS THAT CRITICAL WINDOW
```

**Why "Last Mile" Matters:**
- ✅ Most fraud checks happen BEFORE approval
- ✅ After approval, processes become automated
- ✅ Attackers exploit the "approved" status to make rapid changes
- ✅ Fast payment methods leave no time for reversal

---

## **Execution Overview**

### **How the Logic Executes**

#### **Phase 1: Input Reception & Parsing**

```
INPUT RECEIVED
    ↓
Extract Key Data:
  - claim_status (APPROVED? PENDING?)
  - approval_timestamp
  - payee_change_timestamp
  - payment_method
  - payment_release_request (boolean)
  - verification_flag (boolean)
  - payee_changed_after_approval (boolean)
```

#### **Phase 2: Temporal Analysis**

```
IF approval_timestamp AND payee_change_timestamp PROVIDED:
    ↓
Calculate Time Delta:
    minutes_delta = (payee_change_ts - approval_ts) / 60
    ↓
Store for risk evaluation
```

#### **Phase 3: Risk Factor Evaluation (4 Rules)**

The agent evaluates **4 independent risk factors**, accumulating risk points:

```
┌─────────────────────────────────────────────────────────┐
│ RISK FACTOR 1: Post-Approval Payee Change              │
├─────────────────────────────────────────────────────────┤
│ IF payee_changed_after_approval == True AND             │
│    claim_status == 'APPROVED':                          │
│   ↓                                                      │
│   risk_points += 1                                      │
│   reason: "⚠️ Payee destination changed AFTER claim    │
│            was approved (last-mile risk)"               │
│                                                          │
│ ✅ Detects: Account hijacking attacks                   │
└─────────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────────┐
│ RISK FACTOR 2: Short Time Window                        │
├─────────────────────────────────────────────────────────┤
│ IF minutes_delta <= 10 minutes:                         │
│   ↓                                                      │
│   risk_points += 1                                      │
│   reason: "⚠️ Payee changed within X.X minutes of      │
│            approval (risky window: <=10 min)"           │
│                                                          │
│ ✅ Detects: Rapid manipulation immediately after        │
│             approval (automated attack scripts)          │
└─────────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────────┐
│ RISK FACTOR 3: Fast Payment Method                      │
├─────────────────────────────────────────────────────────┤
│ IF payment_method IN ['ACH_SAME_DAY', 'INSTANT',       │
│                        'WIRE', 'RTP'] AND               │
│    payment_release_request == True:                     │
│   ↓                                                      │
│   risk_points += 1                                      │
│   reason: "⚠️ Fast payment method detected: {method}   │
│            (funds released quickly, hard to reverse)"   │
│                                                          │
│ ✅ Detects: Use of irreversible payment methods         │
│             to prevent recovery                          │
└─────────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────────┐
│ RISK FACTOR 4: No Customer Verification                 │
├─────────────────────────────────────────────────────────┤
│ IF payee_changed_after_approval == True AND             │
│    verification_flag == False:                          │
│   ↓                                                      │
│   risk_points += 1                                      │
│   reason: "⚠️ No customer verification recorded for    │
│            payee change (potential unauthorized mod)"   │
│                                                          │
│ ✅ Detects: Unauthorized changes (social engineering,   │
│             compromised credentials)                     │
└─────────────────────────────────────────────────────────┘
```

#### **Phase 4: Risk Level Determination**

```
CALCULATE FINAL RISK:
    ↓
┌─────────────────────────────────────────────┐
│ IF risk_points >= 2:                        │
│   last_mile_risk = 'HIGH'                   │
│   Action: BLOCK transaction                 │
└─────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────┐
│ ELIF risk_points >= 1:                      │
│   last_mile_risk = 'MED'                    │
│   Action: WARN / Manual Review              │
└─────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────┐
│ ELSE:                                       │
│   last_mile_risk = 'LOW'                    │
│   Action: ALLOW transaction                 │
└─────────────────────────────────────────────┘
```

#### **Phase 5: Output Generation**

```json
{
  "last_mile_risk": "HIGH",
  "reasons": [
    "⚠️ Payee destination changed AFTER claim was approved (last-mile risk)",
    "⚠️ Payee changed within 3.5 minutes of approval (risky window: <=10 min)",
    "⚠️ Fast payment method detected: WIRE (funds released quickly, hard to reverse)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": 3.5,
    "is_fast_payment_method": true,
    "payee_changed_post_approval": true,
    "verification_recorded": false,
    "risk_points": 3
  }
}
```

---

## **Risk Scoring Matrix**

| Risk Factor | Condition | Points | Severity | Detection Target |
|-------------|-----------|--------|----------|------------------|
| **Factor 1** | Payee changed after approval | +1 | 🟡 Moderate | Account hijacking |
| **Factor 2** | Change within 10 minutes | +1 | 🟡 Moderate | Automated attacks |
| **Factor 3** | Fast payment method used | +1 | 🟡 Moderate | Irreversible fraud |
| **Factor 4** | No customer verification | +1 | 🟡 Moderate | Unauthorized access |

**Thresholds:**
- **0 points** → LOW risk (Normal transaction)
- **1 point** → MED risk (Review recommended)
- **2+ points** → HIGH risk (Block transaction)

---

## **Mandatory Input Fields**

### **Complete Input Structure**

```python
input_data = {
    'claim_status': str,                    # ← MANDATORY
    'approval_timestamp': str,              # ← MANDATORY (ISO8601)
    'payee_change_timestamp': str,          # ← OPTIONAL (None if no change)
    'payment_method': str,                  # ← MANDATORY
    'payment_release_request': bool,        # ← MANDATORY
    'verification_flag': bool,              # ← MANDATORY
    'payee_changed_after_approval': bool    # ← MANDATORY
}
```

---

### **Field Specifications**

#### **1. `claim_status` (MANDATORY)**

| Property | Value |
|----------|-------|
| **Type** | string |
| **Required** | ✅ YES |
| **Format** | Uppercase enum |
| **Purpose** | Determine if claim is in approved state |

**Description:**  
Current status of the insurance claim. The agent specifically looks for `'APPROVED'` status to trigger post-approval risk checks.

**Valid Values:**
- `APPROVED` - Claim has been approved for payment
- `PENDING` - Under review
- `REJECTED` - Claim denied
- `PAID` - Payment already released

**Example:**
```json
"claim_status": "APPROVED"
```

**Validation:**
- Must be non-empty
- Case-insensitive (internally normalized to UPPERCASE)
- Only `'APPROVED'` triggers post-approval checks

---

#### **2. `approval_timestamp` (MANDATORY)**

| Property | Value |
|----------|-------|
| **Type** | string |
| **Required** | ✅ YES |
| **Format** | ISO8601 timestamp |
| **Purpose** | Calculate time delta between approval and payee change |

**Description:**  
The exact date/time when the claim was approved. Used to calculate how quickly payee information was modified after approval (critical for detecting rapid manipulation attacks).

**Example:**
```json
"approval_timestamp": "2026-02-07T14:30:00Z"
```

**Validation:**
- Must be valid ISO8601 format
- Supports both `Z` suffix and timezone offset (`+00:00`)
- If invalid, defaults to current time (may affect delta calculation)

---

#### **3. `payee_change_timestamp` (OPTIONAL)**

| Property | Value |
|----------|-------|
| **Type** | string or null |
| **Required** | ⚠️ OPTIONAL |
| **Default** | `null` |
| **Format** | ISO8601 timestamp |
| **Purpose** | Calculate time window for change detection |

**Description:**  
The exact date/time when payee information (bank account, address, etc.) was modified. If `null` or not provided, time-based risk checks are skipped.

**Example:**
```json
"payee_change_timestamp": "2026-02-07T14:33:30Z"
```

**Time Delta Calculation:**
```python
minutes_delta = (payee_change_timestamp - approval_timestamp) / 60

# Example:
# approval: 14:30:00
# change:   14:33:30
# delta:    3.5 minutes ← TRIGGERS Risk Factor 2 (<=10 min)
```

**When to Set:**
- `null` - No payee changes made
- ISO8601 string - Payee modified at this time

---

#### **4. `payment_method` (MANDATORY)**

| Property | Value |
|----------|-------|
| **Type** | string |
| **Required** | ✅ YES |
| **Format** | Uppercase enum |
| **Purpose** | Identify fast/irreversible payment methods |

**Description:**  
The method by which payment will be released. Fast payment methods are flagged as higher risk because they are difficult or impossible to reverse once released.

**Valid Values:**

| Value | Risk | Reversibility | Typical Processing |
|-------|------|---------------|-------------------|
| `ACH_SAME_DAY` | 🔴 HIGH | Difficult | Same day |
| `INSTANT` | 🔴 HIGH | Nearly impossible | < 1 minute |
| `WIRE` | 🔴 HIGH | Impossible | < 1 hour |
| `RTP` | 🔴 HIGH | Impossible | Real-time (seconds) |
| `ACH_STANDARD` | 🟢 LOW | Possible | 2-3 business days |
| `CHECK` | 🟢 LOW | Possible | 5-7 business days |

**Example:**
```json
"payment_method": "WIRE"
```

**Validation:**
- Must be non-empty
- Case-insensitive (internally normalized to UPPERCASE)
- Fast methods: `ACH_SAME_DAY`, `INSTANT`, `WIRE`, `RTP`

---

#### **5. `payment_release_request` (MANDATORY)**

| Property | Value |
|----------|-------|
| **Type** | boolean |
| **Required** | ✅ YES |
| **Format** | true/false |
| **Purpose** | Indicate if payment is being released NOW |

**Description:**  
Indicates whether this transaction is requesting immediate payment release. Combined with fast payment methods, this creates critical urgency for fraud detection.

**Example:**
```json
"payment_release_request": true
```

**Risk Context:**
- `true` + fast payment method → **HIGH URGENCY** (funds leaving soon)
- `false` → Payment scheduled for later (more time to review)

---

#### **6. `verification_flag` (MANDATORY)**

| Property | Value |
|----------|-------|
| **Type** | boolean |
| **Required** | ✅ YES |
| **Format** | true/false |
| **Purpose** | Indicate if customer verified the payee change |

**Description:**  
Indicates whether the customer explicitly verified/authorized the payee change through a secure channel (e.g., callback verification, multi-factor authentication, email confirmation).

**Example:**
```json
"verification_flag": false
```

**Risk Context:**
- `true` → Customer confirmed change (legitimate)
- `false` → No verification → **Potential unauthorized modification**

**Verification Methods (Examples):**
- Phone callback to customer
- SMS verification code
- Email confirmation link
- In-person verification
- Multi-factor authentication

---

#### **7. `payee_changed_after_approval` (MANDATORY)**

| Property | Value |
|----------|-------|
| **Type** | boolean |
| **Required** | ✅ YES |
| **Format** | true/false |
| **Purpose** | Flag post-approval modifications |

**Description:**  
A **pre-computed flag** indicating whether payee information was modified AFTER the claim was approved. This is the primary trigger for last-mile risk analysis.

**Example:**
```json
"payee_changed_after_approval": true
```

**How to Compute (Upstream):**
```python
# Upstream system computes this before calling agent
if claim_approval_timestamp and last_payee_modification_timestamp:
    payee_changed_after_approval = (
        last_payee_modification_timestamp > claim_approval_timestamp
    )
else:
    payee_changed_after_approval = False
```

**Why Pre-Computed?**
- Requires database queries to determine modification history
- Agent focuses on real-time analysis, not data retrieval
- Simplifies agent logic

---

## **Complete Input Examples**

### **Example 1: HIGH Risk Scenario (Last-Mile Attack)**

```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2026-02-07T14:30:00Z",
  "payee_change_timestamp": "2026-02-07T14:33:30Z",
  "payment_method": "WIRE",
  "payment_release_request": true,
  "verification_flag": false,
  "payee_changed_after_approval": true
}
```

**Expected Output:**
```json
{
  "last_mile_risk": "HIGH",
  "reasons": [
    "⚠️ Payee destination changed AFTER claim was approved (last-mile risk)",
    "⚠️ Payee changed within 3.5 minutes of approval (risky window: <=10 min)",
    "⚠️ Fast payment method detected: WIRE (funds released quickly, hard to reverse)",
    "⚠️ No customer verification recorded for payee change (potential unauthorized modification)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": 3.5,
    "is_fast_payment_method": true,
    "payee_changed_post_approval": true,
    "verification_recorded": false,
    "risk_points": 4
  }
}
```

**Why HIGH Risk?**
- ✅ All 4 risk factors triggered
- ✅ 4 points = Maximum risk
- ✅ Clear last-mile attack pattern

---

### **Example 2: MED Risk Scenario (Delayed Change)**

```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2026-02-07T14:30:00Z",
  "payee_change_timestamp": "2026-02-07T15:00:00Z",
  "payment_method": "ACH_STANDARD",
  "payment_release_request": false,
  "verification_flag": true,
  "payee_changed_after_approval": true
}
```

**Expected Output:**
```json
{
  "last_mile_risk": "MED",
  "reasons": [
    "⚠️ Payee destination changed AFTER claim was approved (last-mile risk)"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": 30.0,
    "is_fast_payment_method": false,
    "payee_changed_post_approval": true,
    "verification_recorded": true,
    "risk_points": 1
  }
}
```

**Why MED Risk?**
- ✅ Only 1 risk factor (post-approval change)
- ✅ 30 minutes is outside the 10-minute danger zone
- ✅ Customer verification recorded
- ✅ Standard ACH (not fast payment)

---

### **Example 3: LOW Risk Scenario (Normal Flow)**

```json
{
  "claim_status": "APPROVED",
  "approval_timestamp": "2026-02-07T14:30:00Z",
  "payee_change_timestamp": null,
  "payment_method": "CHECK",
  "payment_release_request": false,
  "verification_flag": true,
  "payee_changed_after_approval": false
}
```

**Expected Output:**
```json
{
  "last_mile_risk": "LOW",
  "reasons": [
    "No significant last-mile payment risks detected"
  ],
  "computed_deltas": {
    "minutes_from_approval_to_payee_change": null,
    "is_fast_payment_method": false,
    "payee_changed_post_approval": false,
    "verification_recorded": true,
    "risk_points": 0
  }
}
```

**Why LOW Risk?**
- ✅ No post-approval changes
- ✅ No risk factors triggered
- ✅ 0 points = Clean transaction

---

## **Fast Payment Methods**

### **Configured Methods (High Risk)**

```python
self.fast_payment_methods = {
    'ACH_SAME_DAY',  # Same-day ACH (Nacha)
    'INSTANT',       # Generic instant payment
    'WIRE',          # Wire transfer (domestic/international)
    'RTP'            # Real-Time Payments (Clearing House)
}
```

### **Why These Methods Are Risky**

| Method | Speed | Reversibility | Fraud Impact |
|--------|-------|---------------|--------------|
| **WIRE** | < 1 hour | ❌ Impossible | Funds gone permanently |
| **RTP** | Seconds | ❌ Impossible | Near-instant theft |
| **INSTANT** | < 1 minute | ❌ Nearly impossible | Very limited recovery window |
| **ACH_SAME_DAY** | Same day | 🟡 Difficult | Recovery requires bank coordination |

### **Safe Alternatives**

| Method | Speed | Reversibility | Benefits |
|--------|-------|---------------|----------|
| **ACH_STANDARD** | 2-3 days | ✅ Possible | Time to detect and stop fraud |
| **CHECK** | 5-7 days | ✅ Possible | Stop payment available |

---

## **Configuration Parameters**

```python
class LastMilePaymentAgent:
    def __init__(self):
        self.risky_time_window_minutes = 10  # Adjustable
        self.fast_payment_methods = {        # Adjustable
            'ACH_SAME_DAY',
            'INSTANT',
            'WIRE',
            'RTP'
        }
```

### **Tuning Options**

| Use Case | Time Window | Impact |
|----------|-------------|--------|
| **Strict Security** | 5 minutes | More alerts, catches rapid attacks |
| **Standard** | 10 minutes | Balanced (default) |
| **High Volume** | 15 minutes | Fewer alerts, focuses on very rapid changes |

---

## **Performance Characteristics**

| Metric | Value |
|--------|-------|
| **Execution Time** | < 5ms (typical) |
| **Memory Usage** | < 1MB |
| **CPU Usage** | Minimal (no ML inference) |
| **Complexity** | O(1) - constant time |
| **Dependencies** | None (no database queries) |

---

## **Error Handling**

```python
try:
    # Execute analysis logic
except Exception as e:
    logger.error(f"Error in last-mile payment analysis: {e}")
    return {
        'last_mile_risk': 'LOW',  # Fail-safe: default to LOW risk
        'reasons': [f"Error in analysis: {str(e)}"],
        'computed_deltas': {}
    }
```

**Fail-Safe Behavior:**
- If agent fails, defaults to `LOW` risk (fail-open)
- Error logged to audit trail
- Transaction proceeds to other agents
- System remains operational

---

## **Integration with Orchestrator**

```python
# In payout_orchestrator.py
lastmile_payment_input = {
    'claim_status': input_data.get('claim_status'),
    'approval_timestamp': input_data.get('approval_timestamp'),
    'payee_change_timestamp': input_data.get('payee_change_timestamp'),
    'payment_method': input_data.get('payment_method'),
    'payment_release_request': input_data.get('payment_release_request', False),
    'verification_flag': input_data.get('verification_flag', False),
    'payee_changed_after_approval': input_data.get('payee_changed_after_approval', False)
}

lastmile_result = await self.lastmile_payment_agent.execute(lastmile_payment_input)
```

---

## **Key Takeaways**

✅ **Last-mile focus**: Protects the critical post-approval window  
✅ **Temporal precision**: 10-minute risky window detection  
✅ **Method-aware**: Flags fast/irreversible payment methods  
✅ **Verification-centric**: Validates customer authorization  
✅ **4-factor analysis**: Multiple independent checks  
✅ **Real-time**: No historical data required  

**Critical Use Cases:**
1. **Account Hijacking**: Payee changed after approval
2. **Automated Attacks**: Rapid modifications (< 10 min)
3. **Irreversible Fraud**: Wire/instant payments
4. **Unauthorized Access**: No customer verification

---

**Next Steps:**
- See `RULE_BASED_LOGIC.md` for detailed scoring rules
- See `../TEST_CASES/LASTMILE_PAYMENT_AGENT/` for test scenarios
- See orchestrator documentation for integration examples

---

**Last Updated**: February 7, 2026  
**Agent Version**: 1.0  
**Author**: Fraud Detection Team
