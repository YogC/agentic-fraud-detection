# 🏢 Customer Enrichment Guide

**For:** Customers integrating with the Multi-Tenant Fraud Detection API  
**Purpose:** How to build your enrichment layer to call the API with compliance-safe fields  
**Audience:** Customer engineering teams, integration partners  
**Date:** February 4, 2026

---

## � Quick Start

### New to the API? Start here:

1. **📖 Read:** `INDUSTRY_COMPARISON.md` - See how this matches Sift, Stripe, Datadog
2. **🔐 Get API Key:** Contact your account manager or sign up at https://yourfrauddetection.com/signup
3. **🧪 Test:** Follow `END_TO_END_TEST_PLAN.md` with test key
4. **🔨 Build:** Use this guide to create your enrichment layer
5. **🚀 Go Live:** Switch to production key

### What You'll Build:

```
Your Database → Enrichment Layer → API Call → Fraud Decision
```

**Estimated Integration Time:** 2-4 days for most customers

---

## �📋 Table of Contents

1. [Getting Started Checklist](#getting-started-checklist)
2. [Architecture Overview](#architecture-overview)
1. [Getting Started Checklist](#getting-started-checklist)
2. [Architecture Overview](#architecture-overview)
3. [Why Customer-Side Enrichment?](#why-customer-side-enrichment)
4. [Integration Flow](#integration-flow)
5. [Compliance-Safe Field Reference](#compliance-safe-field-reference)
6. [Real-Time SQL Enrichment Examples](#real-time-sql-enrichment-examples) ⭐ NEW
7. [Enrichment Layer Examples](#enrichment-layer-examples)
8. [Reference Implementation](#reference-implementation)
9. [Testing Your Integration](#testing-your-integration)
10. [Best Practices](#best-practices)
11. [FAQ](#faq)

---

## ✅ Getting Started Checklist

### Phase 1: Setup (Day 1)
- [ ] **Obtain API Key**
  - Test key: `test_yourcompany_abc123...`
  - Production key: `prod_yourcompany_xyz789...`
  - Store securely (see `API_AUTHENTICATION_GUIDE.md`)

- [ ] **Review Documentation**
  - [ ] Read `INDUSTRY_COMPARISON.md` (understand the model)
  - [ ] Read this guide (enrichment patterns)
  - [ ] Review `API_ERROR_CODES.md` (error handling)

- [ ] **Test API Access**
  ```powershell
  $headers = @{
      "Authorization" = "Bearer test_yourcompany_abc123"
      "Content-Type" = "application/json"
  }
  Invoke-RestMethod -Uri "https://api.yourfrauddetection.com/health" -Headers $headers
  ```

### Phase 2: Development (Days 2-3)
- [ ] **Map Your Data Model**
  - [ ] Identify employee ID field
  - [ ] Identify bank account field (will be hashed)
  - [ ] Identify transaction workflow tables
  
- [ ] **Build Enrichment Layer**
  - [ ] Write SQL queries (see [Real-Time SQL Examples](#real-time-sql-enrichment-examples))
  - [ ] Calculate compliance-safe fields
  - [ ] Test field calculations locally

- [ ] **Integrate API Calls**
  - [ ] Add API client to your codebase
  - [ ] Handle authentication
  - [ ] Implement error handling
  - [ ] Add retry logic for rate limits

### Phase 3: Testing (Day 3-4)
- [ ] **Test All Scenarios**
  - [ ] Run `END_TO_END_TEST_PLAN.md` scenarios
  - [ ] Test with your actual data (test environment)
  - [ ] Verify decisions make sense
  
- [ ] **Monitor & Tune**
  - [ ] Check API response times
  - [ ] Review false positive rate
  - [ ] Adjust enrichment logic if needed

### Phase 4: Go Live (Day 4+)
- [ ] **Switch to Production**
  - [ ] Replace test key with production key
  - [ ] Enable monitoring/alerting
  - [ ] Start with shadow mode (log decisions, don't block)
  
- [ ] **Production Validation**
  - [ ] Monitor first 1000 requests
  - [ ] Review edge cases
  - [ ] Full go-live when confident

---

## 🏗️ Architecture Overview

### The Multi-Tenant Model

```
┌─────────────────────────────────────────────────────────────┐
│ YOUR SYSTEM (Customer A)                                    │
│                                                              │
│  ┌──────────────┐      ┌──────────────────────────┐        │
│  │ Your Database│──────▶│ Enrichment Layer        │        │
│  │ - Employees  │      │ - Query history          │        │
│  │ - Accounts   │      │ - Calculate patterns     │        │
│  │ - Transactions│      │ - Remove PII            │        │
│  └──────────────┘      │ - Build API payload     │        │
│                         └──────────┬───────────────┘        │
│                                    │                         │
└────────────────────────────────────┼─────────────────────────┘
                                     │
                                     │ API Call (Compliance-Safe)
                                     ▼
┌─────────────────────────────────────────────────────────────┐
│ FRAUD DETECTION API (Stateless Multi-Tenant)                │
│                                                              │
│  • Receives enriched transaction data                       │
│  • Runs rule-based agents (employee control, last-mile, etc)│
│  • LLM analyzes with current prompt version                 │
│  • Returns decision: BLOCK / WARN / APPROVE                 │
│  • Does NOT store your transaction data                     │
│                                                              │
└─────────────────────────────────────────────────────────────┘
                                     │
                                     │ Response (Decision + Reasoning)
                                     ▼
┌─────────────────────────────────────────────────────────────┐
│ YOUR SYSTEM (Customer A)                                    │
│                                                              │
│  • Receives fraud decision                                  │
│  • Stores decision in your audit log                        │
│  • Takes action (block payment, route to review, approve)   │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

**Key Points:**
- ✅ **You own your data** - stored in your systems
- ✅ **You enrich your data** - calculate patterns from your history
- ✅ **API is stateless** - doesn't remember your transactions
- ✅ **Multi-tenant safe** - your data never mixes with other customers
- ✅ **Compliance-safe** - no PII sent to the API

---

## 🔒 Why Customer-Side Enrichment?

### 1. **Data Ownership & Privacy**
- You maintain full control of your data
- No customer PII leaves your environment
- Compliance with data residency requirements (GDPR, CCPA, etc.)

### 2. **Multi-Tenant Isolation**
- Your employee IDs are yours (Customer A's "EMP001" ≠ Customer B's "EMP001")
- No risk of data leakage between customers
- API doesn't need to track which customer owns which data

### 3. **Flexibility**
- Use any data source: SQL databases, data lakes, real-time streams
- Implement your own enrichment logic
- Integrate with your existing systems (HR, accounting, etc.)

### 4. **Scalability**
- API remains stateless and fast
- No need to store millions of transactions per customer
- You control data retention policies

### 5. **Compliance-Safe by Design**
- API only sees derived metrics, not raw PII
- Even if API logs were breached, no customer PII exposed
- Safe for LLM training and prompt improvement

---

## 🔄 Integration Flow

### Step-by-Step Process

```
┌─────────────────────────────────────────────────────────────┐
│ STEP 1: Detect Transaction Event                            │
│ Your system detects a payment about to be released          │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│ STEP 2: Query Your Historical Data                          │
│ - Who is the current employee?                              │
│ - What actions were taken in this session?                  │
│ - Has this employee used this account before?               │
│ - What's the payment amount range?                          │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│ STEP 3: Calculate Compliance-Safe Fields                    │
│ employee_pattern: "SINGLE_EMPLOYEE" or "PROPER_SEPARATION"  │
│ account_pattern: "FIRST_USE" or "REUSED_ACROSS_CLAIMS"      │
│ amount_category: "SMALL" / "MEDIUM" / "LARGE"               │
│ workflow_separation: "SAME_EMPLOYEE_ALL_STEPS" or "PROPER"  │
│ time_window_mins: Time between first and last action        │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│ STEP 4: Build API Payload (Remove PII)                      │
│ transaction_id: "TXN_001" (your internal ID)                │
│ bank_account_hash: SHA256 hash (not real account number)    │
│ employee_id: "EMP001" (your internal ID, meaningless to API)│
│ + compliance-safe fields from Step 3                        │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│ STEP 5: Call Fraud Detection API                            │
│ POST /api/v1/payout/decide                                  │
│ { transaction_id, current_action, compliance_fields, ... }  │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│ STEP 6: Receive Decision                                    │
│ {                                                            │
│   "final_decision": "BLOCK" / "WARN" / "APPROVE",          │
│   "agent_results": { ... },                                 │
│   "llm_reasoning": "...",                                   │
│   "llm_confidence": 0.95                                    │
│ }                                                            |
└─────────────────────┬───────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────┐
│ STEP 7: Take Action in Your System                          │
│ - BLOCK: Stop payment, alert fraud team                     │
│ - WARN: Route to manual review queue                        │
│ - APPROVE: Proceed with payment release                     │
│ - Log decision in your audit trail                          │
└─────────────────────────────────────────────────────────────┘
```

---

## 📝 Compliance-Safe Field Reference

### Required Fields (Always Send)

#### Transaction Identity
```json
{
  "transaction_id": "string",           // Your internal ID
  "claimant_id": "string",              // Your internal ID (hashed if needed)
  "bank_account_hash": "string"         // SHA256 hash of account number
}
```

#### Current Action
```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",   // Or APPROVE_CLAIM, UPDATE_PAYEE_BANK
    "employee_id": "string",            // Your internal ID
    "timestamp": "ISO8601",
    "claim_id": "string",               // Your internal ID
    "payment_id": "string"              // Your internal ID
  }
}
```

#### Session Actions (Workflow History)
```json
{
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP001",          // Different employee = separation
      "timestamp": "2026-02-03T10:00:00Z",
      "claim_id": "CLM_001"
    },
    {
      "action_type": "UPDATE_PAYEE_BANK",
      "employee_id": "EMP002",
      "timestamp": "2026-02-03T14:00:00Z",
      "claim_id": "CLM_001"
    }
  ]
}
```

#### Transaction Metadata
```json
{
  "actor_role": "payment_processor",    // Role of current employee
  "claim_status": "APPROVED",
  "payment_amount": 25000.00,           // Actual amount for risk scoring
  "payment_method": "ACH",              // or "Wire Transfer", "Check"
  "payee_changed_after_approval": true, // Boolean
  "verification_flag": true             // Was customer contacted?
}
```

---

### NEW Compliance-Safe Fields (Your Enrichment Layer Calculates)

#### Employee Pattern
```json
{
  "employee_pattern": "SINGLE_EMPLOYEE"
}
```

**Possible Values:**
- `"SINGLE_EMPLOYEE"` - Same employee for all control actions (HIGH RISK)
- `"PROPER_SEPARATION"` - Different employees (LOW RISK)
- `"PARTIAL_SEPARATION"` - Some overlap (MEDIUM RISK)

**How to Calculate:**
```python
def calculate_employee_pattern(session_actions, current_action):
    employees = {action['employee_id'] for action in session_actions}
    employees.add(current_action['employee_id'])
    
    if len(employees) == 1:
        return "SINGLE_EMPLOYEE"
    elif len(employees) == len(session_actions) + 1:
        return "PROPER_SEPARATION"
    else:
        return "PARTIAL_SEPARATION"
```

---

#### Account Pattern ⭐ **REPLACES is_new_account**
```json
{
  "account_pattern": "REUSED_ACROSS_CLAIMS"
}
```

> **Important:** The `account_pattern` field replaces the old `is_new_account` boolean.  
> The API will automatically derive `is_new_account = True` when `account_pattern == "FIRST_USE"`.  
> **You no longer need to send is_new_account** - just provide `account_pattern`.

**Possible Values:**
- `"FIRST_USE"` - First time this employee uses this account (interpreted as new account)
- `"ESTABLISHED"` - Account used by multiple employees over time (LOW RISK)
- `"REUSED_ACROSS_CLAIMS"` - Same employee + same account multiple times (MEDIUM RISK)
- `"SUSPICIOUS_REUSE"` - High frequency, short timeframe (HIGH RISK)

**How to Calculate:**
```python
def calculate_account_pattern(employee_id, bank_account_hash, historical_db):
    query = """
        SELECT COUNT(*) as usage_count, 
               MIN(transaction_date) as first_used,
               MAX(transaction_date) as last_used
        FROM transactions
        WHERE employee_id = %s 
          AND bank_account_hash = %s
          AND transaction_date < NOW()
    """
    result = historical_db.query(query, [employee_id, bank_account_hash])
    
    if result['usage_count'] == 0:
        return "FIRST_USE"
    elif result['usage_count'] < 3:
        return "REUSED_ACROSS_CLAIMS"
    else:
        days_span = (result['last_used'] - result['first_used']).days
        if days_span < 30:
            return "SUSPICIOUS_REUSE"
        else:
            return "ESTABLISHED"
```

---

#### Amount Category
```json
{
  "amount_category": "LARGE"
}
```

**Possible Values:**
- `"SMALL"` - Below $5,000
- `"MEDIUM"` - $5,000 - $50,000
- `"LARGE"` - Above $50,000
- `"OUTLIER"` - Significantly above historical average for this employee

**How to Calculate:**
```python
def calculate_amount_category(payment_amount, employee_id, historical_db):
    # Your business thresholds
    if payment_amount < 5000:
        return "SMALL"
    elif payment_amount < 50000:
        return "MEDIUM"
    else:
        # Check if this is an outlier for this employee
        avg = historical_db.get_employee_avg_payment(employee_id)
        if payment_amount > avg * 3:
            return "OUTLIER"
        return "LARGE"
```

---

#### Workflow Separation
```json
{
  "workflow_separation": "SAME_EMPLOYEE_ALL_STEPS"
}
```

**Possible Values:**
- `"PROPER"` - Different employees for critical actions
- `"SAME_EMPLOYEE_ALL_STEPS"` - One person did everything (HIGH RISK)
- `"SAME_APPROVER_RELEASER"` - Approved and released by same person (MEDIUM RISK)

**How to Calculate:**
```python
def calculate_workflow_separation(session_actions, current_action):
    critical_actions = ['APPROVE_CLAIM', 'UPDATE_PAYEE_BANK', 'RELEASE_PAYMENT']
    
    critical_employees = set()
    for action in session_actions + [current_action]:
        if action['action_type'] in critical_actions:
            critical_employees.add(action['employee_id'])
    
    if len(critical_employees) == 1:
        return "SAME_EMPLOYEE_ALL_STEPS"
    elif len(critical_employees) == 2:
        # Check specific combinations
        approver = next(a['employee_id'] for a in session_actions 
                       if a['action_type'] == 'APPROVE_CLAIM')
        releaser = current_action['employee_id']
        if approver == releaser:
            return "SAME_APPROVER_RELEASER"
    
    return "PROPER"
```

---

#### Time Window
```json
{
  "time_window_mins": 15
}
```

**How to Calculate:**
```python
def calculate_time_window(session_actions, current_action):
    timestamps = [action['timestamp'] for action in session_actions]
    timestamps.append(current_action['timestamp'])
    
    earliest = min(timestamps)
    latest = max(timestamps)
    
    delta = (latest - earliest).total_seconds() / 60
    return int(delta)
```

---

#### Transaction Reference
```json
{
  "transaction_reference": "REF-TXN-001"
}
```

**Purpose:** A human-readable, non-sequential reference for your internal tracking. Don't use sequential IDs that expose transaction volume.

**How to Generate:**
```python
def generate_transaction_reference(transaction_id):
    # Option 1: Random string
    return f"REF-{uuid.uuid4().hex[:8].upper()}"
    
    # Option 2: Hash-based
    hash_val = hashlib.sha256(transaction_id.encode()).hexdigest()[:12]
    return f"REF-{hash_val.upper()}"
```

---

### Optional Fields (Enhanced Detection)

#### Historical Usage (For Account Reuse Detection)
```json
{
  "historical_usage": {
    "employee_account_pairs": [
      {
        "employee_id": "EMP004",
        "bank_account_hash": "acct_hash_abc123",
        "previous_transaction_count": 3,
        "first_used_date": "2025-12-01T00:00:00Z",
        "last_used_date": "2026-01-15T00:00:00Z",
        "total_amount": 15000.00
      }
    ]
  }
}
```

**When to Include:**
- If you want graph entity agent to detect account reuse patterns
- If the same employee has used this account before

**How to Calculate:**
```python
def get_historical_usage(employee_id, bank_account_hash, historical_db):
    query = """
        SELECT employee_id,
               bank_account_hash,
               COUNT(*) as previous_transaction_count,
               MIN(transaction_date) as first_used_date,
               MAX(transaction_date) as last_used_date,
               SUM(payment_amount) as total_amount
        FROM transactions
        WHERE employee_id = %s 
          AND bank_account_hash = %s
          AND transaction_date < NOW()
          AND status = 'COMPLETED'
        GROUP BY employee_id, bank_account_hash
    """
    return historical_db.query(query, [employee_id, bank_account_hash])
```

---

#### Additional Context Fields
```json
{
  "recipient_name": "ABC Consulting LLC",     // For LLM context (OK to include)
  "recipient_country": "US",                  // Geographic risk assessment
  "vendor_relationship_months": 12,           // How long you've worked with vendor
  "payment_description": "Services rendered", // LLM can read for context
  "invoice_details": "Project XYZ milestone", // Additional LLM context
  "is_weekend": false,                        // Temporal pattern
  "is_after_hours": false,                    // Temporal pattern
  "is_automated_process": false,              // System vs human
  "notes": "Additional context for review"    // Free-form notes for LLM
}
```

---

## 💻 Enrichment Layer Examples

### Example 1: Python Enrichment Service

```python
# enrichment_service.py

from datetime import datetime, timedelta
import hashlib
import requests
from typing import Dict, List, Any

class FraudDetectionEnrichmentLayer:
    """
    Customer-side enrichment layer for fraud detection API integration.
    """
    
    def __init__(self, database_connection, api_base_url, api_key):
        self.db = database_connection
        self.api_url = api_base_url
        self.api_key = api_key
    
    def enrich_and_analyze_transaction(
        self, 
        transaction_id: str,
        claim_id: str,
        payment_id: str,
        employee_id: str,
        bank_account_number: str,
        payment_amount: float
    ) -> Dict[str, Any]:
        """
        Main entry point: Enrich transaction data and call fraud API.
        """
        
        # Step 1: Query your historical data
        session_actions = self._get_session_actions(claim_id)
        historical_usage = self._get_historical_usage(employee_id, bank_account_number)
        
        # Step 2: Calculate compliance-safe fields
        compliance_fields = self._calculate_compliance_fields(
            employee_id=employee_id,
            session_actions=session_actions,
            bank_account_number=bank_account_number,
            payment_amount=payment_amount,
            historical_usage=historical_usage
        )
        
        # Step 3: Build API payload (no PII)
        payload = self._build_api_payload(
            transaction_id=transaction_id,
            claim_id=claim_id,
            payment_id=payment_id,
            employee_id=employee_id,
            bank_account_number=bank_account_number,
            payment_amount=payment_amount,
            session_actions=session_actions,
            compliance_fields=compliance_fields,
            historical_usage=historical_usage
        )
        
        # Step 4: Call fraud detection API
        decision = self._call_fraud_api(payload)
        
        # Step 5: Log decision in your system
        self._log_decision(transaction_id, decision)
        
        return decision
    
    def _get_session_actions(self, claim_id: str) -> List[Dict]:
        """Query your database for all actions in this claim workflow."""
        query = """
            SELECT action_type, employee_id, timestamp, claim_id
            FROM claim_actions
            WHERE claim_id = %s
              AND action_type IN ('APPROVE_CLAIM', 'UPDATE_PAYEE_BANK')
            ORDER BY timestamp ASC
        """
        return self.db.query(query, [claim_id])
    
    def _get_historical_usage(self, employee_id: str, bank_account: str) -> Dict:
        """Query historical usage of this account by this employee."""
        bank_hash = self._hash_account(bank_account)
        
        query = """
            SELECT 
                COUNT(*) as previous_transaction_count,
                MIN(transaction_date) as first_used_date,
                MAX(transaction_date) as last_used_date,
                SUM(payment_amount) as total_amount
            FROM transactions
            WHERE employee_id = %s 
              AND bank_account_hash = %s
              AND transaction_date < NOW()
              AND status = 'COMPLETED'
        """
        result = self.db.query_one(query, [employee_id, bank_hash])
        
        if result['previous_transaction_count'] > 0:
            return {
                "employee_account_pairs": [{
                    "employee_id": employee_id,
                    "bank_account_hash": bank_hash,
                    "previous_transaction_count": result['previous_transaction_count'],
                    "first_used_date": result['first_used_date'].isoformat(),
                    "last_used_date": result['last_used_date'].isoformat(),
                    "total_amount": float(result['total_amount'])
                }]
            }
        return None
    
    def _calculate_compliance_fields(
        self,
        employee_id: str,
        session_actions: List[Dict],
        bank_account_number: str,
        payment_amount: float,
        historical_usage: Dict
    ) -> Dict[str, Any]:
        """Calculate all compliance-safe derived fields."""
        
        # Employee Pattern
        employee_pattern = self._calculate_employee_pattern(session_actions, employee_id)
        
        # Account Pattern
        account_pattern = self._calculate_account_pattern(historical_usage)
        
        # Amount Category
        amount_category = self._calculate_amount_category(payment_amount, employee_id)
        
        # Workflow Separation
        workflow_separation = self._calculate_workflow_separation(session_actions, employee_id)
        
        # Time Window
        time_window_mins = self._calculate_time_window(session_actions, employee_id)
        
        # Transaction Reference
        transaction_reference = self._generate_transaction_reference()
        
        return {
            "employee_pattern": employee_pattern,
            "account_pattern": account_pattern,
            "amount_category": amount_category,
            "workflow_separation": workflow_separation,
            "time_window_mins": time_window_mins,
            "transaction_reference": transaction_reference
        }
    
    def _calculate_employee_pattern(self, session_actions: List[Dict], current_employee: str) -> str:
        """Determine if same employee or proper separation."""
        employees = {action['employee_id'] for action in session_actions}
        employees.add(current_employee)
        
        if len(employees) == 1:
            return "SINGLE_EMPLOYEE"
        elif len(employees) == len(session_actions) + 1:
            return "PROPER_SEPARATION"
        else:
            return "PARTIAL_SEPARATION"
    
    def _calculate_account_pattern(self, historical_usage: Dict) -> str:
        """Determine account usage pattern."""
        if not historical_usage or historical_usage['employee_account_pairs'][0]['previous_transaction_count'] == 0:
            return "FIRST_USE"
        
        count = historical_usage['employee_account_pairs'][0]['previous_transaction_count']
        first_used = datetime.fromisoformat(historical_usage['employee_account_pairs'][0]['first_used_date'])
        last_used = datetime.fromisoformat(historical_usage['employee_account_pairs'][0]['last_used_date'])
        days_span = (last_used - first_used).days
        
        if count < 3:
            return "REUSED_ACROSS_CLAIMS"
        elif days_span < 30:
            return "SUSPICIOUS_REUSE"
        else:
            return "ESTABLISHED"
    
    def _calculate_amount_category(self, amount: float, employee_id: str) -> str:
        """Categorize payment amount."""
        if amount < 5000:
            return "SMALL"
        elif amount < 50000:
            return "MEDIUM"
        else:
            # Check if this is an outlier for this employee
            avg_payment = self.db.query_one(
                "SELECT AVG(payment_amount) FROM transactions WHERE employee_id = %s",
                [employee_id]
            )['avg']
            
            if avg_payment and amount > avg_payment * 3:
                return "OUTLIER"
            return "LARGE"
    
    def _calculate_workflow_separation(self, session_actions: List[Dict], current_employee: str) -> str:
        """Check separation of duties in workflow."""
        critical_actions = ['APPROVE_CLAIM', 'UPDATE_PAYEE_BANK', 'RELEASE_PAYMENT']
        
        critical_employees = set()
        for action in session_actions:
            if action['action_type'] in critical_actions:
                critical_employees.add(action['employee_id'])
        critical_employees.add(current_employee)
        
        if len(critical_employees) == 1:
            return "SAME_EMPLOYEE_ALL_STEPS"
        elif len(critical_employees) == 2:
            return "SAME_APPROVER_RELEASER"
        else:
            return "PROPER"
    
    def _calculate_time_window(self, session_actions: List[Dict], current_employee: str) -> int:
        """Calculate time between first and last action."""
        if not session_actions:
            return 0
        
        timestamps = [action['timestamp'] for action in session_actions]
        timestamps.append(datetime.now())
        
        earliest = min(timestamps)
        latest = max(timestamps)
        
        delta_minutes = (latest - earliest).total_seconds() / 60
        return int(delta_minutes)
    
    def _generate_transaction_reference(self) -> str:
        """Generate non-sequential reference ID."""
        import uuid
        return f"REF-{uuid.uuid4().hex[:8].upper()}"
    
    def _hash_account(self, account_number: str) -> str:
        """Hash bank account number for privacy."""
        return hashlib.sha256(account_number.encode()).hexdigest()
    
    def _build_api_payload(
        self,
        transaction_id: str,
        claim_id: str,
        payment_id: str,
        employee_id: str,
        bank_account_number: str,
        payment_amount: float,
        session_actions: List[Dict],
        compliance_fields: Dict,
        historical_usage: Dict
    ) -> Dict[str, Any]:
        """Build the API request payload with NO PII."""
        
        payload = {
            "transaction_id": transaction_id,
            "claimant_id": f"CLMT_{claim_id}",  # Your internal ID
            "bank_account_hash": self._hash_account(bank_account_number),
            "current_action": {
                "action_type": "RELEASE_PAYMENT",
                "employee_id": employee_id,
                "timestamp": datetime.now().isoformat(),
                "claim_id": claim_id,
                "payment_id": payment_id
            },
            "session_actions": [
                {
                    "action_type": action['action_type'],
                    "employee_id": action['employee_id'],
                    "timestamp": action['timestamp'].isoformat(),
                    "claim_id": action['claim_id']
                }
                for action in session_actions
            ],
            "actor_role": self._get_employee_role(employee_id),
            "claim_status": "APPROVED",
            "payment_amount": payment_amount,
            "payment_method": "ACH",
            "payee_changed_after_approval": self._check_payee_changed(claim_id),
            "verification_flag": self._check_verification(claim_id),
            # Note: is_new_account is NO LONGER REQUIRED - derived from account_pattern
            
            # Compliance-safe fields (REQUIRED)
            "transaction_reference": compliance_fields['transaction_reference'],
            "employee_pattern": compliance_fields['employee_pattern'],
            "account_pattern": compliance_fields['account_pattern'],  # This replaces is_new_account
            "amount_category": compliance_fields['amount_category'],
            "workflow_separation": compliance_fields['workflow_separation'],
            "time_window_mins": compliance_fields['time_window_mins']
        }
        
        # Optional: Add historical usage for reuse detection
        if historical_usage:
            payload["historical_usage"] = historical_usage
        
        return payload
    
    def _call_fraud_api(self, payload: Dict) -> Dict[str, Any]:
        """Call the fraud detection API."""
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        response = requests.post(
            f"{self.api_url}/api/v1/payout/decide",
            json=payload,
            headers=headers,
            timeout=30
        )
        
        response.raise_for_status()
        return response.json()
    
    def _log_decision(self, transaction_id: str, decision: Dict):
        """Log the fraud decision in your audit trail."""
        self.db.execute("""
            INSERT INTO fraud_decisions 
            (transaction_id, final_decision, llm_reasoning, llm_confidence, created_at)
            VALUES (%s, %s, %s, %s, NOW())
        """, [
            transaction_id,
            decision['final_decision'],
            decision['llm_reasoning'],
            decision['llm_confidence']
        ])
    
    # Helper methods (implement based on your database schema)
    def _get_employee_role(self, employee_id: str) -> str:
        result = self.db.query_one("SELECT role FROM employees WHERE id = %s", [employee_id])
        return result['role'] if result else "unknown"
    
    def _check_payee_changed(self, claim_id: str) -> bool:
        result = self.db.query_one("""
            SELECT COUNT(*) as changes FROM claim_actions 
            WHERE claim_id = %s AND action_type = 'UPDATE_PAYEE_BANK'
        """, [claim_id])
        return result['changes'] > 0
    
    def _check_verification(self, claim_id: str) -> bool:
        result = self.db.query_one("""
            SELECT verification_completed FROM claims WHERE id = %s
        """, [claim_id])
        return result['verification_completed'] if result else False


# Usage Example
if __name__ == "__main__":
    # Initialize enrichment layer
    enrichment = FraudDetectionEnrichmentLayer(
        database_connection=your_database,
        api_base_url="https://fraud-api.example.com",
        api_key="your-api-key-here"
    )
    
    # When a payment is about to be released:
    decision = enrichment.enrich_and_analyze_transaction(
        transaction_id="TXN_12345",
        claim_id="CLM_67890",
        payment_id="PAY_99999",
        employee_id="EMP001",
        bank_account_number="1234567890",  # Real account (stays in your system)
        payment_amount=25000.00
    )
    
    # Take action based on decision
    if decision['final_decision'] == 'BLOCK':
        print("🚫 PAYMENT BLOCKED - Suspected fraud")
        # Stop payment, alert fraud team
    elif decision['final_decision'] == 'WARN':
        print("⚠️ PAYMENT FLAGGED - Manual review required")
        # Route to review queue
    else:
        print("✅ PAYMENT APPROVED")
        # Proceed with payment
```

---

## 📊 Sample SQL Queries

### Query 1: Get Session Actions for a Claim
```sql
-- Get all workflow actions for this claim
SELECT 
    action_type,
    employee_id,
    timestamp,
    claim_id,
    notes
FROM claim_actions
WHERE claim_id = 'CLM_12345'
  AND action_type IN ('APPROVE_CLAIM', 'UPDATE_PAYEE_BANK', 'RELEASE_PAYMENT')
ORDER BY timestamp ASC;
```

### Query 2: Check Historical Account Usage by Employee
```sql
-- Has this employee used this account before?
SELECT 
    employee_id,
    bank_account_hash,
    COUNT(*) as previous_transaction_count,
    MIN(transaction_date) as first_used_date,
    MAX(transaction_date) as last_used_date,
    SUM(payment_amount) as total_amount
FROM transactions
WHERE employee_id = 'EMP001'
  AND bank_account_hash = SHA2('1234567890', 256)
  AND transaction_date < NOW()
  AND status = 'COMPLETED'
GROUP BY employee_id, bank_account_hash;
```

### Query 3: Calculate Employee Average Payment Amount
```sql
-- Get employee's historical payment average (for outlier detection)
SELECT 
    employee_id,
    AVG(payment_amount) as avg_payment,
    STDDEV(payment_amount) as stddev_payment,
    MAX(payment_amount) as max_payment,
    COUNT(*) as total_payments
FROM transactions
WHERE employee_id = 'EMP001'
  AND transaction_date >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
  AND status = 'COMPLETED'
GROUP BY employee_id;
```

### Query 4: Detect Payee Changes After Approval
```sql
-- Was the payee bank changed after claim approval?
SELECT 
    c.id as claim_id,
    c.approval_date,
    COUNT(ca.id) as payee_changes,
    MAX(ca.timestamp) as last_change_date
FROM claims c
LEFT JOIN claim_actions ca 
    ON c.id = ca.claim_id 
    AND ca.action_type = 'UPDATE_PAYEE_BANK'
    AND ca.timestamp > c.approval_date
WHERE c.id = 'CLM_12345'
GROUP BY c.id, c.approval_date;
```

### Query 5: Check if Account is New to Your System
```sql
-- First time seeing this account across all transactions?
SELECT 
    bank_account_hash,
    MIN(transaction_date) as first_transaction,
    COUNT(DISTINCT employee_id) as unique_employees,
    COUNT(*) as total_transactions
FROM transactions
WHERE bank_account_hash = SHA2('1234567890', 256)
GROUP BY bank_account_hash;
```

---

## 🔍 Real-Time SQL Enrichment Examples

> **Key Question:** "How do customers determine if an account is 'new' in real-time?"
>
> **Answer:** They query their own transaction database (which they already have) before calling your fraud API. These queries take 10-50ms with proper indexes.

---

### Your Customer's Database Schema (Typical)

Most customers already have these tables:

```sql
-- Transactions table (customers own this)
CREATE TABLE transactions (
    transaction_id VARCHAR(50) PRIMARY KEY,
    claim_id VARCHAR(50),
    claimant_id VARCHAR(50),
    employee_id VARCHAR(50),
    bank_account_number VARCHAR(34),  -- Plain text (they hash before sending to you)
    payment_amount DECIMAL(15,2),
    action_type VARCHAR(50),          -- 'APPROVE_CLAIM', 'UPDATE_PAYEE_BANK', 'RELEASE_PAYMENT'
    status VARCHAR(20),                -- 'COMPLETED', 'PENDING', 'CANCELLED'
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    payment_method VARCHAR(20),
    verification_flag BOOLEAN
);

-- Indexes for fast lookups (CRITICAL for 10-50ms performance)
CREATE INDEX idx_bank_account ON transactions(bank_account_number, status);
CREATE INDEX idx_employee_account ON transactions(employee_id, bank_account_number, status);
CREATE INDEX idx_claim_id ON transactions(claim_id);
CREATE INDEX idx_created_at ON transactions(created_at);
```

---

### Real-Time Enrichment Query #1: Is Account New?

**Business Question:** "Has this bank account been used before?"

**SQL Query (10-15ms with index):**

```sql
-- Check if account is new (FIRST_USE) or established
SELECT 
    COUNT(*) as usage_count,
    MIN(created_at) as first_used_date,
    MAX(created_at) as last_used_date,
    SUM(payment_amount) as total_amount_paid,
    COUNT(DISTINCT employee_id) as unique_employees
FROM transactions
WHERE bank_account_number = 'ACCT_123456789'  -- Current transaction's account
  AND status IN ('COMPLETED', 'PENDING')      -- Exclude cancelled
  AND created_at < '2026-02-05 14:30:00';     -- Before current transaction

-- Result interpretation:
-- usage_count = 0    → account_pattern: "FIRST_USE" (NEW ACCOUNT)
-- usage_count = 1-3  → account_pattern: "ESTABLISHED"
-- usage_count > 3    → account_pattern: "ESTABLISHED" (well-known account)
```

**Real-World Example:**

```python
# Customer's enrichment code (runs before calling your API)
def get_account_pattern(bank_account_number, current_timestamp):
    """
    Determines if account is new by querying customer's own database.
    Performance: 10-15ms (indexed query)
    """
    query = """
        SELECT 
            COUNT(*) as usage_count,
            MIN(created_at) as first_used,
            MAX(created_at) as last_used
        FROM transactions
        WHERE bank_account_number = %s
          AND status IN ('COMPLETED', 'PENDING')
          AND created_at < %s
    """
    
    result = db.execute(query, [bank_account_number, current_timestamp])
    
    usage_count = result[0]['usage_count']
    
    # Derive account_pattern
    if usage_count == 0:
        return "FIRST_USE"  # ⬅️ NEW ACCOUNT detected!
    elif usage_count <= 3:
        return "ESTABLISHED"
    else:
        return "ESTABLISHED"
```

---

### Real-Time Enrichment Query #2: Employee-Account Reuse Pattern

**Business Question:** "Has this employee released payments to this account before?"

**SQL Query (10-15ms with index):**

```sql
-- Check for employee-account reuse pattern
SELECT 
    COUNT(*) as reuse_count,
    MIN(created_at) as first_interaction,
    MAX(created_at) as last_interaction,
    SUM(payment_amount) as total_paid_to_account,
    COUNT(DISTINCT claim_id) as distinct_claims
FROM transactions
WHERE employee_id = 'EMP004'                 -- Current employee
  AND bank_account_number = 'ACCT_123456789' -- Current account
  AND action_type = 'RELEASE_PAYMENT'        -- Only payment releases
  AND status IN ('COMPLETED', 'PENDING')
  AND created_at < '2026-02-05 14:30:00';    -- Before current transaction

-- Result interpretation:
-- reuse_count = 0    → First time this employee uses this account (NORMAL)
-- reuse_count = 1    → Second use (POTENTIAL PATTERN - flag for review)
-- reuse_count > 2    → Established relationship (NORMAL for assigned accounts)
```

**Integration Example:**

```python
def check_employee_account_reuse(employee_id, bank_account_number):
    """
    Detects if employee has used this account before.
    Performance: 10-15ms (composite index on employee_id + bank_account_number)
    """
    query = """
        SELECT 
            COUNT(*) as reuse_count,
            COUNT(DISTINCT claim_id) as distinct_claims
        FROM transactions
        WHERE employee_id = %s
          AND bank_account_number = %s
          AND action_type = 'RELEASE_PAYMENT'
          AND status IN ('COMPLETED', 'PENDING')
    """
    
    result = db.execute(query, [employee_id, bank_account_number])
    reuse_count = result[0]['reuse_count']
    
    # Build historical_usage field for API
    if reuse_count > 0:
        return {
            "employee_account_pairs": [{
                "employee_id": employee_id,
                "bank_account_hash": hash_account(bank_account_number),
                "previous_transaction_count": reuse_count,
                "distinct_claims": result[0]['distinct_claims']
            }]
        }
    else:
        return None  # No history (first use)
```

---

### Real-Time Enrichment Query #3: Session Actions (Workflow Analysis)

**Business Question:** "What actions did this employee perform on this claim?"

**SQL Query (5-10ms with index):**

```sql
-- Get all actions for this claim in this session
SELECT 
    action_type,
    employee_id,
    created_at as timestamp,
    claim_id,
    transaction_id,
    payment_id
FROM transactions
WHERE claim_id = 'CLM_A_001'
  AND created_at >= '2026-02-05 14:00:00'  -- Session window (e.g., last 4 hours)
  AND created_at <= '2026-02-05 14:30:00'  -- Current transaction time
  AND status IN ('COMPLETED', 'PENDING')
ORDER BY created_at ASC;

-- Example result:
-- | action_type         | employee_id | timestamp           | claim_id   |
-- |---------------------|-------------|---------------------|------------|
-- | APPROVE_CLAIM       | EMP001      | 2026-02-05 14:15:00 | CLM_A_001  |
-- | UPDATE_PAYEE_BANK   | EMP001      | 2026-02-05 14:20:00 | CLM_A_001  |
-- | RELEASE_PAYMENT     | EMP001      | 2026-02-05 14:30:00 | CLM_A_001  |
--
-- Insight: Same employee (EMP001) did ALL actions! ⚠️ Insider fraud pattern
```

**Code Example:**

```python
def get_session_actions(claim_id, current_timestamp, lookback_hours=4):
    """
    Retrieves all actions in the current claim session.
    Performance: 5-10ms (indexed on claim_id + created_at)
    """
    session_start = current_timestamp - timedelta(hours=lookback_hours)
    
    query = """
        SELECT 
            action_type,
            employee_id,
            created_at as timestamp,
            claim_id,
            transaction_id
        FROM transactions
        WHERE claim_id = %s
          AND created_at BETWEEN %s AND %s
          AND status IN ('COMPLETED', 'PENDING')
        ORDER BY created_at ASC
    """
    
    actions = db.execute(query, [claim_id, session_start, current_timestamp])
    
    # Separate current action from session history
    session_actions = actions[:-1]
    current_action = actions[-1]
    
    return {
        "session_actions": session_actions,
        "current_action": current_action
    }
```
