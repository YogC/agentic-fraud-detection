# Employee Control Agent - Technical Overview

## Table of Contents
1. [Agent Description](#agent-description)
2. [Logic File Details](#logic-file-details)
3. [Execution Flow](#execution-flow)
4. [Mandatory Input Fields](#mandatory-input-fields)
5. [Output Structure](#output-structure)
6. [Risk Scoring Logic](#risk-scoring-logic)
7. [Configuration Parameters](#configuration-parameters)
8. [Integration Guidelines](#integration-guidelines)

---

## Agent Description

### Purpose
The Employee Control Agent is a specialized fraud detection component that monitors **separation of duties violations** in the payment approval workflow. It detects when a single employee performs multiple critical control actions within a short time window, which is a key indicator of internal fraud risk.

### Key Capabilities
- ✅ **Real-time Detection**: Identifies control concentration patterns in milliseconds
- ✅ **Session-Based Analysis**: No historical data required, operates on current session
- ✅ **Privacy Compliant**: Uses hashed identifiers, no PII exposure
- ✅ **Explainable Decisions**: Every risk assessment includes detailed reasoning
- ✅ **Standalone Architecture**: Can operate independently or integrated with orchestration

### Use Cases
1. **Internal Fraud Prevention**: Detect employees attempting to bypass controls
2. **Compliance Monitoring**: Ensure separation of duties policies are enforced
3. **Audit Trail Generation**: Provide evidence for regulatory reviews
4. **Risk-Based Routing**: Flag high-risk transactions for manual review

---

## Logic File Details

### File Location
```
c:\Yogesh\GenAI\Fraud Detection\Fraud-Internal-Detection\app\agents\employee_control_agent.py
```

### Class Definition
```python
class EmployeeControlAgent:
    """
    Analyzes employee control concentration risk.
    
    Detects: Same employee performing >=2 of:
    - APPROVE_CLAIM
    - UPDATE_PAYEE_BANK
    - UPDATE_PAYEE_ADDRESS
    - RELEASE_PAYMENT
    
    within a short time window (configurable, default 30 min).
    """
```

### Dependencies
```python
from typing import Dict, Any, List
from datetime import datetime, timedelta
import logging
```

### Key Attributes
| Attribute | Default Value | Purpose |
|-----------|--------------|---------|
| `name` | "EmployeeControlAgent" | Agent identifier for logging |
| `concentration_threshold` | 2 | Minimum control actions to trigger risk |
| `time_window_minutes` | 30 | Time window for concentration detection |
| `control_actions` | Set of 5 actions | Monitored critical actions |

---

## Execution Flow

### Phase 1: Initialization
```
EmployeeControlAgent.__init__()
├── Set concentration threshold: 2 actions
├── Set time window: 30 minutes
└── Define critical control actions:
    ├── APPROVE_CLAIM
    ├── UPDATE_PAYEE_BANK
    ├── UPDATE_PAYEE_ADDRESS
    ├── UPDATE_PAYEE_PHONE
    └── RELEASE_PAYMENT
```

### Phase 2: Analysis Pipeline

```
INPUT RECEIVED
    ↓
┌──────────────────────────────────────────┐
│ 1. Parse Current Action                  │
│    - Extract employee_id                 │
│    - Extract action_type                 │
│    - Parse timestamp (ISO8601)           │
└──────────────────────────────────────────┘
    ↓
┌──────────────────────────────────────────┐
│ 2. Validate Current Action               │
│    - Is it a control action?             │
│    - If YES → Add to analysis queue      │
└──────────────────────────────────────────┘
    ↓
┌──────────────────────────────────────────┐
│ 3. Scan Session History                  │
│    FOR EACH action in session_actions:   │
│      ✓ Match employee_id?                │
│      ✓ Is control action?                │
│      ✓ Within 30-min window?             │
│      → Add to analysis queue             │
└──────────────────────────────────────────┘
    ↓
┌──────────────────────────────────────────┐
│ 4. De-duplicate Actions                  │
│    - Remove duplicate action types       │
│    - Count unique control actions        │
│    - Track timestamps for each           │
└──────────────────────────────────────────┘
    ↓
┌──────────────────────────────────────────┐
│ 5. Calculate Concentration Metrics       │
│    - Time span (earliest to latest)      │
│    - Total unique control actions        │
│    - Action frequency rate               │
└──────────────────────────────────────────┘
    ↓
┌──────────────────────────────────────────┐
│ 6. Risk Determination                    │
│    IF control_count >= 3:                │
│        risk = HIGH (Critical SoD breach) │
│    ELIF control_count == 2:              │
│        risk = MED (Review required)      │
│    ELSE:                                 │
│        risk = LOW (Normal operations)    │
└──────────────────────────────────────────┘
    ↓
┌──────────────────────────────────────────┐
│ 7. Generate Detailed Response            │
│    - Risk level classification           │
│    - Human-readable reasons              │
│    - Supporting metrics                  │
│    - Evidence for audit                  │
└──────────────────────────────────────────┘
    ↓
OUTPUT RETURNED
```

### Phase 3: Performance Characteristics

| Metric | Typical Value |
|--------|--------------|
| **Execution Time** | < 5ms |
| **Memory Usage** | < 1MB |
| **CPU Usage** | Minimal (no ML) |
| **Scalability** | O(n) where n = session_actions |

---

## Mandatory Input Fields

### Complete Input Structure

```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07T14:45:30Z",
    "claim_id": "CLM-123456",
    "payment_id": "PAY-789012"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:30:00Z",
      "claim_id": "CLM-123456"
    },
    {
      "action_type": "UPDATE_PAYEE_BANK",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:38:15Z",
      "claim_id": "CLM-123456"
    }
  ],
  "actor_role": "Claims Adjuster"
}
```

### Field Specifications

#### 1. `current_action` (MANDATORY OBJECT)

| Field | Type | Required | Format | Validation |
|-------|------|----------|--------|------------|
| **action_type** | string | ✅ YES | Uppercase enum | Must be valid control action |
| **employee_id** | string | ✅ YES | Alphanumeric | Non-empty string |
| **timestamp** | string | ✅ YES | ISO8601 | Valid datetime format |
| **claim_id** | string | ✅ YES | Alphanumeric | Non-empty string |
| **payment_id** | string | ⚠️ OPTIONAL | Alphanumeric | Can be null |

**Valid `action_type` Values:**
- `APPROVE_CLAIM`
- `UPDATE_PAYEE_BANK`
- `UPDATE_PAYEE_ADDRESS`
- `UPDATE_PAYEE_PHONE`
- `RELEASE_PAYMENT`

#### 2. `session_actions` (MANDATORY ARRAY)

Array of previous actions in current session. Can be empty `[]`.

Each item must have:
- `action_type` (string, required)
- `employee_id` (string, required)
- `timestamp` (string ISO8601, required)
- `claim_id` (string, required)

#### 3. `actor_role` (OPTIONAL STRING)

Defaults to `"unknown"` if not provided.

Examples: "Claims Adjuster", "Payment Processor", "Supervisor"

---

## Output Structure

### Success Response

```json
{
  "control_risk": "HIGH",
  "reasons": [
    "Employee performed 3 control actions within 20.0 minutes: APPROVE_CLAIM, UPDATE_PAYEE_BANK, RELEASE_PAYMENT",
    "High concentration risk: Same employee has end-to-end control"
  ],
  "metrics": {
    "control_action_count": 3,
    "time_window_minutes": 20.0,
    "actions_detected": [
      "APPROVE_CLAIM",
      "UPDATE_PAYEE_BANK",
      "RELEASE_PAYMENT"
    ],
    "employee_id": "EMP-5678",
    "actor_role": "Claims Adjuster"
  }
}
```

### Field Descriptions

| Field | Type | Values | Description |
|-------|------|--------|-------------|
| **control_risk** | string | LOW, MED, HIGH | Risk classification |
| **reasons** | array[string] | Human-readable | Explanation of risk determination |
| **metrics.control_action_count** | integer | 0-5 | Number of unique control actions |
| **metrics.time_window_minutes** | float | 0-30 | Time span of detected actions |
| **metrics.actions_detected** | array[string] | Action types | List of control actions found |
| **metrics.employee_id** | string | ID | Employee being analyzed |
| **metrics.actor_role** | string | Role name | Job title or function |

---

## Risk Scoring Logic

### Risk Level Determination

```python
if control_count >= 3:
    risk = "HIGH"      # Critical separation of duties violation
    score = 10
elif control_count == 2:
    risk = "MED"       # Moderate risk, requires review
    score = 5
else:
    risk = "LOW"       # Normal operations
    score = 0
```

### Risk Level Matrix

| Control Actions | Risk Level | Score | Decision Impact |
|----------------|------------|-------|-----------------|
| **3+** | HIGH | 10 | ⛔ Block transaction, immediate review |
| **2** | MED | 5 | ⚠️ Flag for manual review |
| **0-1** | LOW | 0 | ✅ Normal processing |

### Time Window Calculation

```python
time_span = (latest_timestamp - earliest_timestamp).total_seconds() / 60
```

Only actions within the configured time window (default 30 minutes) are counted.

---

## Configuration Parameters

### Adjustable Settings

```python
class EmployeeControlAgent:
    def __init__(self, name: str = "EmployeeControlAgent"):
        self.concentration_threshold = 2       # Minimum actions for risk
        self.time_window_minutes = 30          # Detection time window
        self.control_actions = {               # Monitored actions
            'APPROVE_CLAIM',
            'UPDATE_PAYEE_BANK',
            'UPDATE_PAYEE_ADDRESS',
            'UPDATE_PAYEE_PHONE',
            'RELEASE_PAYMENT'
        }
```

### Recommended Configuration by Use Case

| Environment | Threshold | Time Window | Rationale |
|-------------|-----------|-------------|-----------|
| **High Security** | 2 actions | 60 minutes | Strictest separation of duties |
| **Standard Operations** | 2 actions | 30 minutes | Balanced fraud detection |
| **High Volume Processing** | 3 actions | 15 minutes | Reduce false positives |
| **Testing/Dev** | 2 actions | 120 minutes | Easier testing scenarios |

---

## Integration Guidelines

### API Endpoint Integration

```python
from agents.employee_control_agent import EmployeeControlAgent

# Initialize agent
employee_agent = EmployeeControlAgent()

# Execute analysis
result = await employee_agent.execute(input_data)

# Check risk level
if result['control_risk'] == 'HIGH':
    # Block transaction
    block_payment()
elif result['control_risk'] == 'MED':
    # Route to manual review
    queue_for_review()
else:
    # Continue normal processing
    approve_payment()
```

### Orchestration Layer Integration

The agent is integrated in `payout_orchestrator.py`:

```python
# Prepare input
employee_control_input = {
    'current_action': input_data.get('current_action', {}),
    'session_actions': input_data.get('session_actions', []),
    'actor_role': input_data.get('actor_role', 'unknown')
}

# Execute agent
start_time = time.time()
employee_result = await self.employee_control_agent.execute(employee_control_input)
execution_time = time.time() - start_time

# Log to audit trail
audit_logger.log_agent_analysis(
    agent_name="EmployeeControlAgent",
    claim_id=claim_id,
    risk_level=employee_result.get('control_risk', 'LOW'),
    score=risk_score_map[employee_result.get('control_risk', 'LOW')],
    reasons=employee_result.get('reasons', []),
    evidence=employee_result.get('metrics', {}),
    execution_time_ms=execution_time * 1000
)
```

---

## Error Handling

### Exception Management

```python
try:
    # Execute analysis logic
except Exception as e:
    logger.error(f"Error in control concentration analysis: {e}")
    return {
        'control_risk': 'LOW',  # Fail-safe default
        'reasons': [f"Error in analysis: {str(e)}"],
        'metrics': {}
    }
```

### Fail-Safe Behavior
- Agent failures default to `LOW` risk (fail-open)
- Errors logged to audit trail
- System remains operational
- Other agents continue analysis

---

## Best Practices

### Do's ✅
- Always provide ISO8601 timestamps
- Include all session actions for accurate analysis
- Use consistent employee_id format
- Monitor agent performance metrics
- Review HIGH risk transactions immediately

### Don'ts ❌
- Don't skip timestamp validation
- Don't modify time window without testing
- Don't ignore MED risk warnings
- Don't send PII in employee_id (use hashed IDs)
- Don't disable agent without approval

---

## Support & Troubleshooting

### Common Issues

**Issue**: False positives in high-volume environments
**Solution**: Increase `concentration_threshold` to 3 or reduce `time_window_minutes` to 15

**Issue**: Agent always returns LOW risk
**Solution**: Verify `action_type` values match exact case (UPPERCASE)

**Issue**: Timestamp parsing errors
**Solution**: Ensure timestamps are valid ISO8601 format with timezone

### Contact
For technical support or questions:
- Review logs in `logs/audit/` directory
- Check `TROUBLESHOOTING.md` in this folder
- Consult API documentation

---

**Document Version**: 1.0  
**Last Updated**: February 7, 2026  
**Author**: Fraud Detection System Team
