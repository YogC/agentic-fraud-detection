# Employee Control Agent - Rule-Based Logic Documentation

## Overview
This document explains the **rule-based scoring system** used by the Employee Control Agent to detect separation of duties violations in payment workflows.

---

## Table of Contents
1. [Rule Definition](#rule-definition)
2. [Score Calculation Method](#score-calculation-method)
3. [Percentage Derivation](#percentage-derivation)
4. [Decision Tree Logic](#decision-tree-logic)
5. [Practical Examples](#practical-examples)

---

## Rule Definition

### What is Rule-Based Agent Logic?

**Rule-based agent logic** is a deterministic fraud detection approach that uses **predefined conditional rules** to evaluate transactions and assign risk scores.

### Characteristics:
- ✅ **Deterministic**: Same input always produces same output
- ✅ **Transparent**: Every decision can be traced to specific rules
- ✅ **Fast**: No machine learning inference overhead
- ✅ **Compliant**: Explainable to regulators and auditors
- ✅ **Maintainable**: Rules can be updated independently

---

## Score Calculation Method

### Control Action Monitoring

The agent monitors these **5 critical control actions**:

| Action | Description | Risk Impact |
|--------|-------------|-------------|
| `APPROVE_CLAIM` | Approve claim for payment | High - authorizes payout |
| `UPDATE_PAYEE_BANK` | Modify bank account details | Critical - changes destination |
| `UPDATE_PAYEE_ADDRESS` | Change payee address | Medium - alters contact info |
| `UPDATE_PAYEE_PHONE` | Update phone number | Low - communication channel |
| `RELEASE_PAYMENT` | Authorize payment release | High - final control point |

### Concentration Detection Algorithm

```python
# Step 1: Initialize
control_actions_found = []
time_window = 30 minutes  # Configurable

# Step 2: Check current action
if current_action.type in control_actions:
    control_actions_found.append(current_action)

# Step 3: Scan session history
for action in session_actions:
    if action.employee_id == current_action.employee_id:
        if action.type in control_actions:
            time_delta = abs(current_time - action.timestamp)
            if time_delta <= time_window:
                control_actions_found.append(action)

# Step 4: Remove duplicates
unique_actions = set([a.type for a in control_actions_found])
control_count = len(unique_actions)

# Step 5: Calculate time span
if len(control_actions_found) > 1:
    time_span = max(timestamps) - min(timestamps)
```

### Scoring Rules

#### Rule 1: HIGH Risk (Score = 10)
```
IF control_count >= 3 THEN
    risk_level = HIGH
    score = 10
    reason = "Same employee has end-to-end control"
END IF
```

**Justification**: Employee can approve, modify, and release payment without oversight—critical fraud indicator.

#### Rule 2: MEDIUM Risk (Score = 5)
```
IF control_count == 2 THEN
    risk_level = MED
    score = 5
    reason = "Lack of separation of duties"
END IF
```

**Justification**: Employee controls two critical steps—violates dual-control principle.

#### Rule 3: LOW Risk (Score = 0)
```
IF control_count <= 1 THEN
    risk_level = LOW
    score = 0
    reason = "Normal separation of duties maintained"
END IF
```

**Justification**: Normal operations—different employees handle different steps.

---

## Percentage Derivation

### Method 1: Linear Normalization

Convert score (0-10) to percentage (0-100%):

```python
max_score = 10
risk_percentage = (score / max_score) * 100

# Examples:
# score = 0  → 0% risk
# score = 5  → 50% risk
# score = 10 → 100% risk
```

### Method 2: Non-Linear Mapping (Recommended)

Account for exponential risk increase:

```python
score_to_percentage = {
    0: 0,     # 0% - Clean
    5: 60,    # 60% - Medium concern (not 50%)
    10: 100   # 100% - Critical
}
```

**Rationale**: The jump from 1 to 2 control actions is more significant than 0 to 1.

### Risk Percentage Interpretation

| Score | Percentage | Risk Level | Business Impact |
|-------|------------|------------|-----------------|
| **0** | 0% | LOW | ✅ Normal processing |
| **5** | 50-60% | MED | ⚠️ Manual review required |
| **10** | 100% | HIGH | ⛔ Block transaction immediately |

---

## Decision Tree Logic

### Complete Decision Flow

```
START: Employee Action Received
    ↓
┌─────────────────────────────────────────────────┐
│ Is action_type a CONTROL ACTION?               │
│ (APPROVE, UPDATE_BANK, UPDATE_ADDRESS,         │
│  UPDATE_PHONE, RELEASE_PAYMENT)                │
└─────────────────────────────────────────────────┘
    │
    ├─[NO]──→ Skip (non-control action)
    │
    └─[YES]
        ↓
    ┌─────────────────────────────────────────────┐
    │ Count UNIQUE control actions by same        │
    │ employee within 30-minute window            │
    └─────────────────────────────────────────────┘
        ↓
    ┌─────────────────────────────────────────────┐
    │ How many unique control actions?            │
    └─────────────────────────────────────────────┘
        │
        ├─[count >= 3]
        │    ↓
        │  ┌──────────────────────────────────────┐
        │  │ RISK = HIGH                          │
        │  │ SCORE = 10                           │
        │  │ PERCENTAGE = 100%                    │
        │  │ ACTION = BLOCK TRANSACTION           │
        │  │ REASON: "End-to-end control by      │
        │  │          single employee"            │
        │  └──────────────────────────────────────┘
        │
        ├─[count == 2]
        │    ↓
        │  ┌──────────────────────────────────────┐
        │  │ RISK = MED                           │
        │  │ SCORE = 5                            │
        │  │ PERCENTAGE = 50-60%                  │
        │  │ ACTION = MANUAL REVIEW               │
        │  │ REASON: "Lack of separation of      │
        │  │          duties"                     │
        │  └──────────────────────────────────────┘
        │
        └─[count <= 1]
             ↓
           ┌──────────────────────────────────────┐
           │ RISK = LOW                           │
           │ SCORE = 0                            │
           │ PERCENTAGE = 0%                      │
           │ ACTION = ALLOW                       │
           │ REASON: "Normal separation of       │
           │          duties"                     │
           └──────────────────────────────────────┘
                ↓
              END
```

---

## Practical Examples

### Example 1: SAFE Transaction (Score = 0)

**Scenario**: Multiple employees handle different steps (proper separation)

```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-9999",
    "timestamp": "2026-02-07T14:45:00Z",
    "claim_id": "CLM-123456"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-1111",  ← Different employee
      "timestamp": "2026-02-07T14:30:00Z",
      "claim_id": "CLM-123456"
    },
    {
      "action_type": "UPDATE_PAYEE_BANK",
      "employee_id": "EMP-2222",  ← Different employee
      "timestamp": "2026-02-07T14:35:00Z",
      "claim_id": "CLM-123456"
    }
  ]
}
```

**Analysis**:
- Employee EMP-9999 only performed 1 control action (RELEASE_PAYMENT)
- Other actions done by different employees
- **Control Count**: 1
- **Time Span**: N/A

**Result**:
```json
{
  "control_risk": "LOW",
  "score": 0,
  "percentage": 0,
  "reasons": ["Normal separation of duties maintained"],
  "metrics": {
    "control_action_count": 1,
    "time_window_minutes": 0,
    "actions_detected": ["RELEASE_PAYMENT"]
  }
}
```

**Business Decision**: ✅ **ALLOW** - Continue normal processing

---

### Example 2: SUSPICIOUS Activity (Score = 5)

**Scenario**: Same employee performs 2 control actions

```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07T14:45:00Z",
    "claim_id": "CLM-123456"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-5678",  ← Same employee!
      "timestamp": "2026-02-07T14:30:00Z",
      "claim_id": "CLM-123456"
    },
    {
      "action_type": "UPDATE_PAYEE_BANK",
      "employee_id": "EMP-7777",  ← Different employee
      "timestamp": "2026-02-07T14:35:00Z",
      "claim_id": "CLM-123456"
    }
  ]
}
```

**Analysis**:
- Employee EMP-5678 performed **2 control actions**:
  1. APPROVE_CLAIM (14:30)
  2. RELEASE_PAYMENT (14:45)
- **Control Count**: 2
- **Time Span**: 15.0 minutes

**Result**:
```json
{
  "control_risk": "MED",
  "score": 5,
  "percentage": 60,
  "reasons": [
    "Employee performed 2 control actions within 15.0 minutes: APPROVE_CLAIM, RELEASE_PAYMENT",
    "Medium risk: Lack of separation of duties"
  ],
  "metrics": {
    "control_action_count": 2,
    "time_window_minutes": 15.0,
    "actions_detected": ["APPROVE_CLAIM", "RELEASE_PAYMENT"]
  }
}
```

**Business Decision**: ⚠️ **WARN** - Route to manual review queue

---

### Example 3: FRAUDULENT Pattern (Score = 10)

**Scenario**: Same employee controls entire workflow

```json
{
  "current_action": {
    "action_type": "RELEASE_PAYMENT",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07T14:50:00Z",
    "claim_id": "CLM-123456"
  },
  "session_actions": [
    {
      "action_type": "APPROVE_CLAIM",
      "employee_id": "EMP-5678",  ← Same employee
      "timestamp": "2026-02-07T14:30:00Z",
      "claim_id": "CLM-123456"
    },
    {
      "action_type": "UPDATE_PAYEE_BANK",
      "employee_id": "EMP-5678",  ← Same employee
      "timestamp": "2026-02-07T14:40:00Z",
      "claim_id": "CLM-123456"
    }
  ]
}
```

**Analysis**:
- Employee EMP-5678 performed **3 control actions**:
  1. APPROVE_CLAIM (14:30)
  2. UPDATE_PAYEE_BANK (14:40)
  3. RELEASE_PAYMENT (14:50)
- **Control Count**: 3
- **Time Span**: 20.0 minutes
- **Critical**: Employee approved, changed bank account, AND released payment

**Result**:
```json
{
  "control_risk": "HIGH",
  "score": 10,
  "percentage": 100,
  "reasons": [
    "Employee performed 3 control actions within 20.0 minutes: APPROVE_CLAIM, UPDATE_PAYEE_BANK, RELEASE_PAYMENT",
    "High concentration risk: Same employee has end-to-end control"
  ],
  "metrics": {
    "control_action_count": 3,
    "time_window_minutes": 20.0,
    "actions_detected": [
      "APPROVE_CLAIM",
      "UPDATE_PAYEE_BANK",
      "RELEASE_PAYMENT"
    ]
  }
}
```

**Business Decision**: ⛔ **BLOCK** - Stop transaction immediately, alert fraud team

**Fraud Indicators**:
- 🚨 Same employee controlled approval, modification, and release
- 🚨 Bank account changed during workflow
- 🚨 No oversight or second approval
- 🚨 Classic internal fraud pattern

---

### Example 4: Edge Case - Duplicate Actions

**Scenario**: Employee performs same action multiple times

```json
{
  "current_action": {
    "action_type": "UPDATE_PAYEE_ADDRESS",
    "employee_id": "EMP-5678",
    "timestamp": "2026-02-07T14:50:00Z",
    "claim_id": "CLM-123456"
  },
  "session_actions": [
    {
      "action_type": "UPDATE_PAYEE_ADDRESS",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:30:00Z",
      "claim_id": "CLM-123456"
    },
    {
      "action_type": "UPDATE_PAYEE_ADDRESS",
      "employee_id": "EMP-5678",
      "timestamp": "2026-02-07T14:40:00Z",
      "claim_id": "CLM-123456"
    }
  ]
}
```

**Analysis**:
- Employee performed UPDATE_PAYEE_ADDRESS **3 times**
- After de-duplication: **1 unique control action type**
- **Control Count**: 1
- **Time Span**: 20.0 minutes

**Result**:
```json
{
  "control_risk": "LOW",
  "score": 0,
  "percentage": 0,
  "reasons": ["Normal separation of duties maintained"],
  "metrics": {
    "control_action_count": 1,
    "time_window_minutes": 20.0,
    "actions_detected": ["UPDATE_PAYEE_ADDRESS"]
  }
}
```

**Business Decision**: ✅ **ALLOW** - Multiple corrections to same field is normal

---

## Summary

### Scoring Formula

```
score = f(control_action_count)

where:
  f(0) = 0   → LOW risk
  f(1) = 0   → LOW risk
  f(2) = 5   → MED risk
  f(n≥3) = 10 → HIGH risk
```

### Key Takeaways

1. **Unique Actions Count**: Only unique action types count (duplicates ignored)
2. **Time Window**: Only actions within 30 minutes are considered
3. **Employee Matching**: Only actions by the same employee are analyzed
4. **Deterministic**: Same inputs always produce same outputs
5. **Explainable**: Every decision includes detailed reasoning

### Business Impact

| Risk Level | Score | Percentage | Transactions/Day | Manual Review % |
|------------|-------|------------|------------------|-----------------|
| LOW | 0 | 0% | ~95% | 0% |
| MED | 5 | 60% | ~4% | 100% |
| HIGH | 10 | 100% | ~1% | 100% + Investigation |

---

**Document Version**: 1.0  
**Last Updated**: February 7, 2026  
**Author**: Fraud Detection System Team
